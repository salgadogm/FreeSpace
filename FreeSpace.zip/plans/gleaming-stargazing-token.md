# Plan: Migrasi FreeSpace Navigation

## Context
Aplikasi saat ini adalah "Aset SV IPB – Manajemen Aset". Berdasarkan dokumen markdown yang diunggah pengguna, aplikasi akan dimigrasi identitas dan navigasinya menjadi "FreeSpace – Personal Workspace". Ini adalah migrasi navigasi dan branding — **bukan redesign visual**. Seluruh gaya visual (warna, tipografi, spacing, shadow, border-radius, topbar, profile card) dipertahankan persis.

Semua perubahan terkonsentrasi di `src/app/App.tsx` (sidebar + routing) dan satu file komponen baru sebagai placeholder halaman.

---

## Scope Perubahan

### 1. Brand Area (App.tsx)
- `"Aset SV IPB"` → `"FreeSpace"`
- `"Manajemen Aset"` → `"Personal Workspace"`
- Logo: pertahankan container circular yang ada, ganti ikon placeholder menjadi `Sparkles` atau letter "F" neutral
- Profile user card: **tidak diubah sama sekali**

### 2. State Accordion (App.tsx)
Hapus state lama:
```ts
dashboardOpen, dataAsetOpen, lokasiOpen, settingsOpen, helpOpen
```
Ganti dengan single-open accordion pattern:
```ts
const [openMenu, setOpenMenu] = useState<string | null>(null);
const toggleMenu = (menu: string) => setOpenMenu(prev => prev === menu ? null : menu);
```
Dan navigasi yang otomatis membuka parent:
```ts
const navigate = (pageId: string, parent?: string) => {
  setPage(pageId);
  if (parent) setOpenMenu(parent);
};
```

### 3. Sidebar Menu Structure (App.tsx)
Ganti seluruh isi section MASTER DATA, TRANSAKSI, DOKUMENTASI dengan dua section baru:

**Section Label: MENU UTAMA**
```
Dashboard         (LayoutDashboard)  → page="dashboard"   [no chevron, no submenu]
Keuangan          (Wallet)           → expandable
  Transaksi       (ArrowLeftRight)   → page="transaksi"
  Budget          (PieChart)         → page="budget"
  Analisis & Proyeksi (TrendingUp)   → page="analisis"
  Kondisi Keuangan (Scale)           → page="kondisi-keuangan"
  Investasi       (TrendingUp)       → page="investasi"
  Akuntansi       (Calculator)       → page="akuntansi"
  SPT Orang Pribadi (FileText)       → page="spt"
Produktivitas     (CheckCircle2)     → expandable
  Aktivitas       (CalendarDays)     → page="produktivitas-aktivitas"
  Jurnal Harian   (PenSquare)        → page="jurnal"
  Bible Harian    (BookOpen)         → page="bible"
  Steps Tracker   (MapPin)           → page="steps"
Library           (BookOpen)         → expandable
  Koleksi Buku    (Layers)           → page="koleksi"
  Baca Buku       (Eye)              → page="baca-buku"
  Accounting Space (GraduationCap)   → page="accounting-space"
Karier            (Briefcase)        → expandable
  CV Builder      (FilePlus)         → page="cv-builder"
  ATS Analyzer    (FileSearch)       → page="ats"
  TOEFL Training  (Languages)        → page="toefl"
  Interview Simulator (MessageSquare) → page="interview"
```

**Section Label: SISTEM**
```
History           (Clock)    → page="history"  [no chevron, no submenu]
Profil & Pengaturan (Settings) → expandable
  Profil          (User)      → page="profil"
  Preferensi      (SlidersHorizontal) → page="preferensi"
  Pengaturan Data (Database)  → page="pengaturan-data"
  Pengaturan Notifikasi (BellRing) → page="notifikasi-setting"
  Keamanan & Data (Shield)    → page="keamanan"
```

**Default state:** `page="dashboard"`, `openMenu=null` (semua collapsed)

### 4. Topbar Breadcrumb Logic (App.tsx)
Update `pageMetaMap` / breadcrumb resolver agar mengenali page ID baru:
```ts
const breadcrumb = {
  "dashboard": ["Dashboard"],
  "transaksi": ["Keuangan", "Transaksi"],
  "budget":    ["Keuangan", "Budget"],
  "analisis":  ["Keuangan", "Analisis & Proyeksi"],
  "kondisi-keuangan": ["Keuangan", "Kondisi Keuangan"],
  "investasi": ["Keuangan", "Investasi"],
  "akuntansi": ["Keuangan", "Akuntansi"],
  "spt":       ["Keuangan", "SPT Orang Pribadi"],
  "produktivitas-aktivitas": ["Produktivitas", "Aktivitas"],
  "jurnal":    ["Produktivitas", "Jurnal Harian"],
  "bible":     ["Produktivitas", "Bible Harian"],
  "steps":     ["Produktivitas", "Steps Tracker"],
  "koleksi":   ["Library", "Koleksi Buku"],
  "baca-buku": ["Library", "Baca Buku"],
  "accounting-space": ["Library", "Accounting Space"],
  "cv-builder":["Karier", "CV Builder"],
  "ats":       ["Karier", "ATS Analyzer"],
  "toefl":     ["Karier", "TOEFL Training"],
  "interview": ["Karier", "Interview Simulator"],
  "history":   ["History"],
  "profil":    ["Profil & Pengaturan", "Profil"],
  "preferensi":["Profil & Pengaturan", "Preferensi"],
  "pengaturan-data": ["Profil & Pengaturan", "Pengaturan Data"],
  "notifikasi-setting": ["Profil & Pengaturan", "Pengaturan Notifikasi"],
  "keamanan":  ["Profil & Pengaturan", "Keamanan & Data"],
}
```

### 5. Page Routing — MainContent (App.tsx)
- `"dashboard"` → page Dashboard FreeSpace (reuse EksekutifPage atau OverviewPage dengan title baru)
- `"history"` → reuse `AktivitasPage` (log riwayat aktivitas)
- `"profil"` → reuse existing profile inline page
- `"preferensi"` → reuse existing preferences page
- Semua page lainnya → render `<FreeSpacePlaceholder>` dengan judul & subtitle relevan

### 6. File Baru: `src/app/components/FreeSpacePlaceholder.tsx`
Satu komponen generic yang menerima `title`, `subtitle`, `icon`, dan `description`. Menggunakan visual style yang sama (card, warna, spacing) untuk menampilkan halaman "coming soon" yang rapi:

```tsx
export function FreeSpacePlaceholder({ title, subtitle, icon: Icon, description }) {
  return (
    <main className="flex-1 overflow-y-auto bg-gray-50">
      {/* topBar prop */}
      <div className="px-8 py-7">
        <h1>{title}</h1>
        <p>{subtitle}</p>
        <div className="card centered">
          <Icon />
          <h2>Segera Hadir</h2>
          <p>{description}</p>
        </div>
      </div>
    </main>
  );
}
```

### 7. Icon Imports Baru yang Dibutuhkan (App.tsx)
Tambahkan ke import lucide-react yang ada:
```
Wallet, PieChart, Scale, Calculator, CheckCircle2, CalendarDays,
PenSquare, BookOpen, Eye, GraduationCap, Briefcase, FilePlus,
FileSearch, Languages, Clock, SlidersHorizontal
```
Beberapa mungkin sudah ada; cek dan tambahkan yang belum.

Note: `Languages` di lucide-react mungkin tidak ada → gunakan `Globe2` atau `BookMarked` sebagai alternatif untuk TOEFL.

---

## File yang Dimodifikasi

| File | Perubahan |
|------|-----------|
| `src/app/App.tsx` | Brand, accordion state, sidebar menu, routing, breadcrumb |
| `src/app/components/FreeSpacePlaceholder.tsx` | **Baru** — generic placeholder page |

File lain (DataStore, DashboardPages, dll.) **tidak perlu diubah** — hanya tidak diroutingkan lagi dari sidebar baru.

---

## Verifikasi

1. Jalankan app → sidebar menampilkan "FreeSpace / Personal Workspace"
2. Klik "Dashboard" → aktif tanpa submenu, breadcrumb = "Dashboard"
3. Klik "Keuangan" → expand, show 7 children; klik "Produktivitas" → Keuangan collapse otomatis
4. Klik child mana pun → breadcrumb update sesuai hierarki
5. Cek topbar masih sama (search, Tanya AI, notif, share)
6. Cek profile card kiri atas tidak berubah
7. Semua menu lama (Data Aset, Stock Opname, dll.) tidak muncul
8. History → AktivitasPage tetap fungsional
9. Dashboard page masih menampilkan konten yang ada
