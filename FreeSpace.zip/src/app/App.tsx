import React, { useState, useRef } from "react";
import { AppProvider, useApp } from "./components/AppContext";
import { DataStoreProvider } from "./components/DataStore";
import type { TableDensity, AppLanguage } from "./components/AppContext";
import { MutasiPage } from "./components/MutasiPage";
import { PerbaikanPage } from "./components/PerbaikanPage";
import { PengadaanPage } from "./components/PengadaanPage";
import { StockOpnamePage } from "./components/StockOpnamePage";
import { DokumenPage } from "./components/DokumenPage";
import { PenggunaPage } from "./components/PenggunaPage";
import { AktivitasPage } from "./components/AktivitasPage";
import { OverviewPage } from "./components/OverviewPage";
import { AsetDataTable } from "./components/AsetDataTable";
import { EksekutifPage, DashSubPageFull } from "./components/DashboardPages";
import { PICPage } from "./components/PICPage";
import asistenAiLogo from "../imports/Asisten_AI_Aset_SV_IPB.png";
import {
  Database, MapPin, Users, ArrowLeftRight, Wrench, ClipboardList,
  ShoppingCart, FileText, BarChart2, ScrollText, Settings,
  ChevronDown, ChevronRight, Bell, Search, Sparkles, Filter,
  Download, Info, LayoutDashboard, Calendar, User, LogOut,
  Camera, Shield, BellRing, Smartphone, Lock, MessageSquare,
  Plus, X, Send, Bot, Clock, Layers,
  HelpCircle, Share2, ChevronsUpDown, Headset,
  Wallet, PieChart, TrendingUp, Scale, Calculator, CheckCircle2,
  CalendarDays, Edit3, BookOpen, Eye, GraduationCap, Briefcase,
  FilePlus, FileSearch, Globe2, SlidersHorizontal
} from "lucide-react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import logoImage from "../imports/ChatGPT_Image_Jul_3__2026__06_37_35_PM.png";
import aiLogo from "../imports/ChatGPT_Image_Jul_3__2026__07_44_21_PM.png";
import { FreeSpacePlaceholder } from "./components/FreeSpacePlaceholder";
import { DashboardFreeSpace } from "./components/DashboardFreeSpace";
import { TransaksiPage } from "./components/TransaksiPage";
import { BudgetPage } from "./components/BudgetPage";
import { AnalisisPage } from "./components/AnalisisPage";
import { KondisiKeuanganPage } from "./components/KondisiKeuanganPage";
import { InvestasiPage } from "./components/InvestasiPage";
import { AkuntansiPage } from "./components/AkuntansiPage";
import { SPTPage } from "./components/SPTPage";
import { ProduktivitasAktivitasPage } from "./components/ProduktivitasAktivitasPage";
import { JurnalHarianPage } from "./components/JurnalHarianPage";
import { BibleHarianPage } from "./components/BibleHarianPage";
import { StepsTrackerPage } from "./components/StepsTrackerPage";
import { HistoryPage } from "./components/HistoryPage";
import { PreferensiPage } from "./components/PreferensiPage";
import { PengaturanDataPage } from "./components/PengaturanDataPage";
import { NotifikasiSettingPage } from "./components/NotifikasiSettingPage";
import { KeamananDataPage } from "./components/KeamananDataPage";
import { CVBuilderPage } from "./components/CVBuilderPage";
import { ATSAnalyzerPage } from "./components/ATSAnalyzerPage";
import { TOEFLTrainingPage } from "./components/TOEFLTrainingPage";
import { InterviewSimulatorPage } from "./components/InterviewSimulatorPage";
import { KoleksiBukuPage } from "./components/KoleksiBukuPage";
import { BacaBukuPage } from "./components/BacaBukuPage";
import { AccountingSpacePage } from "./components/AccountingSpacePage";

// ── Palette ───────────────────────────────────────────────────────────────────
const P       = "#111827";
const P_MID   = "#9CA3AF";
const P_LIGHT = "#E5E7EB";
const P_XLIGHT= "#F3F4F6";
const P_DARK  = "#1F2937";
const ORANGE  = "#111827";
const GREEN   = "#22C55E";
const RED     = "#EF4444";
const G100    = "#F3F4F6";
const G200    = "#E5E7EB";
const G400    = "#9CA3AF";
const G800    = "#111827";
const G900    = "#1F2937";

type IC = React.ComponentType<{ size?: number; className?: string }>;

// ── Generic Avatar (dummy user silhouette) ────────────────────────────────────
function GenericAvatar({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" className={className}>
      <circle cx="50" cy="50" r="50" fill="#E5E7EB" />
      <circle cx="50" cy="37" r="18" fill="#9CA3AF" />
      <ellipse cx="50" cy="87" rx="30" ry="24" fill="#9CA3AF" />
    </svg>
  );
}

// ── Logo ──────────────────────────────────────────────────────────────────────
function Logo() {
  return (
    <ImageWithFallback 
      src={logoImage} 
      alt="FreeSpace Logo" 
      className="w-12 h-12 shrink-0 rounded-lg object-cover" 
    />
  );
}

// ── Sidebar SubItem ──────────────────────────────────────────────────────────
function SubItem({ label, id, page, onNavigate }: {
  label: string; id: string; page: string; onNavigate: (id: string) => void;
}) {
  return (
    <div
      onClick={() => onNavigate(id)}
      className={`flex items-center gap-2 px-2 py-1.5 rounded-lg cursor-pointer transition-colors ${
        page === id ? "bg-gray-100" : "hover:bg-gray-50"
      }`}
    >
      <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${
        page === id ? "bg-gray-600" : "border border-gray-400"
      }`} />
      <span className={`text-xs ${page === id ? "text-gray-800 font-medium" : "text-gray-500"}`}>
        {label}
      </span>
    </div>
  );
}

// ── Sidebar Accordion Menu ────────────────────────────────────────────────────
function MenuAccordion({ label, icon: Icon, isOpen, isChildActive, onToggle, children }: {
  label: string; icon: IC; isOpen: boolean; isChildActive: boolean;
  onToggle: () => void; children: React.ReactNode;
}) {
  return (
    <div>
      <div
        onClick={onToggle}
        className={`flex items-center gap-2.5 px-3 py-2 rounded-lg cursor-pointer transition-colors ${
          isChildActive ? "bg-gray-100" : "hover:bg-gray-50"
        }`}
      >
        <Icon size={15} className={isChildActive ? "text-gray-700" : "text-gray-400"} />
        <span className={`text-sm flex-1 ${isChildActive ? "font-semibold text-gray-800" : "text-gray-500"}`}>
          {label}
        </span>
        {isOpen
          ? <ChevronDown size={13} className="text-gray-400 shrink-0" />
          : <ChevronRight size={13} className="text-gray-400 shrink-0" />
        }
      </div>
      {isOpen && (
        <div className="ml-6 mt-0.5 mb-1 flex flex-col gap-0.5 border-l border-gray-200 pl-3">
          {children}
        </div>
      )}
    </div>
  );
}

// ── NavItem ─────────────────────────────────────────────────────────────────
function NavItem({ icon: Icon, label, active, badge, onClick }: {
  icon: IC; label: string; active?: boolean; badge?: string; onClick?: () => void;
}) {
  return (
    <div onClick={onClick} className={`flex items-center gap-2.5 px-3 py-2 rounded-lg cursor-pointer transition-colors ${
      active ? "bg-gray-100" : "hover:bg-gray-50"
    }`}>
      <Icon size={15} className={active ? "text-gray-700" : "text-gray-400"} />
      <span className={`text-sm flex-1 ${active ? "font-semibold text-gray-800" : "text-gray-500"}`}>
        {label}
      </span>
      {badge && (
        <span className="text-[9px] font-bold bg-gray-100 text-gray-700 px-1.5 py-0.5 rounded">
          {badge}
        </span>
      )}
    </div>
  );
}

// ── User Profile Menu ──────────────────────────���──────────────────────────────
function UserProfileMenu({ setPage }: { setPage: (p: string) => void }) {
  const [open, setOpen] = useState(false);
  const [isPressed, setIsPressed] = useState(false);

  return (
    <div className="relative">
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute top-full left-0 mt-2 w-full bg-white border border-gray-200 shadow-[0_4px_24px_rgba(0,0,0,0.08)] rounded-xl z-50 overflow-hidden py-1.5 animate-in fade-in zoom-in-95 duration-100">
            <div className="px-3 py-2.5 border-b border-gray-100 mb-1 bg-gray-50/50">
              <p className="text-sm font-bold text-gray-900">Salgado Ginting</p>
              <p className="text-[10px] text-gray-500 mt-0.5">Administrator • salgadoginting@apps.ipb.ac.id</p>
            </div>
            
            <button 
              onClick={() => { setPage("profile"); setOpen(false); }}
              className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-gray-50 text-left transition-colors"
            >
              <User size={14} className="text-gray-500" />
              <span className="text-xs text-gray-700 font-medium">Profil Saya</span>
            </button>
            
            <div className="my-1 border-t border-gray-100" />
            
            <button 
              onClick={() => setOpen(false)}
              className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-red-50 text-left transition-colors group"
            >
              <LogOut size={14} className="text-red-500 group-hover:text-red-600" />
              <span className="text-xs text-red-600 font-medium">Keluar</span>
            </button>
          </div>
        </>
      )}

      <div
        onMouseDown={() => setIsPressed(true)}
        onMouseUp={() => setIsPressed(false)}
        onMouseLeave={() => setIsPressed(false)}
        onClick={() => setOpen(!open)}
        className={`w-full h-[43px] flex items-center gap-[12px] pl-[3.5px] pr-[10px] rounded-[8px] cursor-pointer transition-all border border-[#EFEFEF] shadow-[0_2px_8px_rgba(0,0,0,0.04)] ${
          open ? "bg-[#F3F4F6]" : "bg-[#FAFAFA] hover:bg-[#F3F4F6]"
        }`}
      >
        <div className="w-[36px] h-[36px] bg-white rounded-full shrink-0 overflow-hidden">
          <GenericAvatar className="w-full h-full" />
        </div>
        <span className="flex-1 text-[16px] font-semibold text-[#061A33] min-w-0 truncate tracking-tight">
          salgadogin...
        </span>
        <div className="w-[25px] h-[25px] rounded-full bg-white flex items-center justify-center shrink-0 shadow-[0_1px_2px_rgba(0,0,0,0.02)] overflow-hidden">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#A0A4AA" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="m7 15 5 5 5-5" style={{ transform: isPressed ? 'translateY(3px)' : 'translateY(0)', transition: 'transform 0.15s ease-out' }} />
            <path d="m7 9 5-5 5 5" style={{ transform: isPressed ? 'translateY(-3px)' : 'translateY(0)', transition: 'transform 0.15s ease-out' }} />
          </svg>
        </div>
      </div>
    </div>
  );
}

// ── Translation helper ────────────────────────────────────────────────────────
function t(id: boolean, idText: string, enText: string) {
  return id ? idText : enText;
}

// ── Sidebar ───────────────────────────────────────────────────────────────────
function Sidebar({ page, setPage }: { page: string; setPage: (p: string) => void }) {
  const { language } = useApp();
  const id = language === "id";

  const CHILD_MAP: Record<string, string[]> = {
    keuangan:      ["transaksi","budget","analisis","kondisi-keuangan","investasi","akuntansi","spt"],
    produktivitas: ["produktivitas-aktivitas","jurnal","bible","steps"],
    library:       ["koleksi","baca-buku","accounting-space"],
    karier:        ["cv-builder","ats","toefl","interview"],
    pengaturan:    ["preferensi","pengaturan-data","notifikasi-setting","keamanan"],
  };

  const getDefaultOpen = () => {
    for (const [menu, children] of Object.entries(CHILD_MAP)) {
      if (children.includes(page)) return menu;
    }
    return null;
  };

  const [openMenu, setOpenMenu] = useState<string | null>(getDefaultOpen);

  const toggleMenu = (menu: string) =>
    setOpenMenu((prev) => (prev === menu ? null : menu));

  const isChildActive = (menuId: string) =>
    (CHILD_MAP[menuId] ?? []).includes(page);

  const nav = (id: string) => setPage(id);

  return (
    <aside className="w-64 shrink-0 bg-white border-r border-gray-100 flex flex-col py-5 px-4 overflow-y-auto">
      {/* Brand */}
      <div className="flex items-center gap-2 px-2 mb-4">
        <Logo />
        <div className="flex flex-col justify-center h-12 -translate-y-0.5">
          <div className="text-base font-bold text-gray-900 leading-tight">FreeSpace</div>
          <div className="text-[11.5px] text-gray-400 mt-0.5 leading-tight">Personal Workspace</div>
        </div>
      </div>

      {/* User profile */}
      <UserProfileMenu setPage={setPage} />

      <div className="my-3 border-t border-gray-100" />

      {/* ── MENU UTAMA ── */}
      <p className="text-[9px] font-semibold uppercase tracking-widest text-gray-400 px-3 mb-1.5">{t(id,"Menu Utama","Main Menu")}</p>

      {/* Dashboard */}
      <NavItem
        icon={LayoutDashboard}
        label="Dashboard"
        active={page === "dashboard"}
        onClick={() => { nav("dashboard"); setOpenMenu(null); }}
      />

      {/* Keuangan */}
      <MenuAccordion
        label={t(id,"Keuangan","Finance")}
        icon={Wallet}
        isOpen={openMenu === "keuangan"}
        isChildActive={isChildActive("keuangan")}
        onToggle={() => toggleMenu("keuangan")}
      >
        <SubItem label={t(id,"Transaksi","Transactions")}          id="transaksi"        page={page} onNavigate={nav} />
        <SubItem label="Budget"                                     id="budget"           page={page} onNavigate={nav} />
        <SubItem label={t(id,"Analisis & Proyeksi","Analysis & Projection")} id="analisis" page={page} onNavigate={nav} />
        <SubItem label={t(id,"Kondisi Keuangan","Financial Health")} id="kondisi-keuangan" page={page} onNavigate={nav} />
        <SubItem label={t(id,"Investasi","Investment")}             id="investasi"        page={page} onNavigate={nav} />
        <SubItem label={t(id,"Akuntansi","Accounting")}             id="akuntansi"        page={page} onNavigate={nav} />
        <SubItem label={t(id,"SPT Orang Pribadi","Personal Tax Return")} id="spt"         page={page} onNavigate={nav} />
      </MenuAccordion>

      {/* Produktivitas */}
      <MenuAccordion
        label={t(id,"Produktivitas","Productivity")}
        icon={CheckCircle2}
        isOpen={openMenu === "produktivitas"}
        isChildActive={isChildActive("produktivitas")}
        onToggle={() => toggleMenu("produktivitas")}
      >
        <SubItem label={t(id,"Aktivitas","Activities")}   id="produktivitas-aktivitas" page={page} onNavigate={nav} />
        <SubItem label={t(id,"Jurnal Harian","Daily Journal")} id="jurnal"             page={page} onNavigate={nav} />
        <SubItem label={t(id,"Renungan Harian","Daily Bible")} id="bible"              page={page} onNavigate={nav} />
        <SubItem label={t(id,"Pelacak Langkah","Steps Tracker")} id="steps"            page={page} onNavigate={nav} />
      </MenuAccordion>

      {/* Library */}
      <MenuAccordion
        label={t(id,"Perpustakaan","Library")}
        icon={BookOpen}
        isOpen={openMenu === "library"}
        isChildActive={isChildActive("library")}
        onToggle={() => toggleMenu("library")}
      >
        <SubItem label={t(id,"Koleksi Buku","Book Collection")} id="koleksi"           page={page} onNavigate={nav} />
        <SubItem label={t(id,"Baca Buku","Read Book")}          id="baca-buku"          page={page} onNavigate={nav} />
        <SubItem label={t(id,"Ruang Akuntansi","Accounting Space")} id="accounting-space" page={page} onNavigate={nav} />
      </MenuAccordion>

      {/* Karier */}
      <MenuAccordion
        label={t(id,"Karier","Career")}
        icon={Briefcase}
        isOpen={openMenu === "karier"}
        isChildActive={isChildActive("karier")}
        onToggle={() => toggleMenu("karier")}
      >
        <SubItem label={t(id,"Pembuat CV","CV Builder")}             id="cv-builder" page={page} onNavigate={nav} />
        <SubItem label={t(id,"Analisis ATS","ATS Analyzer")}         id="ats"        page={page} onNavigate={nav} />
        <SubItem label={t(id,"Latihan TOEFL","TOEFL Training")}      id="toefl"      page={page} onNavigate={nav} />
        <SubItem label={t(id,"Simulator Wawancara","Interview Simulator")} id="interview" page={page} onNavigate={nav} />
      </MenuAccordion>

      <div className="my-3 border-t border-gray-100" />

      {/* ── SISTEM ── */}
      <p className="text-[9px] font-semibold uppercase tracking-widest text-gray-400 px-3 mb-1.5">{t(id,"Sistem","System")}</p>

      {/* Riwayat */}
      <NavItem
        icon={Clock}
        label={t(id,"Riwayat","History")}
        active={page === "history"}
        onClick={() => { nav("history"); setOpenMenu(null); }}
      />

      {/* Pengaturan */}
      <MenuAccordion
        label={t(id,"Pengaturan","Settings")}
        icon={Settings}
        isOpen={openMenu === "pengaturan"}
        isChildActive={isChildActive("pengaturan")}
        onToggle={() => toggleMenu("pengaturan")}
      >
        <SubItem label={t(id,"Preferensi","Preferences")}              id="preferensi"         page={page} onNavigate={nav} />
        <SubItem label={t(id,"Pengaturan Data","Data Settings")}       id="pengaturan-data"    page={page} onNavigate={nav} />
        <SubItem label={t(id,"Pengaturan Notifikasi","Notifications")} id="notifikasi-setting" page={page} onNavigate={nav} />
        <SubItem label={t(id,"Keamanan & Data","Security & Data")}     id="keamanan"           page={page} onNavigate={nav} />
      </MenuAccordion>

      <div className="flex-1" />
    </aside>
  );
}



// ── Share Modal ───────────────────────────────────────────────────────────────
function ShareModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const { showToast } = useApp();
  const shareUrl = "https://freespace.app/dashboard";

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      showToast("Tautan berhasil disalin ke clipboard!");
      setTimeout(() => setCopied(false), 2500);
    } catch {
      showToast("Gagal menyalin tautan.", "error");
    }
  };

  if (!open) return null;
  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[420px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <Share2 size={18} className="text-gray-700" />
            <span className="text-sm font-bold text-gray-900">Bagikan Halaman</span>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
            <X size={16} className="text-gray-500" />
          </button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-2">Tautan Halaman</label>
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 text-xs text-gray-600 truncate font-mono select-all">
                {shareUrl}
              </div>
              <button
                onClick={handleCopy}
                className={`shrink-0 px-4 py-2.5 rounded-lg text-xs font-semibold transition-all ${copied ? "bg-green-500 text-white" : "bg-gray-900 text-white hover:bg-black"}`}
              >
                {copied ? "✓ Disalin" : "Salin"}
              </button>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-2">Bagikan Via</label>
            <div className="flex gap-2">
              <a
                href={`https://wa.me/?text=${encodeURIComponent("Lihat FreeSpace dashboard saya: " + shareUrl)}`}
                target="_blank" rel="noopener noreferrer"
                className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 bg-green-50 border border-green-200 text-green-700 rounded-lg text-xs font-semibold hover:bg-green-100 transition-colors"
              >
                <MessageSquare size={14} /> WhatsApp
              </a>
              <a
                href={`mailto:?subject=FreeSpace Dashboard&body=Akses FreeSpace di: ${shareUrl}`}
                className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 bg-blue-50 border border-blue-200 text-blue-700 rounded-lg text-xs font-semibold hover:bg-blue-100 transition-colors"
              >
                <Send size={14} /> Email
              </a>
            </div>
          </div>
          <p className="text-[10px] text-gray-400 text-center">Hanya pengguna dengan akun terdaftar yang dapat mengakses halaman ini.</p>
        </div>
      </div>
    </>
  );
}

// ── AI Panel ───────────────────────────────────────────────────────��──────────
function AIPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { language } = useApp();
  const id = language === "id";
  const [view, setView] = useState<"chat" | "history">("chat");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([
    { id: 1, role: "ai", text: id ? "Halo Salgado! Saya Asisten AI FreeSpace. Ada yang bisa saya bantu hari ini?" : "Hello Salgado! I'm FreeSpace AI Assistant. How can I help you today?" }
  ]);

  const [history, setHistory] = useState([
    { id: "h1", title: "Analisis penyusutan aset IT", date: "Hari ini" },
    { id: "h2", title: "Cara export data mutasi", date: "Kemarin" },
    { id: "h3", title: "Draft email laporan stok", date: "3 hari yang lalu" },
  ]);

  const handleSend = () => {
    if (!input.trim()) return;
    const newMsg = { id: Date.now(), role: "user", text: input };
    setMessages([...messages, newMsg]);
    setInput("");

    // Simulate AI response
    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: Date.now(),
        role: "ai",
        text: "Saya mengerti. Mari saya bantu analisis data tersebut. Berdasarkan data sistem, penyusutan rata-rata bulan ini adalah 4.2%."
      }]);
    }, 800);
  };

  if (!open) return null;

  return (
    <>
      <div className="fixed inset-0 z-40 bg-gray-900/20 backdrop-blur-sm animate-in fade-in duration-200" onClick={onClose} />
      <div className="fixed top-0 right-0 h-screen w-[400px] bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setView(view === "chat" ? "history" : "chat")}
              className={`p-1.5 rounded-md transition-colors ${view === "history" ? "bg-purple-100 text-purple-600" : "text-gray-500 hover:bg-gray-200"}`}
              title="Riwayat Percakapan"
            >
              <Clock size={16} />
            </button>
            <button
              onClick={() => { setView("chat"); setMessages([{ id: 1, role: "ai", text: "Halo Salgado! Ada hal baru yang ingin didiskusikan hari ini?" }]); }}
              className="p-1.5 rounded-md text-gray-500 hover:bg-gray-200 transition-colors"
              title="Percakapan Baru"
            >
              <Plus size={16} />
            </button>
          </div>
          <div className="text-sm font-bold text-gray-800 flex items-center gap-2">
            <ImageWithFallback src={aiLogo} alt="AI Logo" className="w-7 h-7 object-contain rounded-lg" />
            {t(id,"Asisten AI","AI Assistant")}
          </div>
          <button onClick={onClose} className="p-1.5 rounded-md text-gray-500 hover:bg-gray-200 transition-colors" title="Tutup">
            <X size={16} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden relative">
          {view === "history" ? (
            <div className="absolute inset-0 overflow-y-auto bg-gray-50/50 p-4">
              <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Riwayat Pencarian</h3>
              <div className="space-y-2">
                {history.map(item => (
                  <button key={item.id} onClick={() => setView("chat")} className="w-full text-left p-3 rounded-xl bg-white border border-gray-200 hover:border-purple-300 hover:shadow-sm transition-all group">
                    <div className="text-sm font-medium text-gray-800 truncate mb-1 group-hover:text-purple-600">{item.title}</div>
                    <div className="text-[10px] text-gray-400">{item.date}</div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="absolute inset-0 flex flex-col bg-white">
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map(m => (
                  <div key={m.id} className={`flex gap-3 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
                    {m.role === "user" ? (
                      <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 bg-gray-900 text-white font-medium">
                        S
                      </div>
                    ) : (
                      <div className="w-10 h-10 flex items-center justify-center shrink-0">
                        <ImageWithFallback src={aiLogo} alt="AI" className="w-10 h-10 object-contain rounded-lg" />
                      </div>
                    )}
                    <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${m.role === "user" ? "bg-gray-900 text-white rounded-tr-sm" : "bg-gray-100 text-gray-800 rounded-tl-sm"}`}>
                      {m.text}
                    </div>
                  </div>
                ))}
              </div>

              {/* Input */}
              <div className="p-4 bg-white border-t border-gray-100">
                <div className="relative flex items-end gap-2 bg-gray-50 border border-gray-200 rounded-xl p-1.5 focus-within:ring-1 focus-within:ring-purple-500 focus-within:border-purple-500 transition-all">
                  <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                    placeholder="Tanyakan sesuatu ke AI..."
                    className="flex-1 max-h-32 min-h-[40px] bg-transparent resize-none outline-none text-sm text-gray-700 py-2.5 px-3 placeholder:text-gray-400"
                    rows={1}
                  />
                  <button
                    onClick={handleSend}
                    disabled={!input.trim()}
                    className="w-8 h-8 shrink-0 rounded-lg flex items-center justify-center text-white transition-colors mb-1 mr-1 disabled:opacity-50 disabled:cursor-not-allowed"
                    style={{ backgroundColor: ORANGE }}
                  >
                    <Send size={14} />
                  </button>
                </div>
                <div className="text-[10px] text-center text-gray-400 mt-2">
                  {t(id,"Asisten AI dapat membuat kesalahan. Periksa kembali info penting.","AI Assistant can make mistakes. Please verify important information.")}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// ���─ Top Bar (shared) ──────────────────────────────────────────────────────────
function TopBar({ title, breadcrumbs }: { title?: string; breadcrumbs?: string[] }) {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showAI, setShowAI] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [notifViewAll, setNotifViewAll] = useState(false);
  const { notifications, markAllRead, markRead, unreadCount, language } = useApp();
  const id = language === "id";

  return (
    <>
      <div className="sticky top-0 z-10 bg-[#FFFFFF] border-b border-[#ECECEC] flex items-center px-8 h-[72px]">
        {/* LEFT: page breadcrumb */}
        <div className="flex items-center shrink-0 gap-2.5" style={{ minWidth: "250px" }}>
          <ImageWithFallback src={logoImage} alt="FreeSpace Logo" className="w-7 h-7 object-contain" />
          
          {breadcrumbs ? (
            <div className="flex items-center gap-2.5">
              {(Array.isArray(breadcrumbs) ? breadcrumbs : [breadcrumbs]).map((crumb, idx) => (
                <React.Fragment key={idx}>
                  <ChevronRight size={16} strokeWidth={2} className="text-[#8A8A8A]" />
                  <h1 className={`text-[15px] tracking-tight ${idx === breadcrumbs.length - 1 ? 'font-semibold text-[#171717]' : 'font-medium text-[#6F737A]'}`}>
                    {crumb}
                  </h1>
                </React.Fragment>
              ))}
            </div>
          ) : title && (
            <>
              <ChevronRight size={16} strokeWidth={2} className="text-[#8A8A8A]" />
              <h1 className="text-[16px] font-semibold text-[#171717] tracking-tight">{title}</h1>
            </>
          )}
        </div>

        {/* CENTER: flexible space */}
        <div className="flex-1" />

        {/* RIGHT: action buttons */}
        <div className="flex items-center justify-end gap-[10px] shrink-0 relative pr-4">
          <div className="flex items-center gap-2 bg-[#FFFFFF] border border-[#E5E5E5] rounded-[8px] px-3 h-[38px] w-64">
            <Search size={16} strokeWidth={1.7} className="text-[#6F737A] shrink-0" />
            <input className="text-[15px] text-[#171717] bg-transparent outline-none flex-1 min-w-0 placeholder:text-[#8A8A8A]"
              placeholder="Search..." />
            <div className="flex items-center justify-center bg-[#F6F6F6] border border-[#E7E7E7] rounded-[6px] w-[32px] h-[22px] shrink-0">
              <span className="text-[12px] font-medium text-[#777777]">⌘K</span>
            </div>
          </div>
          <button
            onClick={() => setShowAI(true)}
            className="flex items-center gap-1.5 h-[38px] pl-3 pr-4 rounded-[8px] border border-[#6B7280] bg-[#FFFFFF] transition-colors hover:bg-gray-100"
            title={t(id,"Tanya AI","Ask AI")}
          >
            <ImageWithFallback src={aiLogo} alt="AI Logo" className="w-7 h-7 object-contain rounded-md" />
            <span className="text-[14px] font-medium text-[#6B7280]">{t(id,"Tanya AI","Ask AI")}</span>
          </button>
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="w-[38px] h-[38px] rounded-[8px] border border-[#6B7280] bg-[#FFFFFF] flex items-center justify-center hover:bg-gray-50 transition-colors relative"
            title={t(id,"Notifikasi","Notifications")}
          >
            <Bell size={18} strokeWidth={1.7} className="text-[#6B7280]" />
            {unreadCount > 0 && <span className="absolute -top-1 -right-1 min-w-[17px] h-[17px] rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center px-1">{unreadCount}</span>}
          </button>
          <button
            onClick={() => setShowShare(true)}
            className="w-[38px] h-[38px] rounded-[8px] border border-[#6B7280] bg-[#FFFFFF] flex items-center justify-center hover:bg-gray-50 transition-colors"
            title={t(id,"Bagikan","Share")}
          >
            <Share2 size={18} strokeWidth={1.7} className="text-[#6B7280]" />
          </button>

          {showNotifications && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => { setShowNotifications(false); setNotifViewAll(false); }} />
              <div className="absolute top-full right-0 mt-2 w-[340px] bg-white border border-gray-200 shadow-lg rounded-xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-100">
                <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-gray-900">Notifikasi</span>
                    {unreadCount > 0 && (
                      <span className="text-[10px] font-bold bg-red-100 text-red-600 px-1.5 py-0.5 rounded-full">{unreadCount} baru</span>
                    )}
                  </div>
                  <button
                    onClick={markAllRead}
                    disabled={unreadCount === 0}
                    className={`text-[11px] font-medium transition-colors ${unreadCount > 0 ? "hover:underline cursor-pointer" : "text-gray-400 cursor-default"}`}
                    style={{ color: unreadCount > 0 ? P : undefined }}
                  >
                    Tandai semua dibaca
                  </button>
                </div>
                <div className={`overflow-y-auto transition-all duration-200 ${notifViewAll ? "max-h-[460px]" : "max-h-[300px]"}`}>
                  {(notifViewAll ? notifications : notifications.slice(0, 3)).map((n) => (
                    <div
                      key={n.id}
                      onClick={() => markRead(n.id)}
                      className={`p-4 border-b border-gray-50 last:border-0 hover:bg-gray-50 cursor-pointer transition-colors ${n.unread ? "bg-purple-50/30" : ""}`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${n.unread ? "bg-purple-500" : "bg-transparent border border-gray-300"}`}></div>
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm ${n.unread ? "font-semibold text-gray-900" : "font-medium text-gray-700"}`}>{n.title}</p>
                          <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">{n.message}</p>
                          <p className="text-[10px] text-gray-400 mt-1.5 font-medium">{n.time}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-3 border-t border-gray-100 bg-gray-50/50 text-center">
                  <button
                    onClick={() => setNotifViewAll((v) => !v)}
                    className="text-xs font-semibold text-gray-600 hover:text-gray-900 transition-colors"
                  >
                    {notifViewAll ? "↑ Ciutkan" : `Lihat Semua (${notifications.length})`}
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      <AIPanel open={showAI} onClose={() => setShowAI(false)} />
      <ShareModal open={showShare} onClose={() => setShowShare(false)} />
    </>
  );
}

// ── Pages ─────────────────────────────────────────────────────────────────────

function ProfilePage({ breadcrumbs }: { breadcrumbs: string[] }) {
  const [profileImgUrl, setProfileImgUrl] = useState<string | null>(null);
  const [isBannerOpen, setIsBannerOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { showToast } = useApp();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setProfileImgUrl(URL.createObjectURL(e.target.files[0]));
      showToast("Foto profil berhasil diperbarui!");
    }
  };

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      <TopBar breadcrumbs={breadcrumbs} />
      <div className="px-8 py-6 space-y-6">
        <h1 className="text-xl font-bold text-gray-900">Profil Saya</h1>
        
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          {/* Banner */}
          <div
            className="h-32 relative overflow-hidden bg-[#D1D5DB] cursor-pointer group"
            onClick={() => setIsBannerOpen(true)}
          >
            <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center z-20">
              <div className="bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-semibold text-gray-800 flex items-center gap-2 shadow-sm">
                <Search size={16} />
                Lihat Banner
              </div>
            </div>
          </div>
          
          <div className="px-6 pb-6 relative">
            {/* Avatar */}
            <div className="absolute -top-12 left-6 z-20">
              <div
                className="w-24 h-24 rounded-full border-4 border-white bg-white shadow-sm relative group cursor-pointer overflow-hidden"
                onClick={() => fileInputRef.current?.click()}
              >
                {profileImgUrl
                  ? <img src={profileImgUrl} alt="Profile" className="w-full h-full object-cover" />
                  : <GenericAvatar className="w-full h-full" />
                }
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <Camera size={20} className="text-white" />
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={handleFileChange} 
                />
              </div>
            </div>
            
            {/* Header info */}
            <div className="ml-28 pl-4 pt-3 flex justify-between items-start">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Salgado Ginting</h2>
                <p className="text-sm text-gray-500 mt-0.5">Administrator</p>
              </div>
              <div className="flex gap-2">
                 <button className="px-4 py-2 bg-white border border-gray-200 text-gray-700 text-xs font-semibold rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
                 <button onClick={() => showToast("Profil berhasil disimpan!")} className="px-4 py-2 text-white text-xs font-semibold rounded-lg transition-colors hover:opacity-90" style={{ backgroundColor: P }}>Simpan Perubahan</button>
              </div>
            </div>

            <div className="mt-10 grid grid-cols-2 gap-8">
               <div className="space-y-4">
                 <h3 className="text-sm font-semibold text-gray-900 border-b border-gray-100 pb-2">Informasi Pribadi</h3>
                 
                 <div>
                   <label className="block text-xs font-medium text-gray-700 mb-1.5">Nama Lengkap</label>
                   <input type="text" defaultValue="Salgado Ginting" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-1" style={{ '--tw-ring-color': P } as React.CSSProperties} />
                 </div>
                 
                 <div>
                   <label className="block text-xs font-medium text-gray-700 mb-1.5">Alamat Email</label>
                   <input type="email" defaultValue="salgadoginting@apps.ipb.ac.id" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-1" style={{ '--tw-ring-color': P } as React.CSSProperties} />
                 </div>
                 
                 <div>
                   <label className="block text-xs font-medium text-gray-700 mb-1.5">Nomor Telepon</label>
                   <input type="tel" defaultValue="+62 812 3456 7890" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-1" style={{ '--tw-ring-color': P } as React.CSSProperties} />
                 </div>
               </div>

               <div className="space-y-4">
                 <h3 className="text-sm font-semibold text-gray-900 border-b border-gray-100 pb-2">Jabatan</h3>
                 
                 <div>
                   <label className="block text-xs font-medium text-gray-700 mb-1.5">Jabatan</label>
                   <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg bg-gray-50 text-gray-500 cursor-not-allowed outline-none" disabled>
                     <option>Administrator</option>
                   </select>
                 </div>
                 
                 <div>
                   <label className="block text-xs font-medium text-gray-700 mb-1.5">Lokasi</label>
                   <input type="text" defaultValue="Rektorat IPB, Lt. 3" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-1" style={{ '--tw-ring-color': P } as React.CSSProperties} />
                 </div>
               </div>
            </div>
          </div>
        </div>
      </div>

      {/* Banner Modal */}
      {isBannerOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 sm:p-8 animate-in fade-in duration-200" 
          onClick={() => setIsBannerOpen(false)}
        >
          <div 
            className="relative max-w-5xl w-full flex flex-col items-center animate-in zoom-in-95 duration-300" 
            onClick={e => e.stopPropagation()}
          >
            <button 
              onClick={() => setIsBannerOpen(false)} 
              className="absolute -top-12 right-0 text-white/70 hover:text-white transition-colors"
            >
              <X size={28} />
            </button>
            <div
              className="w-full relative rounded-xl overflow-hidden shadow-2xl bg-[#D1D5DB]"
              style={{ aspectRatio: "6.5 / 1" }}
            >
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

function SettingsPage({ breadcrumbs }: { breadcrumbs: string[] }) {
  const [tab, setTab] = useState("general");
  const [toggles, setToggles] = useState([true, true, true, false]);
  const { language, setLanguage, showToast } = useApp();
  
  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      <TopBar breadcrumbs={breadcrumbs} />
      <div className="px-8 py-6 space-y-6">
        <h1 className="text-xl font-bold text-gray-900">Pengaturan Akun</h1>
        
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm flex overflow-hidden min-h-[500px]">
          {/* Sidebar */}
          <div className="w-64 bg-gray-50/50 border-r border-gray-100 p-4 shrink-0">
            <nav className="space-y-1">
              {[
                { id: "general", label: "Umum", icon: Settings },
                { id: "security", label: "Keamanan & Kata Sandi", icon: Shield },
                { id: "notifications", label: "Notifikasi", icon: BellRing },
                { id: "devices", label: "Perangkat Aktif", icon: Smartphone },
              ].map(t => (
                <button 
                  key={t.id} 
                  onClick={() => setTab(t.id)} 
                  className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm transition-colors ${tab === t.id ? "font-semibold" : "text-gray-600 hover:bg-gray-100"}`}
                  style={tab === t.id ? { backgroundColor: P_XLIGHT, color: P_DARK } : {}}
                >
                  <t.icon size={16} style={{ color: tab === t.id ? P : undefined }} className={tab !== t.id ? "text-gray-400" : ""} />
                  {t.label}
                </button>
              ))}
            </nav>
          </div>
          
          {/* Content */}
          <div className="flex-1 p-8">
            {tab === "general" && (
               <div className="space-y-6 animate-in fade-in duration-300">
                 <div>
                   <h2 className="text-lg font-bold text-gray-900">Pengaturan Umum</h2>
                   <p className="text-xs text-gray-500 mt-1">Kelola preferensi akun dan pengaturan bahasa Anda.</p>
                 </div>
                 
                 <div className="space-y-4">
                   <div className="flex items-center justify-between border-b border-gray-100 pb-4">
                     <div>
                       <div className="text-sm font-medium text-gray-900">Bahasa</div>
                       <div className="text-xs text-gray-500 mt-0.5">Pilih bahasa yang Anda inginkan untuk dasbor.</div>
                     </div>
                     <select
                       value={language}
                       onChange={(e) => setLanguage(e.target.value as AppLanguage)}
                       className="text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1"
                       style={{ "--tw-ring-color": P } as React.CSSProperties}
                     >
                       <option value="en">Inggris (AS)</option>
                       <option value="id">Bahasa Indonesia</option>
                     </select>
                   </div>
                   
                   <div className="flex items-center justify-between border-b border-gray-100 pb-4">
                     <div>
                       <div className="text-sm font-medium text-gray-900">Zona Waktu</div>
                       <div className="text-xs text-gray-500 mt-0.5">Atur zona waktu lokal Anda untuk tanggal dan waktu.</div>
                     </div>
                     <select className="text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1" style={{ '--tw-ring-color': P } as React.CSSProperties}>
                       <option>(GMT+07:00) Waktu Indonesia Barat</option>
                       <option>(GMT+08:00) Waktu Indonesia Tengah</option>
                     </select>
                   </div>
                 </div>
                 
                 <div className="pt-4 flex justify-end">
                   <button onClick={() => showToast(`Pengaturan umum berhasil disimpan! Bahasa: ${language === "id" ? "Bahasa Indonesia" : "Inggris (AS)"}`)} className="px-4 py-2 text-white text-sm font-semibold rounded-lg transition-colors hover:opacity-90" style={{ backgroundColor: P }}>Simpan Preferensi</button>
                 </div>
               </div>
            )}
            
            {tab === "security" && (
               <div className="space-y-6 animate-in fade-in duration-300">
                 <div>
                   <h2 className="text-lg font-bold text-gray-900">Keamanan & Kata Sandi</h2>
                   <p className="text-xs text-gray-500 mt-1">Kelola kata sandi Anda dan amankan akun Anda.</p>
                 </div>
                 
                 <div className="space-y-4">
                   <div className="border border-gray-200 rounded-xl p-5">
                     <h3 className="text-sm font-semibold text-gray-900 mb-4">Ubah Kata Sandi</h3>
                     <div className="space-y-3 max-w-sm">
                       <div>
                         <label className="block text-xs font-medium text-gray-700 mb-1.5">Kata Sandi Saat Ini</label>
                         <input type="password" placeholder="••••••••" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-1" style={{ '--tw-ring-color': P } as React.CSSProperties} />
                       </div>
                       <div>
                         <label className="block text-xs font-medium text-gray-700 mb-1.5">Kata Sandi Baru</label>
                         <input type="password" placeholder="••••••••" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-1" style={{ '--tw-ring-color': P } as React.CSSProperties} />
                       </div>
                       <div className="pt-2">
                         <button onClick={() => showToast("Kata sandi berhasil diperbarui!")} className="px-4 py-2 bg-gray-900 text-white text-xs font-semibold rounded-lg hover:bg-black transition-colors">Perbarui Kata Sandi</button>
                       </div>
                     </div>
                   </div>
                 </div>
               </div>
            )}
            
            {tab === "notifications" && (
               <div className="space-y-6 animate-in fade-in duration-300">
                 <div>
                   <h2 className="text-lg font-bold text-gray-900">Notifikasi</h2>
                   <p className="text-xs text-gray-500 mt-1">Pilih cara Anda menerima peringatan dan pembaruan.</p>
                 </div>
                 
                 <div className="space-y-4">
                   {[
                     { title: "Mutasi Aset", desc: "Dapatkan pemberitahuan saat aset mengubah lokasi atau kepemilikan." },
                     { title: "Peringatan Pemeliharaan", desc: "Terima peringatan untuk pemeliharaan dan perbaikan terjadwal." },
                     { title: "Laporan Stock Opname", desc: "Ringkasan mingguan penyelesaian stock opname." },
                     { title: "Pembaruan Sistem", desc: "Berita tentang pembaruan produk dan fitur." },
                   ].map((item, i) => (
                     <div key={i} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
                       <div>
                         <div className="text-sm font-medium text-gray-900">{item.title}</div>
                         <div className="text-xs text-gray-500 mt-0.5">{item.desc}</div>
                       </div>
                       <label className="relative inline-flex items-center cursor-pointer">
                         <input type="checkbox" className="sr-only peer" checked={toggles[i]} onChange={() => { const t = [...toggles]; t[i] = !t[i]; setToggles(t); }} />
                         <div className="w-9 h-5 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all" style={toggles[i] ? { backgroundColor: P } : {}}></div>
                       </label>
                     </div>
                   ))}
                 </div>
               </div>
            )}
            
            {tab === "devices" && (
               <div className="space-y-6 animate-in fade-in duration-300">
                 <div>
                   <h2 className="text-lg font-bold text-gray-900">Perangkat Aktif</h2>
                   <p className="text-xs text-gray-500 mt-1">Anda saat ini masuk ke perangkat ini.</p>
                 </div>
                 
                 <div className="space-y-3">
                   <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                     <div className="flex items-center gap-3">
                       <Smartphone size={20} className="text-gray-400" />
                       <div>
                         <div className="text-sm font-medium text-gray-900">MacBook Pro - Chrome</div>
                         <div className="text-xs text-gray-500 mt-0.5">Bogor, Indonesia • Aktif sekarang</div>
                       </div>
                     </div>
                     <span className="text-[10px] font-bold bg-green-100 text-green-700 px-2 py-0.5 rounded uppercase tracking-wider">Saat Ini</span>
                   </div>
                   
                   <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                     <div className="flex items-center gap-3">
                       <Smartphone size={20} className="text-gray-400" />
                       <div>
                         <div className="text-sm font-medium text-gray-900">iPhone 13 - Safari</div>
                         <div className="text-xs text-gray-500 mt-0.5">Jakarta, Indonesia • Terakhir aktif 2 jam yang lalu</div>
                       </div>
                     </div>
                     <button className="text-xs font-semibold text-red-500 hover:text-red-600 transition-colors">Cabut</button>
                   </div>
                 </div>
               </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}


const DASH_SUBPAGES: Record<string, { title: string; tabs: string[] }> = {
  "dash-analitik":   { title: "Analitik",   tabs: ["Pola Kerusakan Aset", "Prediksi Perbaikan Aset", "Pengelolaan Aset", "Persebaran Aset", "Perencanaan Pengadaan Aset", "Rekapitulasi"] },
  "dash-keuangan":   { title: "Keuangan",   tabs: ["Valuasi Aset", "Penyusutan", "Aset Bernilai Tinggi", "Biaya Aset per Unit"] },
  "dash-kondisi":    { title: "Kondisi",    tabs: ["Kualitas Aset", "Kelayakan Aset", "Umur Ekonomis", "Prioritas Penggantian"] },
  "dash-monitoring": { title: "Monitoring", tabs: ["Pertumbuhan Aset", "Distribusi Aset", "Komposisi Aset", "Aset per Ruangan"] },
  "dash-utilisasi":  { title: "Utilisasi",  tabs: ["Ringkasan Utilisasi", "Idle Asset", "Pemenuhan Kapasitas", "Ruangan Kekurangan Aset"] },
  "dash-pengadaan":  { title: "Pengadaan",  tabs: ["Ringkasan Pengadaan", "Statistik Pengadaan", "History Pengadaan", "Kebutuhan Aset", "Penggantian Aset"] },
  "dash-maintenance":{ title: "Maintenance",tabs: ["Ringkasan Perbaikan", "Proyeksi Perbaikan", "Biaya Perbaikan", "History Perbaikan", "Jadwal Perbaikan"] },
  "kampus-cilibende":  { title: "Kampus Cilibende",   tabs: ["Ringkasan", "Aset per Ruangan", "Denah / Floorplan", "GIS / Heatmap", "Ruangan Perlu Verifikasi"] },
  "kampus-gunung-gede":{ title: "Kampus Gunung Gede", tabs: ["Ringkasan", "Aset per Ruangan", "Denah / Floorplan", "GIS / Heatmap", "Ruangan Perlu Verifikasi"] },
};

// ── FreeSpace page catalogue ──────────────────────────────────────────────────
interface FSPageMeta { title: string; subtitle: string; icon: IC; breadcrumbs: string[] }

const FREESPACE_PAGES: Record<string, FSPageMeta> = {
  transaksi:              { title: "Transaksi",             subtitle: "Catat dan kelola semua transaksi keuangan pribadi.",           icon: ArrowLeftRight, breadcrumbs: ["Keuangan", "Transaksi"] },
  budget:                 { title: "Budget",                subtitle: "Rencanakan dan pantau anggaran bulanan Anda.",                 icon: PieChart,       breadcrumbs: ["Keuangan", "Budget"] },
  analisis:               { title: "Analisis & Proyeksi",   subtitle: "Analisis tren keuangan dan proyeksi ke depan.",               icon: TrendingUp,     breadcrumbs: ["Keuangan", "Analisis & Proyeksi"] },
  "kondisi-keuangan":     { title: "Kondisi Keuangan",      subtitle: "Ringkasan aset, utang, dan kesehatan keuangan Anda.",         icon: Scale,          breadcrumbs: ["Keuangan", "Kondisi Keuangan"] },
  investasi:              { title: "Investasi",             subtitle: "Pantau portofolio dan performa investasi Anda.",              icon: TrendingUp,     breadcrumbs: ["Keuangan", "Investasi"] },
  akuntansi:              { title: "Akuntansi",             subtitle: "Jurnal, buku besar, dan laporan keuangan.",                  icon: Calculator,     breadcrumbs: ["Keuangan", "Akuntansi"] },
  spt:                    { title: "SPT Orang Pribadi",     subtitle: "Persiapkan dan hitung SPT Orang Pribadi tahunan.",           icon: FileText,       breadcrumbs: ["Keuangan", "SPT Orang Pribadi"] },
  "produktivitas-aktivitas":{ title: "Aktivitas",           subtitle: "Kelola jadwal dan aktivitas harian Anda.",                   icon: CalendarDays,   breadcrumbs: ["Produktivitas", "Aktivitas"] },
  jurnal:                 { title: "Jurnal Harian",         subtitle: "Tulis refleksi dan catatan harian pribadi.",                 icon: Edit3,          breadcrumbs: ["Produktivitas", "Jurnal Harian"] },
  bible:                  { title: "Bible Harian",          subtitle: "Baca dan refleksikan ayat Alkitab setiap hari.",             icon: BookOpen,       breadcrumbs: ["Produktivitas", "Bible Harian"] },
  steps:                  { title: "Steps Tracker",         subtitle: "Pantau langkah kaki dan aktivitas fisik harian.",            icon: MapPin,         breadcrumbs: ["Produktivitas", "Steps Tracker"] },
  koleksi:                { title: "Koleksi Buku",          subtitle: "Kelola dan organisir koleksi buku digital Anda.",            icon: Layers,         breadcrumbs: ["Library", "Koleksi Buku"] },
  "baca-buku":            { title: "Baca Buku",             subtitle: "Baca buku PDF dan tambahkan catatan bacaan.",                icon: Eye,            breadcrumbs: ["Library", "Baca Buku"] },
  "accounting-space":     { title: "Accounting Space",      subtitle: "Ruang belajar akuntansi — buku, catatan, dan latihan.",      icon: GraduationCap,  breadcrumbs: ["Library", "Accounting Space"] },
  "cv-builder":           { title: "CV Builder",            subtitle: "Buat dan kelola CV profesional yang menarik.",               icon: FilePlus,       breadcrumbs: ["Karier", "CV Builder"] },
  ats:                    { title: "ATS Analyzer",          subtitle: "Analisis CV terhadap job description dengan skor ATS.",      icon: FileSearch,     breadcrumbs: ["Karier", "ATS Analyzer"] },
  toefl:                  { title: "TOEFL Training",        subtitle: "Latihan Listening, Structure, dan Reading TOEFL.",           icon: Globe2,         breadcrumbs: ["Karier", "TOEFL Training"] },
  interview:              { title: "Interview Simulator",   subtitle: "Latih kemampuan wawancara dengan simulasi interaktif.",      icon: MessageSquare,  breadcrumbs: ["Karier", "Interview Simulator"] },
  "pengaturan-data":      { title: "Pengaturan Data",       subtitle: "Kelola impor, ekspor, dan backup data aplikasi.",           icon: Database,       breadcrumbs: ["Profil & Pengaturan", "Pengaturan Data"] },
  "notifikasi-setting":   { title: "Pengaturan Notifikasi", subtitle: "Atur preferensi dan jenis notifikasi yang diterima.",       icon: BellRing,       breadcrumbs: ["Profil & Pengaturan", "Pengaturan Notifikasi"] },
  keamanan:               { title: "Keamanan & Data",       subtitle: "Ubah password, backup, dan pengelolaan keamanan akun.",     icon: Shield,         breadcrumbs: ["Profil & Pengaturan", "Keamanan & Data"] },
};

// ── Main Content ──────────────────────────────────────────────────────────────
function MainContent({ page }: { page: string }) {
  const { theme, setTheme, tableDensity, setTableDensity, showToast } = useApp();

  // Breadcrumb resolver for FreeSpace routes
  let currentBreadcrumbs: string[] = [];
  if (page === "dashboard")              currentBreadcrumbs = ["Dashboard"];
  else if (page === "history")           currentBreadcrumbs = ["History"];
  else if (page === "profil")            currentBreadcrumbs = ["Profil"];
  else if (page === "profile")           currentBreadcrumbs = ["Profil"];
  else if (page === "preferensi")        currentBreadcrumbs = ["Pengaturan", "Preferensi"];
  else if (page === "pengaturan-data")   currentBreadcrumbs = ["Pengaturan", "Pengaturan Data"];
  else if (page === "notifikasi-setting")currentBreadcrumbs = ["Pengaturan", "Pengaturan Notifikasi"];
  else if (page === "keamanan")          currentBreadcrumbs = ["Pengaturan", "Keamanan & Data"];
  else if (FREESPACE_PAGES[page])        currentBreadcrumbs = FREESPACE_PAGES[page].breadcrumbs;
  else                                   currentBreadcrumbs = ["Dashboard"];

  // ── Dashboard ──
  if (page === "dashboard") {
    return <DashboardFreeSpace topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  }

  // ── History ──
  if (page === "history") {
    return <HistoryPage topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  }

  // ── Profil ──
  if (page === "profil" || page === "profile") {
    return <ProfilePage breadcrumbs={currentBreadcrumbs} />;
  }

  // ── Keuangan pages — full implementations ──
  if (page === "transaksi")        return <TransaksiPage      topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "budget")           return <BudgetPage         topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "analisis")         return <AnalisisPage       topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "kondisi-keuangan") return <KondisiKeuanganPage topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "investasi")        return <InvestasiPage      topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "akuntansi")        return <AkuntansiPage      topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "spt")              return <SPTPage            topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;

  // ── Produktivitas pages — full implementations ──
  if (page === "produktivitas-aktivitas") return <ProduktivitasAktivitasPage topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "jurnal")                  return <JurnalHarianPage           topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "bible")                   return <BibleHarianPage            topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "steps")                   return <StepsTrackerPage           topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;

  // ── Library pages — full implementations ──
  if (page === "koleksi")          return <KoleksiBukuPage      topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "baca-buku")        return <BacaBukuPage         topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "accounting-space") return <AccountingSpacePage  topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;

  // ── Karier pages — full implementations ──
  if (page === "cv-builder") return <CVBuilderPage         topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "ats")        return <ATSAnalyzerPage       topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "toefl")      return <TOEFLTrainingPage     topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;
  if (page === "interview")  return <InterviewSimulatorPage topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} />;

  // ── Settings pages — full implementations ──
  if (page === "preferensi")       return <PreferensiPage        topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} showToast={showToast} />;
  if (page === "pengaturan-data")  return <PengaturanDataPage    topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} showToast={showToast} />;
  if (page === "notifikasi-setting") return <NotifikasiSettingPage topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} showToast={showToast} />;
  if (page === "keamanan")         return <KeamananDataPage      topBar={<TopBar breadcrumbs={currentBreadcrumbs} />} showToast={showToast} />;

  // ── Other FreeSpace placeholder pages ──
  if (FREESPACE_PAGES[page]) {
    const { title, subtitle, icon } = FREESPACE_PAGES[page];
    return (
      <FreeSpacePlaceholder
        topBar={<TopBar breadcrumbs={currentBreadcrumbs} />}
        title={title}
        subtitle={subtitle}
        icon={icon}
      />
    );
  }

  if (page === "_preferensi_legacy_removed") {
    return (
      <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
        <TopBar breadcrumbs={currentBreadcrumbs} />
        <div className="px-8 py-6 space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-[#022B5F] mb-1">Preferensi</h1>
            <p className="text-sm text-gray-500">Sesuaikan pengalaman tampilan dan notifikasi FreeSpace Anda.</p>
          </div>
          
          <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
              <LayoutDashboard size={18} className="text-[#014285]" />
              <h2 className="text-base font-semibold text-[#022B5F]">Tampilan & Antarmuka</h2>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-[#022B5F]">Tema Visual</p>
                  <p className="text-xs text-gray-500 mt-0.5">Pilih tema warna terang atau gelap untuk dashboard.</p>
                </div>
                <div className="flex bg-gray-100 p-1 rounded-lg">
                  <button
                    onClick={() => { setTheme("light"); showToast("Tema terang diaktifkan!", "info"); }}
                    className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${theme === "light" ? "bg-white shadow-sm text-[#022B5F]" : "text-gray-500 hover:text-gray-700"}`}
                  >☀️ Terang</button>
                  <button
                    onClick={() => { setTheme("dark"); showToast("Tema gelap diaktifkan!", "info"); }}
                    className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${theme === "dark" ? "bg-white shadow-sm text-[#022B5F]" : "text-gray-500 hover:text-gray-700"}`}
                  >🌙 Gelap</button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-[#022B5F]">Kerapatan Data Tabel</p>
                  <p className="text-xs text-gray-500 mt-0.5">Tentukan kerapatan baris untuk tampilan data tabel aset.</p>
                </div>
                <select
                  value={tableDensity}
                  onChange={(e) => setTableDensity(e.target.value as TableDensity)}
                  className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-[#022B5F] font-medium outline-none focus:ring-1 focus:ring-[#014285]"
                >
                  <option value="normal">Normal</option>
                  <option value="compact">Rapat (Compact)</option>
                  <option value="spacious">Longgar (Spacious)</option>
                </select>
              </div>
            </div>
          </div>

          <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
              <Bell size={18} className="text-[#014285]" />
              <h2 className="text-base font-semibold text-[#022B5F]">Pengaturan Notifikasi</h2>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-[#022B5F]">Ringkasan Mingguan</p>
                  <p className="text-xs text-gray-500 mt-0.5">Terima email laporan status dan mutasi aset setiap Senin pagi.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-10 h-5.5 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4.5 after:w-4.5 after:transition-all peer-checked:bg-[#014285]"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-[#022B5F]">Peringatan Pemeliharaan Aset</p>
                  <p className="text-xs text-gray-500 mt-0.5">Notifikasi instan saat ada aset yang mendekati jadwal perawatan.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-10 h-5.5 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4.5 after:w-4.5 after:transition-all peer-checked:bg-[#014285]"></div>
                </label>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-[#022B5F]">Pembaruan FreeSpace</p>
                  <p className="text-xs text-gray-500 mt-0.5">Berita terkait fitur baru dan pembaruan aplikasi FreeSpace.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" />
                  <div className="w-10 h-5.5 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4.5 after:w-4.5 after:transition-all peer-checked:bg-[#014285]"></div>
                </label>
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={() => showToast("Preferensi berhasil disimpan!")}
              className="px-5 py-2.5 text-white text-sm font-semibold rounded-lg transition-all shadow-sm hover:shadow bg-[#014285] hover:bg-[#022B5F]"
            >
              Simpan Perubahan
            </button>
          </div>
        </div>
      </main>
    );
  }

  if (page === "panduan-pengguna") {
    return (
      <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
        <TopBar breadcrumbs={currentBreadcrumbs} />
        <div className="px-8 py-6 space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-[#022B5F] mb-1">Panduan Pengguna</h1>
            <p className="text-sm text-gray-500">Pelajari cara menggunakan setiap fitur di aplikasi Manajemen Aset SV IPB secara optimal.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="bg-white border border-gray-200 rounded-xl p-6 hover:border-[#014285] transition-all hover:shadow-md cursor-pointer group">
              <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center mb-5 text-[#014285] group-hover:bg-[#014285] group-hover:text-white transition-colors">
                <Database size={22} strokeWidth={1.5} />
              </div>
              <h3 className="text-base font-bold text-[#022B5F] mb-2">Pengelolaan Data Aset</h3>
              <p className="text-sm text-gray-500 leading-relaxed">Cara komprehensif untuk menambah, mengedit, dan menghapus data peralatan, mesin, dan aset lainnya di sistem IPB.</p>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-xl p-6 hover:border-[#014285] transition-all hover:shadow-md cursor-pointer group">
              <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center mb-5 text-[#014285] group-hover:bg-[#014285] group-hover:text-white transition-colors">
                <ArrowLeftRight size={22} strokeWidth={1.5} />
              </div>
              <h3 className="text-base font-bold text-[#022B5F] mb-2">Mutasi & Pemindahan</h3>
              <p className="text-sm text-gray-500 leading-relaxed">Prosedur pemindahan lokasi aset antar ruangan atau perubahan penanggung jawab beserta pencatatan BAST.</p>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-xl p-6 hover:border-[#014285] transition-all hover:shadow-md cursor-pointer group">
              <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center mb-5 text-[#014285] group-hover:bg-[#014285] group-hover:text-white transition-colors">
                <Wrench size={22} strokeWidth={1.5} />
              </div>
              <h3 className="text-base font-bold text-[#022B5F] mb-2">Pencatatan Maintenance</h3>
              <p className="text-sm text-gray-500 leading-relaxed">Panduan mencatat riwayat perbaikan kerusakan, suku cadang yang diganti, serta penjadwalan perawatan rutin.</p>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-xl p-6 hover:border-[#014285] transition-all hover:shadow-md cursor-pointer group">
              <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center mb-5 text-[#014285] group-hover:bg-[#014285] group-hover:text-white transition-colors">
                <ClipboardList size={22} strokeWidth={1.5} />
              </div>
              <h3 className="text-base font-bold text-[#022B5F] mb-2">Proses Stock Opname</h3>
              <p className="text-sm text-gray-500 leading-relaxed">Langkah-langkah melakukan stock opname akhir tahun secara sistematis dan pencocokan data fisik dengan sistem.</p>
            </div>
          </div>
          
          <div className="bg-[#022B5F] rounded-xl p-8 mt-6 flex flex-col sm:flex-row items-center justify-between text-white shadow-lg relative overflow-hidden">
            <div className="absolute right-0 top-0 opacity-10 pointer-events-none translate-x-1/4 -translate-y-1/4">
              <svg width="200" height="200" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div className="relative z-10 text-center sm:text-left mb-6 sm:mb-0">
              <h3 className="text-lg font-bold mb-1">Unduh Buku Panduan Lengkap</h3>
              <p className="text-sm text-blue-100 max-w-lg">Dapatkan panduan komprehensif seluruh fitur dalam satu dokumen PDF (Versi 2.1, Ukuran 2.4 MB)</p>
            </div>
            <button className="relative z-10 flex items-center gap-2 bg-white text-[#022B5F] px-5 py-2.5 rounded-lg text-sm hover:bg-gray-50 transition-colors font-bold shadow-md">
              <Download size={18} strokeWidth={2} /> Unduh PDF
            </button>
          </div>
        </div>
      </main>
    );
  }

  if (page === "hubungi-dukungan") {
    return (
      <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
        <TopBar breadcrumbs={currentBreadcrumbs} />
        <div className="px-8 py-6 space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-[#022B5F] mb-1">Hubungi Dukungan</h1>
            <p className="text-sm text-gray-500">Butuh bantuan teknis atau menemukan kendala sistem? Tim support kami siap membantu Anda.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
            <div className="bg-white border border-gray-200 rounded-xl p-6 flex flex-col items-center text-center hover:shadow-md transition-shadow">
              <div className="w-14 h-14 rounded-full bg-blue-50 flex items-center justify-center mb-4 text-[#014285]">
                <Headset size={26} strokeWidth={1.5} />
              </div>
              <h3 className="text-base font-bold text-[#022B5F] mb-1">Layanan Helpdesk</h3>
              <p className="text-xs text-gray-500 mb-4 leading-relaxed">Senin - Jumat<br />(08:00 - 16:00 WIB)</p>
              <p className="text-sm font-bold text-[#014285] bg-blue-50 px-4 py-1.5 rounded-full">Ext. 1234</p>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-xl p-6 flex flex-col items-center text-center hover:shadow-md transition-shadow">
              <div className="w-14 h-14 rounded-full bg-green-50 flex items-center justify-center mb-4 text-green-600">
                <MessageSquare size={26} strokeWidth={1.5} />
              </div>
              <h3 className="text-base font-bold text-[#022B5F] mb-1">WhatsApp</h3>
              <p className="text-xs text-gray-500 mb-4 leading-relaxed">Fast response untuk kendala urgent & mendesak</p>
              <p className="text-sm font-bold text-green-600 bg-green-50 px-4 py-1.5 rounded-full">+62 811-2233-4455</p>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-xl p-6 flex flex-col items-center text-center hover:shadow-md transition-shadow">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center mb-4 text-[#111827]">
                <Bot size={26} strokeWidth={1.5} />
              </div>
              <h3 className="text-base font-bold text-[#022B5F] mb-1">Email IT Support</h3>
              <p className="text-xs text-gray-500 mb-4 leading-relaxed">Laporan kendala detail dengan lampiran screenshot</p>
              <p className="text-sm font-bold text-[#111827] bg-gray-100 px-4 py-1.5 rounded-full">it.sv@apps.ipb.ac.id</p>
            </div>
          </div>
          
          <div className="bg-white border border-gray-200 rounded-xl p-8 shadow-sm">
            <h2 className="text-lg font-bold text-[#022B5F] mb-5 border-b border-gray-100 pb-3">Kirim Pesan Langsung (Tiket)</h2>
            <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-semibold text-[#022B5F] mb-2">Nama Lengkap</label>
                  <input type="text" defaultValue="Salgado Ginting" readOnly className="w-full text-sm border border-gray-200 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-500 outline-none cursor-not-allowed" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#022B5F] mb-2">Kategori Kendala</label>
                  <select className="w-full text-sm border border-gray-200 rounded-lg px-4 py-2.5 bg-white text-[#022B5F] outline-none focus:border-[#014285] focus:ring-1 focus:ring-[#014285]">
                    <option>Sistem Error / Bug (Aplikasi crash)</option>
                    <option>Permintaan Fitur Baru / Perubahan</option>
                    <option>Kendala Login & Akses Pengguna</option>
                    <option>Pertanyaan Umum & Panduan Penggunaan</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#022B5F] mb-2">Detail Pesan & Kronologi</label>
                <textarea rows={5} placeholder="Jelaskan langkah-langkah terjadinya kendala secara detail..." className="w-full text-sm border border-gray-200 rounded-lg px-4 py-3 bg-white text-gray-800 outline-none focus:border-[#014285] focus:ring-1 focus:ring-[#014285] resize-none"></textarea>
              </div>
              <div className="flex items-center justify-between pt-2">
                <p className="text-xs text-gray-400">Tim kami biasanya merespons dalam 1x24 jam kerja.</p>
                <button type="submit" className="flex items-center gap-2 px-5 py-2.5 text-white text-sm font-semibold rounded-lg transition-all shadow-sm hover:shadow bg-[#014285] hover:bg-[#022B5F]">
                  <Send size={16} /> Buat Tiket Dukungan
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>
    );
  }

  // Final fallback — show Dashboard
  return <DashboardFreeSpace topBar={<TopBar breadcrumbs={["Dashboard"]} />} />;
}

// ── Toast Container ───────────────────────────────────────────────────────────
function ToastContainer() {
  const { toasts } = useApp();
  if (!toasts.length) return null;
  return (
    <div className="fixed bottom-6 right-6 z-[200] flex flex-col gap-2 pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`flex items-center gap-3 px-4 py-3 rounded-xl text-white text-sm font-medium shadow-xl animate-in slide-in-from-bottom-2 duration-300 pointer-events-auto min-w-[260px] ${
            t.type === "success" ? "bg-green-500" : t.type === "error" ? "bg-red-500" : "bg-blue-500"
          }`}
        >
          <span className="text-base shrink-0">
            {t.type === "success" ? "✓" : t.type === "error" ? "✗" : "ℹ"}
          </span>
          <span className="flex-1">{t.message}</span>
        </div>
      ))}
    </div>
  );
}

// ── App ───────────────────────────────────────────────────────────────────────
function AppContent() {
  const [page, setPage] = useState("dashboard");
  return (
    <div className="flex h-screen w-full bg-white overflow-hidden">
      <Sidebar page={page} setPage={setPage} />
      <MainContent page={page} />
      <ToastContainer />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <DataStoreProvider>
        <AppContent />
      </DataStoreProvider>
    </AppProvider>
  );
}