import React, { useState } from "react";
import {
  Plus, Tag, Search, ChevronDown, X, Clock, RefreshCw, Bell,
  MoreHorizontal, CheckCircle2, Circle, ChevronLeft, ChevronRight,
  Calendar, List, Check, Trash2, Edit3, Copy, CalendarDays,
  AlertCircle, Repeat, BellRing, Filter,
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────
type Priority = "Tinggi" | "Sedang" | "Rendah";
type Status = "Berjalan" | "Belum Mulai" | "Selesai" | "Terlambat" | "Dibatalkan";
type Kategori = "Belajar" | "Keuangan" | "Membaca" | "Jurnal" | "Pribadi" | "Kesehatan";

interface Aktivitas {
  id: number;
  judul: string;
  jamMulai: string;
  jamSelesai: string;
  kategori: Kategori;
  prioritas: Priority;
  status: Status;
  berulang?: boolean;
  reminder?: boolean;
  deskripsi?: string;
  sesi: "Pagi" | "Sore" | "Malam";
}

// ── Data Simulasi ─────────────────────────────────────────────────────────────
const INIT_AKTIVITAS: Aktivitas[] = [
  { id: 1, judul: "Review materi Akuntansi Keuangan", jamMulai: "09.00", jamSelesai: "10.00", kategori: "Belajar", prioritas: "Tinggi", status: "Berjalan", berulang: true, reminder: true, sesi: "Pagi", deskripsi: "Review bab 3–4 sebelum ujian pekan depan." },
  { id: 2, judul: "Mengerjakan latihan TOEFL", jamMulai: "11.00", jamSelesai: "12.00", kategori: "Belajar", prioritas: "Sedang", status: "Belum Mulai", berulang: false, reminder: false, sesi: "Pagi", deskripsi: "Latihan section Reading dan Listening." },
  { id: 3, judul: "Input pengeluaran harian", jamMulai: "17.00", jamSelesai: "17.15", kategori: "Keuangan", prioritas: "Tinggi", status: "Belum Mulai", berulang: true, reminder: true, sesi: "Sore", deskripsi: "Catat semua transaksi ke aplikasi keuangan." },
  { id: 4, judul: "Membaca buku 20 halaman", jamMulai: "19.00", jamSelesai: "20.00", kategori: "Membaca", prioritas: "Sedang", status: "Belum Mulai", berulang: false, reminder: false, sesi: "Malam", deskripsi: "Target buku: Atomic Habits." },
  { id: 5, judul: "Tulis jurnal harian", jamMulai: "21.00", jamSelesai: "21.20", kategori: "Jurnal", prioritas: "Rendah", status: "Belum Mulai", berulang: true, reminder: false, sesi: "Malam", deskripsi: "Refleksi dan rencana besok." },
];

const SELESAI_LIST = [
  { id: 10, judul: "Sarapan dan persiapan kuliah", jadwal: "07.00", selesaiPada: "07.40", kategori: "Pribadi" as Kategori, tgl: "Hari Ini" },
  { id: 11, judul: "Merapikan catatan kuliah", jadwal: "08.00", selesaiPada: "08.35", kategori: "Belajar" as Kategori, tgl: "Hari Ini" },
  { id: 12, judul: "Review transaksi kemarin", jadwal: "09.00", selesaiPada: "09.20", kategori: "Keuangan" as Kategori, tgl: "2 Jul 2026" },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
const PRIORITAS_CFG: Record<Priority, { color: string; bg: string }> = {
  Tinggi: { color: "#EF4444", bg: "#FEE2E2" },
  Sedang: { color: "#F59E0B", bg: "#FEF3C7" },
  Rendah: { color: "#6B7280", bg: "#F3F4F6" },
};

const STATUS_CFG: Record<Status, { color: string; bg: string; label: string }> = {
  Berjalan:    { color: "#3B82F6", bg: "#DBEAFE", label: "Berjalan" },
  "Belum Mulai":{ color: "#6B7280", bg: "#F3F4F6", label: "Belum Mulai" },
  Selesai:     { color: "#22C55E", bg: "#DCFCE7", label: "Selesai" },
  Terlambat:   { color: "#EF4444", bg: "#FEE2E2", label: "Terlambat" },
  Dibatalkan:  { color: "#9CA3AF", bg: "#F3F4F6", label: "Dibatalkan" },
};

const KATEGORI_CFG: Record<Kategori, { color: string; bg: string }> = {
  Belajar:  { color: "#3B82F6", bg: "#DBEAFE" },
  Keuangan: { color: "#22C55E", bg: "#DCFCE7" },
  Membaca:  { color: "#8B5CF6", bg: "#EDE9FE" },
  Jurnal:   { color: "#F59E0B", bg: "#FEF3C7" },
  Pribadi:  { color: "#6B7280", bg: "#F3F4F6" },
  Kesehatan:{ color: "#0D9488", bg: "#CCFBF1" },
};

// ── Badges ────────────────────────────────────────────────────────────────────
function PrioritasBadge({ p }: { p: Priority }) {
  const c = PRIORITAS_CFG[p];
  return (
    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
      style={{ color: c.color, backgroundColor: c.bg }}>{p}</span>
  );
}

function StatusBadge({ s }: { s: Status }) {
  const c = STATUS_CFG[s];
  return (
    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
      style={{ color: c.color, backgroundColor: c.bg }}>{c.label}</span>
  );
}

function KategoriBadge({ k }: { k: Kategori }) {
  const c = KATEGORI_CFG[k];
  return (
    <span className="text-[10px] font-medium px-2 py-0.5 rounded-full"
      style={{ color: c.color, backgroundColor: c.bg }}>{k}</span>
  );
}

// ── Summary Card ──────────────────────────────────────────────────────────────
function SummaryCard({ label, value, desc, color, icon: Icon }: {
  label: string; value: string | number; desc: string;
  color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
          style={{ backgroundColor: color + "18", color }}>
          <Icon size={16} />
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
      <p className="text-[11px] text-gray-400 leading-snug">{desc}</p>
    </div>
  );
}

// ── Aktivitas Item ─────────────────────────────────────────────────────────────
function AktivitasItem({ item, onCheck, onDetail, onDelete }: {
  item: Aktivitas;
  onCheck: (id: number) => void;
  onDetail: (item: Aktivitas) => void;
  onDelete: (id: number) => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const done = item.status === "Selesai";

  return (
    <div className={`bg-white border rounded-xl px-4 py-3 flex items-center gap-3 hover:border-gray-300 transition-all ${done ? "opacity-60" : "border-gray-200"}`}>
      <button onClick={() => onCheck(item.id)} className="shrink-0 mt-0.5">
        {done
          ? <CheckCircle2 size={18} className="text-green-500" />
          : <Circle size={18} className="text-gray-300 hover:text-gray-500 transition-colors" />
        }
      </button>

      <div className="flex-1 min-w-0 cursor-pointer" onClick={() => onDetail(item)}>
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`text-sm font-medium text-gray-900 ${done ? "line-through text-gray-400" : ""}`}>
            {item.judul}
          </span>
          {item.berulang && <Repeat size={11} className="text-gray-400 shrink-0" />}
          {item.reminder && <BellRing size={11} className="text-amber-400 shrink-0" />}
        </div>
        <div className="flex items-center gap-2 mt-1 flex-wrap">
          <span className="text-xs text-gray-400 flex items-center gap-1">
            <Clock size={10} /> {item.jamMulai}–{item.jamSelesai}
          </span>
          <KategoriBadge k={item.kategori} />
          <PrioritasBadge p={item.prioritas} />
          <StatusBadge s={item.status} />
        </div>
      </div>

      <div className="relative shrink-0">
        <button onClick={() => setMenuOpen(!menuOpen)}
          className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-400">
          <MoreHorizontal size={15} />
        </button>
        {menuOpen && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
            <div className="absolute right-0 top-full mt-1 w-44 bg-white border border-gray-200 rounded-xl shadow-lg z-20 py-1 overflow-hidden">
              {[
                { label: "Lihat Detail", icon: AlertCircle, action: () => { onDetail(item); setMenuOpen(false); } },
                { label: "Tandai Selesai", icon: Check, action: () => { onCheck(item.id); setMenuOpen(false); } },
                { label: "Duplikat", icon: Copy, action: () => setMenuOpen(false) },
                { label: "Jadwalkan Ulang", icon: CalendarDays, action: () => setMenuOpen(false) },
                { label: "Hapus", icon: Trash2, action: () => { onDelete(item.id); setMenuOpen(false); }, danger: true },
              ].map(m => (
                <button key={m.label} onClick={m.action}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs transition-colors ${
                    m.danger ? "text-red-600 hover:bg-red-50" : "text-gray-700 hover:bg-gray-50"
                  }`}>
                  <m.icon size={13} /> {m.label}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ── Calendar View ─────────────────────────────────────────────────────────────
function CalendarView({ aktivitas }: { aktivitas: Aktivitas[] }) {
  const days = [
    { label: "Sen", date: 29, month: "Jun" },
    { label: "Sel", date: 30, month: "Jun" },
    { label: "Rab", date: 1,  month: "Jul" },
    { label: "Kam", date: 2,  month: "Jul" },
    { label: "Jum", date: 3,  month: "Jul", today: true },
    { label: "Sab", date: 4,  month: "Jul" },
    { label: "Min", date: 5,  month: "Jul" },
  ];

  const hours = ["08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22"];

  const EVENT_COLOR: Record<Kategori, string> = {
    Belajar:  "#3B82F6",
    Keuangan: "#22C55E",
    Membaca:  "#8B5CF6",
    Jurnal:   "#F59E0B",
    Pribadi:  "#6B7280",
    Kesehatan:"#0D9488",
  };

  function getTopPct(jam: string) {
    const [h, m] = jam.split(".").map(Number);
    return ((h - 8) * 60 + m) / (15 * 60) * 100;
  }
  function getHeightPct(mulai: string, selesai: string) {
    const [h1, m1] = mulai.split(".").map(Number);
    const [h2, m2] = selesai.split(".").map(Number);
    const dur = (h2 * 60 + m2) - (h1 * 60 + m1);
    return (dur / (15 * 60)) * 100;
  }

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-100">
        <div className="flex gap-1">
          <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors"><ChevronLeft size={15} /></button>
          <button className="px-3 py-1.5 text-xs font-semibold text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">Hari Ini</button>
          <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors"><ChevronRight size={15} /></button>
        </div>
        <span className="text-sm font-semibold text-gray-800">29 Jun – 5 Jul 2026</span>
        <div className="ml-auto flex gap-1">
          {["Hari", "Minggu", "Bulan"].map(v => (
            <button key={v}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${v === "Minggu" ? "bg-gray-900 text-white" : "text-gray-500 hover:bg-gray-100"}`}>
              {v}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="flex overflow-x-auto">
        {/* Time col */}
        <div className="w-14 shrink-0 pt-10 border-r border-gray-100">
          {hours.map(h => (
            <div key={h} className="h-14 flex items-start px-2 pt-1">
              <span className="text-[10px] text-gray-400 font-mono">{h}:00</span>
            </div>
          ))}
        </div>

        {/* Day columns */}
        {days.map((day) => (
          <div key={day.label} className="flex-1 min-w-[100px] relative">
            {/* Day header */}
            <div className={`h-10 flex flex-col items-center justify-center border-b border-r border-gray-100 ${day.today ? "bg-gray-900 text-white" : "bg-white"}`}>
              <span className={`text-[10px] font-semibold ${day.today ? "text-gray-300" : "text-gray-400"}`}>{day.label}</span>
              <span className={`text-sm font-bold ${day.today ? "text-white" : "text-gray-700"}`}>{day.date}</span>
            </div>
            {/* Hour rows */}
            <div className="relative border-r border-gray-100">
              {hours.map(h => (
                <div key={h} className="h-14 border-b border-gray-50" />
              ))}
              {/* Events on Jumat only */}
              {day.today && aktivitas.map(a => (
                <div key={a.id}
                  className="absolute left-1 right-1 rounded-md px-1.5 py-0.5 overflow-hidden"
                  style={{
                    top: `${40 + getTopPct(a.jamMulai)}%`,
                    height: `${Math.max(getHeightPct(a.jamMulai, a.jamSelesai), 4)}%`,
                    backgroundColor: EVENT_COLOR[a.kategori] + "22",
                    borderLeft: `2px solid ${EVENT_COLOR[a.kategori]}`,
                  }}>
                  <span className="text-[9px] font-semibold truncate block" style={{ color: EVENT_COLOR[a.kategori] }}>
                    {a.judul}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Modal Tambah Aktivitas ────────────────────────────────────────────────────
function TambahAktivitasModal({ onClose, onSave }: {
  onClose: () => void;
  onSave: (data: Partial<Aktivitas>) => void;
}) {
  const [judul, setJudul] = useState("");
  const [deskripsi, setDeskripsi] = useState("");
  const [tanggal, setTanggal] = useState("2026-07-03");
  const [jamMulai, setJamMulai] = useState("09:00");
  const [jamSelesai, setJamSelesai] = useState("10:00");
  const [allDay, setAllDay] = useState(false);
  const [kategori, setKategori] = useState<Kategori>("Belajar");
  const [prioritas, setPrioritas] = useState<Priority>("Sedang");
  const [reminder, setReminder] = useState("1 hari sebelumnya");
  const [berulang, setBerulang] = useState(false);
  const [frekuensi, setFrekuensi] = useState("Harian");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!judul.trim()) e.judul = "Nama aktivitas wajib diisi.";
    if (!tanggal) e.tanggal = "Tanggal wajib diisi.";
    if (!allDay && jamSelesai <= jamMulai) e.waktu = "Waktu selesai tidak boleh lebih awal dari waktu mulai.";
    return e;
  };

  const handleSave = () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setSaving(true);
    setTimeout(() => {
      onSave({ judul, deskripsi, kategori, prioritas, berulang, reminder: reminder !== "Tidak ada" });
      onClose();
    }, 700);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-0 right-0 h-screen w-[480px] bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-300">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Tambah Aktivitas</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {/* Nama */}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Nama Aktivitas <span className="text-red-500">*</span></label>
            <input value={judul} onChange={e => setJudul(e.target.value)} placeholder="Nama aktivitas..."
              className={`w-full text-sm px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-gray-300 ${errors.judul ? "border-red-300" : "border-gray-200"}`} />
            {errors.judul && <p className="text-[11px] text-red-500 mt-1">{errors.judul}</p>}
          </div>

          {/* Deskripsi */}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Deskripsi</label>
            <textarea value={deskripsi} onChange={e => setDeskripsi(e.target.value)} rows={2}
              placeholder="Deskripsi singkat..."
              className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none" />
          </div>

          {/* Tanggal */}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Tanggal <span className="text-red-500">*</span></label>
            <input type="date" value={tanggal} onChange={e => setTanggal(e.target.value)}
              className={`w-full text-sm px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-gray-300 ${errors.tanggal ? "border-red-300" : "border-gray-200"}`} />
          </div>

          {/* All-day + waktu */}
          <div className="flex items-center gap-2 mb-1">
            <input type="checkbox" id="allday" checked={allDay} onChange={e => setAllDay(e.target.checked)} className="rounded" />
            <label htmlFor="allday" className="text-xs text-gray-600">Sepanjang hari</label>
          </div>
          {!allDay && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Mulai</label>
                <input type="time" value={jamMulai} onChange={e => setJamMulai(e.target.value)}
                  className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Selesai</label>
                <input type="time" value={jamSelesai} onChange={e => setJamSelesai(e.target.value)}
                  className={`w-full text-sm px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-gray-300 ${errors.waktu ? "border-red-300" : "border-gray-200"}`} />
              </div>
              {errors.waktu && <p className="col-span-2 text-[11px] text-red-500">{errors.waktu}</p>}
            </div>
          )}

          {/* Kategori & Prioritas */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Kategori</label>
              <select value={kategori} onChange={e => setKategori(e.target.value as Kategori)}
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                {["Belajar","Keuangan","Membaca","Jurnal","Pribadi","Kesehatan"].map(k => <option key={k}>{k}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Prioritas</label>
              <select value={prioritas} onChange={e => setPrioritas(e.target.value as Priority)}
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                {["Rendah","Sedang","Tinggi"].map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
          </div>

          {/* Pengingat */}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Pengingat</label>
            <select value={reminder} onChange={e => setReminder(e.target.value)}
              className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
              {["Saat kegiatan dimulai","10 menit sebelumnya","30 menit sebelumnya","1 jam sebelumnya","1 hari sebelumnya","Tidak ada"].map(r => <option key={r}>{r}</option>)}
            </select>
          </div>

          {/* Berulang */}
          <div className="border border-gray-200 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-gray-700">Ulangi Aktivitas</span>
              <button onClick={() => setBerulang(!berulang)}
                className={`w-9 h-5 rounded-full transition-colors relative ${berulang ? "bg-gray-900" : "bg-gray-200"}`}>
                <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${berulang ? "left-[18px]" : "left-0.5"}`} />
              </button>
            </div>
            {berulang && (
              <div className="space-y-2">
                <select value={frekuensi} onChange={e => setFrekuensi(e.target.value)}
                  className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                  {["Harian","Mingguan","Bulanan","Custom"].map(f => <option key={f}>{f}</option>)}
                </select>
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Berakhir pada</label>
                  <input type="date" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <button onClick={handleSave} disabled={saving}
            className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-70 flex items-center gap-2">
            {saving ? <><RefreshCw size={13} className="animate-spin" /> Menyimpan...</> : "Simpan Aktivitas"}
          </button>
        </div>
      </div>
    </>
  );
}

// ── Detail Drawer ─────────────────────────────────────────────────────────────
function DetailDrawer({ item, onClose, onCheck }: {
  item: Aktivitas; onClose: () => void; onCheck: (id: number) => void;
}) {
  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/30" onClick={onClose} />
      <div className="fixed top-0 right-0 h-screen w-[380px] bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-300">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900 truncate flex-1 mr-2">{item.judul}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 shrink-0"><X size={16} /></button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          <div className="flex gap-2 flex-wrap">
            <StatusBadge s={item.status} />
            <PrioritasBadge p={item.prioritas} />
            <KategoriBadge k={item.kategori} />
          </div>

          {[
            { label: "Tanggal", value: "Jumat, 3 Juli 2026" },
            { label: "Waktu", value: `${item.jamMulai} – ${item.jamSelesai}` },
            { label: "Durasi", value: "1 jam" },
            { label: "Pengingat", value: item.reminder ? "1 hari sebelumnya" : "Tidak ada" },
            { label: "Berulang", value: item.berulang ? "Ya — Harian" : "Tidak" },
          ].map(r => (
            <div key={r.label} className="flex justify-between py-2 border-b border-gray-50">
              <span className="text-xs text-gray-500">{r.label}</span>
              <span className="text-xs font-medium text-gray-800">{r.value}</span>
            </div>
          ))}

          {item.deskripsi && (
            <div>
              <p className="text-xs font-medium text-gray-700 mb-1">Deskripsi</p>
              <p className="text-sm text-gray-600 leading-relaxed">{item.deskripsi}</p>
            </div>
          )}

          <div>
            <p className="text-xs font-medium text-gray-700 mb-2">Riwayat Perubahan</p>
            <div className="text-xs text-gray-400 bg-gray-50 rounded-lg p-3">Dibuat hari ini, 03 Jul 2026</div>
          </div>
        </div>

        <div className="px-5 py-4 border-t border-gray-100 space-y-2">
          <button onClick={() => onCheck(item.id)}
            className="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-semibold text-white bg-gray-900 rounded-xl hover:bg-black transition-colors">
            <Check size={15} /> Tandai Selesai
          </button>
          <div className="flex gap-2">
            <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
              <Edit3 size={12} /> Edit
            </button>
            <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
              <CalendarDays size={12} /> Jadwalkan Ulang
            </button>
            <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-red-500 border border-red-100 rounded-lg hover:bg-red-50 transition-colors">
              <Trash2 size={12} /> Hapus
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
type TabView = "daftar" | "kalender" | "selesai";

export function ProduktivitasAktivitasPage({ topBar }: { topBar?: React.ReactNode }) {
  const [tab, setTab] = useState<TabView>("daftar");
  const [aktivitas, setAktivitas] = useState<Aktivitas[]>(INIT_AKTIVITAS);
  const [search, setSearch] = useState("");
  const [filterKategori, setFilterKategori] = useState("Semua Kategori");
  const [filterPrioritas, setFilterPrioritas] = useState("Semua Prioritas");
  const [filterStatus, setFilterStatus] = useState("Semua Status");
  const [showModal, setShowModal] = useState(false);
  const [detailItem, setDetailItem] = useState<Aktivitas | null>(null);

  const handleCheck = (id: number) => {
    setAktivitas(prev => prev.map(a =>
      a.id === id ? { ...a, status: a.status === "Selesai" ? "Belum Mulai" : "Selesai" } : a
    ));
  };

  const handleDelete = (id: number) => {
    setAktivitas(prev => prev.filter(a => a.id !== id));
  };

  const handleSave = (data: Partial<Aktivitas>) => {
    const newId = Date.now();
    setAktivitas(prev => [...prev, {
      id: newId,
      judul: data.judul || "Aktivitas Baru",
      jamMulai: "09.00", jamSelesai: "10.00",
      kategori: data.kategori || "Pribadi",
      prioritas: data.prioritas || "Sedang",
      status: "Belum Mulai",
      berulang: data.berulang,
      reminder: data.reminder,
      sesi: "Pagi",
    }]);
  };

  const selesaiCount = aktivitas.filter(a => a.status === "Selesai").length;
  const belumCount = aktivitas.filter(a => a.status !== "Selesai" && a.status !== "Dibatalkan").length;
  const berulangCount = aktivitas.filter(a => a.berulang).length;

  const filtered = aktivitas.filter(a => {
    const q = search.toLowerCase();
    const matchQ = a.judul.toLowerCase().includes(q);
    const matchK = filterKategori === "Semua Kategori" || a.kategori === filterKategori;
    const matchP = filterPrioritas === "Semua Prioritas" || a.prioritas === filterPrioritas;
    const matchS = filterStatus === "Semua Status" || a.status === filterStatus;
    return matchQ && matchK && matchP && matchS;
  }).filter(a => a.status !== "Selesai");

  const sesiGroups: { label: "Pagi" | "Sore" | "Malam"; items: Aktivitas[] }[] = [
    { label: "Pagi",  items: filtered.filter(a => a.sesi === "Pagi") },
    { label: "Sore",  items: filtered.filter(a => a.sesi === "Sore") },
    { label: "Malam", items: filtered.filter(a => a.sesi === "Malam") },
  ].filter(g => g.items.length > 0);

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Page Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Aktivitas</h1>
            <p className="text-xs text-gray-500 mt-0.5">Kelola jadwal, prioritas, dan aktivitas harian Anda.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
              <Tag size={13} /> Atur Kategori
            </button>
            <button onClick={() => setShowModal(true)}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors shadow-sm">
              <Plus size={13} /> Tambah Aktivitas
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <SummaryCard label="Agenda Hari Ini" value={aktivitas.length} desc={`${selesaiCount} aktivitas telah selesai`} color="#111827" icon={CalendarDays} />
          <SummaryCard label="Belum Selesai" value={belumCount} desc="Masih perlu diselesaikan hari ini" color="#F59E0B" icon={Clock} />
          <SummaryCard label="Deadline Terdekat" value="Besok" desc="Tugas Akuntansi Keuangan" color="#EF4444" icon={AlertCircle} />
          <SummaryCard label="Aktivitas Berulang" value={berulangCount} desc="Aktif pada minggu ini" color="#6B7280" icon={Repeat} />
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {([["daftar","Daftar",List], ["kalender","Kalender",Calendar], ["selesai","Selesai",CheckCircle2]] as const).map(([id, label, Icon]) => (
            <button key={id} onClick={() => setTab(id as TabView)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${tab === id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              <Icon size={13} /> {label}
            </button>
          ))}
        </div>

        {/* Filter Toolbar — Daftar tab */}
        {tab === "daftar" && (
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative flex-1 min-w-[180px]">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari aktivitas..."
                className="w-full pl-8 pr-3 py-2 text-sm border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 bg-white" />
            </div>
            <select value={filterKategori} onChange={e => setFilterKategori(e.target.value)}
              className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 outline-none">
              <option>Semua Kategori</option>
              {["Belajar","Keuangan","Membaca","Jurnal","Pribadi","Kesehatan"].map(k => <option key={k}>{k}</option>)}
            </select>
            <select value={filterPrioritas} onChange={e => setFilterPrioritas(e.target.value)}
              className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 outline-none">
              <option>Semua Prioritas</option>
              {["Tinggi","Sedang","Rendah"].map(p => <option key={p}>{p}</option>)}
            </select>
            <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
              className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 outline-none">
              <option>Semua Status</option>
              {["Berjalan","Belum Mulai","Terlambat"].map(s => <option key={s}>{s}</option>)}
            </select>
            <button onClick={() => { setSearch(""); setFilterKategori("Semua Kategori"); setFilterPrioritas("Semua Prioritas"); setFilterStatus("Semua Status"); }}
              className="text-xs text-gray-500 hover:text-gray-700 px-2 py-2 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors flex items-center gap-1">
              <Filter size={12} /> Reset
            </button>
          </div>
        )}

        {/* Tab Content */}
        {tab === "daftar" && (
          <div className="space-y-5">
            {sesiGroups.length === 0 ? (
              <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
                <CalendarDays size={32} className="text-gray-200 mx-auto mb-3" />
                <p className="text-sm font-semibold text-gray-700 mb-1">Belum ada aktivitas</p>
                <p className="text-xs text-gray-400 mb-4">Tambahkan aktivitas pertama untuk mulai menyusun jadwal Anda.</p>
                <button onClick={() => setShowModal(true)}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
                  <Plus size={13} /> Tambah Aktivitas
                </button>
              </div>
            ) : (
              sesiGroups.map(g => (
                <div key={g.label}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{g.label}</span>
                    <div className="flex-1 h-px bg-gray-200" />
                    <span className="text-[10px] text-gray-400">{g.items.length} aktivitas</span>
                  </div>
                  <div className="space-y-2">
                    {g.items.map(a => (
                      <AktivitasItem key={a.id} item={a}
                        onCheck={handleCheck}
                        onDetail={setDetailItem}
                        onDelete={handleDelete}
                      />
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {tab === "kalender" && <CalendarView aktivitas={aktivitas} />}

        {tab === "selesai" && (
          <div className="space-y-4">
            <div className="flex gap-2">
              {["Hari Ini","Minggu Ini","Bulan Ini"].map(f => (
                <button key={f} className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${f === "Hari Ini" ? "bg-gray-900 text-white border-gray-900" : "bg-white border-gray-200 text-gray-600 hover:bg-gray-50"}`}>{f}</button>
              ))}
            </div>
            {SELESAI_LIST.map(s => (
              <div key={s.id} className="bg-white border border-gray-200 rounded-xl px-4 py-3 flex items-center gap-3">
                <CheckCircle2 size={18} className="text-green-500 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-700 line-through">{s.judul}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-xs text-gray-400">{s.tgl} • Dijadwalkan {s.jadwal}</span>
                    <span className="text-[10px] text-green-600 bg-green-50 px-2 py-0.5 rounded-full">Selesai {s.selesaiPada}</span>
                    <KategoriBadge k={s.kategori} />
                  </div>
                </div>
                <button className="text-xs text-gray-500 hover:text-gray-700 px-2 py-1 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors shrink-0">Kembalikan</button>
              </div>
            ))}
          </div>
        )}
      </div>

      {showModal && <TambahAktivitasModal onClose={() => setShowModal(false)} onSave={handleSave} />}
      {detailItem && <DetailDrawer item={detailItem} onClose={() => setDetailItem(null)} onCheck={handleCheck} />}
    </main>
  );
}
