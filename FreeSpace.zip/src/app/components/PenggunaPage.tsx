import React, { useState, useMemo } from "react";
import { useDataStore } from "./DataStore";
import {
  Search, Download, Plus, X, Edit2, Trash2,
  Shield, UserCheck, UserX, Users, User,
  Check, AlertTriangle, Activity,
  Building2, Key, Eye,
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────
type UserRole = "Admin Sistem" | "Operator Aset" | "Pengelola Pengadaan" | "Teknisi" | "Pimpinan" | "Auditor";
type UserStatus = "Aktif" | "Non-Aktif";

interface LoginHistory {
  tgl: string;
  waktu: string;
  ip: string;
  device: string;
  status: "Berhasil" | "Gagal";
}

interface UserRecord {
  id: string;
  nama: string;
  email: string;
  nip: string;
  jabatan: string;
  role: UserRole;
  unit: string;
  status: UserStatus;
  lastLogin: string;
  loginHistory: LoginHistory[];
}

// ── Mock Data ─────────────────────────────────────────────────────────────────
const USERS_DATA: UserRecord[] = [
  {
    id: "U-101",
    nama: "Salgado Ginting",
    email: "salgadoginting@apps.ipb.ac.id",
    nip: "19850112 201001 1 005",
    jabatan: "Kepala Bagian Aset & Umum",
    role: "Admin Sistem",
    unit: "Pusat",
    status: "Aktif",
    lastLogin: "2026-06-01 08:30",
    loginHistory: [
      { tgl: "2026-06-01", waktu: "08:30", ip: "10.0.1.45", device: "Chrome / MacOS",    status: "Berhasil" },
      { tgl: "2026-05-31", waktu: "09:15", ip: "10.0.1.45", device: "Chrome / MacOS",    status: "Berhasil" },
      { tgl: "2026-05-30", waktu: "08:45", ip: "10.0.1.45", device: "Chrome / MacOS",    status: "Berhasil" },
      { tgl: "2026-05-28", waktu: "09:00", ip: "192.168.1.10", device: "Safari / iPhone",  status: "Gagal"    },
    ],
  },
  {
    id: "U-102",
    nama: "Rina Maharani",
    email: "rina.m@apps.ipb.ac.id",
    nip: "19900305 201501 2 008",
    jabatan: "Pengelola Aset",
    role: "Operator Aset",
    unit: "Sekolah Vokasi",
    status: "Aktif",
    lastLogin: "2026-06-01 07:15",
    loginHistory: [
      { tgl: "2026-06-01", waktu: "07:15", ip: "10.0.1.67", device: "Firefox / Windows", status: "Berhasil" },
      { tgl: "2026-05-31", waktu: "07:30", ip: "10.0.1.67", device: "Firefox / Windows", status: "Berhasil" },
    ],
  },
  {
    id: "U-103",
    nama: "Budi Santoso",
    email: "budis@apps.ipb.ac.id",
    nip: "19880720 201201 1 003",
    jabatan: "Teknisi Peralatan",
    role: "Teknisi",
    unit: "Kampus Gunung Gede",
    status: "Non-Aktif",
    lastLogin: "2026-05-28 14:20",
    loginHistory: [
      { tgl: "2026-05-28", waktu: "14:20", ip: "10.0.3.11", device: "Safari / MacOS",    status: "Berhasil" },
      { tgl: "2026-05-27", waktu: "09:00", ip: "10.0.3.11", device: "Safari / MacOS",    status: "Berhasil" },
    ],
  },
  {
    id: "U-104",
    nama: "Anita Wijaya",
    email: "anita.w@apps.ipb.ac.id",
    nip: "19920815 201701 2 011",
    jabatan: "Staf Pengadaan",
    role: "Pengelola Pengadaan",
    unit: "Kampus Gunung Gede",
    status: "Aktif",
    lastLogin: "2026-05-31 09:45",
    loginHistory: [
      { tgl: "2026-05-31", waktu: "09:45", ip: "10.0.2.88", device: "Edge / Windows",    status: "Berhasil" },
      { tgl: "2026-05-19", waktu: "09:45", ip: "10.0.3.22", device: "Edge / Windows",    status: "Berhasil" },
      { tgl: "2026-05-19", waktu: "11:33", ip: "10.0.3.22", device: "Edge / Windows",    status: "Gagal"    },
    ],
  },
  {
    id: "U-105",
    nama: "Dodi Pratama",
    email: "dodip@apps.ipb.ac.id",
    nip: "19951001 202001 1 007",
    jabatan: "Operator Inventaris",
    role: "Operator Aset",
    unit: "Kampus Cilibende",
    status: "Aktif",
    lastLogin: "2026-06-01 08:00",
    loginHistory: [
      { tgl: "2026-06-01", waktu: "08:00", ip: "10.0.2.12", device: "Chrome / Windows",  status: "Berhasil" },
      { tgl: "2026-05-31", waktu: "08:10", ip: "10.0.2.12", device: "Chrome / Windows",  status: "Berhasil" },
    ],
  },
  {
    id: "U-106",
    nama: "Dr. Rudi Hartono",
    email: "rudih@ipb.ac.id",
    nip: "19780215 200501 1 002",
    jabatan: "Wakil Dekan Bidang Umum",
    role: "Pimpinan",
    unit: "Pusat",
    status: "Aktif",
    lastLogin: "2026-05-23 10:00",
    loginHistory: [
      { tgl: "2026-05-23", waktu: "10:00", ip: "10.0.4.22", device: "Chrome / iPad",     status: "Berhasil" },
      { tgl: "2026-05-15", waktu: "08:10", ip: "10.0.4.22", device: "Chrome / iPad",     status: "Berhasil" },
    ],
  },
  {
    id: "U-107",
    nama: "Joko Prayitno",
    email: "jokop@apps.ipb.ac.id",
    nip: "19830610 200901 1 004",
    jabatan: "Pengelola Kendaraan",
    role: "Operator Aset",
    unit: "Kampus Cilibende",
    status: "Aktif",
    lastLogin: "2026-05-25 08:30",
    loginHistory: [
      { tgl: "2026-05-25", waktu: "08:30", ip: "10.0.2.55", device: "Chrome / Windows",  status: "Berhasil" },
    ],
  },
  {
    id: "U-108",
    nama: "Andi Firmansyah",
    email: "andif@apps.ipb.ac.id",
    nip: "19880430 201301 1 006",
    jabatan: "Auditor Aset",
    role: "Auditor",
    unit: "Pusat",
    status: "Aktif",
    lastLogin: "2026-05-20 09:00",
    loginHistory: [
      { tgl: "2026-05-20", waktu: "09:00", ip: "10.0.1.88", device: "Firefox / Linux",   status: "Berhasil" },
    ],
  },
];

// ── Permission Matrix Data ────────────────────────────────────────────────────
const ROLES_DEF: UserRole[] = ["Admin Sistem", "Operator Aset", "Pengelola Pengadaan", "Teknisi", "Pimpinan", "Auditor"];
const MENU_ROWS = [
  "Dashboard",
  "Data Aset",
  "Lokasi & Ruangan",
  "Penanggung Jawab",
  "Mutasi Aset",
  "Perbaikan",
  "Stock Opname",
  "Pengadaan",
  "Dokumen",
  "Aktivitas",
  "Pengguna",
];
const PERM_COLS = ["Lihat", "Tambah", "Edit", "Hapus", "Approve", "Export", "Import"] as const;
type Perm = typeof PERM_COLS[number];

type PermMatrix = Record<UserRole, Record<string, Perm[]>>;

const MATRIX: PermMatrix = {
  "Admin Sistem": Object.fromEntries(MENU_ROWS.map(m => [m, [...PERM_COLS]])) as Record<string, Perm[]>,
  "Operator Aset": {
    "Dashboard":         ["Lihat"],
    "Data Aset":         ["Lihat", "Tambah", "Edit", "Export", "Import"],
    "Lokasi & Ruangan":  ["Lihat", "Tambah", "Edit"],
    "Penanggung Jawab":  ["Lihat", "Edit"],
    "Mutasi Aset":       ["Lihat", "Tambah"],
    "Perbaikan":         ["Lihat", "Tambah", "Edit"],
    "Stock Opname":      ["Lihat", "Tambah", "Edit", "Export"],
    "Pengadaan":         ["Lihat"],
    "Dokumen":           ["Lihat", "Tambah", "Edit", "Export"],
    "Aktivitas":         [],
    "Pengguna":          [],
  },
  "Pengelola Pengadaan": {
    "Dashboard":         ["Lihat"],
    "Data Aset":         ["Lihat"],
    "Lokasi & Ruangan":  ["Lihat"],
    "Penanggung Jawab":  ["Lihat"],
    "Mutasi Aset":       ["Lihat"],
    "Perbaikan":         [],
    "Stock Opname":      [],
    "Pengadaan":         ["Lihat", "Tambah", "Edit", "Approve", "Export", "Import"],
    "Dokumen":           ["Lihat", "Tambah", "Edit", "Export"],
    "Aktivitas":         [],
    "Pengguna":          [],
  },
  "Teknisi": {
    "Dashboard":         ["Lihat"],
    "Data Aset":         ["Lihat"],
    "Lokasi & Ruangan":  ["Lihat"],
    "Penanggung Jawab":  ["Lihat"],
    "Mutasi Aset":       [],
    "Perbaikan":         ["Lihat", "Tambah", "Edit", "Export"],
    "Stock Opname":      ["Lihat", "Tambah", "Edit"],
    "Pengadaan":         [],
    "Dokumen":           ["Lihat"],
    "Aktivitas":         [],
    "Pengguna":          [],
  },
  "Pimpinan": {
    "Dashboard":         ["Lihat", "Export"],
    "Data Aset":         ["Lihat", "Export"],
    "Lokasi & Ruangan":  ["Lihat"],
    "Penanggung Jawab":  ["Lihat"],
    "Mutasi Aset":       ["Lihat", "Approve"],
    "Perbaikan":         ["Lihat", "Approve"],
    "Stock Opname":      ["Lihat", "Approve"],
    "Pengadaan":         ["Lihat", "Approve"],
    "Dokumen":           ["Lihat"],
    "Aktivitas":         ["Lihat"],
    "Pengguna":          ["Lihat"],
  },
  "Auditor": {
    "Dashboard":         ["Lihat", "Export"],
    "Data Aset":         ["Lihat", "Export"],
    "Lokasi & Ruangan":  ["Lihat"],
    "Penanggung Jawab":  ["Lihat"],
    "Mutasi Aset":       ["Lihat", "Export"],
    "Perbaikan":         ["Lihat", "Export"],
    "Stock Opname":      ["Lihat", "Export"],
    "Pengadaan":         ["Lihat", "Export"],
    "Dokumen":           ["Lihat", "Export"],
    "Aktivitas":         ["Lihat", "Export"],
    "Pengguna":          [],
  },
};

// ── Helpers ───────────────────────────────────────────────────────────────────
function fmtDate(s: string): string {
  try {
    return new Date(s).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });
  } catch { return s; }
}

const ROLE_COLOR: Record<UserRole, string> = {
  "Admin Sistem":         "bg-red-100 text-red-700",
  "Operator Aset":        "bg-blue-100 text-blue-700",
  "Pengelola Pengadaan":  "bg-amber-100 text-amber-700",
  "Teknisi":              "bg-orange-100 text-orange-700",
  "Pimpinan":             "bg-purple-100 text-purple-700",
  "Auditor":              "bg-teal-100 text-teal-700",
};

function RoleBadge({ role }: { role: UserRole }) {
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold ${ROLE_COLOR[role]}`}>
      {role}
    </span>
  );
}

function StatusBadge({ status }: { status: UserStatus }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${
      status === "Aktif" ? "bg-green-50 text-green-700 border-green-200" : "bg-gray-100 text-gray-500 border-gray-200"
    }`}>
      {status === "Aktif" ? <UserCheck size={10} /> : <UserX size={10} />}
      {status}
    </span>
  );
}

function initials(nama: string): string {
  return nama.split(" ").map(n => n[0]).join("").substring(0, 2).toUpperCase();
}

// ── User Detail Drawer ────────────────────────────────────────────────────────
function UserDetailDrawer({ user, onClose }: { user: UserRecord; onClose: () => void }) {
  const [detailTab, setDetailTab] = useState<"profil" | "akses" | "histori">("profil");
  const perms = MATRIX[user.role] ?? {};

  return (
    <>
      <div className="fixed inset-0 z-40 bg-gray-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-0 right-0 h-full z-50 w-[480px] bg-white shadow-2xl flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-start gap-3">
          <div className="w-12 h-12 rounded-full bg-gray-900 flex items-center justify-center text-white text-lg font-bold shrink-0">
            {initials(user.nama)}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-base font-bold text-gray-900">{user.nama}</p>
            <p className="text-xs text-gray-500 mt-0.5">{user.jabatan} · {user.unit}</p>
            <div className="flex items-center gap-2 mt-1.5">
              <RoleBadge role={user.role} />
              <StatusBadge status={user.status} />
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 shrink-0">
            <X size={16} />
          </button>
        </div>

        {/* Sub tabs */}
        <div className="flex items-center gap-1 px-4 py-2 border-b border-gray-100">
          {(["profil", "akses", "histori"] as const).map((t) => (
            <button key={t} onClick={() => setDetailTab(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors capitalize ${
                detailTab === t ? "bg-gray-100 text-gray-900" : "text-gray-500 hover:text-gray-700"
              }`}>
              {t === "profil" ? "Profil" : t === "akses" ? "Akses Menu" : "Histori Login"}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {detailTab === "profil" && (
            <>
              <div className="space-y-3">
                {[
                  { label: "ID Pengguna",  value: user.id },
                  { label: "NIP",          value: user.nip },
                  { label: "Email",        value: user.email },
                  { label: "Unit",         value: user.unit },
                  { label: "Login Terakhir",value: user.lastLogin },
                ].map((r) => (
                  <div key={r.label} className="flex items-start gap-4 py-2 border-b border-gray-50 last:border-0">
                    <span className="text-xs text-gray-400 w-32 shrink-0 pt-0.5">{r.label}</span>
                    <span className="text-xs font-medium text-gray-800 flex-1">{r.value}</span>
                  </div>
                ))}
              </div>
              <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 flex items-start gap-3">
                <AlertTriangle size={14} className="text-amber-600 shrink-0 mt-0.5" />
                <p className="text-xs text-amber-700">
                  <span className="font-semibold">Perubahan hak akses akan dicatat dalam audit trail.</span>
                  {" "}Pastikan perubahan role sesuai otorisasi pimpinan terkait.
                </p>
              </div>
            </>
          )}

          {detailTab === "akses" && (
            <div className="space-y-2">
              <p className="text-xs text-gray-500 mb-3">Hak akses berdasarkan role <span className="font-semibold text-gray-700">{user.role}</span>:</p>
              {MENU_ROWS.map((menu) => {
                const menuPerms = perms[menu] ?? [];
                const hasAny = menuPerms.length > 0;
                return (
                  <div key={menu} className={`flex items-center gap-3 p-3 rounded-xl border ${hasAny ? "bg-white border-gray-200" : "bg-gray-50 border-gray-100"}`}>
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${hasAny ? "bg-gray-100" : "bg-gray-50"}`}>
                      {hasAny ? <Check size={12} className="text-green-600" /> : <X size={12} className="text-gray-300" />}
                    </div>
                    <span className={`text-xs flex-1 font-medium ${hasAny ? "text-gray-800" : "text-gray-400"}`}>{menu}</span>
                    <div className="flex flex-wrap gap-1 justify-end">
                      {menuPerms.map((p) => (
                        <span key={p} className="text-[9px] font-bold bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded uppercase">{p}</span>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {detailTab === "histori" && (
            <div className="space-y-2">
              {user.loginHistory.map((h, i) => (
                <div key={i} className={`flex items-center gap-3 p-3 rounded-xl border ${h.status === "Gagal" ? "bg-red-50 border-red-100" : "bg-white border-gray-100"}`}>
                  <div className={`w-2 h-2 rounded-full shrink-0 ${h.status === "Berhasil" ? "bg-green-400" : "bg-red-400"}`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-semibold ${h.status === "Berhasil" ? "text-green-600" : "text-red-600"}`}>{h.status}</span>
                      <span className="text-xs text-gray-500">{fmtDate(h.tgl)} · {h.waktu}</span>
                    </div>
                    <div className="text-[10px] text-gray-400 truncate">{h.ip} · {h.device}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="p-4 border-t border-gray-100 flex gap-2">
          <button className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-gray-900 text-white text-sm font-semibold rounded-xl hover:bg-black transition-colors">
            <Edit2 size={14} /> Edit Pengguna
          </button>
          <button className="px-4 py-2.5 border border-red-100 text-red-400 rounded-xl hover:bg-red-50 transition-colors">
            <Trash2 size={14} />
          </button>
        </div>
      </div>
    </>
  );
}

// ── Permission Matrix Component ───────────────────────────────────────────────
function RolePermMatrix() {
  const [editMode, setEditMode] = useState(false);
  const [localMatrix, setLocalMatrix] = useState<PermMatrix>(MATRIX);

  const togglePerm = (role: UserRole, menu: string, perm: Perm) => {
    setLocalMatrix(prev => {
      const cur = prev[role][menu] ?? [];
      const next = cur.includes(perm) ? cur.filter(p => p !== perm) : [...cur, perm];
      return { ...prev, [role]: { ...prev[role], [menu]: next } };
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 flex items-center gap-2 flex-1 mr-4">
          <AlertTriangle size={14} className="text-amber-600 shrink-0" />
          <p className="text-xs text-amber-700">
            <span className="font-semibold">Perubahan hak akses akan dicatat dalam audit trail.</span>
            {" "}Hanya Admin Sistem yang dapat mengubah permission role.
          </p>
        </div>
        <button
          onClick={() => setEditMode(e => !e)}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors shrink-0 ${
            editMode ? "bg-gray-900 text-white" : "bg-white border border-gray-200 text-gray-700 hover:bg-gray-50"
          }`}>
          {editMode ? <Check size={14} /> : <Edit2 size={14} />}
          {editMode ? "Simpan" : "Edit Permission"}
        </button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full" style={{ minWidth: 900 }}>
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                <th className="text-left py-3 px-4 text-[11px] font-semibold text-gray-500 uppercase tracking-wide w-40 sticky left-0 bg-gray-50 z-10">Menu</th>
                {ROLES_DEF.map((role) => (
                  <th key={role} className="py-3 px-3 text-center">
                    <div className="text-[10px] font-bold text-gray-700 whitespace-nowrap">{role}</div>
                    <div className="flex items-center justify-center gap-0.5 mt-1">
                      {PERM_COLS.map(p => (
                        <span key={p} className="text-[8px] text-gray-400 font-medium">{p.slice(0, 2)}</span>
                      ))}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {MENU_ROWS.map((menu, ri) => (
                <tr key={menu} className={`border-b border-gray-50 ${ri % 2 === 0 ? "" : "bg-gray-50/30"}`}>
                  <td className="py-3 px-4 text-xs font-medium text-gray-700 whitespace-nowrap sticky left-0 bg-inherit z-10">
                    {menu}
                  </td>
                  {ROLES_DEF.map((role) => {
                    const rolePerms = localMatrix[role][menu] ?? [];
                    return (
                      <td key={role} className="py-3 px-3">
                        <div className="flex items-center justify-center gap-0.5">
                          {PERM_COLS.map((p) => {
                            const has = rolePerms.includes(p);
                            const isAdmin = role === "Admin Sistem";
                            return (
                              <button
                                key={p}
                                disabled={!editMode || isAdmin}
                                onClick={() => togglePerm(role, menu, p)}
                                title={p}
                                className={`w-5 h-5 rounded flex items-center justify-center text-[9px] font-bold transition-colors ${
                                  has
                                    ? isAdmin ? "bg-gray-900 text-white cursor-default" : "bg-gray-800 text-white hover:bg-gray-700"
                                    : editMode && !isAdmin ? "bg-gray-100 text-gray-300 hover:bg-gray-200" : "bg-transparent text-gray-200"
                                }`}>
                                {has ? "✓" : "·"}
                              </button>
                            );
                          })}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 border-t border-gray-100 bg-gray-50/50">
          <div className="flex items-center gap-4 text-[10px] text-gray-400">
            <span className="font-semibold text-gray-500">Legenda:</span>
            {PERM_COLS.map(p => (
              <span key={p}><span className="font-mono font-bold">{p.slice(0, 2)}</span> = {p}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Unit Pengguna Tab ─────────────────────────────────────────────────────────
function UnitPenggunaTab({ users }: { users: UserRecord[] }) {
  const byUnit = useMemo(() => {
    const map: Record<string, UserRecord[]> = {};
    users.forEach(u => {
      if (!map[u.unit]) map[u.unit] = [];
      map[u.unit].push(u);
    });
    return map;
  }, [users]);

  return (
    <div className="grid grid-cols-2 gap-4">
      {Object.entries(byUnit).sort((a, b) => b[1].length - a[1].length).map(([unit, unitUsers]) => (
        <div key={unit} className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-5 py-3 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building2 size={14} className="text-gray-500" />
              <span className="text-sm font-semibold text-gray-800">{unit}</span>
            </div>
            <span className="text-xs font-bold text-gray-500">{unitUsers.length} pengguna</span>
          </div>
          <div className="divide-y divide-gray-50">
            {unitUsers.map(u => (
              <div key={u.id} className="flex items-center gap-3 px-5 py-3">
                <div className="w-8 h-8 rounded-full bg-gray-900 flex items-center justify-center text-white text-xs font-bold shrink-0">
                  {initials(u.nama)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-800 truncate">{u.nama}</p>
                  <p className="text-[10px] text-gray-400 truncate">{u.jabatan}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <RoleBadge role={u.role} />
                  <StatusBadge status={u.status} />
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Login History Tab ─────────────────────────────────────────────────────────
function AktivitasLoginTab({ users }: { users: UserRecord[] }) {
  const allLogins = useMemo(() => {
    return users.flatMap(u => u.loginHistory.map(h => ({ ...h, nama: u.nama, role: u.role })))
      .sort((a, b) => `${b.tgl} ${b.waktu}`.localeCompare(`${a.tgl} ${a.waktu}`));
  }, [users]);

  const gagal = allLogins.filter(h => h.status === "Gagal").length;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Total Sesi Login",  value: allLogins.filter(h => h.status === "Berhasil").length, color: "#22C55E" },
          { label: "Login Gagal",       value: gagal,                                                  color: "#EF4444" },
          { label: "Pengguna Unik",     value: new Set(allLogins.map(h => h.nama)).size,               color: "#111827" },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
            <p className="text-xs text-gray-500 mb-2">{s.label}</p>
            <p className="text-2xl font-bold" style={{ color: s.color }}>{s.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-100 bg-gray-50/70">
              {["Pengguna", "Role", "Tanggal", "Waktu", "IP Address", "Device", "Status"].map(h => (
                <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {allLogins.map((h, i) => (
              <tr key={i} className={`border-b border-gray-50 hover:bg-gray-50 transition-colors ${h.status === "Gagal" ? "bg-red-50/30" : ""}`}>
                <td className="py-3 px-4 text-sm font-medium text-gray-800 whitespace-nowrap">{h.nama}</td>
                <td className="py-3 px-4"><RoleBadge role={h.role} /></td>
                <td className="py-3 px-4 text-xs text-gray-600 whitespace-nowrap">{fmtDate(h.tgl)}</td>
                <td className="py-3 px-4 text-xs font-mono text-gray-600 whitespace-nowrap">{h.waktu} WIB</td>
                <td className="py-3 px-4 text-xs font-mono text-gray-500 whitespace-nowrap">{h.ip}</td>
                <td className="py-3 px-4 text-xs text-gray-500 whitespace-nowrap">{h.device}</td>
                <td className="py-3 px-4">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                    h.status === "Berhasil" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                  }`}>{h.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Add User Modal ────────────────────────────────────────────────────────────
function AddUserModal({ onClose }: { onClose: () => void }) {
  const [nama, setNama]       = useState("");
  const [email, setEmail]     = useState("");
  const [nip, setNip]         = useState("");
  const [jabatan, setJabatan] = useState("");
  const [role, setRole]       = useState("");
  const [unit, setUnit]       = useState("");

  const valid = nama && email && role && unit;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md flex flex-col overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-base font-bold text-gray-900">Tambah Pengguna Baru</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>
        <div className="p-6 space-y-4 overflow-y-auto" style={{ maxHeight: "60vh" }}>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1.5">Nama Lengkap *</label>
            <input value={nama} onChange={e => setNama(e.target.value)} placeholder="Nama lengkap pengguna"
              className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2.5 outline-none" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1.5">Email *</label>
            <input value={email} onChange={e => setEmail(e.target.value)} placeholder="email@apps.ipb.ac.id" type="email"
              className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2.5 outline-none" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1.5">NIP</label>
            <input value={nip} onChange={e => setNip(e.target.value)} placeholder="19XXXXXX XXXXXX X XXX"
              className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2.5 outline-none font-mono" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1.5">Jabatan</label>
            <input value={jabatan} onChange={e => setJabatan(e.target.value)} placeholder="Jabatan/posisi"
              className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2.5 outline-none" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1.5">Role *</label>
            <select value={role} onChange={e => setRole(e.target.value)}
              className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2.5 bg-white outline-none">
              <option value="">-- Pilih Role --</option>
              {ROLES_DEF.map(r => <option key={r}>{r}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1.5">Unit *</label>
            <select value={unit} onChange={e => setUnit(e.target.value)}
              className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2.5 bg-white outline-none">
              <option value="">-- Pilih Unit --</option>
              <option>Pusat</option><option>Sekolah Vokasi</option>
              <option>Kampus Cilibende</option><option>Kampus Gunung Gede</option>
            </select>
          </div>
          <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 flex items-start gap-2">
            <AlertTriangle size={13} className="text-amber-600 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700">Penambahan pengguna akan dicatat dalam audit trail sistem.</p>
          </div>
        </div>
        <div className="px-6 py-4 border-t border-gray-100 flex items-center justify-between">
          <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50">Batal</button>
          <button onClick={onClose} disabled={!valid}
            className="flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black disabled:opacity-40 disabled:cursor-not-allowed">
            <Check size={14} /> Tambah Pengguna
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
type PengTab = "daftar" | "role" | "unit" | "login";

export function PenggunaPage({ topBar }: { topBar?: React.ReactNode }) {
  const store = useDataStore();

  // Merge store.users with USERS_DATA enrichment (NIP, jabatan, loginHistory)
  const allUsers = useMemo<UserRecord[]>(() => {
    const enriched = store.users.map(su => {
      const match = USERS_DATA.find(u => u.nama === su.nama || u.id === su.id);
      return {
        id: su.id,
        nama: su.nama,
        email: su.email || match?.email || "",
        nip: match?.nip || "",
        jabatan: match?.jabatan || su.role,
        role: (su.role || match?.role || "Operator Aset") as UserRole,
        unit: su.unit || match?.unit || "Pusat",
        status: (su.aktif ? "Aktif" : "Non-Aktif") as UserStatus,
        lastLogin: match?.lastLogin || "—",
        loginHistory: match?.loginHistory || [],
      };
    });
    const storeNames = new Set(store.users.map(u => u.nama));
    const extra = USERS_DATA.filter(u => !storeNames.has(u.nama));
    return [...enriched, ...extra];
  }, [store.users]);

  const [activeTab, setActiveTab] = useState<PengTab>("daftar");
  const [search, setSearch]       = useState("");
  const [roleFilter, setRoleFilter] = useState("Semua Role");
  const [statusFilter, setStatusFilter] = useState("Semua Status");
  const [openUserId, setOpenUserId] = useState<string | null>(null);
  const [showAdd, setShowAdd]       = useState(false);

  const filteredUsers = useMemo(() => allUsers.filter(u => {
    const q = search.toLowerCase();
    const matchQ = u.nama.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || u.unit.toLowerCase().includes(q);
    const matchR = roleFilter === "Semua Role" || u.role === roleFilter;
    const matchS = statusFilter === "Semua Status" || u.status === statusFilter;
    return matchQ && matchR && matchS;
  }), [allUsers, search, roleFilter, statusFilter]);

  const selectedUser = openUserId ? allUsers.find(u => u.id === openUserId) : undefined;

  const kpi = useMemo(() => ({
    total:    allUsers.length,
    admin:    allUsers.filter(u => u.role === "Admin Sistem").length,
    operator: allUsers.filter(u => ["Operator Aset", "Pengelola Pengadaan", "Teknisi"].includes(u.role)).length,
    pimpinan: allUsers.filter(u => u.role === "Pimpinan").length,
    nonAktif: allUsers.filter(u => u.status === "Non-Aktif").length,
  }), [allUsers]);

  const kpiCards = [
    { label: "Total Pengguna",  value: kpi.total,    sub: "terdaftar dalam sistem",   color: "#111827", Icon: Users   },
    { label: "Admin Sistem",    value: kpi.admin,    sub: "akses penuh",               color: "#EF4444", Icon: Shield  },
    { label: "Operator",        value: kpi.operator, sub: "operator & teknisi",        color: "#3B82F6", Icon: User    },
    { label: "Pimpinan",        value: kpi.pimpinan, sub: "view & approve",            color: "#8B5CF6", Icon: Key     },
    { label: "Akun Nonaktif",   value: kpi.nonAktif, sub: "akses dibekukan",           color: "#6B7280", Icon: UserX   },
  ];

  const tabs: { id: PengTab; label: string; icon: React.ElementType }[] = [
    { id: "daftar", label: "Daftar Pengguna",  icon: Users    },
    { id: "role",   label: "Role & Hak Akses", icon: Shield   },
    { id: "unit",   label: "Unit Pengguna",    icon: Building2 },
    { id: "login",  label: "Aktivitas Login",  icon: Activity  },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Pengguna</h1>
            <p className="text-xs text-gray-500 mt-0.5">
              Kelola akun, role, unit pengguna, otorisasi menu, dan akses dashboard sistem aset.
            </p>
          </div>
          <button onClick={() => setShowAdd(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gray-900 text-white text-sm font-semibold rounded-lg hover:bg-black transition-colors shadow-sm">
            <Plus size={15} /> Tambah Pengguna
          </button>
        </div>

        {/* KPI cards */}
        <div className="grid grid-cols-5 gap-4">
          {kpiCards.map((s) => (
            <div key={s.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-gray-500">{s.label}</span>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: s.color + "15", color: s.color }}>
                  <s.Icon size={18} />
                </div>
              </div>
              <p className="text-2xl font-bold text-gray-900">{s.value}</p>
              <p className="text-[10px] text-gray-400 mt-0.5">{s.sub}</p>
            </div>
          ))}
        </div>

        {/* Tab Bar */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200">
          {tabs.map((t) => {
            const Icon = t.icon;
            return (
              <button key={t.id} onClick={() => setActiveTab(t.id)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all flex-1 justify-center ${
                  activeTab === t.id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"
                }`}>
                <Icon size={13} />
                {t.label}
              </button>
            );
          })}
        </div>

        {/* Daftar Pengguna Tab */}
        {activeTab === "daftar" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative flex-1 min-w-[200px]">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Cari nama, email, atau unit..."
                  className="w-full pl-9 pr-4 py-2 text-sm bg-white border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
              </div>
              <select value={roleFilter} onChange={e => setRoleFilter(e.target.value)}
                className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 outline-none">
                <option value="Semua Role">Semua Role</option>
                {ROLES_DEF.map(r => <option key={r}>{r}</option>)}
              </select>
              <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
                className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 outline-none">
                <option value="Semua Status">Semua Status</option>
                <option>Aktif</option><option>Non-Aktif</option>
              </select>
              <button className="flex items-center gap-2 bg-white border border-gray-200 text-gray-600 px-3 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">
                <Download size={14} /> Export
              </button>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100 bg-gray-50/70">
                    {["Nama", "Email", "Role", "Unit", "Status", "Login Terakhir", "Aksi"].map(h => (
                      <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((u) => (
                    <tr key={u.id} onClick={() => setOpenUserId(u.id)}
                      className="border-b border-gray-50 hover:bg-gray-50 transition-colors cursor-pointer">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-gray-900 flex items-center justify-center text-white text-xs font-bold shrink-0">
                            {initials(u.nama)}
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-900">{u.nama}</p>
                            <p className="text-[10px] text-gray-400">{u.jabatan}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-gray-600 whitespace-nowrap">{u.email}</td>
                      <td className="py-3.5 px-4"><RoleBadge role={u.role} /></td>
                      <td className="py-3.5 px-4 text-xs text-gray-600 whitespace-nowrap">{u.unit}</td>
                      <td className="py-3.5 px-4"><StatusBadge status={u.status} /></td>
                      <td className="py-3.5 px-4 text-xs text-gray-500 whitespace-nowrap">{u.lastLogin}</td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                          <button onClick={() => setOpenUserId(u.id)}
                            className="p-1.5 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition-colors">
                            <Eye size={13} />
                          </button>
                          <button className="p-1.5 rounded hover:bg-blue-50 text-gray-400 hover:text-blue-600 transition-colors">
                            <Edit2 size={13} />
                          </button>
                          <button className="p-1.5 rounded hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors">
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredUsers.length === 0 && (
                <div className="py-12 text-center">
                  <Users size={28} className="text-gray-200 mx-auto mb-2" />
                  <p className="text-sm text-gray-400">Tidak ada pengguna yang sesuai filter.</p>
                </div>
              )}
              <div className="px-5 py-3 border-t border-gray-100 bg-gray-50/50 flex items-center justify-between">
                <span className="text-xs text-gray-500">
                  Menampilkan <span className="font-semibold text-gray-700">{filteredUsers.length}</span> dari {allUsers.length} pengguna
                </span>
              </div>
            </div>
          </div>
        )}

        {activeTab === "role"   && <RolePermMatrix />}
        {activeTab === "unit"   && <UnitPenggunaTab users={allUsers} />}
        {activeTab === "login"  && <AktivitasLoginTab users={allUsers} />}
      </div>

      {selectedUser && <UserDetailDrawer user={selectedUser} onClose={() => setOpenUserId(null)} />}
      {showAdd && <AddUserModal onClose={() => setShowAdd(false)} />}
    </main>
  );
}
