import React, { useState, useMemo } from "react";
import { exportToExcel, downloadBlob } from "./excelUtils";
import { useDataStore, type ActivityLog as StoreActivityLog } from "./DataStore";
import {
  Search, Download, RefreshCw, LogIn, LogOut, Plus,
  Edit3, Trash2, FileText, ArrowLeftRight, Wrench, ShoppingCart, ClipboardList,
  AlertTriangle, XCircle, CheckCircle, Activity, Shield, Filter,
  ChevronDown, Monitor, Database,
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────
type AktRole = "Admin Sistem" | "Operator Aset" | "Pengelola Pengadaan" | "Teknisi" | "Pimpinan" | "Auditor";
type AktMenu = "Data Aset" | "Mutasi" | "Perbaikan" | "Pengadaan" | "Opname" | "Dokumen" | "Sistem" | "Pengguna" | "Aktivitas" | "Dashboard" | "PIC";
type AktJenis = "login" | "logout" | "tambah" | "update" | "hapus" | "dokumen" | "mutasi" | "perbaikan" | "pengadaan" | "opname" | "sistem" | "gagal";
type AktStatus = "Berhasil" | "Gagal" | "Berisiko";
type ValidasiStatus = "Valid" | "Ditinjau" | "Ditolak";

interface ActivityLog {
  id: number;
  waktu: string;
  tgl: string;
  pengguna: string;
  role: AktRole;
  menu: AktMenu;
  aktivitas: string;
  status: AktStatus;
  ip: string;
  device: string;
  jenis: AktJenis;
}

interface AuditRecord {
  id: number;
  waktu: string;
  tgl: string;
  pengguna: string;
  role: AktRole;
  aset: string;
  kodeAset: string;
  field: string;
  nilaiLama: string;
  nilaiBaru: string;
  alasan: string;
  statusValidasi: ValidasiStatus;
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function fmtDate(s: string): string {
  try {
    return new Date(s).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });
  } catch { return s; }
}

const JENIS_CFG: Record<AktJenis, { color: string; bg: string; label: string }> = {
  login:      { color: "#3B82F6", bg: "#DBEAFE", label: "Login"      },
  logout:     { color: "#6B7280", bg: "#F3F4F6", label: "Logout"     },
  tambah:     { color: "#22C55E", bg: "#DCFCE7", label: "Tambah"     },
  update:     { color: "#F59E0B", bg: "#FEF3C7", label: "Update"     },
  hapus:      { color: "#EF4444", bg: "#FEE2E2", label: "Hapus"      },
  dokumen:    { color: "#8B5CF6", bg: "#EDE9FE", label: "Dokumen"    },
  mutasi:     { color: "#6366F1", bg: "#E0E7FF", label: "Mutasi"     },
  perbaikan:  { color: "#EA580C", bg: "#FFEDD5", label: "Perbaikan"  },
  pengadaan:  { color: "#0D9488", bg: "#CCFBF1", label: "Pengadaan"  },
  opname:     { color: "#06B6D4", bg: "#CFFAFE", label: "Opname"     },
  sistem:     { color: "#374151", bg: "#E5E7EB", label: "Sistem"     },
  gagal:      { color: "#EF4444", bg: "#FEE2E2", label: "Gagal"      },
};

function StatusBadge({ status }: { status: AktStatus }) {
  const cfg = {
    Berhasil: "bg-green-100 text-green-700",
    Gagal:    "bg-red-100 text-red-700",
    Berisiko: "bg-amber-100 text-amber-700",
  }[status];
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold ${cfg}`}>{status}</span>;
}

function JenisBadge({ jenis }: { jenis: AktJenis }) {
  const cfg = JENIS_CFG[jenis];
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold"
      style={{ backgroundColor: cfg.bg, color: cfg.color }}>
      {cfg.label}
    </span>
  );
}

function ValidasiBadge({ status }: { status: ValidasiStatus }) {
  const cfg = {
    Valid:    "bg-green-100 text-green-700",
    Ditinjau: "bg-amber-100 text-amber-700",
    Ditolak:  "bg-red-100 text-red-700",
  }[status];
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold ${cfg}`}>{status}</span>;
}

const ROLE_LIST  = ["Semua Role", "Admin Sistem", "Operator Aset", "Pengelola Pengadaan", "Teknisi", "Pimpinan", "Auditor"];
const MENU_LIST  = ["Semua Menu", "Data Aset", "Mutasi", "Perbaikan", "Pengadaan", "Opname", "Dokumen", "Sistem", "Pengguna", "Dashboard", "PIC", "Aktivitas"];
const JENIS_LIST = ["Semua Jenis", "Login", "Logout", "Tambah", "Update", "Hapus", "Mutasi", "Perbaikan", "Pengadaan", "Opname", "Dokumen", "Gagal"];

// ── Activity Log Tab ──────────────────────────────────────────────────────────
function mapStoreLog(s: StoreActivityLog): ActivityLog {
  return {
    id: s.id,
    waktu: s.waktu,
    tgl: s.tgl,
    pengguna: s.pengguna,
    role: (s.role as AktRole) || "Operator Aset",
    menu: (s.menu as AktMenu) || "Data Aset",
    aktivitas: s.aksi + (s.target_id ? ` (${s.target_id})` : ""),
    status: s.status,
    ip: s.ip || "-",
    device: s.device || "-",
    jenis: s.jenis,
  };
}

type StoreAsset = { id: string; Nama_Barang?: string };

function mapStoreLogToAudit(s: StoreActivityLog, assets: StoreAsset[]): AuditRecord {
  const asset = assets.find(a => a.id === s.target_id);
  return {
    id: s.id,
    waktu: s.waktu,
    tgl: s.tgl,
    pengguna: s.pengguna,
    role: (s.role as AktRole) || "Operator Aset",
    aset: asset?.Nama_Barang || s.target_id || "—",
    kodeAset: s.target_id || s.target_type || "—",
    field: s.field_changed || s.aksi,
    nilaiLama: s.old_value || "—",
    nilaiBaru: s.new_value || "—",
    alasan: s.aksi,
    statusValidasi: "Valid",
  };
}

function ActivityLogTab() {
  const store = useDataStore();
  const combined = useMemo<ActivityLog[]>(
    () => store.activityLogs.map(mapStoreLog),
    [store.activityLogs]
  );
  const USER_LIST = useMemo(
    () => ["Semua Pengguna", ...Array.from(new Set(store.activityLogs.map(a => a.pengguna))).sort()],
    [store.activityLogs]
  );
  const [search, setSearch]       = useState("");
  const [roleFilter, setRoleFilter] = useState("Semua Role");
  const [menuFilter, setMenuFilter] = useState("Semua Menu");
  const [userFilter, setUserFilter] = useState("Semua Pengguna");
  const [jenisFilter, setJenisFilter] = useState("Semua Jenis");

  const filtered = useMemo(() => combined.filter(a => {
    const q = search.toLowerCase();
    const matchQ = a.aktivitas.toLowerCase().includes(q) || a.pengguna.toLowerCase().includes(q);
    const matchR = roleFilter === "Semua Role" || a.role === roleFilter;
    const matchM = menuFilter === "Semua Menu" || a.menu === menuFilter;
    const matchU = userFilter === "Semua Pengguna" || a.pengguna === userFilter;
    const matchJ = jenisFilter === "Semua Jenis" || JENIS_CFG[a.jenis]?.label === jenisFilter;
    return matchQ && matchR && matchM && matchU && matchJ;
  }), [combined, search, roleFilter, menuFilter, userFilter, jenisFilter]);

  return (
    <div className="space-y-4">
      {/* Filter bar */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Cari aktivitas atau pengguna..."
            className="w-full pl-9 pr-4 py-2 text-sm bg-white border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
        </div>
        {[
          { val: userFilter, set: setUserFilter, opts: USER_LIST },
          { val: roleFilter, set: setRoleFilter, opts: ROLE_LIST },
          { val: menuFilter, set: setMenuFilter, opts: MENU_LIST },
          { val: jenisFilter, set: setJenisFilter, opts: JENIS_LIST },
        ].map((f, i) => (
          <select key={i} value={f.val} onChange={e => f.set(e.target.value)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 outline-none">
            {f.opts.map(o => <option key={o}>{o}</option>)}
          </select>
        ))}
      </div>

      <div className="flex items-center gap-2">
        <p className="text-xs text-gray-400 flex-1">{filtered.length} aktivitas ditemukan</p>
        <button
          onClick={() => exportToExcel(filtered.map(a => ({
            "Tanggal": a.tgl, "Waktu": a.waktu, "Pengguna": a.pengguna,
            "Role": a.role, "Menu": a.menu, "Aktivitas": a.aktivitas,
            "Jenis": a.jenis, "Status": a.status, "IP": a.ip, "Device": a.device,
          })), `activity-log-${new Date().toISOString().slice(0,10)}`, "Log")}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50">
          <Download size={12} /> Export
        </button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full" style={{ minWidth: 900 }}>
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/70">
                {["Waktu", "Pengguna", "Role", "Menu", "Aktivitas", "Status", "IP / Device"].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((a) => (
                <tr key={a.id} className={`border-b border-gray-50 hover:bg-gray-50 transition-colors ${a.status === "Gagal" || a.status === "Berisiko" ? "bg-red-50/20" : ""}`}>
                  <td className="py-3 px-4 text-xs text-gray-500 whitespace-nowrap">
                    <div className="font-mono">{a.waktu}</div>
                    <div className="text-[10px] text-gray-400">{fmtDate(a.tgl)}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="text-sm font-medium text-gray-800 whitespace-nowrap">{a.pengguna}</div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-[10px] font-medium bg-gray-100 text-gray-600 px-2 py-0.5 rounded whitespace-nowrap">{a.role}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-xs text-gray-600 whitespace-nowrap">{a.menu}</span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <JenisBadge jenis={a.jenis} />
                      <span className="text-xs text-gray-700 max-w-[220px] truncate">{a.aktivitas}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4"><StatusBadge status={a.status} /></td>
                  <td className="py-3 px-4 text-xs text-gray-500 whitespace-nowrap">
                    <div className="font-mono text-[10px]">{a.ip}</div>
                    <div className="text-[10px] text-gray-400">{a.device}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="py-12 text-center">
            <Activity size={28} className="text-gray-200 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Tidak ada aktivitas yang sesuai filter.</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Audit Table Tab ───────────────────────────────────────────────────────────
function AuditTableTab() {
  const store = useDataStore();
  const [search, setSearch] = useState("");
  const [validasiFilter, setValidasiFilter] = useState("Semua");

  const combined = useMemo<AuditRecord[]>(() => {
    return store.activityLogs
      .filter(l => ["tambah","update","hapus","mutasi","perbaikan","pengadaan","opname","dokumen"].includes(l.jenis))
      .map(l => mapStoreLogToAudit(l, store.assets))
      .sort((a, b) => `${b.tgl}${b.waktu}`.localeCompare(`${a.tgl}${a.waktu}`));
  }, [store.activityLogs, store.assets]);

  const filtered = useMemo(() => combined.filter(a => {
    const q = search.toLowerCase();
    const matchQ = a.aset.toLowerCase().includes(q) || a.kodeAset.toLowerCase().includes(q) ||
      a.pengguna.toLowerCase().includes(q) || a.field.toLowerCase().includes(q);
    const matchV = validasiFilter === "Semua" || a.statusValidasi === validasiFilter;
    return matchQ && matchV;
  }), [combined, search, validasiFilter]);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Cari aset, field yang diubah, atau pengguna..."
            className="w-full pl-9 pr-4 py-2 text-sm bg-white border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
        </div>
        <select value={validasiFilter} onChange={e => setValidasiFilter(e.target.value)}
          className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 outline-none">
          <option value="Semua">Semua Status Validasi</option>
          <option>Valid</option><option>Ditinjau</option><option>Ditolak</option>
        </select>
        <button
          onClick={() => exportToExcel(filtered.map(a => ({
            "Tanggal": a.tgl, "Waktu": a.waktu, "Pengguna": a.pengguna, "Role": a.role,
            "Aset": a.aset, "Kode Aset": a.kodeAset, "Field Diubah": a.field,
            "Nilai Lama": a.nilaiLama, "Nilai Baru": a.nilaiBaru,
            "Alasan": a.alasan, "Status Validasi": a.statusValidasi,
          })), `audit-trail-${new Date().toISOString().slice(0,10)}`, "Audit")}
          className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50">
          <Download size={14} /> Export
        </button>
      </div>

      <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 flex items-center gap-3">
        <Shield size={15} className="text-amber-600 shrink-0" />
        <p className="text-xs text-amber-700">
          <span className="font-semibold">Audit Trail</span> — Perubahan data dicatat otomatis oleh sistem. Tidak dapat diedit secara manual.
        </p>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full" style={{ minWidth: 1000 }}>
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/70">
                {["Waktu", "Pengguna", "Aset", "Field Diubah", "Nilai Lama", "Nilai Baru", "Alasan", "Status Validasi"].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((a) => (
                <tr key={a.id} className={`border-b border-gray-50 hover:bg-gray-50 transition-colors ${a.statusValidasi === "Ditinjau" ? "bg-amber-50/30" : ""}`}>
                  <td className="py-3 px-4 text-xs text-gray-500 whitespace-nowrap">
                    <div className="font-mono text-[11px]">{a.waktu}</div>
                    <div className="text-[10px] text-gray-400">{fmtDate(a.tgl)}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="text-xs font-medium text-gray-800 whitespace-nowrap">{a.pengguna}</div>
                    <div className="text-[10px] text-gray-400">{a.role}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="text-xs font-medium text-gray-800 max-w-[150px] truncate">{a.aset}</div>
                    <span className="text-[10px] font-mono font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">{a.kodeAset}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-xs font-semibold text-gray-700 bg-gray-100 px-2 py-0.5 rounded whitespace-nowrap">{a.field}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-xs text-red-600 bg-red-50 px-2 py-0.5 rounded line-through whitespace-nowrap max-w-[120px] truncate block">{a.nilaiLama || "—"}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-xs text-green-700 bg-green-50 px-2 py-0.5 rounded font-medium whitespace-nowrap max-w-[120px] truncate block">{a.nilaiBaru}</span>
                  </td>
                  <td className="py-3 px-4 text-xs text-gray-600 max-w-[180px]">
                    <span className="truncate block" title={a.alasan}>{a.alasan}</span>
                  </td>
                  <td className="py-3 px-4"><ValidasiBadge status={a.statusValidasi} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="py-12 text-center">
            <Database size={28} className="text-gray-200 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Tidak ada audit record yang sesuai filter.</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Perubahan Data Aset Tab ───────────────────────────────────────────────────
function PerubahanAsetTab() {
  const store = useDataStore();
  const allAudit = useMemo<AuditRecord[]>(() => {
    return store.activityLogs
      .filter(l => ["tambah","update","hapus","mutasi","perbaikan","pengadaan","opname","dokumen"].includes(l.jenis))
      .map(l => mapStoreLogToAudit(l, store.assets))
      .sort((a, b) => `${b.tgl}${b.waktu}`.localeCompare(`${a.tgl}${a.waktu}`));
  }, [store.activityLogs, store.assets]);
  const asetChanges = allAudit.filter(a => a.kodeAset !== "PIC" && a.kodeAset !== "USER");

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Total Perubahan",   value: asetChanges.length,                                               color: "#111827" },
          { label: "Telah Divalidasi",  value: asetChanges.filter(a => a.statusValidasi === "Valid").length,     color: "#22C55E" },
          { label: "Perlu Ditinjau",    value: asetChanges.filter(a => a.statusValidasi === "Ditinjau").length,  color: "#F59E0B" },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
            <p className="text-xs text-gray-500 mb-2">{s.label}</p>
            <p className="text-2xl font-bold" style={{ color: s.color }}>{s.value}</p>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        {asetChanges.map((a) => (
          <div key={a.id} className={`bg-white border rounded-xl p-4 ${a.statusValidasi === "Ditinjau" ? "border-amber-200" : "border-gray-200"}`}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-mono font-bold bg-blue-50 text-blue-700 px-2 py-0.5 rounded">{a.kodeAset}</span>
                  <span className="text-sm font-medium text-gray-800 truncate">{a.aset}</span>
                  <ValidasiBadge status={a.statusValidasi} />
                </div>
                <div className="flex items-center gap-2 text-xs mb-2">
                  <span className="font-semibold text-gray-600 bg-gray-100 px-2 py-0.5 rounded">{a.field}</span>
                  <span className="text-red-500 bg-red-50 px-2 py-0.5 rounded line-through">{a.nilaiLama || "—"}</span>
                  <span className="text-gray-400">→</span>
                  <span className="text-green-600 bg-green-50 px-2 py-0.5 rounded font-medium">{a.nilaiBaru}</span>
                </div>
                <p className="text-xs text-gray-500">{a.alasan}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-xs font-medium text-gray-700">{a.pengguna}</p>
                <p className="text-[10px] text-gray-400">{fmtDate(a.tgl)} — {a.waktu}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Aktivitas Sistem Tab ──────────────────────────────────────────────────────
function AktivitasSistemTab() {
  const store = useDataStore();
  const allLogs = useMemo<ActivityLog[]>(() => {
    return store.activityLogs
      .map(mapStoreLog)
      .sort((a, b) => `${b.tgl}${b.waktu}`.localeCompare(`${a.tgl}${a.waktu}`));
  }, [store.activityLogs]);
  const sistemLogs = allLogs.filter(a => ["login", "logout", "sistem"].includes(a.jenis));
  const grouped = sistemLogs.reduce((acc, a) => {
    if (!acc[a.tgl]) acc[a.tgl] = [];
    acc[a.tgl].push(a);
    return acc;
  }, {} as Record<string, ActivityLog[]>);
  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Total Login Hari Ini", value: allLogs.filter(a => a.tgl === today && a.jenis === "login").length, color: "#3B82F6" },
          { label: "Sesi Aktif",           value: 3,  color: "#22C55E" },
          { label: "Login Gagal (7 Hari)", value: allLogs.filter(a => a.jenis === "gagal").length, color: "#EF4444" },
          { label: "Pengguna Unik",        value: new Set(sistemLogs.map(a => a.pengguna)).size, color: "#8B5CF6" },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
            <p className="text-xs text-gray-500 mb-2">{s.label}</p>
            <p className="text-2xl font-bold" style={{ color: s.color }}>{s.value}</p>
          </div>
        ))}
      </div>

      {Object.entries(grouped).sort((a, b) => b[0].localeCompare(a[0])).map(([tgl, logs]) => (
        <div key={tgl} className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-5 py-3 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-600">{fmtDate(tgl)}</span>
            <span className="text-xs text-gray-400">{logs.length} sesi</span>
          </div>
          <div className="divide-y divide-gray-50">
            {logs.map(a => (
              <div key={a.id} className={`flex items-center gap-4 px-5 py-3 ${a.status !== "Berhasil" ? "bg-red-50/30" : ""}`}>
                <Monitor size={14} className="text-gray-400 shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-gray-800">{a.pengguna}</span>
                    <span className="text-[10px] text-gray-400">{a.role}</span>
                  </div>
                  <div className="text-xs text-gray-500">{a.aktivitas}</div>
                </div>
                <StatusBadge status={a.status} />
                <div className="text-right shrink-0">
                  <div className="text-xs font-mono text-gray-500">{a.waktu}</div>
                  <div className="text-[10px] text-gray-400">{a.ip}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
type AktTab = "log" | "audit" | "perubahan" | "sistem";

export function AktivitasPage({ topBar }: { topBar?: React.ReactNode }) {
  const store = useDataStore();
  const [activeTab, setActiveTab] = useState<AktTab>("log");

  const kpi = useMemo(() => {
    const allLogs = store.activityLogs.map(mapStoreLog);
    const today = new Date().toISOString().slice(0, 10);
    return {
      hariIni:    allLogs.filter(a => a.tgl === today).length,
      perubahan:  allLogs.filter(a => ["tambah", "update", "hapus"].includes(a.jenis)).length,
      login:      allLogs.filter(a => a.jenis === "login").length,
      berisiko:   allLogs.filter(a => a.status === "Berisiko").length,
      gagal:      allLogs.filter(a => a.status === "Gagal").length,
    };
  }, [store.activityLogs]);

  const kpiCards = [
    { label: "Total Aktivitas Hari Ini", value: kpi.hariIni,   sub: "1 Jun 2026",            color: "#111827", Icon: Activity       },
    { label: "Perubahan Data Aset",      value: kpi.perubahan, sub: "tambah, edit, hapus",    color: "#F59E0B", Icon: Edit3          },
    { label: "Login Pengguna",           value: kpi.login,     sub: "sesi tercatat",           color: "#3B82F6", Icon: LogIn          },
    { label: "Aktivitas Berisiko",       value: kpi.berisiko,  sub: "perlu tindak lanjut",     color: "#EF4444", Icon: AlertTriangle  },
    { label: "Gagal Validasi",           value: kpi.gagal,     sub: "audit perlu ditinjau",    color: "#8B5CF6", Icon: XCircle        },
  ];

  const tabs: { id: AktTab; label: string; icon: React.ElementType }[] = [
    { id: "log",       label: "Activity Log",        icon: Activity    },
    { id: "audit",     label: "Audit Trail",          icon: Shield      },
    { id: "perubahan", label: "Perubahan Data Aset",  icon: Database    },
    { id: "sistem",    label: "Aktivitas Sistem",      icon: Monitor     },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Aktivitas</h1>
            <p className="text-xs text-gray-500 mt-0.5">
              Log aktivitas pengguna, audit trail, dan perubahan data aset yang dicatat otomatis oleh sistem.
            </p>
          </div>
          <button
            onClick={() => {
              const allLogs = store.activityLogs.map(mapStoreLog);
              exportToExcel(allLogs.map(a => ({
                "Tanggal": a.tgl, "Waktu": a.waktu, "Pengguna": a.pengguna,
                "Role": a.role, "Menu": a.menu, "Aktivitas": a.aktivitas,
                "Jenis": a.jenis, "Status": a.status, "IP": a.ip, "Device": a.device,
              })), `activity-log-${new Date().toISOString().slice(0,10)}`, "Log Aktivitas");
            }}
            className="flex items-center gap-2 bg-white border border-gray-200 text-gray-600 px-3 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 shadow-sm transition-colors">
            <Download size={14} /> Unduh Log
          </button>
        </div>

        {/* KPI cards */}
        <div className="grid grid-cols-5 gap-4">
          {kpiCards.map((s) => (
            <div key={s.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-gray-500">{s.label}</span>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: s.color + "15", color: s.color }}>
                  <s.Icon size={18} />
                </div>
              </div>
              <p className="text-2xl font-bold text-gray-900">{s.value}</p>
              <p className="text-[10px] text-gray-400 mt-0.5">{s.sub}</p>
            </div>
          ))}
        </div>

        {/* Tab Bar */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200">
          {tabs.map((t) => {
            const Icon = t.icon;
            return (
              <button key={t.id} onClick={() => setActiveTab(t.id)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all flex-1 justify-center ${
                  activeTab === t.id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"
                }`}>
                <Icon size={13} />
                {t.label}
              </button>
            );
          })}
        </div>

        {/* Tab content */}
        {activeTab === "log"       && <ActivityLogTab />}
        {activeTab === "audit"     && <AuditTableTab />}
        {activeTab === "perubahan" && <PerubahanAsetTab />}
        {activeTab === "sistem"    && <AktivitasSistemTab />}
      </div>
    </main>
  );
}
