import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import apiClient from "../services/apiClient";
import { onEvent, connectSocket, disconnectSocket } from "../services/socketService";

// ─────────────────────────────────────────────────────────────────────────────
// Types — single source of truth shapes.
// ─────────────────────────────────────────────────────────────────────────────

export type JenisAset = "PM" | "ATB" | "ATL" | "AL";

// Asset uses the existing Row shape from AsetDataTable — every extended field
// in the brief (kode_tag_aset, nama_pic, ..., catatan_mutasi_terakhir) is
// already present.
export type Asset = Record<string, string>;

export type StatusOpname =
  | "Terverifikasi"
  | "Belum Dicek"
  | "Selisih"
  | "Tidak Ditemukan"
  | "Perlu Verifikasi";

export type StatusMaintenance =
  | "Scheduled"
  | "Due Soon"
  | "Overdue"
  | "Dalam Proses"
  | "Selesai";

export type StatusMutasi =
  | "Draft"
  | "Menunggu Persetujuan"
  | "Disetujui"
  | "Ditolak"
  | "Selesai";

export type StatusPengadaan =
  | "Draft"
  | "Menunggu Persetujuan"
  | "Disetujui"
  | "Dalam Pengadaan"
  | "Selesai"
  | "Ditolak";

export type StatusKondisi =
  | "Baik"
  | "Perlu Monitoring"
  | "Rusak Ringan"
  | "Rusak Berat"
  | "Prioritas Penggantian";

export type DataQuality = "Lengkap" | "Perlu Verifikasi" | "Tidak Lengkap" | "Konflik Data";

export interface MaintenanceTicket {
  id: string;
  asset_id: string;
  tanggal: string;
  jenis: "Preventif" | "Korektif" | "Inspeksi";
  kategori_kerusakan: string;
  tingkat_kerusakan: "Ringan" | "Sedang" | "Berat" | "Kritis";
  biaya: number;
  downtime_jam: number;
  status: StatusMaintenance;
  catatan?: string;
  jadwal_berikutnya?: string;
}

export interface MutationRequest {
  id: string;
  asset_id: string;
  tanggal: string;
  dari_ruangan: string;
  ke_ruangan: string;
  dari_pic: string;
  ke_pic: string;
  status: StatusMutasi;
  catatan?: string;
}

export interface ProcurementRequest {
  id: string;
  tanggal: string;
  nama_barang: string;
  jenis_aset: JenisAset;
  jumlah: number;
  estimasi_biaya: number;
  alasan: string;
  status: StatusPengadaan;
  asset_id_baru?: string; // when received, populated
}

export interface StockOpnameRecord {
  id: string;
  asset_id: string;
  kode_tag: string;
  tanggal: string;
  status_opname: string;
  kondisi_fisik: string;
  status_lokasi: string;
  diverifikasi_oleh: string;
  catatan?: string;
}

export interface DocumentRecord {
  id: string;
  nama: string;
  jenis: "Pengadaan" | "Perbaikan" | "Mutasi" | "Opname" | "Aset" | "Lainnya";
  asset_id?: string;
  transaction_id?: string;
  url: string;
  diunggah_oleh: string;
  tanggal: string;
}

export interface ActivityLog {
  id: number;
  waktu: string; // HH:mm:ss
  tgl: string;   // yyyy-mm-dd
  pengguna: string;
  role: string;
  menu: string;
  aksi: string;
  target_type: string;
  target_id: string;
  field_changed?: string;
  old_value?: string;
  new_value?: string;
  status: "Berhasil" | "Gagal" | "Berisiko";
  jenis: "login" | "logout" | "tambah" | "update" | "hapus" | "dokumen" | "mutasi" | "perbaikan" | "pengadaan" | "opname" | "sistem" | "gagal";
  ip?: string;
  device?: string;
}

export interface UserRecord {
  id: string;
  nama: string;
  role: "Admin Sistem" | "Operator Aset" | "Teknisi" | "Pengelola Pengadaan" | "Pimpinan" | "Auditor";
  unit?: string;
  email?: string;
  aktif: boolean;
}

export interface RoomRecord {
  kode_ruangan: string;
  nama_ruangan: string;
  nama_gedung: string;
  lantai_level: string;
  kategori: string;
  luas_m2: number;
  kapasitas: number;
}

export interface Filters {
  search: string;
  tahun: string;     // "semua" | "2024" | ...
  unit: string;
  kampus: string;
  gedung: string;
  lantai: string;
  ruangan: string;
  kategori: string; // kategori_ruangan etc
  jenis: string;    // PM/ATB/ATL/AL or "semua"
  kondisi: string;
  statusOpname: string;
  statusMaintenance: string;
  pic: string;
}

export const DEFAULT_FILTERS: Filters = {
  search: "",
  tahun: "semua",
  unit: "semua",
  kampus: "semua",
  gedung: "semua",
  lantai: "semua",
  ruangan: "semua",
  kategori: "semua",
  jenis: "semua",
  kondisi: "semua",
  statusOpname: "semua",
  statusMaintenance: "semua",
  pic: "semua",
};

// ─────────────────────────────────────────────────────────────────────────────
// Seed data factory (extracted from former AsetDataTable.tsx).
// ─────────────────────────────────────────────────────────────────────────────

const TODAY = "2026-06-01";
const GEDUNG_LIST = ["Gedung A", "Gedung B", "Gedung C", "Lab Terpadu", "Gedung Administrasi"];
const KAT_RUANGAN_LIST = ["Ruang Kelas", "Lab Komputer", "Ruang Kerja", "Ruang Rapat", "Lab Sains"];

const fmtRp = (n: number) => `Rp ${n.toLocaleString("id-ID")}`;

export function makeAsset(
  id: string,
  nama: string,
  merk: string,
  spec: string,
  kode: string,
  tglPerolehan: string,
  harga: number,
  sumber: string,
  kondisi: string,
  ruangan: string,
  pj: string,
  masaTahun: number,
  unit = "Sekolah Vokasi",
  tahun = "2023",
  extra: Partial<Asset> = {},
): Asset {
  const start = new Date(tglPerolehan);
  const end = new Date(TODAY);
  const months = Math.max(
    0,
    (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth()),
  );
  const deprMonth = masaTahun > 0 ? Math.round(harga / (masaTahun * 12)) : 0;
  const totalDepr = Math.min(harga, deprMonth * months);
  const nilaiBook = Math.max(0, harga - totalDepr);
  const sisaMonths = Math.max(0, masaTahun * 12 - months);
  const seq = id.replace(/[^0-9]/g, "").padStart(4, "0").slice(-4);
  const trxStatus =
    kondisi === "Rusak Berat" ? "Dihapus" : kondisi === "Rusak Ringan" ? "Perbaikan" : "Aktif";
  const seqInt = parseInt(seq) || 1;
  const gedung = GEDUNG_LIST[(seqInt - 1) % GEDUNG_LIST.length];
  const lantaiN = ((seqInt - 1) % 3) + 1;
  const katR = KAT_RUANGAN_LIST[(seqInt - 1) % KAT_RUANGAN_LIST.length];
  const phone = `0852${String(200000000 + seqInt).slice(0, 8)}`;

  return {
    id,
    KodeGl: `132${seq.slice(-3)}`,
    Nama_unit: unit,
    Id: seq,
    Trx_id_unit: "U01",
    Trx_tgl_update: TODAY,
    Trx_status: trxStatus,
    Cek: "Yes",
    Cek_unit: "Yes",
    TahunBuku: tahun,
    KodeAkun: "532111",
    KodeRKAT: `R${(parseInt(seq) % 9) + 1}`,
    Dokumen: `DOK-${id}`,
    Referensi: `REF-${id}`,
    Id_upload_bap: `BAP${100 + parseInt(seq)}`,
    Tgl_pengadaan: tglPerolehan,
    Tgl_transaksi: tglPerolehan,
    Spesifikasi: spec,
    MerkType: merk,
    TglPerolehan: tglPerolehan,
    HargaSatuan: fmtRp(harga),
    KodeBarang: kode,
    SumberDana: sumber,
    Kondisi: kondisi,
    Keterangan: "-",
    Export_tgl: TODAY,
    Export_user: "Admin",
    IsAdmin: "True",
    Id_ruangan: `R${100 + parseInt(seq)}`,
    Pengguna: pj,
    Id_iplan_aset: `IP${seq}`,
    Iplan_dokumen: "-",
    Url_thumb: "-",
    Id_unit: "U01",
    Tgl_update: TODAY,
    Nama_Barang: nama,
    Id_upload: `UPL${100 + parseInt(seq)}`,
    Url: "-",
    Kode: `K${seq}`,
    Nama_ruangan: ruangan,
    TipeAset: id.split("-")[0],
    Penyusutan_per_bulan: fmtRp(deprMonth),
    HargaDiterima: fmtRp(harga),
    Umur_tahun: Math.floor(months / 12).toString(),
    Umur_bulan: (months % 12).toString(),
    Masa_manfaat: `${masaTahun} Tahun`,
    Sisa_masa_manfaat: `${Math.floor(sisaMonths / 12)} Th ${sisaMonths % 12} Bln`,
    Jml_penyusutan: fmtRp(totalDepr),
    Akumulasi: fmtRp(totalDepr),
    NilaiBuku: fmtRp(nilaiBook),
    // numeric mirrors used by selectors (avoid re-parsing display strings)
    _harga_perolehan: String(harga),
    _nilai_buku: String(nilaiBook),
    _akumulasi_penyusutan: String(totalDepr),
    _penyusutan_per_bulan: String(deprMonth),
    _sisa_masa_manfaat_bulan: String(sisaMonths),
    _masa_manfaat_bulan: String(masaTahun * 12),
    Verifikasi_status: trxStatus === "Aktif" ? "Verified" : "Pending",
    NoPolisi: "-",
    JenisAngkutan: "-",
    Model: merk,
    NoRangka: "-",
    NoMesin: "-",
    NoBpkb: "-",
    TglPembuatan: "-",
    TglStnk: "-",
    Pajak: "-",
    Bmi_bmn: "-",
    Url_stnk: "-",
    Url_bpkb: "-",
    Url_status_penetapan: "-",
    Total_perbaikan: fmtRp(0),
    kode_tag_aset: `TAG-SV-${seq}`,
    nama_pic: pj,
    unit_pic: unit,
    kontak_pic: phone,
    tanggal_opname_terakhir: "2025-12-15",
    status_opname_terakhir: "Ditemukan",
    kondisi_fisik_opname_terakhir: kondisi,
    status_lokasi_opname_terakhir: "Sesuai",
    diverifikasi_oleh_terakhir: "Tim Opname 2025",
    catatan_opname_terakhir: "-",
    nama_gedung: gedung,
    lantai_level: `Lantai ${lantaiN}`,
    kode_ruangan: `KR-${seq}`,
    nama_ruangan_standar: ruangan,
    kategori_ruangan: katR,
    luas_ruangan_m2: String(20 + seqInt * 5),
    kapasitas_orang_ruangan: String(8 + seqInt * 2),
    latitude: "-6.5597",
    longitude: "106.8040",
    referensi_denah: `DENAH/${gedung.replace(/ /g, "-")}/L${lantaiN}`,
    status_kejelasan_lokasi: "Jelas",
    status_penggunaan_aset: kondisi === "Rusak Berat" ? "Tidak Digunakan" : "Digunakan",
    tanggal_maintenance_terakhir: kondisi !== "Baik" ? "2025-09-01" : "2026-01-15",
    jenis_maintenance_terakhir: "Preventif",
    kategori_kerusakan_terakhir:
      kondisi === "Rusak Ringan" ? "Mekanis" : kondisi === "Rusak Berat" ? "Struktural" : "-",
    tingkat_kerusakan_terakhir:
      kondisi === "Rusak Ringan" ? "Ringan" : kondisi === "Rusak Berat" ? "Berat" : "-",
    biaya_maintenance_terakhir: kondisi !== "Baik" ? fmtRp(250000 * seqInt) : fmtRp(0),
    total_frekuensi_maintenance: String(seqInt % 5),
    total_biaya_maintenance: fmtRp(250000 * seqInt * (seqInt % 5 || 1)),
    _total_biaya_maintenance: String(250000 * seqInt * (seqInt % 5 || 1)),
    downtime_terakhir_jam: kondisi !== "Baik" ? String(seqInt * 4) : "0",
    rata_rata_waktu_perbaikan_jam: kondisi !== "Baik" ? String(seqInt * 2) : "0",
    jadwal_maintenance_berikutnya: seqInt % 7 === 0 ? "2026-03-01" : "2026-12-01",
    tanggal_mutasi_terakhir: "-",
    status_mutasi_terakhir: "-",
    catatan_mutasi_terakhir: "-",
    ...extra,
  };
}

export const INITIAL_PM: Asset[] = [
  makeAsset("PM-001","Laptop Lenovo ThinkPad X1 Carbon","Lenovo ThinkPad X1","Intel i7-1165G7 16GB 512GB SSD","B001","2023-01-10",18500000,"BOPTN","Baik","Ruang Dosen A","Andi Pratama",4,"Teknik Informatika"),
  makeAsset("PM-002","Printer Epson L3150","Epson L3150","Print/Scan/Copy Color Ink Tank","B002","2022-06-15",3500000,"Mandiri","Baik","Ruang Admin","Budi Santoso",4,"Administrasi Umum"),
  makeAsset("PM-003","Server Dell PowerEdge T40","Dell PowerEdge T40","Xeon E-2224G 16GB ECC 1TB","B003","2021-03-20",25000000,"BOPTN","Rusak Ringan","Ruang Server","Andi Pratama",5,"Teknik Informatika"),
  makeAsset("PM-004","Proyektor Epson EB-X51","Epson EB-X51","3600 Lumens XGA HDMI","B004","2022-08-10",7500000,"BOPTN","Baik","Ruang Kelas 101","Citra Dewi",5,"Teknik Informatika"),
  makeAsset("PM-005","AC LG Dualcool 2 PK","LG LPNQ18GV3A","2 PK Inverter 18000 BTU","B005","2021-12-01",8500000,"Mandiri","Rusak Ringan","Lab Komputer","Dewi Rahayu",10,"Lab Komputer"),
  makeAsset("PM-006","Scanner Canon DR-C240","Canon DR-C240","ADF 60ppm USB3 A4 Flatbed","B006","2023-03-15",12000000,"BOPTN","Baik","Ruang Admin","Budi Santoso",4,"Administrasi Umum"),
  makeAsset("PM-007","UPS APC Back-UPS 1500VA","APC BX1500M-MS","1500VA 865W Auto-Shutdown","B007","2022-01-20",4500000,"Mandiri","Baik","Ruang Server","Andi Pratama",5,"Teknik Informatika"),
  makeAsset("PM-008","Monitor LG 27 inch 4K","LG 27UK850-W","27\" 4K UHD IPS HDR400 USB-C","B008","2023-07-05",6500000,"BOPTN","Baik","Ruang Dosen B","Eko Susanto",4,"Teknik Informatika"),
  makeAsset("PM-009","Oscilloscope Digital Rigol","Rigol DS1054Z","4CH 50MHz 1GSa/s 12Mpts","B009","2022-11-10",15000000,"Hibah","Baik","Lab Elektronika","Farid Hasan",5,"Lab Fisika"),
  makeAsset("PM-010","Kursi Ergonomis Herman Miller","Herman Miller Aeron","Size B Fully Adjustable","B010","2023-05-20",9800000,"BOPTN","Baik","Ruang Dosen A","Andi Pratama",5,"Teknik Informatika"),
  makeAsset("PM-011","Mesin Fotokopi Canon IR2625","Canon iR2625","25ppm A3/A4 Duplex Network","B011","2021-08-30",45000000,"BOPTN","Rusak Ringan","Ruang TU","Galih Saputra",8,"Administrasi Umum"),
  makeAsset("PM-012","Kamera DSLR Canon EOS 800D","Canon EOS 800D","24.2MP APS-C Wi-Fi Kit","B012","2022-04-12",8200000,"Mandiri","Baik","Lab Multimedia","Hendra Wijaya",4,"Ekowisata"),
  makeAsset("PM-013","Whiteboard 240x120 Magnetic","Sakana Premium Plus","240x120cm Magnetic","B013","2020-09-15",850000,"Mandiri","Baik","Ruang Kelas 201","Indah Permata",8,"Agribisnis",
    "2020", { status_kejelasan_lokasi: "Perlu Verifikasi", nama_pic: "" } as any),
  makeAsset("PM-014","Laptop ASUS VivoBook 15","ASUS VivoBook K513","Intel i5-1135G7 8GB 512GB","B014","2024-01-08",11500000,"BOPTN","Baik","Lab Komputer","Joko Widodo",4,"Lab Komputer"),
  makeAsset("PM-015","TV LED Samsung 65 inch","Samsung QA65Q60B","65\" QLED 4K Smart TV","B015","2023-10-25",12000000,"BOPTN","Baik","Ruang Rapat Besar","Kartika Sari",5,"Administrasi Umum"),
];

export const INITIAL_ATB: Asset[] = [
  makeAsset("ATB-001","Lisensi Microsoft 365 Business","Microsoft","Microsoft 365 Business Premium 50 User","SW001","2025-04-01",45000000,"BOPTN","Baik","Jaringan Kampus","Admin IT",1,"Teknik Informatika","2025"),
  makeAsset("ATB-002","Lisensi AutoCAD 2025","Autodesk","AutoCAD 2025 1 Seat Perpetual","SW002","2025-01-15",28000000,"BOPTN","Baik","Lab CAD","Irwan Fauzy",3,"Teknik Informatika","2025"),
  makeAsset("ATB-003","Lisensi SPSS Statistics 29","IBM","SPSS Statistics 29 Academic 5 User","SW003","2024-07-20",18000000,"BOPTN","Baik","Lab Statistik","Lena Marlina",3,"Agribisnis","2024"),
  makeAsset("ATB-004","Adobe Creative Cloud Teams","Adobe","Creative Cloud All Apps 10 User","SW004","2025-03-10",24000000,"Mandiri","Baik","Lab Multimedia","Hendra Wijaya",1,"Ekowisata","2025"),
  makeAsset("ATB-005","Antivirus Kaspersky Endpoint","Kaspersky Lab","Endpoint Security for Business 50PC","SW005","2024-06-01",8500000,"BOPTN","Baik","Jaringan Kampus","Admin IT",1,"Teknik Informatika","2024"),
  makeAsset("ATB-006","Turnitin Institutional License","Turnitin LLC","Institutional License 500/yr","SW006","2025-01-01",32000000,"BOPTN","Baik","Perpustakaan","Mira Agustina",1,"Administrasi Umum","2025"),
  makeAsset("ATB-007","Software ERP Accounting","Accurate Online","Accurate Online Professional 5 User","SW007","2023-08-15",12000000,"Mandiri","Baik","Ruang Keuangan","Nanda Saputri",4,"Administrasi Umum","2023"),
  makeAsset("ATB-008","Platform LMS Moodle Premium","Moodle HQ","Moodle Premium Hosting 500 User","SW008","2024-09-01",15000000,"BOPTN","Rusak Ringan","Server Room","Admin IT",2,"Teknik Informatika","2024"),
];

export const INITIAL_ATL: Asset[] = [
  makeAsset("ATL-001","Meja Kerja Direktur","Informa Executive","180x90x75cm Kayu Jati","F001","2021-04-10",8500000,"Mandiri","Baik","Ruang Direktur","Sekretaris",10,"Administrasi Umum","2021"),
  makeAsset("ATL-002","Lemari Arsip Besi 4 Laci","Brother Metal","Filing Cabinet 4 Drawer","F002","2022-02-20",3200000,"Mandiri","Baik","Ruang TU","Staff TU",8,"Administrasi Umum","2022"),
  makeAsset("ATL-003","Filling Cabinet Lateral","Bisley Multidrawer","10 Laci A4 Metal","F003","2020-11-05",5600000,"BOPTN","Rusak Ringan","Ruang Arsip","Kepala TU",8,"Administrasi Umum","2020"),
  makeAsset("ATL-004","Meja Rapat Oval 12 Kursi","Olymplast Meeting Table","300x120cm Oval","F004","2021-07-15",15000000,"BOPTN","Baik","Ruang Rapat","Staff Umum",10,"Administrasi Umum","2021"),
  makeAsset("ATL-005","Genset Perkins 20KVA","Perkins 20P","Diesel Generator 20KVA","F005","2020-03-28",85000000,"BOPTN","Baik","Ruang Genset","Teknisi",10,"Administrasi Umum","2020"),
  makeAsset("ATL-006","Rak Server Open Frame 42U","APC NetShelter SX","42U 600mm x 1070mm","F006","2022-09-12",18000000,"BOPTN","Baik","Ruang Server","Admin IT",10,"Teknik Informatika","2022"),
  makeAsset("ATL-007","Partisi Kantor Full Panel","Cubicle System","Panel H=1500mm L=3600mm","F007","2021-01-20",12500000,"Mandiri","Baik","Ruang Kerja Open","Staff Umum",8,"Administrasi Umum","2021"),
  makeAsset("ATL-008","Kulkas Kantor 2 Pintu","Sharp SJ-ID320","2 Pintu 275L No Frost","F008","2023-06-30",4200000,"Mandiri","Baik","Pantry Kantor","Staff Umum",8,"Administrasi Umum","2023"),
];

export const INITIAL_AL: Asset[] = [
  makeAsset("AL-001","Toyota Avanza E 1.3L MT","Toyota Avanza","1.3L 5MT 7 Seat","KBM001","2022-03-10",280000000,"BOPTN","Baik","Pool Kendaraan","Pengemudi Dinas",8,"Administrasi Umum","2022",
    { NoPolisi: "F 1234 BC", JenisAngkutan: "Minibus", Model: "Toyota Avanza E", NoRangka: "MHKM5EA3JJK123456", NoMesin: "3SZE1234567", NoBpkb: "BK12345678", TglPembuatan: "2022-01-15", TglStnk: "2027-03-10", Pajak: "Dibayar", Bmi_bmn: "BMN" }),
  makeAsset("AL-002","Honda Beat CBS-ISS 2021","Honda Beat","110cc CBS-ISS FI","SPM001","2021-06-20",17500000,"Mandiri","Baik","Pool Kendaraan","Kurir Surat",8,"Administrasi Umum","2021",
    { NoPolisi: "F 5678 CD", JenisAngkutan: "Sepeda Motor", Model: "Honda Beat CBS-ISS", NoRangka: "MH1JFP117MK100001", NoMesin: "JFP1E1100001", NoBpkb: "BK87654321", TglPembuatan: "2021-04-10", TglStnk: "2026-06-20", Pajak: "Dibayar", Bmi_bmn: "BMN" }),
  makeAsset("AL-003","Toyota Innova Reborn G 2.0","Toyota Innova","2.0L G AT 7 Seat","KBM002","2023-05-15",425000000,"BOPTN","Baik","Pool Kendaraan","Pengemudi Pimpinan",8,"Administrasi Umum","2023",
    { NoPolisi: "F 9012 EF", JenisAngkutan: "Minibus", Model: "Toyota Innova Reborn", NoRangka: "MHFXW8EM1P1234567", NoMesin: "2GD1234567", NoBpkb: "BK11223344", TglPembuatan: "2023-03-01", TglStnk: "2028-05-15", Pajak: "Dibayar", Bmi_bmn: "BMN" }),
  makeAsset("AL-004","Daihatsu Xenia 1.3 R DLX","Daihatsu Xenia","1.3L R DLX MT 7 Seat","KBM003","2021-09-08",225000000,"Mandiri","Rusak Ringan","Pool Kendaraan","Pengemudi Dinas",8,"Administrasi Umum","2021",
    { NoPolisi: "F 3456 GH", JenisAngkutan: "Minibus", Model: "Daihatsu Xenia 1.3", NoRangka: "MHKV5EA3MJK234567", NoMesin: "3SZ234567", NoBpkb: "BK55667788", TglPembuatan: "2021-07-20", TglStnk: "2026-09-08", Pajak: "Dibayar", Bmi_bmn: "BMN" }),
  makeAsset("AL-005","Motor Viar Karya 200","Viar Karya 200","200cc Roda Tiga","R3-001","2022-11-25",28000000,"BOPTN","Baik","Gudang Logistik","Staff Logistik",8,"Administrasi Umum","2022",
    { NoPolisi: "F 7890 IJ", JenisAngkutan: "Roda Tiga", Model: "Viar Karya 200", NoRangka: "MH8KA200NCK300001", NoMesin: "KA200300001", NoBpkb: "BK99001122", TglPembuatan: "2022-09-10", TglStnk: "2027-11-25", Pajak: "Dibayar", Bmi_bmn: "BMN" }),
  makeAsset("AL-006","Sepeda Listrik United TX7","United TX7","Sepeda Listrik 350W","SPD-001","2024-02-14",8500000,"Mandiri","Baik","Area Kampus","Security",5,"Administrasi Umum","2024",
    { NoPolisi: "-", JenisAngkutan: "Sepeda Listrik", Model: "United TX7", NoRangka: "TX7240001", NoMesin: "-", NoBpkb: "-", TglPembuatan: "2024-01-10", TglStnk: "-", Pajak: "-", Bmi_bmn: "Mandiri" }),
];

const GENERATED_ASSET_BLUEPRINTS: Record<JenisAset, Array<{ nama: string; merk: string; spec: string; kode: string; masa: number; baseHarga: number }>> = {
  PM: [
    { nama: "Laptop Operasional", merk: "Lenovo ThinkPad E14", spec: "Intel i5 16GB 512GB SSD", kode: "NB", masa: 4, baseHarga: 14250000 },
    { nama: "Printer Layanan", merk: "Epson EcoTank L4260", spec: "Print Scan Copy WiFi Duplex", kode: "PRN", masa: 4, baseHarga: 4850000 },
    { nama: "Proyektor Kelas", merk: "Epson EB-E500", spec: "XGA 3600 Lumens HDMI", kode: "PRJ", masa: 5, baseHarga: 7200000 },
    { nama: "Access Point", merk: "Ubiquiti UniFi U6+", spec: "WiFi 6 Dual Band PoE", kode: "NET", masa: 5, baseHarga: 2350000 },
  ],
  ATB: [
    { nama: "Lisensi Produktivitas", merk: "Microsoft 365", spec: "Business Standard Annual", kode: "SW", masa: 1, baseHarga: 2150000 },
    { nama: "Lisensi Desain", merk: "Adobe Creative Cloud", spec: "All Apps Education Annual", kode: "SWD", masa: 1, baseHarga: 7850000 },
    { nama: "Sistem Informasi", merk: "Aset SV Module", spec: "Subscription Modul Inventaris", kode: "APP", masa: 3, baseHarga: 18500000 },
    { nama: "Antivirus Endpoint", merk: "ESET Endpoint", spec: "Endpoint Security Annual", kode: "SEC", masa: 1, baseHarga: 875000 },
  ],
  ATL: [
    { nama: "Meja Kerja Staff", merk: "Olympic Office", spec: "120x60cm engineered wood", kode: "FUR", masa: 8, baseHarga: 1850000 },
    { nama: "Kursi Ergonomis", merk: "Savello Vergo", spec: "Mesh back adjustable armrest", kode: "CHR", masa: 5, baseHarga: 1650000 },
    { nama: "Lemari Arsip", merk: "Brother Metal", spec: "Filing cabinet 4 drawer", kode: "CAB", masa: 8, baseHarga: 3250000 },
    { nama: "Whiteboard Kelas", merk: "Sakura", spec: "Magnetic porcelain 240x120cm", kode: "WBD", masa: 5, baseHarga: 1450000 },
  ],
  AL: [
    { nama: "Sepeda Motor Operasional", merk: "Honda Vario 160", spec: "160cc CBS ISS", kode: "MTR", masa: 8, baseHarga: 28500000 },
    { nama: "Kendaraan Angkut Ringan", merk: "Daihatsu Gran Max", spec: "1.5L Pick Up AC PS", kode: "CAR", masa: 8, baseHarga: 168000000 },
    { nama: "Mobil Operasional", merk: "Toyota Avanza", spec: "1.5G CVT 7 Seat", kode: "CAR", masa: 8, baseHarga: 258000000 },
    { nama: "Mobil Listrik Kampus", merk: "Wuling Air EV", spec: "Long Range Campus Mobility", kode: "EV", masa: 8, baseHarga: 295000000 },
  ],
};

function generateAccumulatedAssets(): Asset[] {
  const units = ["Teknik Informatika", "Administrasi Umum", "Lab Komputer", "Program Vokasi", "Pusat Layanan Akademik", "Keuangan dan SDM", "UPT Bahasa", "Laboratorium Terpadu"];
  const rooms = ["Ruang Dosen A", "Ruang Admin", "Lab Komputer", "Ruang Kelas 101", "Gudang Aset", "Ruang Rapat", "Pool Kendaraan", "Studio Multimedia"];
  const pics = ["Andi Pratama", "Budi Santoso", "Citra Dewi", "Dewi Rahayu", "Joko Widodo", "Rina Maharani", "Anita Wijaya", "Irwan Fauzy"];
  const funds = ["BOPTN", "Mandiri", "Hibah", "PNBP"];
  const conditions = ["Baik", "Baik", "Baik", "Perlu Monitoring", "Rusak Ringan", "Rusak Berat"];
  const years = ["2021", "2022", "2023", "2024", "2025", "2026"];
  const out: Asset[] = [];

  (["PM", "ATB", "ATL", "AL"] as JenisAset[]).forEach((jenis) => {
    const offset = jenis === "PM" ? INITIAL_PM.length : jenis === "ATB" ? INITIAL_ATB.length : jenis === "ATL" ? INITIAL_ATL.length : INITIAL_AL.length;
    for (let i = 1; i <= 50; i += 1) {
      const blueprint = GENERATED_ASSET_BLUEPRINTS[jenis][(i - 1) % GENERATED_ASSET_BLUEPRINTS[jenis].length];
      const seq = offset + i;
      const globalSeq = jenis === "PM" ? 1000 + i : jenis === "ATB" ? 2000 + i : jenis === "ATL" ? 3000 + i : 4000 + i;
      const tahun = years[(i - 1) % years.length];
      const month = String(((i - 1) % 12) + 1).padStart(2, "0");
      const day = String(((i * 7) % 27) + 1).padStart(2, "0");
      const kondisi = conditions[(i + (jenis === "AL" ? 2 : 0)) % conditions.length];
      const harga = blueprint.baseHarga + (i % 10) * Math.round(blueprint.baseHarga * 0.035);
      const id = `${jenis}-${String(seq).padStart(3, "0")}`;
      out.push(makeAsset(
        id,
        `${blueprint.nama} ${String(i).padStart(2, "0")}`,
        blueprint.merk,
        blueprint.spec,
        `${blueprint.kode}${String(globalSeq).padStart(4, "0")}`,
        `${tahun}-${month}-${day}`,
        harga,
        funds[(i - 1) % funds.length],
        kondisi,
        rooms[(i - 1) % rooms.length],
        pics[(i - 1) % pics.length],
        blueprint.masa,
        units[(i - 1) % units.length],
        tahun,
        {
          Dokumen: `DOK-AKUM-${jenis}-${String(i).padStart(3, "0")}`,
          Referensi: `AKUM/${jenis}/${tahun}/${String(i).padStart(3, "0")}`,
          tanggal_opname_terakhir: i % 9 === 0 ? "-" : `2026-${month}-${day}`,
          status_opname_terakhir: i % 13 === 0 ? "Tidak Ditemukan" : i % 9 === 0 ? "Belum Dicek" : "Ditemukan",
          status_lokasi_opname_terakhir: i % 11 === 0 ? "Tidak Sesuai" : "Sesuai",
          status_kejelasan_lokasi: i % 11 === 0 ? "Perlu Verifikasi" : "Jelas",
          status_penggunaan_aset: kondisi === "Rusak Berat" || i % 17 === 0 ? "Tidak Digunakan" : "Digunakan",
          NoPolisi: jenis === "AL" ? `F ${7000 + i} SV` : "-",
          JenisAngkutan: jenis === "AL" ? (blueprint.kode === "MTR" ? "Sepeda Motor" : "Mobil") : "-",
          Model: blueprint.merk,
        },
      ));
    }
  });
  return out;
}

const SEED_ASSETS: Asset[] = [...INITIAL_PM, ...INITIAL_ATB, ...INITIAL_ATL, ...INITIAL_AL, ...generateAccumulatedAssets()];
const SEED_ASSET_COUNT = SEED_ASSETS.length;

const SEED_USERS: UserRecord[] = [
  { id: "U-001", nama: "Salgado Ginting", role: "Admin Sistem", unit: "Rektorat", email: "salgadoginting@apps.ipb.ac.id", aktif: true },
  { id: "U-002", nama: "Rina Maharani", role: "Operator Aset", unit: "Teknik Informatika", email: "rina@ipb.ac.id", aktif: true },
  { id: "U-003", nama: "Budi Santoso", role: "Teknisi", unit: "Sarpras", email: "budi@ipb.ac.id", aktif: true },
  { id: "U-004", nama: "Anita Wijaya", role: "Pengelola Pengadaan", unit: "BPK", email: "anita@ipb.ac.id", aktif: true },
  { id: "U-005", nama: "Dr. Rudi Hartono", role: "Pimpinan", unit: "Rektorat", email: "rudi@ipb.ac.id", aktif: true },
];

const SEED_MAINTENANCE: MaintenanceTicket[] = [
  { id: "PRB-2026-001", asset_id: "PM-003", tanggal: "2025-09-01", jenis: "Korektif", kategori_kerusakan: "Struktural", tingkat_kerusakan: "Sedang", biaya: 750000, downtime_jam: 12, status: "Selesai", catatan: "Ganti PSU." },
  { id: "PRB-2026-002", asset_id: "PM-005", tanggal: "2026-04-15", jenis: "Korektif", kategori_kerusakan: "Mekanis", tingkat_kerusakan: "Ringan", biaya: 350000, downtime_jam: 6, status: "Dalam Proses" },
  { id: "PRB-2026-003", asset_id: "PM-011", tanggal: "2026-05-10", jenis: "Korektif", kategori_kerusakan: "Mekanis", tingkat_kerusakan: "Ringan", biaya: 500000, downtime_jam: 8, status: "Dalam Proses" },
  { id: "PRB-2026-004", asset_id: "ATL-003", tanggal: "2025-12-12", jenis: "Korektif", kategori_kerusakan: "Mekanis", tingkat_kerusakan: "Ringan", biaya: 250000, downtime_jam: 4, status: "Selesai" },
  { id: "PRB-2026-005", asset_id: "ATB-008", tanggal: "2026-03-21", jenis: "Korektif", kategori_kerusakan: "Software", tingkat_kerusakan: "Ringan", biaya: 200000, downtime_jam: 2, status: "Selesai" },
  { id: "PRB-2026-006", asset_id: "AL-004", tanggal: "2026-02-08", jenis: "Korektif", kategori_kerusakan: "Mekanis", tingkat_kerusakan: "Sedang", biaya: 1200000, downtime_jam: 24, status: "Selesai" },
];

const SEED_MUTASI: MutationRequest[] = [
  { id: "MT-2026-001", asset_id: "PM-001", tanggal: "2026-05-30", dari_ruangan: "Ruang Admin", ke_ruangan: "Ruang Dosen A", dari_pic: "Budi Santoso", ke_pic: "Andi Pratama", status: "Selesai" },
  { id: "MT-2026-002", asset_id: "PM-014", tanggal: "2026-05-15", dari_ruangan: "Gudang", ke_ruangan: "Lab Komputer", dari_pic: "Staff Logistik", ke_pic: "Joko Widodo", status: "Menunggu Persetujuan" },
];

const SEED_PROCUREMENT: ProcurementRequest[] = [
  { id: "PGD-2026-001", tanggal: "2026-04-10", nama_barang: "Laptop Lenovo ThinkPad E14", jenis_aset: "PM", jumlah: 5, estimasi_biaya: 75000000, alasan: "Penggantian aset PM-003 yang sering rusak.", status: "Disetujui" },
  { id: "PGD-2026-002", tanggal: "2026-05-05", nama_barang: "Lisensi Microsoft 365 Tambahan", jenis_aset: "ATB", jumlah: 1, estimasi_biaya: 12000000, alasan: "Ekspansi kebutuhan staff baru.", status: "Menunggu Persetujuan" },
];

const SEED_OPNAME: StockOpnameRecord[] = SEED_ASSETS.slice(0, 8).map((a, i) => ({
  id: `SO-2025-${String(i + 1).padStart(3, "0")}`,
  asset_id: a.id,
  kode_tag: a.kode_tag_aset,
  tanggal: "2025-12-15",
  status_opname: "Terverifikasi",
  kondisi_fisik: a.Kondisi,
  status_lokasi: "Sesuai",
  diverifikasi_oleh: "Tim Opname 2025",
}));

const SEED_DOCUMENTS: DocumentRecord[] = [
  { id: "DOC-001", nama: "BAP Pengadaan 2026", jenis: "Pengadaan", transaction_id: "PGD-2026-001", url: "#", diunggah_oleh: "Anita Wijaya", tanggal: "2026-04-10" },
  { id: "DOC-002", nama: "Faktur Servis PM-003", jenis: "Perbaikan", asset_id: "PM-003", transaction_id: "PRB-2026-001", url: "#", diunggah_oleh: "Budi Santoso", tanggal: "2025-09-01" },
];

const SEED_ROOMS: RoomRecord[] = (() => {
  const seen = new Set<string>();
  const out: RoomRecord[] = [];
  for (const a of SEED_ASSETS) {
    if (seen.has(a.kode_ruangan)) continue;
    seen.add(a.kode_ruangan);
    out.push({
      kode_ruangan: a.kode_ruangan,
      nama_ruangan: a.nama_ruangan_standar || a.Nama_ruangan,
      nama_gedung: a.nama_gedung,
      lantai_level: a.lantai_level,
      kategori: a.kategori_ruangan,
      luas_m2: parseInt(a.luas_ruangan_m2) || 0,
      kapasitas: parseInt(a.kapasitas_orang_ruangan) || 0,
    });
  }
  return out;
})();

const SEED_ACTIVITY: ActivityLog[] = [
  { id: 1, waktu: "08:30:12", tgl: "2026-06-01", pengguna: "Salgado Ginting", role: "Admin Sistem", menu: "Sistem", aksi: "Login ke sistem", target_type: "Sistem", target_id: "-", status: "Berhasil", jenis: "login", ip: "10.0.1.45", device: "Chrome / MacOS" },
  { id: 2, waktu: "09:10:45", tgl: "2026-06-01", pengguna: "Rina Maharani", role: "Operator Aset", menu: "Data Aset", aksi: "Menambahkan aset PM-014 (ASUS VivoBook)", target_type: "Asset", target_id: "PM-014", status: "Berhasil", jenis: "tambah", ip: "10.0.1.67", device: "Firefox / Windows" },
];

// ─────────────────────────────────────────────────────────────────────────────
// Status / quality rules — single source of truth for badge logic.
// ─────────────────────────────────────────────────────────────────────────────

function n(s: string | undefined): number {
  if (!s) return 0;
  const v = parseInt(String(s).replace(/[^0-9-]/g, ""));
  return isNaN(v) ? 0 : v;
}

function daysBetween(a: string, b: string): number {
  const da = new Date(a).getTime();
  const db = new Date(b).getTime();
  if (isNaN(da) || isNaN(db)) return 0;
  return Math.round((db - da) / (1000 * 60 * 60 * 24));
}

export function getOpnameStatus(a: Asset): StatusOpname {
  if (!a.tanggal_opname_terakhir || a.tanggal_opname_terakhir === "-") return "Belum Dicek";
  if (a.status_opname_terakhir === "Hilang" || a.status_opname_terakhir === "Tidak Ditemukan") return "Tidak Ditemukan";
  if (a.status_lokasi_opname_terakhir === "Tidak Sesuai" || a.status_lokasi_opname_terakhir === "Berbeda") return "Selisih";
  if (a.status_kejelasan_lokasi === "Tidak Jelas" || a.status_kejelasan_lokasi === "Perlu Verifikasi") return "Perlu Verifikasi";
  if (a.status_opname_terakhir === "Ditemukan" || a.status_opname_terakhir === "Terverifikasi") return "Terverifikasi";
  return "Perlu Verifikasi";
}

export function getMaintenanceStatus(a: Asset): StatusMaintenance {
  if (!a.jadwal_maintenance_berikutnya || a.jadwal_maintenance_berikutnya === "-") return "Scheduled";
  const diff = daysBetween(TODAY, a.jadwal_maintenance_berikutnya);
  if (diff < 0) return "Overdue";
  if (diff <= 30) return "Due Soon";
  return "Scheduled";
}

export function getKondisiSistem(a: Asset): StatusKondisi {
  const sisaBulan = n(a._sisa_masa_manfaat_bulan);
  const totalFreq = n(a.total_frekuensi_maintenance);
  const totalBiaya = n(a._total_biaya_maintenance);
  const tingkat = a.tingkat_kerusakan_terakhir;
  const kondisi = a.Kondisi;

  if (tingkat === "Berat" || tingkat === "Kritis" || kondisi === "Rusak Berat") {
    if (sisaBulan <= 0 && totalBiaya > 5000000) return "Prioritas Penggantian";
    return "Rusak Berat";
  }
  if (kondisi === "Rusak Ringan" || tingkat === "Ringan") return "Rusak Ringan";
  if (sisaBulan <= 12 || totalFreq >= 3) return "Perlu Monitoring";
  return "Baik";
}

export function getDataQuality(a: Asset): DataQuality {
  // Konflik
  if (a.status_opname_terakhir === "Hilang" && a.status_penggunaan_aset === "Digunakan") return "Konflik Data";
  if (a.kondisi_fisik_opname_terakhir === "Rusak Berat" && a.Kondisi === "Baik") return "Konflik Data";
  if (a.status_lokasi_opname_terakhir === "Tidak Sesuai" && a.status_kejelasan_lokasi === "Jelas") return "Konflik Data";
  if (n(a._total_biaya_maintenance) < n(a.biaya_maintenance_terakhir)) return "Konflik Data";
  if (a.latitude && !a.longitude) return "Konflik Data";

  // Tidak Lengkap
  const required = [a.id, a.Nama_Barang, a.Nama_unit, a._nilai_buku, a.TglPerolehan];
  if (required.some((v) => !v || v === "-")) return "Tidak Lengkap";

  // Perlu Verifikasi
  if (
    !a.nama_pic ||
    a.status_kejelasan_lokasi === "Tidak Jelas" ||
    a.status_kejelasan_lokasi === "Perlu Verifikasi" ||
    !a.tanggal_opname_terakhir ||
    a.tanggal_opname_terakhir === "-" ||
    getMaintenanceStatus(a) === "Overdue"
  ) return "Perlu Verifikasi";

  return "Lengkap";
}

export function computeConditionScore(a: Asset): number {
  // 0–100, higher = better
  let score = 100;
  if (a.Kondisi === "Rusak Ringan") score -= 25;
  if (a.Kondisi === "Rusak Berat") score -= 60;
  if (a.kondisi_fisik_opname_terakhir === "Rusak Ringan") score -= 5;
  if (a.kondisi_fisik_opname_terakhir === "Rusak Berat") score -= 15;
  const sisaBulan = n(a._sisa_masa_manfaat_bulan);
  const masaBulan = n(a._masa_manfaat_bulan) || 1;
  const sisaPct = sisaBulan / masaBulan;
  if (sisaPct < 0.25) score -= 15;
  if (sisaPct <= 0) score -= 20;
  score -= Math.min(20, n(a.total_frekuensi_maintenance) * 4);
  score -= Math.min(15, Math.floor(n(a._total_biaya_maintenance) / 5_000_000) * 3);
  if (a.tingkat_kerusakan_terakhir === "Berat") score -= 15;
  if (a.tingkat_kerusakan_terakhir === "Kritis") score -= 25;
  score -= Math.min(10, Math.floor(n(a.downtime_terakhir_jam) / 24) * 5);
  return Math.max(0, Math.min(100, score));
}

export function computeReplacementPriority(a: Asset): number {
  // 0–100, higher = should replace sooner
  let s = 0;
  const sisaBulan = n(a._sisa_masa_manfaat_bulan);
  if (sisaBulan <= 0) s += 35;
  else if (sisaBulan <= 6) s += 25;
  else if (sisaBulan <= 12) s += 12;

  if (a.Kondisi === "Rusak Berat") s += 25;
  else if (a.Kondisi === "Rusak Ringan") s += 10;

  s += Math.min(20, n(a.total_frekuensi_maintenance) * 5);
  s += Math.min(15, Math.floor(n(a._total_biaya_maintenance) / 2_500_000) * 3);
  if (n(a.downtime_terakhir_jam) >= 24) s += 5;

  // unecnomical: nilai buku ≤ 5% harga perolehan
  if (n(a._harga_perolehan) > 0 && n(a._nilai_buku) / n(a._harga_perolehan) < 0.05) s += 5;
  return Math.min(100, s);
}

// ─────────────────────────────────────────────────────────────────────────────
// Context
// ─────────────────────────────────────────────────────────────────────────────

export interface NavigationIntent {
  page: string;
  payload?: Record<string, unknown>;
}

interface DataStoreContextType {
  // collections
  assets: Asset[];
  maintenanceTickets: MaintenanceTicket[];
  mutationRequests: MutationRequest[];
  procurementRequests: ProcurementRequest[];
  stockOpnameRecords: StockOpnameRecord[];
  documents: DocumentRecord[];
  activityLogs: ActivityLog[];
  users: UserRecord[];
  rooms: RoomRecord[];

  // selection + filters
  selectedAssetId: string | null;
  setSelectedAssetId: (id: string | null) => void;
  filters: Filters;
  setFilters: (next: Partial<Filters>) => void;
  resetFilters: () => void;

  // navigation intent — pages read this to react to cross-module clicks
  pendingNav: NavigationIntent | null;
  navigateTo: (page: string, payload?: Record<string, unknown>) => void;
  consumePendingNav: () => NavigationIntent | null;

  // selectors
  getAssetById: (id: string) => Asset | undefined;
  getAssetByTag: (tag: string) => Asset | undefined;
  getAssetsByJenis: (jenis: JenisAset) => Asset[];
  getAssetsByUnit: (unit: string) => Asset[];
  getAssetsByRoom: (kodeRuangan: string) => Asset[];
  getAssetsByPIC: (pic: string) => Asset[];
  filteredAssets: Asset[];

  // computed metrics
  computeTotalAssets: () => number;
  computeTotalBookValue: () => number;
  computeTotalAcquisitionValue: () => number;
  computeTotalDepreciation: () => number;
  computeStockOpnameProgress: () => { done: number; total: number; pct: number };
  computeMissingAssets: () => number;
  computeUnverifiedAssets: () => number;
  computeAssetsWithoutClearLocation: () => number;
  computeAssetsWithoutPIC: () => number;
  computeMaintenanceOverdue: () => number;
  computeTopUnits: (limit?: number) => { unit: string; value: number }[];
  computeTopMaintenanceCost: (limit?: number) => { unit: string; biaya: number; freq: number }[];
  computeKondisiBreakdown: () => { label: StatusKondisi; value: number }[];
  computeIdleAssetRate: () => { idle: number; total: number; pct: number };
  computeRoomUtilization: () => { kode_ruangan: string; nama: string; count: number; kapasitas: number; pct: number }[];
  computeProcurementNeed: () => Asset[];
  computeReplacementCandidates: (limit?: number) => Asset[];

  // mutations (record activity automatically)
  upsertAsset: (a: Asset, opts?: { reason?: string; user?: string }) => void;
  deleteAsset: (id: string, opts?: { user?: string }) => void;
  recordStockOpname: (asset_id: string, partial: Partial<Asset>, opts?: { user?: string }) => void;
  completeMaintenance: (ticket: MaintenanceTicket, opts?: { user?: string }) => void;
  approveMutation: (id: string, opts?: { user?: string }) => void;
  completeProcurement: (id: string, newAsset?: Asset, opts?: { user?: string }) => void;
  uploadDocument: (doc: DocumentRecord, opts?: { user?: string }) => void;
  appendActivity: (log: Omit<ActivityLog, "id" | "waktu" | "tgl">) => void;
}

const DataStoreContext = createContext<DataStoreContextType | null>(null);

export function useDataStore(): DataStoreContextType {
  const ctx = useContext(DataStoreContext);
  if (!ctx) throw new Error("useDataStore must be used within DataStoreProvider");
  return ctx;
}

function nowParts() {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return {
    waktu: `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`,
    tgl: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
  };
}

const CURRENT_USER = { nama: "Salgado Ginting", role: "Admin Sistem" };

export function DataStoreProvider({ children }: { children: React.ReactNode }) {
  const [assets, setAssets] = useState<Asset[]>(SEED_ASSETS);
  const [maintenanceTickets, setMaintenanceTickets] = useState<MaintenanceTicket[]>(SEED_MAINTENANCE);
  const [mutationRequests, setMutationRequests] = useState<MutationRequest[]>(SEED_MUTASI);
  const [procurementRequests, setProcurementRequests] = useState<ProcurementRequest[]>(SEED_PROCUREMENT);
  const [stockOpnameRecords, setStockOpnameRecords] = useState<StockOpnameRecord[]>(SEED_OPNAME);
  const [documents, setDocuments] = useState<DocumentRecord[]>(SEED_DOCUMENTS);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(SEED_ACTIVITY);
  const [users] = useState<UserRecord[]>(SEED_USERS);
  const [rooms] = useState<RoomRecord[]>(SEED_ROOMS);
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);
  const [filters, setFiltersState] = useState<Filters>(DEFAULT_FILTERS);
  const [pendingNav, setPendingNav] = useState<NavigationIntent | null>(null);

  // Figma Make / Vite HMR can preserve React state after seed data changes.
  // Reconcile by id so the additional 200 accumulated assets appear instantly
  // without requiring users to reset the preview session. User-created/edited
  // records are kept because we only append seed rows that are still missing.
  useEffect(() => {
    setAssets((prev) => {
      if (prev.length >= SEED_ASSET_COUNT) return prev;
      const existingIds = new Set(prev.map((asset) => asset.id));
      const missingSeedAssets = SEED_ASSETS.filter((asset) => !existingIds.has(asset.id));
      return missingSeedAssets.length === 0 ? prev : [...prev, ...missingSeedAssets];
    });
  }, []);

  // ── API bridge — silently hydrate from NestJS when backend is reachable ─────
  // Falls back to local seed data automatically when backend is offline.
  useEffect(() => {
    let cancelled = false;
    async function hydrate() {
      try {
        const [
          assetsRes,
          maintenanceRes,
          mutasiRes,
          pengadaanRes,
          opnameRes,
          dokumenRes,
          aktivitasRes,
        ] = await Promise.all([
          apiClient.get<{ data: Asset[] }>("/assets", { params: { limit: 9999 } }),
          apiClient.get<{ data: MaintenanceTicket[] }>("/maintenance", { params: { limit: 9999 } }),
          apiClient.get<{ data: MutationRequest[] }>("/mutasi", { params: { limit: 9999 } }),
          apiClient.get<{ data: ProcurementRequest[] }>("/pengadaan", { params: { limit: 9999 } }),
          apiClient.get<{ data: StockOpnameRecord[] }>("/opname/records", { params: { limit: 9999 } }),
          apiClient.get<{ data: DocumentRecord[] }>("/dokumen", { params: { limit: 9999 } }),
          apiClient.get<{ data: ActivityLog[] }>("/aktivitas", { params: { limit: 9999 } }),
        ]);
        if (cancelled) return;
        if (assetsRes.data.data?.length) setAssets(assetsRes.data.data);
        if (maintenanceRes.data.data?.length) setMaintenanceTickets(maintenanceRes.data.data);
        if (mutasiRes.data.data?.length) setMutationRequests(mutasiRes.data.data);
        if (pengadaanRes.data.data?.length) setProcurementRequests(pengadaanRes.data.data);
        if (opnameRes.data.data?.length) setStockOpnameRecords(opnameRes.data.data);
        if (dokumenRes.data.data?.length) setDocuments(dokumenRes.data.data);
        if (aktivitasRes.data.data?.length) setActivityLogs(aktivitasRes.data.data);
      } catch {
        // Backend offline — local seed data remains active. No action needed.
      }
    }
    hydrate();
    return () => { cancelled = true; };
  }, []);

  // ── Socket.IO — apply real-time mutations from the NestJS gateway ───────────
  useEffect(() => {
    connectSocket();
    const offs = [
      onEvent<Asset>("asset:created", (a) => setAssets((p) => [...p, a])),
      onEvent<Asset>("asset:updated", (a) =>
        setAssets((p) => p.map((x) => (x.id === a.id ? a : x)))),
      onEvent<{ id: string }>("asset:deleted", ({ id }) =>
        setAssets((p) => p.filter((x) => x.id !== id))),
      onEvent<MutationRequest>("mutasi:status_changed", (m) =>
        setMutationRequests((p) => p.map((x) => (x.id === m.id ? m : x)))),
      onEvent<ProcurementRequest>("pengadaan:status_changed", (pr) =>
        setProcurementRequests((p) => p.map((x) => (x.id === pr.id ? pr : x)))),
      onEvent<MaintenanceTicket>("maintenance:status_changed", (t) =>
        setMaintenanceTickets((p) => p.map((x) => (x.id === t.id ? t : x)))),
      onEvent<StockOpnameRecord>("opname:record_verified", (r) =>
        setStockOpnameRecords((p) => p.map((x) => (x.id === r.id ? r : x)))),
    ];
    return () => {
      offs.forEach((off) => off());
      disconnectSocket();
    };
  }, []);

  const setFilters = useCallback((next: Partial<Filters>) => {
    setFiltersState((prev) => ({ ...prev, ...next }));
  }, []);
  const resetFilters = useCallback(() => setFiltersState(DEFAULT_FILTERS), []);

  const appendActivity = useCallback((log: Omit<ActivityLog, "id" | "waktu" | "tgl">) => {
    const t = nowParts();
    setActivityLogs((prev) => [{ id: Date.now(), waktu: t.waktu, tgl: t.tgl, ...log }, ...prev]);
  }, []);

  const navigateTo = useCallback((page: string, payload?: Record<string, unknown>) => {
    setPendingNav({ page, payload });
  }, []);

  const consumePendingNav = useCallback(() => {
    const v = pendingNav;
    setPendingNav(null);
    return v;
  }, [pendingNav]);

  // ── Selectors ───────────────────────────────────────────────────────────────
  const getAssetById = useCallback((id: string) => assets.find((a) => a.id === id), [assets]);
  const getAssetByTag = useCallback(
    (tag: string) => assets.find((a) => a.kode_tag_aset === tag),
    [assets],
  );
  const getAssetsByJenis = useCallback(
    (jenis: JenisAset) => assets.filter((a) => a.TipeAset === jenis),
    [assets],
  );
  const getAssetsByUnit = useCallback(
    (unit: string) => assets.filter((a) => a.Nama_unit === unit),
    [assets],
  );
  const getAssetsByRoom = useCallback(
    (kodeRuangan: string) => assets.filter((a) => a.kode_ruangan === kodeRuangan),
    [assets],
  );
  const getAssetsByPIC = useCallback(
    (pic: string) => assets.filter((a) => a.nama_pic === pic),
    [assets],
  );

  // global filter application
  const filteredAssets = useMemo(() => {
    const f = filters;
    return assets.filter((a) => {
      if (f.search) {
        const q = f.search.toLowerCase();
        if (!Object.values(a).some((v) => String(v).toLowerCase().includes(q))) return false;
      }
      if (f.jenis !== "semua" && a.TipeAset !== f.jenis) return false;
      if (f.tahun !== "semua" && a.TahunBuku !== f.tahun) return false;
      if (f.unit !== "semua" && a.Nama_unit !== f.unit) return false;
      if (f.gedung !== "semua" && a.nama_gedung !== f.gedung) return false;
      if (f.lantai !== "semua" && a.lantai_level !== f.lantai) return false;
      if (f.ruangan !== "semua" && a.kode_ruangan !== f.ruangan) return false;
      if (f.kategori !== "semua" && a.kategori_ruangan !== f.kategori) return false;
      if (f.kondisi !== "semua" && a.Kondisi !== f.kondisi) return false;
      if (f.pic !== "semua" && a.nama_pic !== f.pic) return false;
      if (f.statusOpname !== "semua" && getOpnameStatus(a) !== f.statusOpname) return false;
      if (f.statusMaintenance !== "semua" && getMaintenanceStatus(a) !== f.statusMaintenance) return false;
      return true;
    });
  }, [assets, filters]);

  // ── Computed metrics ────────────────────────────────────────────────────────
  const computeTotalAssets = useCallback(() => filteredAssets.length, [filteredAssets]);
  const computeTotalBookValue = useCallback(
    () => filteredAssets.reduce((s, a) => s + n(a._nilai_buku), 0),
    [filteredAssets],
  );
  const computeTotalAcquisitionValue = useCallback(
    () => filteredAssets.reduce((s, a) => s + n(a._harga_perolehan), 0),
    [filteredAssets],
  );
  const computeTotalDepreciation = useCallback(
    () => filteredAssets.reduce((s, a) => s + n(a._akumulasi_penyusutan), 0),
    [filteredAssets],
  );
  const computeStockOpnameProgress = useCallback(() => {
    const total = filteredAssets.length;
    const done = filteredAssets.filter((a) => getOpnameStatus(a) === "Terverifikasi").length;
    return { done, total, pct: total === 0 ? 0 : Math.round((done / total) * 100) };
  }, [filteredAssets]);
  const computeMissingAssets = useCallback(
    () => filteredAssets.filter((a) => getOpnameStatus(a) === "Tidak Ditemukan").length,
    [filteredAssets],
  );
  const computeUnverifiedAssets = useCallback(
    () =>
      filteredAssets.filter((a) => {
        const s = getOpnameStatus(a);
        return s === "Belum Dicek" || s === "Perlu Verifikasi";
      }).length,
    [filteredAssets],
  );
  const computeAssetsWithoutClearLocation = useCallback(
    () =>
      filteredAssets.filter(
        (a) =>
          !a.status_kejelasan_lokasi ||
          a.status_kejelasan_lokasi === "Tidak Jelas" ||
          a.status_kejelasan_lokasi === "Perlu Verifikasi",
      ).length,
    [filteredAssets],
  );
  const computeAssetsWithoutPIC = useCallback(
    () => filteredAssets.filter((a) => !a.nama_pic || a.nama_pic === "-").length,
    [filteredAssets],
  );
  const computeMaintenanceOverdue = useCallback(
    () => filteredAssets.filter((a) => getMaintenanceStatus(a) === "Overdue").length,
    [filteredAssets],
  );
  const computeTopUnits = useCallback(
    (limit = 6) => {
      const map = new Map<string, number>();
      for (const a of filteredAssets) map.set(a.Nama_unit, (map.get(a.Nama_unit) || 0) + 1);
      return Array.from(map.entries())
        .map(([unit, value]) => ({ unit, value }))
        .sort((a, b) => b.value - a.value)
        .slice(0, limit);
    },
    [filteredAssets],
  );
  const computeTopMaintenanceCost = useCallback(
    (limit = 5) => {
      const map = new Map<string, { biaya: number; freq: number }>();
      for (const a of filteredAssets) {
        const cur = map.get(a.Nama_unit) || { biaya: 0, freq: 0 };
        cur.biaya += n(a._total_biaya_maintenance);
        cur.freq += n(a.total_frekuensi_maintenance);
        map.set(a.Nama_unit, cur);
      }
      return Array.from(map.entries())
        .map(([unit, v]) => ({ unit, biaya: v.biaya, freq: v.freq }))
        .sort((a, b) => b.biaya - a.biaya)
        .slice(0, limit);
    },
    [filteredAssets],
  );
  const computeKondisiBreakdown = useCallback(() => {
    const counts: Record<string, number> = {};
    for (const a of filteredAssets) {
      const k = getKondisiSistem(a);
      counts[k] = (counts[k] || 0) + 1;
    }
    const order: StatusKondisi[] = ["Baik", "Perlu Monitoring", "Rusak Ringan", "Rusak Berat", "Prioritas Penggantian"];
    return order.map((label) => ({ label, value: counts[label] || 0 }));
  }, [filteredAssets]);
  const computeIdleAssetRate = useCallback(() => {
    const total = filteredAssets.length;
    const idle = filteredAssets.filter(
      (a) =>
        a.status_penggunaan_aset === "Tidak Digunakan" ||
        a.status_penggunaan_aset === "Idle",
    ).length;
    return { idle, total, pct: total === 0 ? 0 : Math.round((idle / total) * 100) };
  }, [filteredAssets]);
  const computeRoomUtilization = useCallback(() => {
    const map = new Map<string, { nama: string; count: number; kapasitas: number }>();
    for (const a of filteredAssets) {
      const k = a.kode_ruangan;
      const cur = map.get(k) || {
        nama: a.nama_ruangan_standar || a.Nama_ruangan,
        count: 0,
        kapasitas: parseInt(a.kapasitas_orang_ruangan) || 0,
      };
      cur.count += 1;
      map.set(k, cur);
    }
    return Array.from(map.entries()).map(([kode_ruangan, v]) => ({
      kode_ruangan,
      nama: v.nama,
      count: v.count,
      kapasitas: v.kapasitas,
      pct: v.kapasitas === 0 ? 0 : Math.round((v.count / v.kapasitas) * 100),
    }));
  }, [filteredAssets]);
  const computeProcurementNeed = useCallback(
    () =>
      filteredAssets.filter((a) => {
        const sisa = n(a._sisa_masa_manfaat_bulan);
        return (
          a.Kondisi === "Rusak Berat" ||
          (sisa <= 0 && n(a.total_frekuensi_maintenance) >= 3) ||
          computeReplacementPriority(a) >= 70
        );
      }),
    [filteredAssets],
  );
  const computeReplacementCandidates = useCallback(
    (limit = 10) =>
      [...filteredAssets]
        .map((a) => ({ a, score: computeReplacementPriority(a) }))
        .sort((x, y) => y.score - x.score)
        .slice(0, limit)
        .map((x) => x.a),
    [filteredAssets],
  );

  // ── Mutations ───────────────────────────────────────────────────────────────
  const upsertAsset = useCallback(
    (a: Asset, opts?: { reason?: string; user?: string }) => {
      setAssets((prev) => {
        const idx = prev.findIndex((x) => x.id === a.id);
        if (idx === -1) {
          appendActivity({
            pengguna: opts?.user || CURRENT_USER.nama,
            role: CURRENT_USER.role,
            menu: "Data Aset",
            aksi: `Menambahkan aset ${a.id} (${a.Nama_Barang})`,
            target_type: "Asset",
            target_id: a.id,
            status: "Berhasil",
            jenis: "tambah",
          });
          return [...prev, a];
        }
        appendActivity({
          pengguna: opts?.user || CURRENT_USER.nama,
          role: CURRENT_USER.role,
          menu: "Data Aset",
          aksi: `Memperbarui aset ${a.id}${opts?.reason ? ` — ${opts.reason}` : ""}`,
          target_type: "Asset",
          target_id: a.id,
          status: "Berhasil",
          jenis: "update",
        });
        const copy = [...prev];
        copy[idx] = { ...prev[idx], ...a };
        return copy;
      });
    },
    [appendActivity],
  );

  const deleteAsset = useCallback(
    (id: string, opts?: { user?: string }) => {
      setAssets((prev) => prev.filter((a) => a.id !== id));
      appendActivity({
        pengguna: opts?.user || CURRENT_USER.nama,
        role: CURRENT_USER.role,
        menu: "Data Aset",
        aksi: `Menghapus aset ${id}`,
        target_type: "Asset",
        target_id: id,
        status: "Berisiko",
        jenis: "hapus",
      });
    },
    [appendActivity],
  );

  const recordStockOpname = useCallback(
    (asset_id: string, partial: Partial<Asset>, opts?: { user?: string }) => {
      const user = opts?.user || CURRENT_USER.nama;
      setAssets((prev) =>
        prev.map((a) =>
          a.id === asset_id
            ? {
                ...a,
                tanggal_opname_terakhir: nowParts().tgl,
                diverifikasi_oleh_terakhir: user,
                ...partial,
              }
            : a,
        ),
      );
      const t = nowParts();
      setStockOpnameRecords((prev) => [
        ...prev,
        {
          id: `SO-${Date.now()}`,
          asset_id,
          kode_tag: partial.kode_tag_aset || "",
          tanggal: t.tgl,
          status_opname: partial.status_opname_terakhir || "Terverifikasi",
          kondisi_fisik: partial.kondisi_fisik_opname_terakhir || "-",
          status_lokasi: partial.status_lokasi_opname_terakhir || "Sesuai",
          diverifikasi_oleh: user,
        },
      ]);
      appendActivity({
        pengguna: user,
        role: CURRENT_USER.role,
        menu: "Opname",
        aksi: `Scan opname aset ${asset_id} — ${partial.status_opname_terakhir || "Terverifikasi"}`,
        target_type: "Asset",
        target_id: asset_id,
        status: "Berhasil",
        jenis: "opname",
      });
    },
    [appendActivity],
  );

  const completeMaintenance = useCallback(
    (ticket: MaintenanceTicket, opts?: { user?: string }) => {
      setMaintenanceTickets((prev) => {
        const idx = prev.findIndex((t) => t.id === ticket.id);
        if (idx === -1) return [...prev, { ...ticket, status: "Selesai" }];
        const copy = [...prev];
        copy[idx] = { ...ticket, status: "Selesai" };
        return copy;
      });
      setAssets((prev) =>
        prev.map((a) => {
          if (a.id !== ticket.asset_id) return a;
          const totalFreq = n(a.total_frekuensi_maintenance) + 1;
          const totalBiaya = n(a._total_biaya_maintenance) + ticket.biaya;
          const avg = n(a.rata_rata_waktu_perbaikan_jam);
          return {
            ...a,
            tanggal_maintenance_terakhir: ticket.tanggal,
            jenis_maintenance_terakhir: ticket.jenis,
            kategori_kerusakan_terakhir: ticket.kategori_kerusakan,
            tingkat_kerusakan_terakhir: ticket.tingkat_kerusakan,
            biaya_maintenance_terakhir: fmtRp(ticket.biaya),
            total_frekuensi_maintenance: String(totalFreq),
            total_biaya_maintenance: fmtRp(totalBiaya),
            _total_biaya_maintenance: String(totalBiaya),
            downtime_terakhir_jam: String(ticket.downtime_jam),
            rata_rata_waktu_perbaikan_jam: String(Math.round((avg + ticket.downtime_jam) / 2)),
            jadwal_maintenance_berikutnya: ticket.jadwal_berikutnya || a.jadwal_maintenance_berikutnya,
          };
        }),
      );
      appendActivity({
        pengguna: opts?.user || CURRENT_USER.nama,
        role: "Teknisi",
        menu: "Perbaikan",
        aksi: `Selesaikan tiket ${ticket.id} untuk aset ${ticket.asset_id}`,
        target_type: "Asset",
        target_id: ticket.asset_id,
        status: "Berhasil",
        jenis: "perbaikan",
      });
    },
    [appendActivity],
  );

  const approveMutation = useCallback(
    (id: string, opts?: { user?: string }) => {
      let target: MutationRequest | undefined;
      setMutationRequests((prev) =>
        prev.map((m) => {
          if (m.id === id) {
            target = { ...m, status: "Selesai" };
            return target;
          }
          return m;
        }),
      );
      if (target) {
        setAssets((prev) =>
          prev.map((a) =>
            a.id === target!.asset_id
              ? {
                  ...a,
                  Nama_ruangan: target!.ke_ruangan,
                  nama_ruangan_standar: target!.ke_ruangan,
                  nama_pic: target!.ke_pic,
                  tanggal_mutasi_terakhir: target!.tanggal,
                  status_mutasi_terakhir: "Selesai",
                  catatan_mutasi_terakhir: target!.catatan || "-",
                }
              : a,
          ),
        );
        appendActivity({
          pengguna: opts?.user || CURRENT_USER.nama,
          role: CURRENT_USER.role,
          menu: "Mutasi",
          aksi: `Menyetujui mutasi ${id} (aset ${target.asset_id})`,
          target_type: "Asset",
          target_id: target.asset_id,
          status: "Berhasil",
          jenis: "mutasi",
        });
      }
    },
    [appendActivity],
  );

  const completeProcurement = useCallback(
    (id: string, newAsset?: Asset, opts?: { user?: string }) => {
      setProcurementRequests((prev) =>
        prev.map((p) =>
          p.id === id ? { ...p, status: "Selesai", asset_id_baru: newAsset?.id || p.asset_id_baru } : p,
        ),
      );
      if (newAsset) setAssets((prev) => [...prev, newAsset]);
      appendActivity({
        pengguna: opts?.user || CURRENT_USER.nama,
        role: "Pengelola Pengadaan",
        menu: "Pengadaan",
        aksi: `Pengadaan ${id} selesai${newAsset ? ` — aset baru ${newAsset.id}` : ""}`,
        target_type: "Procurement",
        target_id: id,
        status: "Berhasil",
        jenis: "pengadaan",
      });
    },
    [appendActivity],
  );

  const uploadDocument = useCallback(
    (doc: DocumentRecord, opts?: { user?: string }) => {
      setDocuments((prev) => [...prev, doc]);
      appendActivity({
        pengguna: opts?.user || CURRENT_USER.nama,
        role: CURRENT_USER.role,
        menu: "Dokumen",
        aksi: `Mengunggah dokumen ${doc.nama}`,
        target_type: "Document",
        target_id: doc.id,
        status: "Berhasil",
        jenis: "dokumen",
      });
    },
    [appendActivity],
  );

  const value: DataStoreContextType = {
    assets,
    maintenanceTickets,
    mutationRequests,
    procurementRequests,
    stockOpnameRecords,
    documents,
    activityLogs,
    users,
    rooms,
    selectedAssetId,
    setSelectedAssetId,
    filters,
    setFilters,
    resetFilters,
    pendingNav,
    navigateTo,
    consumePendingNav,
    getAssetById,
    getAssetByTag,
    getAssetsByJenis,
    getAssetsByUnit,
    getAssetsByRoom,
    getAssetsByPIC,
    filteredAssets,
    computeTotalAssets,
    computeTotalBookValue,
    computeTotalAcquisitionValue,
    computeTotalDepreciation,
    computeStockOpnameProgress,
    computeMissingAssets,
    computeUnverifiedAssets,
    computeAssetsWithoutClearLocation,
    computeAssetsWithoutPIC,
    computeMaintenanceOverdue,
    computeTopUnits,
    computeTopMaintenanceCost,
    computeKondisiBreakdown,
    computeIdleAssetRate,
    computeRoomUtilization,
    computeProcurementNeed,
    computeReplacementCandidates,
    upsertAsset,
    deleteAsset,
    recordStockOpname,
    completeMaintenance,
    approveMutation,
    completeProcurement,
    uploadDocument,
    appendActivity,
  };

  return <DataStoreContext.Provider value={value}>{children}</DataStoreContext.Provider>;
}

// ─────────────────────────────────────────────────────────────────────────────
// Badge color helpers — rule-based, exposed for any page to consume.
// ─────────────────────────────────────────────────────────────────────────────

export function badgeColorFor(status: string): "green" | "yellow" | "blue" | "red" | "gray" {
  if (
    ["Baik", "Aktif", "Selesai", "Terverifikasi", "Disetujui", "Verified", "Lengkap", "Sesuai", "Digunakan", "Jelas"].includes(
      status,
    )
  )
    return "green";
  if (["Menunggu Persetujuan", "Due Soon", "Perlu Verifikasi", "Perlu Monitoring", "Pending", "Rusak Ringan"].includes(status))
    return "yellow";
  if (["Dalam Proses", "Scheduled", "Dalam Pengadaan", "Korektif", "Dipinjam"].includes(status)) return "blue";
  if (
    [
      "Rusak Berat",
      "Overdue",
      "Ditolak",
      "Tidak Ditemukan",
      "Selisih",
      "Konflik Data",
      "Prioritas Penggantian",
      "Dihapus",
      "Tidak Sesuai",
      "Tidak Digunakan",
      "Gagal",
    ].includes(status)
  )
    return "red";
  return "gray";
}

export function badgeClass(status: string): string {
  const c = badgeColorFor(status);
  return {
    green: "bg-green-100 text-green-700",
    yellow: "bg-yellow-100 text-yellow-700",
    blue: "bg-blue-100 text-blue-700",
    red: "bg-red-100 text-red-700",
    gray: "bg-gray-100 text-gray-600",
  }[c];
}
