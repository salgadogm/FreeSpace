import React from "react";

type IC = React.ComponentType<{ size?: number; className?: string }>;

export function FreeSpacePlaceholder({
  topBar,
  title,
  subtitle,
  icon: Icon,
}: {
  topBar: React.ReactNode;
  title: string;
  subtitle: string;
  icon: IC;
}) {
  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-7 space-y-6">
        <div>
          <h1 className="text-xl font-bold text-gray-900">{title}</h1>
          <p className="text-sm text-gray-500 mt-1">{subtitle}</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-16 flex flex-col items-center justify-center gap-5 text-center min-h-[360px]">
          <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center">
            <Icon size={28} className="text-gray-400" />
          </div>
          <div className="space-y-1.5">
            <h2 className="text-base font-semibold text-gray-700">Segera Hadir</h2>
            <p className="text-sm text-gray-400 max-w-sm leading-relaxed">
              Fitur <span className="font-medium text-gray-600">{title}</span> sedang dalam
              pengembangan dan akan tersedia dalam waktu dekat.
            </p>
          </div>
          <div className="flex items-center gap-1.5 mt-2">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-1.5 h-1.5 rounded-full bg-gray-300"
                style={{ animationDelay: `${i * 0.2}s` }}
              />
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
