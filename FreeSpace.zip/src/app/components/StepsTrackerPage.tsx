import React, { useState } from "react";
import {
  Plus, Target, Edit3, Trash2, MoreHorizontal, X,
  RefreshCw, CheckCircle2, AlertCircle, TrendingUp,
  ChevronDown,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine, Cell,
} from "recharts";

// ── Data ──────────────────────────────────────────────────────────────────────
const WEEKLY_DATA = [
  { hari: "Sen", langkah: 8200 },
  { hari: "Sel", langkah: 10450 },
  { hari: "Rab", langkah: 7800 },
  { hari: "Kam", langkah: 9150 },
  { hari: "Jum", langkah: 7420 },
  { hari: "Sab", langkah: 6900 },
  { hari: "Min", langkah: 5600 },
];

const HOURLY_DATA = [
  { sesi: "06–09", langkah: 1250 },
  { sesi: "09–12", langkah: 2100 },
  { sesi: "12–15", langkah: 1480 },
  { sesi: "15–18", langkah: 1390 },
  { sesi: "18–21", langkah: 1200 },
];

const HISTORY = [
  { tanggal: "3 Jul 2026", langkah: 7420,  target: 10000, pct: 74.2,  status: "Belum Tercapai", sumber: "Input Manual" },
  { tanggal: "2 Jul 2026", langkah: 9150,  target: 10000, pct: 91.5,  status: "Hampir Tercapai",  sumber: "Input Manual" },
  { tanggal: "1 Jul 2026", langkah: 7800,  target: 10000, pct: 78,    status: "Belum Tercapai", sumber: "Input Manual" },
  { tanggal: "30 Jun 2026",langkah: 10450, target: 10000, pct: 104.5, status: "Tercapai",         sumber: "Input Manual" },
  { tanggal: "29 Jun 2026",langkah: 8200,  target: 10000, pct: 82,    status: "Belum Tercapai", sumber: "Input Manual" },
];

const HEATMAP_DATA: Record<number, number> = {
  1: 7800, 2: 9150, 3: 7420, 22: 10450, 23: 9200, 24: 8800,
  25: 11000, 26: 6500, 27: 9700, 28: 10200, 29: 8200, 30: 10450,
};

// ── Helpers ───────────────────────────────────────────────────────────────────
const TARGET = 10000;

function getStepLevel(steps: number) {
  if (steps === 0)       return { label: "Tidak ada data", color: "#F3F4F6", textColor: "#9CA3AF" };
  if (steps < 4000)      return { label: "0–3.999",  color: "#E5E7EB", textColor: "#6B7280" };
  if (steps < 7000)      return { label: "4.000–6.999",  color: "#BBF7D0", textColor: "#15803D" };
  if (steps < 10000)     return { label: "7.000–9.999",  color: "#60A5FA", textColor: "#1D4ED8" };
  return                          { label: "10.000+", color: "#1D4ED8", textColor: "#FFFFFF" };
}

function getStatusCfg(status: string) {
  switch (status) {
    case "Tercapai":        return { color: "#22C55E", bg: "#DCFCE7" };
    case "Hampir Tercapai": return { color: "#F59E0B", bg: "#FEF3C7" };
    case "Melebihi Target": return { color: "#8B5CF6", bg: "#EDE9FE" };
    default:                return { color: "#EF4444", bg: "#FEE2E2" };
  }
}

// ── Progress Ring ─────────────────────────────────────────────────────────────
function ProgressRing({ value, max, size = 180 }: { value: number; max: number; size?: number }) {
  const radius = (size - 24) / 2;
  const circ = 2 * Math.PI * radius;
  const pct = Math.min(value / max, 1);
  const offset = circ * (1 - pct);

  return (
    <svg width={size} height={size} className="transform -rotate-90">
      <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke="#F3F4F6" strokeWidth="16" />
      <circle cx={size/2} cy={size/2} r={radius} fill="none"
        stroke={pct >= 1 ? "#22C55E" : "#111827"} strokeWidth="16"
        strokeLinecap="round"
        strokeDasharray={circ}
        strokeDashoffset={offset}
        style={{ transition: "stroke-dashoffset 0.6s ease" }}
      />
    </svg>
  );
}

// ── Input Langkah Modal ───────────────────────────────────────────────────────
function InputLangkahModal({ onClose }: { onClose: () => void }) {
  const [tanggal, setTanggal] = useState("2026-07-03");
  const [langkah, setLangkah] = useState("");
  const [target, setTarget] = useState("10000");
  const [sumber, setSumber] = useState("Input Manual");
  const [catatan, setCatatan] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [conflict, setConflict] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!tanggal) e.tanggal = "Tanggal wajib diisi.";
    if (!langkah) e.langkah = "Jumlah langkah wajib diisi.";
    else if (Number(langkah) < 0) e.langkah = "Jumlah langkah tidak boleh negatif.";
    if (Number(target) <= 0) e.target = "Target minimal lebih dari 0.";
    return e;
  };

  const handleSave = () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    // Simulate conflict check for today's date
    if (tanggal === "2026-07-03") { setConflict(true); return; }
    setSaving(true);
    setTimeout(() => { setSaving(false); onClose(); }, 700);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[420px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Input Langkah Harian</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>
        <div className="p-5 space-y-4">
          {conflict && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-start gap-2">
              <AlertCircle size={15} className="text-amber-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-xs font-semibold text-amber-700">Data langkah pada tanggal ini sudah tersedia.</p>
                <div className="flex gap-2 mt-2">
                  <button onClick={() => { setConflict(false); setSaving(true); setTimeout(() => { setSaving(false); onClose(); }, 700); }}
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-amber-600 rounded-lg hover:bg-amber-700 transition-colors">Perbarui Data</button>
                  <button onClick={() => setConflict(false)} className="px-3 py-1.5 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
                </div>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Tanggal <span className="text-red-500">*</span></label>
            <input type="date" value={tanggal} onChange={e => setTanggal(e.target.value)}
              className={`w-full text-sm px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-gray-300 ${errors.tanggal ? "border-red-300" : "border-gray-200"}`} />
            {errors.tanggal && <p className="text-[11px] text-red-500 mt-1">{errors.tanggal}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Jumlah Langkah <span className="text-red-500">*</span></label>
              <input type="number" value={langkah} onChange={e => setLangkah(e.target.value)} min="0" placeholder="0"
                className={`w-full text-sm px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-gray-300 ${errors.langkah ? "border-red-300" : "border-gray-200"}`} />
              {errors.langkah && <p className="text-[11px] text-red-500 mt-1">{errors.langkah}</p>}
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Target</label>
              <input type="number" value={target} onChange={e => setTarget(e.target.value)} min="1"
                className={`w-full text-sm px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-gray-300 ${errors.target ? "border-red-300" : "border-gray-200"}`} />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Sumber Data</label>
            <select value={sumber} onChange={e => setSumber(e.target.value)}
              className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
              <option>Input Manual</option>
              <option disabled>Perangkat (Belum Terhubung)</option>
              <option disabled>Aplikasi Kesehatan (Belum Terhubung)</option>
            </select>
            <p className="text-[10px] text-gray-400 mt-1">Integrasi perangkat belum tersedia pada versi ini.</p>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Catatan</label>
            <textarea value={catatan} onChange={e => setCatatan(e.target.value)} rows={2} placeholder="Catatan opsional..."
              className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none" />
          </div>
        </div>
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <button onClick={handleSave} disabled={saving}
            className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-70 flex items-center gap-2">
            {saving ? <><RefreshCw size={13} className="animate-spin" /> Menyimpan...</> : "Simpan Langkah"}
          </button>
        </div>
      </div>
    </>
  );
}

// ── Atur Target Modal ─────────────────────────────────────────────────────────
function AturTargetModal({ onClose }: { onClose: () => void }) {
  const [targetHarian, setTargetHarian] = useState("10000");
  const [reminder, setReminder] = useState("19:00");
  const [reminderToggle, setReminderToggle] = useState(true);

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[400px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Atur Target Langkah</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Target Harian (langkah)</label>
            <input type="number" value={targetHarian} onChange={e => setTargetHarian(e.target.value)} min="1"
              className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Berlaku Mulai</label>
              <input type="date" defaultValue="2026-07-03"
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Target Akhir Pekan</label>
              <input type="number" defaultValue="8000"
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Hari Aktif</label>
            <div className="flex gap-1.5">
              {["Sen","Sel","Rab","Kam","Jum","Sab","Min"].map((d, i) => (
                <button key={d}
                  className={`w-9 h-9 rounded-lg text-xs font-semibold transition-colors ${i < 5 ? "bg-gray-900 text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200"}`}>
                  {d}
                </button>
              ))}
            </div>
          </div>
          <div className="border border-gray-200 rounded-xl p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-gray-700">Ingatkan jika target belum tercapai</span>
              <button onClick={() => setReminderToggle(!reminderToggle)}
                className={`w-9 h-5 rounded-full transition-colors relative ${reminderToggle ? "bg-gray-900" : "bg-gray-200"}`}>
                <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${reminderToggle ? "left-[18px]" : "left-0.5"}`} />
              </button>
            </div>
            {reminderToggle && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">Pukul</span>
                <input type="time" value={reminder} onChange={e => setReminder(e.target.value)}
                  className="text-sm px-3 py-1.5 border border-gray-200 rounded-lg outline-none" />
              </div>
            )}
          </div>
        </div>
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">Simpan Target</button>
        </div>
      </div>
    </>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function StepsTrackerPage({ topBar }: { topBar?: React.ReactNode }) {
  const [showInput, setShowInput] = useState(false);
  const [showTarget, setShowTarget] = useState(false);
  const [selectedDate, setSelectedDate] = useState<number | null>(null);

  const today = 7420;
  const pct = (today / TARGET) * 100;
  const sisa = TARGET - today;

  const summaryCards = [
    { label: "Langkah Hari Ini", value: "7.420", desc: "74,2% dari target harian", color: "#111827", icon: TrendingUp },
    { label: "Target Harian", value: "10.000", desc: `Sisa ${sisa.toLocaleString("id")} langkah`, color: "#6B7280", icon: Target },
    { label: "Rata-rata 7 Hari", value: "7.865", desc: "Naik 6,4% dari minggu lalu", color: "#22C55E", icon: TrendingUp },
    { label: "Streak Target", value: "4 Hari", desc: "Target tercapai berturut-turut", color: "#3B82F6", icon: CheckCircle2 },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Steps Tracker</h1>
            <p className="text-xs text-gray-500 mt-0.5">Catat dan pantau progres langkah harian Anda.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button onClick={() => setShowTarget(true)}
              className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
              <Target size={13} /> Atur Target
            </button>
            <button onClick={() => setShowInput(true)}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors shadow-sm">
              <Plus size={13} /> Input Langkah
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          {summaryCards.map(c => (
            <div key={c.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">{c.label}</span>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: c.color + "18", color: c.color }}>
                  <c.icon size={16} />
                </div>
              </div>
              <p className="text-2xl font-bold text-gray-900">{c.value}</p>
              <p className="text-[11px] text-gray-400 leading-snug">{c.desc}</p>
            </div>
          ))}
        </div>

        {/* Progress Section */}
        <div className="grid grid-cols-2 gap-4">
          {/* Left — Donut */}
          <div className="bg-white border border-gray-200 rounded-xl p-6 flex flex-col items-center">
            <p className="text-sm font-semibold text-gray-700 mb-4 self-start">Progress Hari Ini</p>
            <div className="relative">
              <ProgressRing value={today} max={TARGET} size={200} />
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold text-gray-900">{today.toLocaleString("id")}</span>
                <span className="text-xs text-gray-400">dari {TARGET.toLocaleString("id")} langkah</span>
                <span className="text-sm font-bold text-gray-700 mt-1">{pct.toFixed(1)}%</span>
              </div>
            </div>
            <div className="mt-4 space-y-1.5 w-full">
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-500">Sisa langkah</span>
                <span className="font-semibold text-gray-800">{sisa.toLocaleString("id")}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-500">Estimasi jarak</span>
                <span className="font-semibold text-gray-800">≈ 1,8 km lagi</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-500">Status</span>
                <span className="font-semibold text-red-500">Belum Tercapai</span>
              </div>
            </div>
            <p className="text-[9px] text-gray-300 mt-3 text-center">
              Estimasi jarak dapat berbeda tergantung panjang langkah pengguna.
            </p>
          </div>

          {/* Right — Hourly bars */}
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <p className="text-sm font-semibold text-gray-700 mb-4">Breakdown Per Sesi</p>
            <div className="space-y-3">
              {HOURLY_DATA.map(h => {
                const pctBar = (h.langkah / 2500) * 100;
                return (
                  <div key={h.sesi}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-gray-500">{h.sesi}</span>
                      <span className="text-xs font-semibold text-gray-800">{h.langkah.toLocaleString("id")}</span>
                    </div>
                    <div className="bg-gray-100 rounded-full h-2 overflow-hidden">
                      <div className="h-2 rounded-full bg-gray-900 transition-all duration-500"
                        style={{ width: `${Math.min(pctBar, 100)}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
            <p className="text-[10px] text-gray-300 mt-4">Data simulasi per sesi. Aktifkan integrasi perangkat untuk data real-time.</p>
          </div>
        </div>

        {/* Weekly Trend Chart */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-sm font-semibold text-gray-700">Tren Langkah Mingguan</p>
              <p className="text-xs text-gray-400 mt-0.5">29 Jun – 5 Jul 2026</p>
            </div>
            <div className="flex items-center gap-3 text-xs text-gray-500">
              <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-gray-900 inline-block" /> Langkah</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-red-400 inline-block border-dashed border-t border-red-400" /> Target 10.000</span>
            </div>
          </div>
          <div className="h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart id="bar-steps-weekly" data={WEEKLY_DATA} barSize={32}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
                <XAxis dataKey="hari" tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#9CA3AF" }} axisLine={false} tickLine={false}
                  tickFormatter={v => v >= 1000 ? `${v/1000}k` : String(v)} />
                <Tooltip formatter={(v: number) => [v.toLocaleString("id") + " langkah", ""]}
                  contentStyle={{ fontSize: 11, borderRadius: 8, border: "1px solid #E5E7EB" }} />
                <ReferenceLine y={TARGET} stroke="#EF4444" strokeDasharray="4 4" strokeWidth={1.5} />
                <Bar dataKey="langkah" radius={[4,4,0,0]}>
                  {WEEKLY_DATA.map((entry) => (
                    <Cell key={`steps-${entry.hari}`} fill={entry.langkah >= TARGET ? "#22C55E" : entry.hari === "Jum" ? "#111827" : "#D1D5DB"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center gap-4 mt-3 pt-3 border-t border-gray-100 text-xs text-gray-500">
            <span>Rata-rata: <strong className="text-gray-800">7.865</strong></span>
            <span>Terbaik: <strong className="text-gray-800">Selasa (10.450)</strong></span>
            <span>Target tercapai: <strong className="text-gray-800">1 dari 7 hari</strong></span>
          </div>
        </div>

        {/* Calendar Heatmap */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm font-semibold text-gray-700">Kalender Langkah — Juli 2026</p>
            <div className="flex items-center gap-2 text-[10px] text-gray-400">
              {[
                { label: "0–3.999", bg: "#E5E7EB" },
                { label: "4.000–6.999", bg: "#BBF7D0" },
                { label: "7.000–9.999", bg: "#60A5FA" },
                { label: "10.000+", bg: "#1D4ED8" },
              ].map(l => (
                <span key={l.label} className="flex items-center gap-1">
                  <span className="w-3 h-3 rounded-sm inline-block" style={{ backgroundColor: l.bg }} />
                  {l.label}
                </span>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {["Min","Sen","Sel","Rab","Kam","Jum","Sab"].map(d => (
              <div key={d} className="text-center text-[9px] text-gray-400 font-medium pb-1">{d}</div>
            ))}
            {[1,2,3].map(i => <div key={"pad"+i} />)}
            {Array.from({ length: 31 }, (_, i) => i + 1).map(d => {
              const steps = HEATMAP_DATA[d] || 0;
              const cfg = getStepLevel(steps);
              const isToday = d === 3;
              return (
                <button key={d}
                  onClick={() => setSelectedDate(selectedDate === d ? null : d)}
                  className={`aspect-square rounded-md flex items-center justify-center text-[10px] font-medium cursor-pointer transition-all hover:opacity-80 ${
                    isToday ? "ring-2 ring-gray-900 ring-offset-1" : ""
                  }`}
                  style={{ backgroundColor: cfg.color, color: cfg.textColor }}>
                  {d}
                </button>
              );
            })}
          </div>
          {selectedDate && HEATMAP_DATA[selectedDate] && (
            <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between text-xs">
              <span className="text-gray-500">{selectedDate} Juli 2026</span>
              <span className="font-semibold text-gray-800">{HEATMAP_DATA[selectedDate].toLocaleString("id")} langkah</span>
              <button className="text-gray-400 hover:text-gray-600 transition-colors flex items-center gap-1">
                <Edit3 size={11} /> Edit
              </button>
            </div>
          )}
        </div>

        {/* History Table */}
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
            <p className="text-sm font-semibold text-gray-700">Riwayat Langkah</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50/70">
                  {["Tanggal","Jumlah Langkah","Target","Progress","Status","Sumber","Aksi"].map(h => (
                    <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {HISTORY.map((r, i) => {
                  const cfg = getStatusCfg(r.status);
                  return (
                    <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                      <td className="py-3 px-4 text-xs text-gray-600 whitespace-nowrap">{r.tanggal}</td>
                      <td className="py-3 px-4 text-sm font-bold text-gray-900">{r.langkah.toLocaleString("id")}</td>
                      <td className="py-3 px-4 text-xs text-gray-500">{r.target.toLocaleString("id")}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                            <div className="h-1.5 rounded-full" style={{ width: `${Math.min(r.pct, 100)}%`, backgroundColor: cfg.color }} />
                          </div>
                          <span className="text-xs font-medium text-gray-600">{r.pct}%</span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                          style={{ color: cfg.color, backgroundColor: cfg.bg }}>{r.status}</span>
                      </td>
                      <td className="py-3 px-4 text-xs text-gray-500">{r.sumber}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1">
                          <button className="p-1 rounded hover:bg-gray-100 text-gray-400 transition-colors"><Edit3 size={12} /></button>
                          <button className="p-1 rounded hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors"><Trash2 size={12} /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {showInput && <InputLangkahModal onClose={() => setShowInput(false)} />}
      {showTarget && <AturTargetModal onClose={() => setShowTarget(false)} />}
    </main>
  );
}
