import React, { useState } from "react";
import {
  BookOpen, StickyNote, FileText, CheckCircle2, Star,
  Search, Plus, X, Bookmark, ChevronRight,
  Bold, Italic, List, Quote, Link, CheckSquare, Table2,
  RefreshCw, AlertCircle, Lightbulb, RotateCcw, Eye,
  GraduationCap, MoreHorizontal, Download,
} from "lucide-react";

type ASTab = "buku" | "catatan" | "latihan";
type PracticeState = "soal" | "correct" | "incorrect";
type HintLevel = 0 | 1 | 2 | 3;

// ── Data ─────────────────────────────────────────────────────────────────────
const ACCOUNTING_BOOKS = [
  { id:1, judul:"Akuntansi Keuangan Menengah", matkul:"Akuntansi Keuangan", progress:68, catatan:8,  latihan:5, status:"Sedang Dibaca" },
  { id:2, judul:"Dasar-Dasar Akuntansi",        matkul:"Pengantar Akuntansi", progress:100,catatan:6,  latihan:4, status:"Selesai" },
  { id:3, judul:"Audit dan Pengendalian Internal",matkul:"Audit",             progress:0,  catatan:0,  latihan:3, status:"Belum Dibaca" },
  { id:4, judul:"Analisis Laporan Keuangan",     matkul:"Akuntansi Keuangan", progress:35, catatan:4,  latihan:3, status:"Sedang Dibaca" },
];

const CATATAN_LIST = [
  { id:1, judul:"Konsep Jurnal Penyesuaian",                    buku:"Akuntansi Keuangan Menengah", hal:"118–124", updated:"3 Jul 2026", topik:"Penyesuaian",     favorit:true  },
  { id:2, judul:"Perbedaan Beban Akrual dan Dibayar Dimuka",    buku:"Akuntansi Keuangan Menengah", hal:"97",      updated:"2 Jul 2026", topik:"Penyesuaian",     favorit:false },
  { id:3, judul:"Tahapan Siklus Akuntansi",                     buku:"Dasar-Dasar Akuntansi",       hal:"45–53",   updated:"1 Jul 2026", topik:"Siklus Akuntansi",favorit:true  },
  { id:4, judul:"Analisis Current Ratio",                        buku:"Analisis Laporan Keuangan",  hal:"68–75",   updated:"30 Jun 2026",topik:"Laporan Keuangan", favorit:false },
];

const LATIHAN_LIST = [
  { id:1, judul:"Pembelian Perlengkapan Secara Tunai",  topik:"Jurnal Umum",       kesulitan:"Dasar",    status:"Selesai",         skor:100 },
  { id:2, judul:"Pendapatan Diterima Dimuka",           topik:"Jurnal Penyesuaian",kesulitan:"Menengah", status:"Belum Dikerjakan", skor:null },
  { id:3, judul:"Penyusutan Peralatan",                 topik:"Jurnal Penyesuaian",kesulitan:"Menengah", status:"Selesai",         skor:80  },
  { id:4, judul:"Penutupan Akun Pendapatan dan Beban",  topik:"Jurnal Penutup",    kesulitan:"Lanjutan", status:"Sedang Dikerjakan",skor:null },
  { id:5, judul:"Pembelian Persediaan Secara Kredit",   topik:"Persediaan",        kesulitan:"Menengah", status:"Belum Dikerjakan", skor:null },
];

const LATIHAN_HISTORY = [
  { tgl:"3 Jul 2026", latihan:"Penyusutan Peralatan",    topik:"Penyesuaian",  percobaan:2, skor:"80%",  durasi:"8 mnt",  status:"Selesai" },
  { tgl:"2 Jul 2026", latihan:"Pembelian Perlengkapan",  topik:"Jurnal Umum",  percobaan:1, skor:"100%", durasi:"5 mnt",  status:"Selesai" },
  { tgl:"1 Jul 2026", latihan:"Pendapatan Diterima Dimuka",topik:"Penyesuaian",percobaan:3, skor:"70%",  durasi:"12 mnt", status:"Selesai" },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function SummaryCard({ label, value, desc, color, icon: Icon }: {
  label: string; value: string | number; desc: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: color + "18", color }}>
          <Icon size={16} />
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 leading-tight">{value}</p>
      <p className="text-[11px] text-gray-400 leading-snug">{desc}</p>
    </div>
  );
}

function DiffBadge({ d }: { d: string }) {
  const cfg = { Dasar: "bg-gray-100 text-gray-500", Menengah: "bg-amber-50 text-amber-600", Lanjutan: "bg-red-50 text-red-500" }[d] ?? "bg-gray-100 text-gray-500";
  return <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${cfg}`}>{d}</span>;
}

function StatusBadge({ s }: { s: string }) {
  const cfg: Record<string, string> = {
    "Selesai": "bg-green-50 text-green-700",
    "Belum Dikerjakan": "bg-gray-100 text-gray-500",
    "Sedang Dikerjakan": "bg-blue-50 text-blue-700",
    "Perlu Diulang": "bg-red-50 text-red-500",
    "Sedang Dibaca": "bg-blue-50 text-blue-700",
    "Belum Dibaca": "bg-gray-100 text-gray-400",
  };
  return <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${cfg[s] ?? "bg-gray-100 text-gray-500"}`}>{s}</span>;
}

// ── TAB BUKU AKUNTANSI ────────────────────────────────────────────────────────
function BukuAkuntansiTab() {
  const [search, setSearch] = useState("");
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari buku akuntansi..."
            className="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-lg outline-none bg-white focus:ring-1 focus:ring-gray-300" />
        </div>
        <select className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
          {["Semua Mata Kuliah","Pengantar Akuntansi","Akuntansi Keuangan","Akuntansi Biaya","Audit","Perpajakan"].map(m => <option key={m}>{m}</option>)}
        </select>
        <select className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
          <option>Semua Status</option>
          {["Belum Dibaca","Sedang Dibaca","Selesai"].map(s => <option key={s}>{s}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {ACCOUNTING_BOOKS.filter(b => !search || b.judul.toLowerCase().includes(search.toLowerCase())).map(b => (
          <div key={b.id} className="bg-white border border-gray-200 rounded-xl p-5 hover:border-gray-300 hover:shadow-sm transition-all">
            <div className="flex items-start gap-4">
              <div className="w-16 h-20 rounded-xl bg-blue-50 flex flex-col items-center justify-center shrink-0">
                <span className="text-sm font-bold text-blue-700">{b.judul.split(" ").slice(0,2).map(w=>w[0]).join("")}</span>
                <BookOpen size={12} className="text-blue-300 mt-1" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-900 mb-1 leading-tight">{b.judul}</p>
                <span className="text-[10px] bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full font-semibold">{b.matkul}</span>
                {b.progress > 0 && (
                  <div className="mt-2">
                    <div className="flex justify-between text-[10px] mb-0.5">
                      <span className="text-gray-400">Progress</span>
                      <span className="font-semibold text-gray-700">{b.progress}%</span>
                    </div>
                    <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-1.5 rounded-full bg-blue-500" style={{ width: `${b.progress}%` }} />
                    </div>
                  </div>
                )}
                <div className="flex gap-3 mt-2 text-[10px] text-gray-400">
                  <span>{b.catatan} catatan</span>
                  <span>{b.latihan} latihan</span>
                </div>
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <button className="flex-1 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">Baca Buku</button>
              <button className="flex-1 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Catatan</button>
              <button className="flex-1 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Latihan</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── TAB CATATAN AKUNTANSI ─────────────────────────────────────────────────────
const TOPIK_LIST = ["Persamaan Dasar Akuntansi","Siklus Akuntansi","Jurnal Umum","Buku Besar","Neraca Saldo","Penyesuaian","Laporan Keuangan","Aset","Liabilitas","Ekuitas","Pendapatan","Beban"];

function CatatanAkuntansiTab() {
  const [selectedNote, setSelectedNote] = useState<typeof CATATAN_LIST[0] | null>(CATATAN_LIST[0]);
  const [search, setSearch] = useState("");
  const [noteText, setNoteText] = useState(`Jurnal penyesuaian adalah jurnal yang dibuat pada akhir periode akuntansi.

**Jenis-jenis penyesuaian:**
1. Beban dibayar dimuka
2. Beban akrual
3. Pendapatan diterima dimuka
4. Pendapatan akrual

**Persamaan Akuntansi:**
Aset = Liabilitas + Ekuitas

**Contoh Jurnal Penyesuaian (Beban Akrual):**
| Akun | Debit | Kredit |
|------|-------|--------|
| Beban Gaji | Rp5.000.000 | - |
| Utang Gaji | - | Rp5.000.000 |`);
  const [autosaved, setAutosaved] = useState(true);

  const handleTextChange = (v: string) => {
    setNoteText(v);
    setAutosaved(false);
    setTimeout(() => setAutosaved(true), 1200);
  };

  return (
    <div className="grid grid-cols-[280px_1fr] gap-0 border border-gray-200 rounded-xl overflow-hidden bg-white shadow-sm h-[600px]">
      {/* Left sidebar */}
      <div className="border-r border-gray-100 flex flex-col bg-gray-50/50">
        <div className="p-3 border-b border-gray-100">
          <div className="relative">
            <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari catatan..."
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-gray-200 rounded-lg outline-none bg-white" />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {/* Groups */}
          <div className="px-3 pt-3 pb-1">
            <p className="text-[9px] font-semibold text-gray-400 uppercase tracking-wider mb-1">GRUP</p>
            {["Semua Catatan","Favorit","Terbaru"].map(g => (
              <button key={g} className="w-full text-left text-xs py-1.5 px-2 rounded-lg text-gray-600 hover:bg-gray-100 transition-colors">{g}</button>
            ))}
          </div>
          <div className="px-3 pt-2 pb-1">
            <p className="text-[9px] font-semibold text-gray-400 uppercase tracking-wider mb-1">TOPIK</p>
            {TOPIK_LIST.slice(0, 6).map(t => (
              <button key={t} className="w-full text-left text-xs py-1.5 px-2 rounded-lg text-gray-500 hover:bg-gray-100 transition-colors">{t}</button>
            ))}
          </div>
          <div className="px-3 pt-2 pb-3">
            <p className="text-[9px] font-semibold text-gray-400 uppercase tracking-wider mb-2">CATATAN</p>
            {CATATAN_LIST.filter(c => !search || c.judul.toLowerCase().includes(search.toLowerCase())).map(c => (
              <button key={c.id} onClick={() => setSelectedNote(c)}
                className={`w-full text-left p-2.5 rounded-xl mb-1.5 transition-all ${selectedNote?.id === c.id ? "bg-white border border-gray-200 shadow-sm" : "hover:bg-gray-100"}`}>
                <div className="flex items-start justify-between gap-1 mb-0.5">
                  <p className="text-xs font-semibold text-gray-800 leading-tight line-clamp-1">{c.judul}</p>
                  {c.favorit && <Star size={10} className="text-amber-400 shrink-0 fill-amber-400 mt-0.5" />}
                </div>
                <p className="text-[10px] text-gray-400 truncate">{c.buku}</p>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-[9px] text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">{c.topik}</span>
                  <span className="text-[9px] text-gray-400">{c.updated}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
        <div className="p-3 border-t border-gray-100">
          <button className="w-full flex items-center justify-center gap-2 py-2 text-xs font-semibold text-gray-700 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
            <Plus size={12} /> Catatan Baru
          </button>
        </div>
      </div>

      {/* Right editor */}
      <div className="flex flex-col overflow-hidden">
        {selectedNote ? (
          <>
            {/* Editor header */}
            <div className="px-5 py-3 border-b border-gray-100 flex items-center justify-between">
              <div>
                <input defaultValue={selectedNote.judul} className="text-sm font-bold text-gray-900 outline-none bg-transparent border-b border-transparent focus:border-gray-300 pb-0.5" />
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">{selectedNote.topik}</span>
                  <span className="text-[10px] text-gray-400">{selectedNote.buku} • Hal. {selectedNote.hal}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-gray-400 flex items-center gap-1">
                  {autosaved ? <><CheckCircle2 size={11} className="text-green-500" /> Tersimpan</> : <><RefreshCw size={11} className="animate-spin text-gray-400" /> Menyimpan...</>}
                </span>
                <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><Star size={13} /></button>
                <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><Download size={13} /></button>
              </div>
            </div>

            {/* Toolbar */}
            <div className="px-5 py-2 border-b border-gray-100 flex items-center gap-1 flex-wrap">
              {[Bold, Italic, List, Quote, Link, CheckSquare, Table2].map((Icon, i) => (
                <button key={i} className="p-1.5 rounded hover:bg-gray-100 text-gray-400 transition-colors"><Icon size={13} /></button>
              ))}
              <div className="w-px h-4 bg-gray-200 mx-1" />
              {["Jurnal","Persamaan","T-Akun"].map(b => (
                <button key={b} className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg hover:bg-blue-100 transition-colors">{b}</button>
              ))}
            </div>

            {/* Editor content */}
            <div className="flex-1 overflow-y-auto px-5 py-4">
              <textarea value={noteText} onChange={e => handleTextChange(e.target.value)}
                className="w-full h-full text-sm text-gray-700 leading-relaxed outline-none resize-none font-mono"
                placeholder="Tulis catatan di sini..." />

              {/* Accounting equation block */}
              <div className="mt-4 border border-blue-200 rounded-xl p-4 bg-blue-50/30">
                <p className="text-[10px] font-semibold text-blue-600 mb-2 uppercase">PERSAMAAN AKUNTANSI</p>
                <div className="flex items-center gap-3 text-sm font-bold text-gray-800">
                  <span className="bg-white border border-blue-200 rounded-lg px-3 py-2">Aset</span>
                  <span className="text-blue-500">=</span>
                  <span className="bg-white border border-blue-200 rounded-lg px-3 py-2">Liabilitas</span>
                  <span className="text-blue-500">+</span>
                  <span className="bg-white border border-blue-200 rounded-lg px-3 py-2">Ekuitas</span>
                </div>
              </div>

              {/* T-Account block */}
              <div className="mt-4 border border-gray-200 rounded-xl overflow-hidden">
                <p className="text-[10px] font-semibold text-gray-500 px-4 py-2 bg-gray-50 border-b border-gray-100 uppercase">T-AKUN — KAS</p>
                <div className="grid grid-cols-2">
                  <div className="border-r border-gray-200 p-3">
                    <p className="text-[10px] font-bold text-gray-600 text-center mb-2">DEBIT</p>
                    <div className="text-xs text-gray-600 space-y-1">
                      <div className="flex justify-between"><span>Modal awal</span><span>Rp50.000.000</span></div>
                      <div className="flex justify-between border-t border-gray-100 pt-1 font-bold"><span>Total</span><span>Rp50.000.000</span></div>
                    </div>
                  </div>
                  <div className="p-3">
                    <p className="text-[10px] font-bold text-gray-600 text-center mb-2">KREDIT</p>
                    <div className="text-xs text-gray-600 space-y-1">
                      <div className="flex justify-between"><span>Perlengkapan</span><span>Rp1.200.000</span></div>
                      <div className="flex justify-between border-t border-gray-100 pt-1 font-bold"><span>Total</span><span>Rp1.200.000</span></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Related notes */}
              <div className="mt-4 border border-gray-200 rounded-xl p-4">
                <p className="text-[10px] font-semibold text-gray-500 mb-2 uppercase">CATATAN TERKAIT</p>
                <div className="space-y-1.5">
                  {["Jurnal Umum","Posting Buku Besar","Neraca Saldo Sebelum Penyesuaian"].map(r => (
                    <button key={r} className="w-full flex items-center justify-between text-xs text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-lg px-2 py-1.5 transition-colors">
                      <span>{r}</span><ChevronRight size={12} className="text-gray-300" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <StickyNote size={32} className="text-gray-200 mx-auto mb-2" />
              <p className="text-sm text-gray-400">Pilih catatan atau buat catatan baru</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Journal Practice Interface ────────────────────────────────────────────────
function JournalPractice({ onBack }: { onBack: () => void }) {
  const [qIdx, setQIdx]           = useState(0);
  const [state, setState]         = useState<PracticeState>("soal");
  const [hintLevel, setHintLevel] = useState<HintLevel>(0);
  const [rows, setRows]           = useState([
    { akun: "", debit: "", kredit: "", ket: "" },
    { akun: "", debit: "", kredit: "", ket: "" },
  ]);

  const questions = [
    {
      soal: "Pada 3 Juli 2026, perusahaan membeli perlengkapan kantor secara tunai sebesar Rp1.200.000.",
      topik: "Jurnal Umum", kesulitan: "Dasar", no: "3 dari 10",
      jawaban: [{ akun: "Perlengkapan", debit: "1.200.000", kredit: "" }, { akun: "Kas", debit: "", kredit: "1.200.000" }],
      penjelasan: "Perlengkapan bertambah sehingga dicatat di sisi debit. Kas berkurang sehingga dicatat di sisi kredit.",
    },
  ];

  const q = questions[0];
  const totalDebit  = rows.reduce((s, r) => s + (Number(r.debit.replace(/\./g,"")) || 0), 0);
  const totalKredit = rows.reduce((s, r) => s + (Number(r.kredit.replace(/\./g,"")) || 0), 0);
  const balanced = totalDebit > 0 && totalDebit === totalKredit;

  const HINTS = [
    "Identifikasi akun yang berubah: Perlengkapan dan Kas.",
    "Tentukan arah perubahan: Perlengkapan bertambah, Kas berkurang.",
    "Tentukan posisi: Akun yang bertambah di sisi normal. Aset normal di Debit.",
  ];

  const updateRow = (i: number, field: string, val: string) => {
    setRows(rows.map((r, idx) => idx === i ? { ...r, [field]: val } : r));
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-gray-800 transition-colors">
          ← Kembali ke Latihan
        </button>
        <span className="text-xs text-gray-500">Soal {q.no}</span>
      </div>

      <div className="grid grid-cols-2 gap-5">
        {/* Left — Soal */}
        <div className="space-y-4">
          <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <DiffBadge d={q.kesulitan} />
              <span className="text-[10px] bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full font-semibold">{q.topik}</span>
            </div>
            <p className="text-sm font-semibold text-gray-800 leading-relaxed mb-4">"{q.soal}"</p>
            <p className="text-xs text-gray-500">Petunjuk: Catat transaksi ini dalam bentuk jurnal umum.</p>
          </div>

          {/* Hints */}
          {hintLevel > 0 && (
            <div className="space-y-2">
              {HINTS.slice(0, hintLevel).map((h, i) => (
                <div key={i} className="bg-amber-50 border border-amber-100 rounded-xl p-3 flex items-start gap-2">
                  <Lightbulb size={14} className="text-amber-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-800"><strong>Petunjuk {i+1}:</strong> {h}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right — Form Jurnal */}
        <div className="space-y-4">
          {state === "soal" && (
            <>
              <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
                <div className="bg-gray-50 px-4 py-2.5 border-b border-gray-100">
                  <p className="text-xs font-semibold text-gray-700">Jurnal Umum — 3 Juli 2026</p>
                </div>
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-100">
                      {["Akun","Debit (Rp)","Kredit (Rp)","Keterangan"].map(h => (
                        <th key={h} className="text-left py-2.5 px-3 text-[10px] font-semibold text-gray-400 uppercase">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r, i) => (
                      <tr key={i} className="border-b border-gray-50">
                        <td className="py-2 px-3">
                          <input value={r.akun} onChange={e => updateRow(i, "akun", e.target.value)} placeholder="Nama akun"
                            className="w-full text-xs outline-none border-b border-transparent focus:border-gray-300 py-0.5 bg-transparent" />
                        </td>
                        <td className="py-2 px-3">
                          <input value={r.debit} onChange={e => updateRow(i, "debit", e.target.value)} placeholder="0"
                            className="w-full text-xs outline-none border-b border-transparent focus:border-gray-300 py-0.5 bg-transparent text-right" />
                        </td>
                        <td className="py-2 px-3">
                          <input value={r.kredit} onChange={e => updateRow(i, "kredit", e.target.value)} placeholder="0"
                            className="w-full text-xs outline-none border-b border-transparent focus:border-gray-300 py-0.5 bg-transparent text-right" />
                        </td>
                        <td className="py-2 px-3">
                          <input value={r.ket} onChange={e => updateRow(i, "ket", e.target.value)} placeholder="Keterangan"
                            className="w-full text-xs outline-none border-b border-transparent focus:border-gray-300 py-0.5 bg-transparent" />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div className="px-3 py-2 bg-gray-50 border-t border-gray-100 flex items-center gap-3">
                  <button onClick={() => setRows([...rows, { akun:"", debit:"", kredit:"", ket:"" }])}
                    className="text-xs text-gray-500 hover:text-gray-700 flex items-center gap-1 transition-colors">
                    <Plus size={11} /> Tambah Baris
                  </button>
                </div>
                <div className="px-4 py-3 border-t border-gray-200 bg-gray-50/70 space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-600">Total Debit</span>
                    <span className="font-mono font-semibold text-gray-800">Rp{totalDebit.toLocaleString("id")}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-600">Total Kredit</span>
                    <span className="font-mono font-semibold text-gray-800">Rp{totalKredit.toLocaleString("id")}</span>
                  </div>
                  <div className={`flex justify-between text-xs pt-1 border-t border-gray-200 ${balanced ? "text-green-600" : "text-red-500"}`}>
                    <span className="font-semibold">Selisih</span>
                    <span className="font-mono font-semibold">{balanced ? "✓ Seimbang" : `Rp${Math.abs(totalDebit - totalKredit).toLocaleString("id")}`}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button onClick={() => { if (hintLevel < 3) setHintLevel(h => (h + 1) as HintLevel); }}
                  disabled={hintLevel >= 3}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-amber-600 border border-amber-200 rounded-lg hover:bg-amber-50 transition-colors disabled:opacity-50">
                  <Lightbulb size={12} /> Tampilkan Hint
                </button>
                <button onClick={() => setRows([{ akun:"", debit:"", kredit:"", ket:"" },{ akun:"", debit:"", kredit:"", ket:"" }])}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <RotateCcw size={12} /> Reset
                </button>
                <button onClick={() => setState("correct")} disabled={!balanced}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-50">
                  Periksa Jawaban
                </button>
              </div>
            </>
          )}

          {state === "correct" && (
            <div className="bg-white border border-green-200 rounded-xl p-5 shadow-sm space-y-4">
              <div className="flex items-center gap-2">
                <CheckCircle2 size={20} className="text-green-600" />
                <p className="text-sm font-bold text-green-700">Jawaban Benar!</p>
              </div>
              <p className="text-xs text-gray-600 leading-relaxed">{q.penjelasan}</p>
              <div className="bg-green-50 rounded-xl p-3">
                <p className="text-[10px] font-semibold text-green-700 mb-2">JURNAL YANG BENAR</p>
                {q.jawaban.map((j, i) => (
                  <div key={i} className="flex gap-3 text-xs py-1 border-b border-green-100 last:border-0">
                    <span className="flex-1 font-medium text-gray-800">{j.akun}</span>
                    <span className="w-24 text-right font-mono text-gray-700">{j.debit ? `Rp${Number(j.debit.replace(/\./g,"")).toLocaleString("id")}` : ""}</span>
                    <span className="w-24 text-right font-mono text-gray-700">{j.kredit ? `Rp${Number(j.kredit.replace(/\./g,"")).toLocaleString("id")}` : ""}</span>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <button className="flex-1 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Lihat Materi</button>
                <button onClick={() => { setState("soal"); setHintLevel(0); setRows([{akun:"",debit:"",kredit:"",ket:""},{akun:"",debit:"",kredit:"",ket:""}]); }}
                  className="flex-1 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
                  Soal Berikutnya →
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── TAB LATIHAN JURNAL ────────────────────────────────────────────────────────
function LatihanJurnalTab() {
  const [practicing, setPracticing] = useState(false);

  if (practicing) return <JournalPractice onBack={() => setPracticing(false)} />;

  return (
    <div className="space-y-5">
      {/* Summary */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Tersedia",    value: 20,    color: "#111827" },
          { label: "Selesai",     value: 15,    color: "#22C55E" },
          { label: "Benar",       value: 13,    color: "#3B82F6" },
          { label: "Rata-Rata",   value: "86%", color: "#8B5CF6" },
        ].map(s => (
          <div key={s.label} className="bg-white border border-gray-200 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold" style={{ color: s.color }}>{s.value}</p>
            <p className="text-xs text-gray-400 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        {[["Kesulitan","Dasar,Menengah,Lanjutan"],["Topik","Jurnal Umum,Penyesuaian,Penutup,Persediaan"],["Status","Belum Dikerjakan,Sedang,Selesai"]].map(([label, opts]) => (
          <select key={label} className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
            <option>Semua {label}</option>
            {opts.split(",").map(o => <option key={o}>{o}</option>)}
          </select>
        ))}
      </div>

      {/* Practice cards */}
      <div className="space-y-3">
        {LATIHAN_LIST.map(l => (
          <div key={l.id} className="bg-white border border-gray-200 rounded-xl p-4 hover:border-gray-300 transition-all flex items-center gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <p className="text-sm font-semibold text-gray-900">{l.judul}</p>
                <DiffBadge d={l.kesulitan} />
                <span className="text-[10px] bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full font-semibold">{l.topik}</span>
              </div>
              <div className="flex items-center gap-3">
                <StatusBadge s={l.status} />
                {l.skor !== null && <span className="text-xs font-semibold text-green-600">{l.skor}%</span>}
              </div>
            </div>
            <div className="flex gap-2 shrink-0">
              {l.status === "Selesai" && <button className="text-xs text-gray-500 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50 transition-colors">Pembahasan</button>}
              <button onClick={() => setPracticing(true)}
                className="text-xs font-semibold text-white bg-gray-900 px-3 py-1.5 rounded-lg hover:bg-black transition-colors">
                {l.status === "Selesai" ? "Ulangi" : l.status === "Sedang Dikerjakan" ? "Lanjutkan" : "Mulai"}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* History */}
      <div>
        <h3 className="text-sm font-semibold text-gray-800 mb-3">Riwayat Latihan</h3>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/70">
                {["Tanggal","Latihan","Topik","Percobaan","Skor","Durasi","Status"].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {LATIHAN_HISTORY.map((r, i) => (
                <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4 text-xs text-gray-600">{r.tgl}</td>
                  <td className="py-3 px-4 text-xs font-medium text-gray-800">{r.latihan}</td>
                  <td className="py-3 px-4"><span className="text-[10px] bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full font-semibold">{r.topik}</span></td>
                  <td className="py-3 px-4 text-xs text-gray-500">{r.percobaan}x</td>
                  <td className="py-3 px-4 text-xs font-bold text-green-600">{r.skor}</td>
                  <td className="py-3 px-4 text-xs text-gray-400">{r.durasi}</td>
                  <td className="py-3 px-4"><StatusBadge s={r.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function AccountingSpacePage({ topBar }: { topBar?: React.ReactNode }) {
  const [tab, setTab] = useState<ASTab>("buku");

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Accounting Space</h1>
            <p className="text-xs text-gray-500 mt-0.5">Pelajari materi akuntansi, susun catatan, dan latih pencatatan jurnal.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
              <StickyNote size={13} /> Tambah Catatan
            </button>
            <button onClick={() => setTab("latihan")}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors shadow-sm">
              <GraduationCap size={13} /> Mulai Belajar
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <SummaryCard label="Buku Akuntansi"  value={8}   desc="Tersimpan dalam Library"      color="#111827" icon={BookOpen} />
          <SummaryCard label="Catatan Akuntansi" value={24}  desc="6 catatan dibuat bulan ini"  color="#3B82F6" icon={StickyNote} />
          <SummaryCard label="Latihan Selesai"  value={15}  desc="Dari 20 latihan tersedia"     color="#22C55E" icon={CheckCircle2} />
          <SummaryCard label="Rata-Rata Skor"   value="86%" desc="Naik 4% dari bulan lalu"      color="#8B5CF6" icon={Star} />
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {([["buku","Buku Akuntansi",BookOpen],["catatan","Catatan Akuntansi",StickyNote],["latihan","Latihan Jurnal",GraduationCap]] as const).map(([id, label, Icon]) => (
            <button key={id} onClick={() => setTab(id as ASTab)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${tab === id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              <Icon size={13} /> {label}
            </button>
          ))}
        </div>

        {tab === "buku"    && <BukuAkuntansiTab />}
        {tab === "catatan" && <CatatanAkuntansiTab />}
        {tab === "latihan" && <LatihanJurnalTab />}
      </div>
    </main>
  );
}
