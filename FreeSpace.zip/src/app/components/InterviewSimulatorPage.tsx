import React, { useState, useEffect } from "react";
import {
  Mic, MessageSquare, X, ChevronLeft, ChevronRight,
  Play, Square, RefreshCw, CheckCircle2, Clock,
  TrendingUp, AlertCircle, BookOpen, Star,
  Bookmark, Filter, Download, RotateCcw,
  User, MoreHorizontal, Info,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer,
} from "recharts";

type IVTab = "latihan" | "simulasi" | "hasil";

// ── Data ──────────────────────────────────────────────────────────────────────
const QUESTIONS = [
  { id: 1, q: "Ceritakan tentang diri Anda.",                                            type: "Wawancara HR",          difficulty: "Dasar",    lang: "Indonesia", saved: false },
  { id: 2, q: "Mengapa Anda tertarik bekerja sebagai Junior Accountant?",               type: "Motivation",            difficulty: "Dasar",    lang: "Indonesia", saved: false },
  { id: 3, q: "Jelaskan proses penyusunan jurnal penyesuaian.",                          type: "Teknik Akuntansi",      difficulty: "Menengah", lang: "Indonesia", saved: true  },
  { id: 4, q: "Ceritakan pengalaman ketika Anda bekerja dalam tim.",                     type: "Behavioral",            difficulty: "Menengah", lang: "Indonesia", saved: false },
  { id: 5, q: "Bagaimana Anda menangani perbedaan antara saldo buku besar dan rekening bank?", type: "Teknik Akuntansi", difficulty: "Lanjutan", lang: "Indonesia", saved: false },
  { id: 6, q: "Tell me about a time you had to meet a difficult deadline.",              type: "Behavioral (Inggris)",  difficulty: "Menengah", lang: "English",   saved: false },
];

const COMPETENCY_SCORES = [
  { name: "Komunikasi",          score: 82 },
  { name: "Struktur Jawaban",    score: 84 },
  { name: "Teknik Akuntansi",score: 80 },
  { name: "Problem Solving",     score: 74 },
  { name: "Confidence",          score: 72 },
  { name: "Relevansi",           score: 79 },
];

const IV_HISTORY = [
  { tgl: "3 Jul 2026",  posisi: "Junior Accountant",  bidang: "Akuntansi", jenis: "Campuran", lang: "Indonesia", score: 78, dur: "18 mnt" },
  { tgl: "1 Jul 2026",  posisi: "Finance Intern",     bidang: "Keuangan",  jenis: "HR",       lang: "English",   score: 72, dur: "14 mnt" },
  { tgl: "28 Jun 2026", posisi: "Audit Intern",       bidang: "Audit",     jenis: "Teknikal", lang: "Indonesia", score: 75, dur: "20 mnt" },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function SummaryCard({ label, value, desc, color, icon: Icon }: {
  label: string; value: string | number; desc: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
          style={{ backgroundColor: color + "18", color }}>
          <Icon size={16} />
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 leading-tight">{value}</p>
      <p className="text-[11px] text-gray-400 leading-snug">{desc}</p>
    </div>
  );
}

// ── Interview Setup (Stepper) ─────────────────────────────────────────────────
function InterviewSetup({ onClose, onStart }: { onClose: () => void; onStart: () => void }) {
  const [step, setStep]   = useState(1);
  const [posisi, setPosisi] = useState("Junior Accountant");
  const [level, setLevel] = useState("Fresh Graduate");
  const [jenis, setJenis] = useState("Campuran");
  const [mode, setMode]   = useState("Jawaban Teks");
  const [jumlah, setJumlah] = useState("8");
  const [bahasa, setBahasa] = useState("Bahasa Indonesia");
  const [style, setStyle] = useState("Profesional");
  const [permissionDone, setPermissionDone] = useState(false);

  const steps = ["Pilih Posisi","Jenis Interview","Pilih Mode","Atur Sesi","Permission"];

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[520px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 shrink-0">
          <div>
            <h2 className="text-sm font-bold text-gray-900">Setup Simulasi Interview</h2>
            <p className="text-xs text-gray-400">Langkah {step} dari {steps.length}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>

        {/* Step indicator */}
        <div className="flex items-center gap-1.5 px-5 pt-4 shrink-0">
          {steps.map((s, i) => (
            <React.Fragment key={s}>
              <div className={`flex items-center justify-center w-5 h-5 rounded-full text-[9px] font-bold shrink-0 ${step > i ? "bg-gray-900 text-white" : step === i+1 ? "border-2 border-gray-900 text-gray-900" : "bg-gray-100 text-gray-400"}`}>{i+1}</div>
              {i < steps.length - 1 && <div className={`flex-1 h-0.5 ${step > i+1 ? "bg-gray-900" : "bg-gray-100"}`} />}
            </React.Fragment>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {step === 1 && (
            <>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Target Posisi</label>
                <input value={posisi} onChange={e => setPosisi(e.target.value)} className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">Bidang</label>
                  <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                    {["Akuntansi","Keuangan","Audit","Perpajakan","Perbankan"].map(b => <option key={b}>{b}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">Level</label>
                  <select value={level} onChange={e => setLevel(e.target.value)} className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                    {["Fresh Graduate","Junior","Menengah","Senior"].map(l => <option key={l}>{l}</option>)}
                  </select>
                </div>
              </div>
            </>
          )}

          {step === 2 && (
            <div className="grid grid-cols-2 gap-3">
              {["Wawancara HR","Behavioral","Teknikal","Campuran"].map(j => (
                <button key={j} onClick={() => setJenis(j)}
                  className={`py-4 rounded-xl border-2 text-sm font-semibold transition-all ${jenis === j ? "border-gray-900 bg-gray-50 text-gray-900" : "border-gray-200 text-gray-500 hover:border-gray-300"}`}>
                  {j}
                </button>
              ))}
            </div>
          )}

          {step === 3 && (
            <div className="space-y-3">
              {[
                { label: "Jawaban Teks",  desc: "Ketik jawaban langsung",   active: true },
                { label: "Jawaban Audio", desc: "Rekam jawaban suara",      active: true },
                { label: "Jawaban Video", desc: "Rekam dengan kamera",      active: false, tag: "Opsional" },
              ].map(m => (
                <button key={m.label} onClick={() => m.active && setMode(m.label)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 text-left transition-all ${mode === m.label ? "border-gray-900 bg-gray-50" : m.active ? "border-gray-200 hover:border-gray-300" : "border-gray-100 opacity-60 cursor-not-allowed"}`}>
                  <div className={`w-4 h-4 rounded-full border-2 shrink-0 ${mode === m.label ? "bg-gray-900 border-gray-900" : "border-gray-300"}`} />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-800">{m.label}</p>
                    <p className="text-xs text-gray-500">{m.desc}</p>
                  </div>
                  {m.tag && <span className="text-[10px] text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">{m.tag}</span>}
                </button>
              ))}
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">Jumlah Pertanyaan</label>
                  <select value={jumlah} onChange={e => setJumlah(e.target.value)} className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                    {["5","8","10","12"].map(j => <option key={j}>{j}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">Bahasa</label>
                  <select value={bahasa} onChange={e => setBahasa(e.target.value)} className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                    <option>Bahasa Indonesia</option><option>English</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Gaya Interviewer</label>
                <div className="flex gap-2">
                  {["Ramah","Profesional","Menantang"].map(s => (
                    <button key={s} onClick={() => setStyle(s)}
                      className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors ${style === s ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"}`}>{s}</button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-4">
              {mode === "Jawaban Audio" && (
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 space-y-2">
                  <p className="text-xs font-semibold text-blue-800">Izin Microphone Diperlukan</p>
                  <p className="text-xs text-blue-700">Jawaban audio Anda hanya digunakan untuk evaluasi latihan pribadi dan tidak dibagikan ke pihak mana pun.</p>
                  <div className="flex items-center gap-2">
                    <input type="checkbox" id="perm" checked={permissionDone} onChange={e => setPermissionDone(e.target.checked)} />
                    <label htmlFor="perm" className="text-xs text-blue-800">Saya menyetujui penggunaan microphone untuk sesi ini</label>
                  </div>
                  <button onClick={() => setPermissionDone(true)} className="text-xs font-semibold text-blue-700 border border-blue-300 px-3 py-1.5 rounded-lg hover:bg-blue-100 transition-colors flex items-center gap-1.5">
                    <Mic size={12} /> Aktifkan Microphone
                  </button>
                </div>
              )}
              <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                <p className="text-xs font-semibold text-gray-700 mb-2">Ringkasan Sesi</p>
                {[["Posisi",posisi],["Jenis",jenis],["Mode",mode],["Pertanyaan",jumlah],["Bahasa",bahasa],["Gaya",style]].map(([k,v]) => (
                  <div key={k} className="flex justify-between text-xs py-0.5">
                    <span className="text-gray-500">{k}</span>
                    <span className="font-medium text-gray-800">{v}</span>
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-gray-400 text-center">Feedback merupakan evaluasi latihan dan tidak menjamin hasil proses rekrutmen.</p>
            </div>
          )}
        </div>

        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-between shrink-0">
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <div className="flex gap-2">
            {step > 1 && <button onClick={() => setStep(step-1)} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Kembali</button>}
            {step < 5
              ? <button onClick={() => setStep(step+1)} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">Lanjut</button>
              : <button onClick={onStart} disabled={mode === "Jawaban Audio" && !permissionDone}
                  className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-50 flex items-center gap-2">
                  <Mic size={13} /> Mulai Simulasi
                </button>
            }
          </div>
        </div>
      </div>
    </>
  );
}

// ── Interview Session ─────────────────────────────────────────────────────────
function InterviewSession({ onFinish }: { onFinish: () => void }) {
  const [qIdx, setQIdx]       = useState(0);
  const [answer, setAnswer]   = useState("");
  const [timeLeft, setTimeLeft] = useState(90);
  const [showFeedback, setShowFeedback] = useState(false);
  const [recording, setRecording] = useState(false);
  const [submitted, setSubmitted] = useState<Set<number>>(new Set());

  useEffect(() => {
    if (showFeedback) return;
    const t = setInterval(() => setTimeLeft(prev => Math.max(0, prev - 1)), 1000);
    return () => clearInterval(t);
  }, [showFeedback]);

  const sessionQs = [
    "Ceritakan tentang diri Anda.",
    "Mengapa Anda tertarik bekerja sebagai Junior Accountant?",
    "Ceritakan pengalaman ketika Anda harus menyelesaikan pekerjaan dengan tenggat waktu yang terbatas.",
    "Jelaskan proses rekonsiliasi bank yang pernah Anda lakukan.",
  ];

  const handleSubmit = () => {
    setSubmitted(new Set([...submitted, qIdx]));
    setShowFeedback(true);
    setTimeLeft(90);
  };

  const nextQ = () => {
    if (qIdx >= sessionQs.length - 1) { onFinish(); return; }
    setQIdx(qIdx + 1);
    setAnswer("");
    setShowFeedback(false);
    setRecording(false);
  };

  const fmt = (s: number) => `${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;

  return (
    <div className="flex flex-col h-full">
      {/* Session bar */}
      <div className="bg-white border-b border-gray-200 px-5 py-3 flex items-center gap-4 shrink-0">
        <button onClick={onFinish} className="text-xs text-gray-500 hover:text-gray-800 transition-colors flex items-center gap-1">
          <ChevronLeft size={14} /> Keluar
        </button>
        <div className="flex-1 text-center">
          <span className="text-sm font-semibold text-gray-800">Simulasi Interview — Junior Accountant</span>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <span className="text-gray-500">Pertanyaan {qIdx + 1} dari {sessionQs.length}</span>
          <span className={`font-mono font-semibold ${timeLeft < 20 ? "text-red-500" : "text-gray-700"}`}>{fmt(timeLeft)}</span>
        </div>
      </div>

      <div className="flex flex-1 min-h-0 overflow-hidden">
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Interviewer panel */}
          <div className="bg-white border border-gray-200 rounded-xl p-5 flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center shrink-0">
              <User size={28} className="text-gray-400" />
            </div>
            <div className="flex-1">
              <p className="text-xs font-semibold text-gray-500 mb-0.5">Recruiter FreeSpace • Campuran • Pertanyaan {qIdx+1} dari {sessionQs.length}</p>
              <p className="text-base font-medium text-gray-900 leading-relaxed">"{sessionQs[qIdx]}"</p>
              <div className="flex gap-2 mt-2">
                <span className="text-[10px] bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full font-semibold">
                  {qIdx < 2 ? "Wawancara HR" : qIdx < 3 ? "Behavioral" : "Teknik Akuntansi"}
                </span>
              </div>
            </div>
          </div>

          {/* Response area */}
          {!showFeedback && (
            <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-semibold text-gray-700">Jawaban Anda</p>
                <span className="text-[10px] text-gray-400">{answer.split(/\s+/).filter(Boolean).length} kata</span>
              </div>
              <textarea value={answer} onChange={e => setAnswer(e.target.value)}
                rows={6} placeholder="Tuliskan jawaban Anda di sini..."
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none leading-relaxed" />

              {/* STAR guide */}
              <div className="bg-gray-50 rounded-xl p-3">
                <p className="text-[10px] font-semibold text-gray-500 mb-2">Panduan STAR (Behavioral Questions)</p>
                <div className="grid grid-cols-4 gap-2">
                  {[["S","Situation","Konteks/latar belakang"],["T","Task","Tugas yang dihadapi"],["A","Action","Tindakan yang diambil"],["R","Result","Hasil yang dicapai"]].map(([abbr,label,desc]) => (
                    <div key={abbr} className="text-center">
                      <div className="w-6 h-6 rounded-full bg-gray-200 text-gray-700 flex items-center justify-center text-xs font-bold mx-auto mb-1">{abbr}</div>
                      <p className="text-[10px] font-semibold text-gray-700">{label}</p>
                      <p className="text-[9px] text-gray-400">{desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 justify-end">
                <button onClick={handleSubmit} disabled={!answer.trim()}
                  className="px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-50">
                  Submit Jawaban
                </button>
              </div>
            </div>
          )}

          {/* Feedback */}
          {showFeedback && (
            <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold text-gray-900">Feedback</p>
                <span className="text-lg font-bold text-green-600">78<span className="text-xs text-gray-400 font-normal">/100</span></span>
              </div>

              <div className="space-y-3">
                <div className="bg-green-50 border border-green-100 rounded-xl p-3">
                  <p className="text-xs font-semibold text-green-700 mb-1">Yang Sudah Baik</p>
                  <p className="text-xs text-green-700">Jawaban memiliki urutan kejadian yang jelas dan alur yang mudah diikuti.</p>
                </div>
                <div className="bg-amber-50 border border-amber-100 rounded-xl p-3">
                  <p className="text-xs font-semibold text-amber-700 mb-1">Perlu Diperbaiki</p>
                  <p className="text-xs text-amber-700">Hasil akhir belum dijelaskan secara terukur. Tambahkan angka atau dampak konkret.</p>
                </div>
                <div className="bg-gray-50 rounded-xl p-3">
                  <p className="text-xs font-semibold text-gray-700 mb-1">Saran Perbaikan</p>
                  <p className="text-xs text-gray-600">Tambahkan hasil atau pembelajaran yang diperoleh. Gunakan angka seperti "mengurangi 20% waktu", "selesai 2 hari lebih awal", dll.</p>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button onClick={() => { setShowFeedback(false); setAnswer(""); }}
                  className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors">
                  <RotateCcw size={12} /> Coba Lagi
                </button>
                <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors">
                  Simpan Feedback
                </button>
                <button onClick={nextQ} className="ml-auto flex items-center gap-1.5 text-xs text-white bg-gray-900 px-4 py-2 rounded-lg hover:bg-black transition-colors">
                  {qIdx >= sessionQs.length - 1 ? "Selesai" : "Lanjut →"}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Progress sidebar */}
        <div className="w-44 shrink-0 bg-white border-l border-gray-100 p-4">
          <p className="text-[10px] font-semibold text-gray-400 uppercase mb-3">Progress</p>
          <div className="space-y-2">
            {sessionQs.map((q, i) => (
              <div key={i}
                className={`flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs ${i === qIdx ? "bg-gray-100 text-gray-900 font-semibold" : submitted.has(i) ? "text-green-600" : "text-gray-400"}`}>
                {submitted.has(i) ? <CheckCircle2 size={11} className="text-green-500 shrink-0" /> : i === qIdx ? <div className="w-2.5 h-2.5 rounded-full bg-gray-900 shrink-0" /> : <div className="w-2.5 h-2.5 rounded-full border border-gray-300 shrink-0" />}
                <span className="truncate">Soal {i+1}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-3 border-t border-gray-100">
            <p className="text-[10px] text-gray-400">Rekaman hanya untuk evaluasi latihan pribadi.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Hasil Tab ─────────────────────────────────────────────────────────────────
function HasilFeedbackTab() {
  return (
    <div className="space-y-5">
      {/* Overall Score */}
      <div className="bg-white border border-gray-200 rounded-xl p-5 flex items-center gap-6">
        <div className="text-center">
          <p className="text-4xl font-bold text-gray-900">78</p>
          <p className="text-xs text-gray-400">/ 100</p>
          <span className="text-[10px] font-bold bg-green-50 text-green-700 px-2 py-0.5 rounded-full">Baik</span>
        </div>
        <div className="flex-1">
          <p className="text-sm font-bold text-gray-900 mb-1">Simulasi Selesai — Junior Accountant</p>
          <p className="text-xs text-gray-500">8 pertanyaan • 18 menit • Bahasa Indonesia</p>
          <div className="flex gap-3 mt-3 text-xs">
            {[["Kekuatan","Struktur jawaban dan pemahaman akuntansi"],["Perbaikan","Contoh terukur dan English fluency"]].map(([k,v]) => (
              <div key={k} className="flex-1 bg-gray-50 rounded-lg p-2">
                <p className="font-semibold text-gray-600 mb-0.5">{k}</p>
                <p className="text-gray-500">{v}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="flex flex-col gap-2 shrink-0">
          <button className="px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-1.5"><Download size={12} /> Export</button>
          <button className="px-3 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors flex items-center gap-1.5"><RotateCcw size={12} /> Ulangi</button>
        </div>
      </div>

      {/* Competency Scores */}
      <div className="grid grid-cols-2 gap-5">
        <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
          <p className="text-sm font-semibold text-gray-800 mb-4">Skor per Kompetensi</p>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart id="bar-competency" data={COMPETENCY_SCORES} layout="vertical" barSize={14}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" horizontal={false} />
                <XAxis type="number" domain={[0,100]} tick={{ fontSize: 10, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 10, fill: "#6B7280" }} axisLine={false} tickLine={false} width={120} />
                <Tooltip formatter={(v: number) => [`${v}/100`, ""]} contentStyle={{ fontSize: 11, borderRadius: 8 }} />
                <Bar dataKey="score" fill="#111827" radius={[0,4,4,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
          <p className="text-sm font-semibold text-gray-800 mb-4">Action Plan Personal</p>
          <div className="space-y-2.5">
            {[
              "Latihan behavioral question dua kali sebelum simulasi berikutnya.",
              "Latihan technical accounting tiga kali minggu ini.",
              "Latihan jawaban dalam Bahasa Inggris setidaknya sekali.",
              "Gunakan kerangka STAR di setiap jawaban behavioral.",
              "Tambahkan angka dan hasil konkret dalam setiap jawaban.",
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="text-[10px] font-bold bg-gray-900 text-white w-4 h-4 rounded flex items-center justify-center shrink-0 mt-0.5">{i+1}</span>
                <p className="text-xs text-gray-700">{item}</p>
              </div>
            ))}
          </div>
          <button className="mt-4 w-full text-xs font-semibold text-gray-600 border border-gray-200 py-2 rounded-lg hover:bg-gray-50 transition-colors">
            Buat Jadwal Latihan
          </button>
        </div>
      </div>

      {/* History */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b border-gray-100 bg-gray-50/50">
          <p className="text-sm font-semibold text-gray-800">Riwayat Simulasi</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-100">
                {["Tanggal","Target Posisi","Bidang","Jenis","Bahasa","Skor","Durasi","Aksi"].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {IV_HISTORY.map((r, i) => (
                <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4 text-xs text-gray-600">{r.tgl}</td>
                  <td className="py-3 px-4 text-xs font-medium text-gray-800">{r.posisi}</td>
                  <td className="py-3 px-4 text-xs text-gray-500">{r.bidang}</td>
                  <td className="py-3 px-4"><span className="text-[10px] font-semibold bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{r.jenis}</span></td>
                  <td className="py-3 px-4 text-xs text-gray-500">{r.lang}</td>
                  <td className="py-3 px-4 text-sm font-bold text-gray-900">{r.score}</td>
                  <td className="py-3 px-4 text-xs text-gray-400">{r.dur}</td>
                  <td className="py-3 px-4">
                    <div className="flex gap-1">
                      <button className="text-xs text-gray-500 border border-gray-200 px-2 py-1 rounded hover:bg-gray-50 transition-colors">Lihat</button>
                      <button className="text-xs text-gray-500 border border-gray-200 px-2 py-1 rounded hover:bg-gray-50 transition-colors">Ulangi</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Latihan Tab ───────────────────────────────────────────────────────────────
function LatihanPertanyaanTab({ onAnswer }: { onAnswer: () => void }) {
  const [filterBidang, setFilterBidang] = useState("Semua");
  const [filterTipe, setFilterTipe]     = useState("Semua");
  const [filterLang, setFilterLang]     = useState("Semua");

  const filtered = QUESTIONS.filter(q => {
    return (filterBidang === "Semua" || q.type.includes(filterBidang)) &&
           (filterTipe   === "Semua" || q.type === filterTipe) &&
           (filterLang   === "Semua" || q.lang === filterLang);
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        <select value={filterBidang} onChange={e => setFilterBidang(e.target.value)} className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
          <option value="Semua">Semua Bidang</option>
          {["Akuntansi","Keuangan","Audit","Fresh Graduate"].map(b => <option key={b}>{b}</option>)}
        </select>
        <select value={filterTipe} onChange={e => setFilterTipe(e.target.value)} className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
          <option value="Semua">Semua Tipe</option>
          {["Wawancara HR","Behavioral","Teknikal","Teknik Akuntansi","Motivasi"].map(t => <option key={t}>{t}</option>)}
        </select>
        <select value={filterLang} onChange={e => setFilterLang(e.target.value)} className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
          <option value="Semua">Semua Bahasa</option>
          <option>Indonesia</option><option>English</option>
        </select>
      </div>

      <div className="space-y-3">
        {filtered.map(q => (
          <div key={q.id} className="bg-white border border-gray-200 rounded-xl p-4 hover:border-gray-300 transition-all group">
            <div className="flex items-start gap-3">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 leading-relaxed mb-2">{q.q}</p>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-semibold bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">{q.type}</span>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${q.difficulty === "Dasar" ? "bg-gray-100 text-gray-500" : q.difficulty === "Menengah" ? "bg-amber-50 text-amber-600" : "bg-red-50 text-red-500"}`}>{q.difficulty}</span>
                  <span className="text-[10px] text-gray-400 bg-gray-50 px-2 py-0.5 rounded-full">{q.lang}</span>
                </div>
              </div>
              <div className="flex gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={onAnswer} className="text-xs font-semibold text-white bg-gray-900 px-3 py-1.5 rounded-lg hover:bg-black transition-colors flex items-center gap-1">
                  <Mic size={11} /> Jawab
                </button>
                <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors">
                  <Bookmark size={13} className={q.saved ? "text-amber-500 fill-amber-500" : ""} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function InterviewSimulatorPage({ topBar }: { topBar?: React.ReactNode }) {
  const [tab, setTab]           = useState<IVTab>("latihan");
  const [showSetup, setShowSetup] = useState(false);
  const [inSession, setInSession] = useState(false);

  if (inSession) {
    return (
      <main className="flex-1 overflow-hidden bg-gray-50 min-w-0 flex flex-col">
        <InterviewSession onFinish={() => { setInSession(false); setTab("hasil"); }} />
      </main>
    );
  }

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Interview Simulator</h1>
            <p className="text-xs text-gray-500 mt-0.5">Latih jawaban interview secara terstruktur dan dapatkan feedback untuk meningkatkan performa Anda.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button onClick={() => setTab("latihan")}
              className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
              Latihan Pertanyaan
            </button>
            <button onClick={() => setShowSetup(true)}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors shadow-sm">
              <Mic size={13} /> Mulai Simulasi
            </button>
          </div>
        </div>

        {/* Info Banner */}
        <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 flex items-start gap-2 text-xs text-blue-700">
          <Info size={14} className="shrink-0 mt-0.5" />
          Feedback merupakan evaluasi latihan dan tidak menjamin hasil proses rekrutmen.
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <SummaryCard label="Simulasi Selesai" value={8}          desc="3 sesi bulan ini"                     color="#111827" icon={CheckCircle2} />
          <SummaryCard label="Skor Terakhir"    value={78}         desc="Kategori Baik"                         color="#22C55E" icon={Star} />
          <SummaryCard label="Rata-Rata Durasi" value="18 Menit"   desc="Per sesi"                              color="#3B82F6" icon={Clock} />
          <SummaryCard label="Area Perbaikan"   value={2}          desc="Contoh pengalaman & English fluency"   color="#F59E0B" icon={AlertCircle} />
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {([["latihan","Latihan Pertanyaan"],["simulasi","Simulasi Interview"],["hasil","Hasil & Feedback"]] as const).map(([id, label]) => (
            <button key={id} onClick={() => setTab(id as IVTab)}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${tab === id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              {label}
            </button>
          ))}
        </div>

        {tab === "latihan"  && <LatihanPertanyaanTab onAnswer={() => { setShowSetup(true); }} />}
        {tab === "simulasi" && (
          <div className="bg-white border border-gray-200 rounded-xl p-8 text-center">
            <Mic size={36} className="text-gray-300 mx-auto mb-3" />
            <p className="text-sm font-semibold text-gray-700 mb-1">Siap untuk Simulasi Interview?</p>
            <p className="text-xs text-gray-400 mb-5">Klik tombol di bawah untuk memulai setup simulasi interview.</p>
            <button onClick={() => setShowSetup(true)}
              className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-gray-900 rounded-xl hover:bg-black transition-colors">
              <Mic size={15} /> Mulai Simulasi
            </button>
          </div>
        )}
        {tab === "hasil" && <HasilFeedbackTab />}
      </div>

      {showSetup && (
        <InterviewSetup
          onClose={() => setShowSetup(false)}
          onStart={() => { setShowSetup(false); setInSession(true); }}
        />
      )}
    </main>
  );
}
