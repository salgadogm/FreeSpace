import React, { useState } from "react";
import { Plus, Upload, Search, ChevronDown, MoreHorizontal, Paperclip, X, Check } from "lucide-react";

// ── Formatter ──────────────────────────────────────────────────────────────────
const fmtRp = (n: number) => "Rp" + Math.abs(n).toLocaleString("id-ID");

// ── Shared ─────────────────────────────────────────────────────────────────────
type TipeTransaksi = "Pemasukan" | "Pengeluaran" | "Transfer";

const TABS = [
  { id: "semua",     label: "Semua Transaksi",   count: 48 },
  { id: "masuk",     label: "Pemasukan",          count: 7  },
  { id: "keluar",    label: "Pengeluaran",         count: 36 },
  { id: "transfer",  label: "Transfer",            count: 5  },
  { id: "berulang",  label: "Transaksi Berulang",  count: 6  },
];

const TRANSAKSI_DATA = [
  { id: 1, tgl: "3 Jul 2026",  nama: "Makan Siang",            kat: "Makanan",     akun: "E-Wallet",              tipe: "Pengeluaran" as TipeTransaksi, lampiran: true,  nominal: -35000 },
  { id: 2, tgl: "3 Jul 2026",  nama: "Transportasi Kampus",     kat: "Transportasi",akun: "E-Wallet",              tipe: "Pengeluaran" as TipeTransaksi, lampiran: false, nominal: -22000 },
  { id: 3, tgl: "2 Jul 2026",  nama: "Pembelian Buku Akuntansi",kat: "Pendidikan",  akun: "Bank Utama",            tipe: "Pengeluaran" as TipeTransaksi, lampiran: true,  nominal: -185000 },
  { id: 4, tgl: "1 Jul 2026",  nama: "Uang Saku Bulanan",       kat: "Pemasukan",   akun: "Bank Utama",            tipe: "Pemasukan"  as TipeTransaksi, lampiran: false, nominal: 3000000 },
  { id: 5, tgl: "1 Jul 2026",  nama: "Langganan Internet",      kat: "Tagihan",     akun: "Bank Utama",            tipe: "Pengeluaran" as TipeTransaksi, lampiran: true,  nominal: -150000 },
  { id: 6, tgl: "1 Jul 2026",  nama: "Transfer ke E-Wallet",    kat: "Transfer",    akun: "Bank Utama → E-Wallet", tipe: "Transfer"   as TipeTransaksi, lampiran: false, nominal: 500000 },
  { id: 7, tgl: "30 Jun 2026", nama: "Freelance Input Data",    kat: "Pemasukan",   akun: "Bank Utama",            tipe: "Pemasukan"  as TipeTransaksi, lampiran: true,  nominal: 750000 },
];

// ── Action Menu ────────────────────────────────────────────────────────────────
function ActionMenu() {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)}
        className="p-1 rounded hover:bg-gray-100 transition-colors">
        <MoreHorizontal size={15} className="text-gray-400" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="absolute right-0 mt-1 w-36 bg-white border border-gray-200 rounded-lg shadow-lg z-40 py-1">
            {["Lihat Detail","Edit","Duplikat","Hapus"].map(a => (
              <button key={a} onClick={() => setOpen(false)}
                className={`w-full px-3 py-1.5 text-left text-xs transition-colors ${a === "Hapus" ? "text-red-600 hover:bg-red-50" : "text-gray-700 hover:bg-gray-50"}`}>
                {a}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ── Filter Dropdown ────────────────────────────────────────────────────────────
function FDropdown({ value, opts }: { value: string; opts: string[] }) {
  const [open, setOpen] = useState(false);
  const [sel, setSel] = useState(value);
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-xs font-medium text-gray-700 hover:bg-gray-50">
        {sel}<ChevronDown size={11} className="text-gray-400" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="absolute left-0 mt-1 w-44 bg-white border border-gray-200 rounded-lg shadow-lg z-40 py-1">
            {opts.map(o => (
              <button key={o} onClick={() => { setSel(o); setOpen(false); }}
                className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50">
                {o}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ── Tipe Badge ─────────────────────────────────────────────────────────────────
function TipeBadge({ tipe }: { tipe: TipeTransaksi }) {
  const cfg: Record<TipeTransaksi, string> = {
    Pemasukan:  "bg-green-50 text-green-700 border-green-200",
    Pengeluaran:"bg-red-50 text-red-600 border-red-200",
    Transfer:   "bg-blue-50 text-blue-700 border-blue-200",
  };
  return (
    <span className={`text-[10px] font-semibold border px-1.5 py-0.5 rounded ${cfg[tipe]}`}>
      {tipe}
    </span>
  );
}

// ── Modal Tambah Transaksi ─────────────────────────────────────────────────────
function TambahTransaksiModal({ onClose }: { onClose: () => void }) {
  const [tipe, setTipe] = useState<TipeTransaksi>("Pengeluaran");
  const [berulang, setBerulang] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSave = () => {
    setSuccess(true);
    setTimeout(onClose, 1200);
  };

  if (success) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
        <div className="bg-white rounded-2xl p-10 flex flex-col items-center gap-3 shadow-2xl animate-in zoom-in-95 duration-200">
          <div className="w-14 h-14 rounded-full bg-green-100 flex items-center justify-center">
            <Check size={28} className="text-green-600" />
          </div>
          <p className="text-base font-bold text-gray-900">Transaksi Disimpan!</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[520px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 sticky top-0 bg-white">
          <h2 className="text-sm font-bold text-gray-900">Tambah Transaksi</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100">
            <X size={16} className="text-gray-500" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Tipe Segmented */}
          <div className="flex bg-gray-100 p-1 rounded-lg">
            {(["Pemasukan","Pengeluaran","Transfer"] as TipeTransaksi[]).map(t => (
              <button key={t} onClick={() => setTipe(t)}
                className={`flex-1 py-1.5 rounded-md text-xs font-semibold transition-all ${tipe === t ? "bg-white shadow-sm text-gray-900" : "text-gray-500"}`}>
                {t}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Nominal <span className="text-red-500">*</span></label>
              <input type="text" placeholder="Rp0" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Tanggal <span className="text-red-500">*</span></label>
              <input type="date" defaultValue="2026-07-03" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900" />
            </div>
          </div>

          {tipe === "Transfer" ? (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Akun Asal <span className="text-red-500">*</span></label>
                <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                  <option>Bank Utama</option><option>E-Wallet</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Akun Tujuan <span className="text-red-500">*</span></label>
                <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                  <option>E-Wallet</option><option>Bank Utama</option>
                </select>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Akun <span className="text-red-500">*</span></label>
                <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                  <option>Bank Utama</option><option>E-Wallet</option><option>Dana Darurat</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Kategori <span className="text-red-500">*</span></label>
                <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                  <option>Makanan</option><option>Transportasi</option><option>Pendidikan</option>
                  <option>Tagihan</option><option>Hiburan</option><option>Pemasukan</option>
                </select>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Nama Transaksi</label>
            <input type="text" placeholder="Contoh: Makan siang" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900" />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Deskripsi</label>
            <textarea placeholder="Catatan tambahan..." rows={2}
              className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900 resize-none" />
          </div>

          <div className="flex items-center gap-3">
            <label className="text-xs font-medium text-gray-700 flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={berulang} onChange={() => setBerulang(!berulang)}
                className="rounded" />
              Transaksi Berulang
            </label>
            {berulang && (
              <select className="text-sm px-2 py-1 border border-gray-200 rounded-lg outline-none bg-white">
                <option>Setiap Bulan</option><option>Setiap Minggu</option><option>Setiap Hari</option>
              </select>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Lampiran Bukti Transaksi</label>
            <div className="border-2 border-dashed border-gray-200 rounded-lg p-4 text-center cursor-pointer hover:border-gray-400 transition-colors">
              <Upload size={18} className="text-gray-400 mx-auto mb-1" />
              <p className="text-xs text-gray-500">Klik atau seret file ke sini (JPG, PNG, PDF)</p>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-100">
          <button onClick={onClose} className="px-4 py-2 text-sm text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Batal</button>
          <button onClick={handleSave} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black">Simpan Transaksi</button>
        </div>
      </div>
    </>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export function TransaksiPage({ topBar }: { topBar: React.ReactNode }) {
  const [activeTab, setActiveTab] = useState("semua");
  const [showModal, setShowModal] = useState(false);
  const [checked, setChecked] = useState<number[]>([]);

  const toggleCheck = (id: number) =>
    setChecked(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      {showModal && <TambahTransaksiModal onClose={() => setShowModal(false)} />}

      <div className="px-8 py-6 space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Transaksi</h1>
            <p className="text-sm text-gray-500 mt-1">Catat dan kelola seluruh transaksi keuangan pribadi.</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1.5 px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg text-sm font-semibold hover:bg-gray-50 transition-colors">
              <Upload size={14} /> Import
            </button>
            <button onClick={() => setShowModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-semibold hover:bg-black transition-colors">
              <Plus size={14} /> Tambah Transaksi
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "Pemasukan",       value: "Rp6.500.000",  sub: "+5,2% dari bulan lalu",         color: "text-green-600" },
            { label: "Pengeluaran",     value: "Rp3.150.000",  sub: "Turun 6,8% dari bulan lalu",   color: "text-red-500"   },
            { label: "Arus Kas Bersih", value: "Rp3.350.000",  sub: "Pemasukan dikurangi pengeluaran",color:"text-blue-600" },
            { label: "Jumlah Transaksi",value: "48",           sub: "12 transaksi minggu ini",        color: "text-gray-900"  },
          ].map(c => (
            <div key={c.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
              <p className="text-xs font-medium text-gray-500 mb-2">{c.label}</p>
              <p className={`text-2xl font-bold ${c.color} leading-tight`}>{c.value}</p>
              <p className="text-xs text-gray-400 mt-1">{c.sub}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-0 border-b border-gray-200">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                activeTab === t.id
                  ? "border-gray-900 text-gray-900"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}>
              {t.label}
              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                activeTab === t.id ? "bg-gray-900 text-white" : "bg-gray-100 text-gray-600"
              }`}>{t.count}</span>
            </button>
          ))}
        </div>

        {/* Filter Bar */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-lg px-3 py-1.5 w-56">
            <Search size={13} className="text-gray-400 shrink-0" />
            <input className="text-xs flex-1 outline-none placeholder:text-gray-400" placeholder="Cari transaksi..." />
          </div>
          <FDropdown value="1–31 Juli 2026" opts={["1–31 Juli 2026","1–30 Jun 2026","1–31 Mei 2026"]} />
          <FDropdown value="Semua Akun"     opts={["Semua Akun","Bank Utama","E-Wallet","Dana Darurat"]} />
          <FDropdown value="Semua Kategori" opts={["Semua Kategori","Makanan","Transportasi","Pendidikan","Tagihan","Hiburan"]} />
          <FDropdown value="Semua Tipe"     opts={["Semua Tipe","Pemasukan","Pengeluaran","Transfer"]} />
          <button className="px-3 py-1.5 text-xs text-gray-500 border border-gray-200 rounded-lg hover:bg-gray-50 bg-white">
            Reset Filter
          </button>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="px-4 py-3 text-left w-8">
                  <input type="checkbox" className="rounded" />
                </th>
                <th className="px-3 py-3 text-left font-medium text-gray-500">Tanggal</th>
                <th className="px-3 py-3 text-left font-medium text-gray-500">Transaksi</th>
                <th className="px-3 py-3 text-left font-medium text-gray-500">Kategori</th>
                <th className="px-3 py-3 text-left font-medium text-gray-500">Akun</th>
                <th className="px-3 py-3 text-left font-medium text-gray-500">Tipe</th>
                <th className="px-3 py-3 text-center font-medium text-gray-500">Lampiran</th>
                <th className="px-3 py-3 text-right font-medium text-gray-500">Nominal</th>
                <th className="px-3 py-3 text-center font-medium text-gray-500 w-10"></th>
              </tr>
            </thead>
            <tbody>
              {TRANSAKSI_DATA.map(row => (
                <tr key={row.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <input type="checkbox" checked={checked.includes(row.id)}
                      onChange={() => toggleCheck(row.id)} className="rounded" />
                  </td>
                  <td className="px-3 py-3 text-gray-500 whitespace-nowrap">{row.tgl}</td>
                  <td className="px-3 py-3 font-medium text-gray-800">{row.nama}</td>
                  <td className="px-3 py-3 text-gray-500">{row.kat}</td>
                  <td className="px-3 py-3 text-gray-500">{row.akun}</td>
                  <td className="px-3 py-3"><TipeBadge tipe={row.tipe} /></td>
                  <td className="px-3 py-3 text-center">
                    {row.lampiran
                      ? <Paperclip size={13} className="text-blue-500 mx-auto" />
                      : <span className="text-gray-300">—</span>
                    }
                  </td>
                  <td className={`px-3 py-3 text-right font-semibold ${row.nominal > 0 ? "text-green-600" : "text-red-500"}`}>
                    {row.nominal > 0 ? "+" : ""}{fmtRp(row.nominal)}
                  </td>
                  <td className="px-3 py-3 text-center"><ActionMenu /></td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Pagination */}
          <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
            <p className="text-xs text-gray-500">Menampilkan 7 dari 48 transaksi</p>
            <div className="flex items-center gap-1">
              {[1,2,3,"…",5].map((p, i) => (
                <button key={i}
                  className={`w-7 h-7 rounded flex items-center justify-center text-xs font-medium transition-colors ${
                    p === 1 ? "bg-gray-900 text-white" : "text-gray-500 hover:bg-gray-100"
                  }`}>{p}</button>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500">Baris per halaman:</span>
              <select className="text-xs border border-gray-200 rounded px-2 py-1 outline-none">
                <option>10</option><option>25</option><option>50</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
