import React, { useState } from "react";
import { Bell, Send, RefreshCw, X, CheckCircle2, AlertCircle, Shield, Lock } from "lucide-react";

// ── Helpers ───────────────────────────────────────────────────────────────────
function Toggle({ value, onChange, locked }: {
  value: boolean; onChange: (v: boolean) => void; locked?: boolean;
}) {
  return (
    <button onClick={() => !locked && onChange(!value)}
      className={`w-10 h-6 rounded-full relative transition-colors shrink-0 ${value ? "bg-gray-900" : "bg-gray-200"} ${locked ? "opacity-80 cursor-not-allowed" : "cursor-pointer"}`}
      title={locked ? "Notifikasi ini tidak dapat dinonaktifkan sepenuhnya" : undefined}>
      <span className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ${value ? "left-5" : "left-1"}`} />
    </button>
  );
}

function SectionCard({ title, icon: Icon, children }: {
  title: string; icon?: React.ElementType; children: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      <div className="px-5 py-3.5 border-b border-gray-100 bg-gray-50/50 flex items-center gap-2">
        {Icon && <Icon size={15} className="text-gray-500" />}
        <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
      </div>
      <div className="px-5 divide-y divide-gray-50">{children}</div>
    </div>
  );
}

interface NotifRowProps {
  label: string;
  desc?: string;
  value: boolean;
  onChange: (v: boolean) => void;
  locked?: boolean;
  extra?: React.ReactNode;
}

function NotifRow({ label, desc, value, onChange, locked, extra }: NotifRowProps) {
  return (
    <div className="flex items-start justify-between py-3.5 gap-4">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <p className="text-sm font-medium text-gray-800">{label}</p>
          {locked && <Lock size={11} className="text-gray-400" title="Tidak dapat dinonaktifkan" />}
        </div>
        {desc && <p className="text-xs text-gray-500 mt-0.5">{desc}</p>}
        {extra && <div className="mt-2">{extra}</div>}
      </div>
      <Toggle value={value} onChange={onChange} locked={locked} />
    </div>
  );
}

// ── Test Modal ────────────────────────────────────────────────────────────────
function TestNotifModal({ onClose, showToast }: { onClose: () => void; showToast?: (msg: string) => void }) {
  const [saluran, setSaluran] = useState("Dalam Aplikasi");
  const [sending, setSending] = useState(false);

  const handleSend = () => {
    setSending(true);
    setTimeout(() => {
      setSending(false);
      showToast?.("Notifikasi uji berhasil dikirim.");
      onClose();
    }, 800);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[400px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Kirim Notifikasi Uji</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Saluran</label>
            <div className="flex gap-2">
              {["Dalam Aplikasi","Browser","Email"].map(s => (
                <button key={s} onClick={() => setSaluran(s)}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors ${saluran === s ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Jenis Notifikasi</label>
            <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
              <option>Notifikasi Umum</option>
              <option>Pengingat Aktivitas</option>
              <option>Peringatan Budget</option>
            </select>
          </div>
        </div>
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <button onClick={handleSend} disabled={sending}
            className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-70 flex items-center gap-2">
            {sending ? <><RefreshCw size={13} className="animate-spin" /> Mengirim...</> : <><Send size={13} /> Kirim Uji</>}
          </button>
        </div>
      </div>
    </>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function NotifikasiSettingPage({ topBar, showToast }: {
  topBar?: React.ReactNode;
  showToast?: (msg: string, type?: string) => void;
}) {
  const [showTest, setShowTest] = useState(false);
  const [saving, setSaving] = useState(false);
  const [unsaved, setUnsaved] = useState(false);

  const mark = () => setUnsaved(true);
  const handleSave = () => {
    setSaving(true);
    setTimeout(() => { setSaving(false); setUnsaved(false); showToast?.("Pengaturan notifikasi berhasil disimpan."); }, 700);
  };

  // Saluran
  const [inApp, setInApp]     = useState(true);
  const [browser, setBrowser] = useState(true);
  const [email, setEmail]     = useState(true);

  // Mode Tenang
  const [modeTenang, setModeTenang]     = useState(true);
  const [waktuMulai, setWaktuMulai]     = useState("22:00");
  const [waktuSelesai, setWaktuSelesai] = useState("07:00");
  const [ringkasanHarian, setRingkasanHarian] = useState(true);
  const [wktRingkasan, setWktRingkasan] = useState("07:30");
  const [ringkasanMinggu, setRingkasanMinggu] = useState(true);

  // Keuangan
  const [budgetMendekati, setBudgetMendekati] = useState(true);
  const [budgetLampaui, setBudgetLampaui]     = useState(true);
  const [transBerulang, setTransBerulang]     = useState(true);
  const [jatuhTempo, setJatuhTempo]           = useState(true);
  const [targetKeu, setTargetKeu]             = useState(true);
  const [draftAI, setDraftAI]                 = useState(true);
  const [laporanSelesai, setLaporanSelesai]   = useState(true);

  // Produktivitas
  const [aktivitasMendatang, setAktivitasMendatang] = useState(true);
  const [deadline, setDeadline]                     = useState(true);
  const [jurnalReminder, setJurnalReminder]         = useState(true);
  const [wktJurnal, setWktJurnal]                   = useState("21:00");
  const [bibleReminder, setBibleReminder]           = useState(true);
  const [wktBible, setWktBible]                     = useState("06:30");
  const [targetBaca, setTargetBaca]                 = useState(true);
  const [targetLangkah, setTargetLangkah]           = useState(true);

  // Library & Karier
  const [rencanaBaca, setRencanaBaca]       = useState(true);
  const [bukuBelum, setBukuBelum]           = useState(true);
  const [toeflJadwal, setToeflJadwal]       = useState(true);
  const [interview, setInterview]           = useState(true);
  const [ats, setAts]                       = useState(true);

  // Sistem & Keamanan
  const [perangkatBaru, setPerangkatBaru]   = useState(true);
  const [loginGagal, setLoginGagal]         = useState(true);
  const [backupBerhasil, setBackupBerhasil] = useState(false);
  const [backupGagal, setBackupGagal]       = useState(true);
  const [restoreSelesai, setRestoreSelesai] = useState(true);
  const [updateApp, setUpdateApp]           = useState(true);

  const ch = <T,>(setter: (v: T) => void) => (v: T) => { setter(v); mark(); };

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Pengaturan Notifikasi</h1>
            <p className="text-xs text-gray-500 mt-0.5">Atur jenis, saluran, dan waktu notifikasi yang ingin Anda terima.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button onClick={() => setShowTest(true)}
              className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
              <Send size={12} /> Kirim Notifikasi Uji
            </button>
            <button onClick={handleSave} disabled={saving || !unsaved}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors shadow-sm disabled:opacity-50">
              {saving ? <><RefreshCw size={12} className="animate-spin" /> Menyimpan...</> : <><CheckCircle2 size={12} /> Simpan Perubahan</>}
            </button>
          </div>
        </div>

        {/* Saluran */}
        <SectionCard title="Saluran Notifikasi" icon={Bell}>
          <NotifRow label="Notifikasi dalam Aplikasi" desc="Ditampilkan melalui ikon lonceng pada topbar."
            value={inApp} onChange={ch(setInApp)} />
          <NotifRow label="Notifikasi Browser" desc="Izin diberikan — notifikasi ditampilkan di luar tab."
            value={browser} onChange={ch(setBrowser)} />
          <NotifRow label="Email" desc="Dikirim ke salgadoginting@example.com"
            value={email} onChange={ch(setEmail)} />
        </SectionCard>

        {/* Jadwal & Mode Tenang */}
        <SectionCard title="Jadwal & Mode Tenang">
          <NotifRow label="Mode Tenang" desc="Notifikasi non-penting ditunda selama jam tenang. Peringatan keamanan tetap dikirim."
            value={modeTenang} onChange={ch(setModeTenang)}
            extra={modeTenang ? (
              <div className="flex items-center gap-3 flex-wrap">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">Mulai</span>
                  <input type="time" value={waktuMulai} onChange={e => { setWaktuMulai(e.target.value); mark(); }}
                    className="text-sm px-2 py-1 border border-gray-200 rounded-lg outline-none" />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">Selesai</span>
                  <input type="time" value={waktuSelesai} onChange={e => { setWaktuSelesai(e.target.value); mark(); }}
                    className="text-sm px-2 py-1 border border-gray-200 rounded-lg outline-none" />
                </div>
                <span className="text-xs text-gray-400">Setiap Hari</span>
              </div>
            ) : undefined}
          />
          <NotifRow label="Ringkasan Harian" desc={`Dikirim pukul ${wktRingkasan} setiap pagi.`}
            value={ringkasanHarian} onChange={ch(setRingkasanHarian)}
            extra={ringkasanHarian ? (
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">Waktu</span>
                <input type="time" value={wktRingkasan} onChange={e => { setWktRingkasan(e.target.value); mark(); }}
                  className="text-sm px-2 py-1 border border-gray-200 rounded-lg outline-none" />
              </div>
            ) : undefined}
          />
          <NotifRow label="Ringkasan Mingguan" desc="Dikirim setiap Senin pukul 08.00."
            value={ringkasanMinggu} onChange={ch(setRingkasanMinggu)} />
        </SectionCard>

        {/* Keuangan */}
        <SectionCard title="Keuangan">
          <NotifRow label="Budget Mendekati Batas" desc="Notifikasi saat pengeluaran mencapai 80% dari budget." value={budgetMendekati} onChange={ch(setBudgetMendekati)} />
          <NotifRow label="Budget Terlampaui" value={budgetLampaui} onChange={ch(setBudgetLampaui)} />
          <NotifRow label="Transaksi Berulang" desc="1 hari sebelumnya." value={transBerulang} onChange={ch(setTransBerulang)} />
          <NotifRow label="Jatuh Tempo Utang & Piutang" desc="3 hari sebelumnya." value={jatuhTempo} onChange={ch(setJatuhTempo)} />
          <NotifRow label="Target Keuangan" desc="Ringkasan mingguan." value={targetKeu} onChange={ch(setTargetKeu)} />
          <NotifRow label="Draft Jurnal AI Menunggu Review" value={draftAI} onChange={ch(setDraftAI)} />
          <NotifRow label="Laporan Keuangan Selesai Dibentuk" value={laporanSelesai} onChange={ch(setLaporanSelesai)} />
        </SectionCard>

        {/* Produktivitas */}
        <SectionCard title="Produktivitas">
          <NotifRow label="Aktivitas Mendatang" desc="Default: 1 hari sebelumnya." value={aktivitasMendatang} onChange={ch(setAktivitasMendatang)} />
          <NotifRow label="Deadline Aktivitas" desc="1 hari dan 1 jam sebelumnya." value={deadline} onChange={ch(setDeadline)} />
          <NotifRow label="Pengingat Jurnal Harian" desc={`Setiap hari pukul ${wktJurnal}.`} value={jurnalReminder} onChange={ch(setJurnalReminder)}
            extra={jurnalReminder ? (
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">Waktu</span>
                <input type="time" value={wktJurnal} onChange={e => { setWktJurnal(e.target.value); mark(); }}
                  className="text-sm px-2 py-1 border border-gray-200 rounded-lg outline-none" />
              </div>
            ) : undefined}
          />
          <NotifRow label="Pengingat Bacaan Alkitab" desc={`Setiap hari pukul ${wktBible}.`} value={bibleReminder} onChange={ch(setBibleReminder)}
            extra={bibleReminder ? (
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">Waktu</span>
                <input type="time" value={wktBible} onChange={e => { setWktBible(e.target.value); mark(); }}
                  className="text-sm px-2 py-1 border border-gray-200 rounded-lg outline-none" />
              </div>
            ) : undefined}
          />
          <NotifRow label="Target Membaca" desc="Pukul 19.00 jika target belum tercapai." value={targetBaca} onChange={ch(setTargetBaca)} />
          <NotifRow label="Target Langkah" desc="Pukul 19.00 jika target belum tercapai." value={targetLangkah} onChange={ch(setTargetLangkah)} />
        </SectionCard>

        {/* Library & Karier */}
        <SectionCard title="Library & Karier">
          <NotifRow label="Rencana Membaca" value={rencanaBaca} onChange={ch(setRencanaBaca)} />
          <NotifRow label="Buku Belum Dilanjutkan" desc="Setelah 7 hari tanpa aktivitas." value={bukuBelum} onChange={ch(setBukuBelum)} />
          <NotifRow label="Jadwal Latihan TOEFL" value={toeflJadwal} onChange={ch(setToeflJadwal)} />
          <NotifRow label="Jadwal Simulasi Interview" value={interview} onChange={ch(setInterview)} />
          <NotifRow label="Hasil Analisis ATS" value={ats} onChange={ch(setAts)} />
        </SectionCard>

        {/* Sistem & Keamanan */}
        <SectionCard title="Sistem & Keamanan" icon={Shield}>
          <NotifRow label="Login dari Perangkat Baru" desc="Tidak dapat dinonaktifkan sepenuhnya demi keamanan."
            value={perangkatBaru} onChange={ch(setPerangkatBaru)} locked />
          <NotifRow label="Percobaan Login Gagal" value={loginGagal} onChange={ch(setLoginGagal)} />
          <NotifRow label="Backup Berhasil" value={backupBerhasil} onChange={ch(setBackupBerhasil)} />
          <NotifRow label="Backup Gagal" value={backupGagal} onChange={ch(setBackupGagal)} />
          <NotifRow label="Restore Data Selesai" value={restoreSelesai} onChange={ch(setRestoreSelesai)} />
          <NotifRow label="Pembaruan FreeSpace" value={updateApp} onChange={ch(setUpdateApp)} />
        </SectionCard>

        <div className="pb-4" />
      </div>

      {showTest && <TestNotifModal onClose={() => setShowTest(false)} showToast={msg => showToast?.(msg)} />}
    </main>
  );
}
