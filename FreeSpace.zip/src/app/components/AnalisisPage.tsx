import React, { useState } from "react";
import { AlertCircle } from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid
} from "recharts";

const fmtRp = (n: number) => "Rp" + n.toLocaleString("id-ID");

// ── Data ───────────────────────────────────────────────────────────────────────
const MONTHLY_DATA = [
  { bln: "Feb", masuk: 6000000, keluar: 3500000 },
  { bln: "Mar", masuk: 6200000, keluar: 3400000 },
  { bln: "Apr", masuk: 5800000, keluar: 3600000 },
  { bln: "Mei", masuk: 6100000, keluar: 3200000 },
  { bln: "Jun", masuk: 6300000, keluar: 3380000 },
  { bln: "Jul", masuk: 6500000, keluar: 3150000 },
];

const PROJECTION_DATA = [
  { bln: "Jul", saldo: 4850000 },
  { bln: "Agu", saldo: 5150000 },
  { bln: "Sep", saldo: 5450000 },
  { bln: "Okt", saldo: 5750000 },
];

const DONUT_DATA = [
  { name: "Makanan",      value: 32, color: "#3B82F6" },
  { name: "Transportasi", value: 24, color: "#8B5CF6" },
  { name: "Pendidikan",   value: 18, color: "#22C55E" },
  { name: "Hiburan",      value: 14, color: "#F59E0B" },
  { name: "Lainnya",      value: 12, color: "#E5E7EB" },
];

const SCENARIO_PRESETS = [
  { id: "hemat",   label: "Hemat 10%",          desc: "Kurangi pengeluaran 10%" },
  { id: "tambah",  label: "Pendapatan Bertambah",desc: "Tambah pemasukan Rp1 jt" },
  { id: "cicilan", label: "Cicilan Baru",         desc: "Cicilan Rp500.000/bln"  },
  { id: "darurat", label: "Target Dana Darurat",  desc: "Tabung Rp400.000/bln"   },
];

// ── Helpers ────────────────────────────────────────────────────────────────────
function SummaryCard({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
      <p className="text-xs font-medium text-gray-500 mb-2">{label}</p>
      <p className="text-2xl font-bold text-gray-900 leading-tight">{value}</p>
      {sub && <p className="text-xs text-gray-400 mt-1">{sub}</p>}
    </div>
  );
}

function PeriodFilter() {
  const [active, setActive] = useState("6 Bulan");
  return (
    <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-lg">
      {["3 Bulan","6 Bulan","12 Bulan","Custom"].map(p => (
        <button key={p} onClick={() => setActive(p)}
          className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${active === p ? "bg-white shadow-sm text-gray-900" : "text-gray-500"}`}>
          {p}
        </button>
      ))}
    </div>
  );
}

// ── Tab: Analisis ──────────────────────────────────────────────────────────────
function TabAnalisis() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-4">
        <SummaryCard label="Rata-rata Pemasukan"  value="Rp6.150.000" sub="6 bulan terakhir" />
        <SummaryCard label="Rata-rata Pengeluaran" value="Rp3.320.000" sub="6 bulan terakhir" />
        <SummaryCard label="Rata-rata Tabungan"    value="Rp2.830.000" sub="6 bulan terakhir" />
        <SummaryCard label="Savings Rate"          value="46%"         sub="Di atas target 40%" />
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Line Chart */}
        <div className="col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-800 mb-4">Pemasukan vs Pengeluaran (6 Bulan)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={MONTHLY_DATA}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" />
              <XAxis dataKey="bln" tick={{ fontSize: 11, fill: "#6B7280" }} />
              <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickFormatter={v => `${v/1000000}jt`} />
              <Tooltip formatter={(v: number) => fmtRp(v)} />
              <Legend />
              <Line type="monotone" dataKey="masuk"  name="Pemasukan"  stroke="#22C55E" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="keluar" name="Pengeluaran" stroke="#EF4444" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Donut */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">Komposisi Pengeluaran</h3>
          <div className="relative w-full" style={{ height: 140 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={DONUT_DATA} cx="50%" cy="50%" innerRadius={40} outerRadius={60} dataKey="value" stroke="none">
                  {DONUT_DATA.map((d, i) => <Cell key={i} fill={d.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 space-y-1.5">
            {DONUT_DATA.map(d => (
              <div key={d.name} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: d.color }} />
                <span className="text-xs text-gray-600 flex-1">{d.name}</span>
                <span className="text-xs font-semibold">{d.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Insight */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <h3 className="text-sm font-semibold text-gray-800 mb-3">Insight Pola Keuangan</h3>
        <div className="space-y-2">
          {[
            { text: "Pengeluaran tertinggi terjadi pada kategori Makanan.", color: "bg-blue-500" },
            { text: "Pengeluaran Hiburan meningkat dibanding bulan sebelumnya.", color: "bg-amber-500" },
            { text: "Savings rate masih berada di atas target 40%.", color: "bg-green-500" },
            { text: "Pengeluaran rutin mencakup 28% dari total pengeluaran.", color: "bg-blue-500" },
            { text: "Arus kas tetap positif selama tiga bulan terakhir.", color: "bg-green-500" },
          ].map((item, i) => (
            <div key={i} className="flex items-start gap-2.5">
              <div className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${item.color}`} />
              <p className="text-sm text-gray-700">{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Tab: Proyeksi ──────────────────────────────────────────────────────────────
function TabProyeksi() {
  return (
    <div className="space-y-4">
      <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl flex items-start gap-2">
        <AlertCircle size={14} className="text-blue-600 mt-0.5 shrink-0" />
        <p className="text-xs text-blue-700">Hasil proyeksi merupakan estimasi dan dapat berubah berdasarkan transaksi aktual. Proyeksi berdasarkan pola transaksi enam bulan terakhir.</p>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <SummaryCard label="Proyeksi Saldo Akhir Bulan" value="Rp5.250.000"  />
        <SummaryCard label="Estimasi Pengeluaran"       value="Rp3.450.000"  />
        <SummaryCard label="Estimasi Tabungan"          value="Rp3.050.000"  />
        <SummaryCard label="Proyeksi Savings Rate"      value="46,9%"        />
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <h3 className="text-sm font-semibold text-gray-800 mb-4">Proyeksi Saldo 3 Bulan</h3>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={PROJECTION_DATA}>
            <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" />
            <XAxis dataKey="bln" tick={{ fontSize: 11, fill: "#6B7280" }} />
            <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickFormatter={v => `${v/1000000}jt`} />
            <Tooltip formatter={(v: number) => fmtRp(v)} />
            <Line type="monotone" dataKey="saldo" name="Proyeksi Saldo" stroke="#3B82F6" strokeWidth={2} strokeDasharray="5 5" dot={true} />
          </LineChart>
        </ResponsiveContainer>
        <p className="text-[10px] text-gray-400 mt-2">Proyeksi berdasarkan pola transaksi 6 bulan terakhir.</p>
      </div>
    </div>
  );
}

// ── Tab: Skenario ──────────────────────────────────────────────────────────────
function TabSkenario() {
  const [selectedPreset, setSelectedPreset] = useState("hemat");
  const [pendapatan, setPendapatan] = useState("0");
  const [penghematan, setPenghematan] = useState("10");
  const [cicilan, setCicilan] = useState("0");
  const [tabungan, setTabungan] = useState("400000");

  const penghematanVal = parseFloat(penghematan) / 100;
  const pendapatanVal = parseInt(pendapatan.replace(/\D/g, "")) || 0;
  const cicilanVal = parseInt(cicilan.replace(/\D/g, "")) || 0;
  const tabunganVal = parseInt(tabungan.replace(/\D/g, "")) || 0;

  const baselineKeluar = 3150000;
  const baselineMasuk = 6500000;
  const newKeluar = baselineKeluar * (1 - penghematanVal) + cicilanVal + tabunganVal;
  const newMasuk = baselineMasuk + pendapatanVal;
  const newSaldo = newMasuk - newKeluar;
  const newSavings = newMasuk > 0 ? ((newMasuk - newKeluar) / newMasuk * 100).toFixed(1) : "0";

  const COMPARE = [
    { name: "Baseline", Pemasukan: 6.5, Pengeluaran: 3.15, Saldo: 3.35 },
    { name: "Skenario", Pemasukan: newMasuk/1000000, Pengeluaran: newKeluar/1000000, Saldo: newSaldo/1000000 },
  ];

  return (
    <div className="grid grid-cols-2 gap-4">
      {/* Builder */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 space-y-4">
        <h3 className="text-sm font-semibold text-gray-800">Scenario Builder</h3>

        <div className="flex flex-wrap gap-2">
          {SCENARIO_PRESETS.map(p => (
            <button key={p.id} onClick={() => {
              setSelectedPreset(p.id);
              if (p.id === "hemat")   { setPenghematan("10"); setPendapatan("0"); setCicilan("0"); }
              if (p.id === "tambah")  { setPendapatan("1000000"); setPenghematan("0"); }
              if (p.id === "cicilan") { setCicilan("500000"); }
              if (p.id === "darurat") { setTabungan("400000"); }
            }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                selectedPreset === p.id ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
              }`}>
              {p.label}
            </button>
          ))}
        </div>

        <div className="space-y-3">
          {[
            { label: "Perubahan Pendapatan (Rp)", val: pendapatan, set: setPendapatan, ph: "Contoh: 1000000" },
            { label: "Pengurangan Pengeluaran (%)", val: penghematan, set: setPenghematan, ph: "Contoh: 10" },
            { label: "Cicilan Baru (Rp/bln)", val: cicilan, set: setCicilan, ph: "Contoh: 500000" },
            { label: "Target Tabungan (Rp/bln)", val: tabungan, set: setTabungan, ph: "Contoh: 400000" },
          ].map(f => (
            <div key={f.label}>
              <label className="block text-xs font-medium text-gray-700 mb-1">{f.label}</label>
              <input value={f.val} onChange={e => f.set(e.target.value)} placeholder={f.ph}
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900" />
            </div>
          ))}
        </div>
      </div>

      {/* Result */}
      <div className="space-y-4">
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">Hasil Skenario</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Saldo Akhir",     value: `Rp${newSaldo.toLocaleString("id-ID")}` },
              { label: "Total Tabungan",  value: `Rp${tabunganVal.toLocaleString("id-ID")}` },
              { label: "Savings Rate",    value: `${newSavings}%` },
              { label: "Dampak Cash Flow",value: newSaldo > 3350000 ? "Positif ↑" : "Menurun ↓" },
            ].map(c => (
              <div key={c.label} className="bg-gray-50 rounded-lg p-3">
                <p className="text-[11px] text-gray-500">{c.label}</p>
                <p className="text-base font-bold text-gray-900 mt-0.5">{c.value}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">Baseline vs Skenario</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={COMPARE} barGap={4}>
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#6B7280" }} />
              <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickFormatter={v => `${v}jt`} />
              <Tooltip formatter={(v: number) => `Rp${v.toFixed(2)}jt`} />
              <Legend />
              <Bar dataKey="Pemasukan"   fill="#22C55E" radius={[4,4,0,0]} />
              <Bar dataKey="Pengeluaran" fill="#EF4444" radius={[4,4,0,0]} />
              <Bar dataKey="Saldo"       fill="#3B82F6" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export function AnalisisPage({ topBar }: { topBar: React.ReactNode }) {
  const [activeTab, setActiveTab] = useState("analisis");

  const TABS = [
    { id: "analisis", label: "Analisis"   },
    { id: "proyeksi", label: "Proyeksi"   },
    { id: "skenario", label: "Skenario"   },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Analisis & Proyeksi</h1>
            <p className="text-sm text-gray-500 mt-1">Pahami pola keuangan dan proyeksikan kondisi keuangan ke depan.</p>
          </div>
          <PeriodFilter />
        </div>

        <div className="flex items-center gap-0 border-b border-gray-200">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                activeTab === t.id ? "border-gray-900 text-gray-900" : "border-transparent text-gray-500 hover:text-gray-700"
              }`}>{t.label}</button>
          ))}
        </div>

        {activeTab === "analisis" && <TabAnalisis />}
        {activeTab === "proyeksi" && <TabProyeksi />}
        {activeTab === "skenario" && <TabSkenario />}
      </div>
    </main>
  );
}
