import React, { useState, useMemo, useRef } from "react";
import { useDataStore, type Asset } from "./DataStore";
import { BarcodeScanner, type BarcodeScanResult } from "./BarcodeScanner";
import { exportToExcel, importFromExcel } from "./excelUtils";
import {
  ClipboardList, Search, Download, Plus, X, ChevronDown, Clock,
  CheckCircle2, AlertTriangle, Check, Cpu, Car, Layers,
  BarChart2, RefreshCw, ShieldCheck, AlertCircle,
  ChevronRight, Printer, PenLine, Building, MapPin, User,
  FileText, Equal, TrendingUp, TrendingDown, QrCode,
  Camera, Package, Hash, Calendar,
  DollarSign, BookOpen, Target, Crosshair, Ban,
  Upload, Info,
} from "lucide-react";

// ── Types ──────────────────────────────────────────────────────────────────────
type StokKategori      = "PM" | "ATL" | "AL";
type StatusSesi        = "Draft" | "Berlangsung" | "Selesai" | "Diverifikasi";
type StatusOpname      = "Terverifikasi" | "Belum Dicek" | "Selisih" | "Tidak Ditemukan" | "Tidak Ada Lokasi Jelas";
type KondisiFisikOpname = "Baik" | "Rusak Ringan" | "Rusak Berat" | "Tidak Ditemukan";
type StatusLokasiOpname = "Sesuai" | "Berbeda" | "Tidak Diketahui";
type StatusKejelasan   = "Jelas" | "Tidak Jelas";

interface OpnameItem {
  kodeAset: string;
  kodeTagAset: string;
  namaAset: string;
  merkTipe: string;
  spesifikasi: string;
  kategori: StokKategori;
  tipeAset: string;
  gedung: string;
  ruangan: string;
  unit: string;
  pic: string;
  tahunPerolehan: number;
  sumberDana: string;
  kondisiAset: string;
  nilaiPerolehan: number;
  nilaiBuku: number;
  masaManfaat: number;
  // Opname result (from source data fields)
  statusOpname: StatusOpname;
  kondisiFisikOpname: KondisiFisikOpname | null;
  statusLokasiOpname: StatusLokasiOpname | null;
  diverifikasiOleh: string | null;
  tanggalVerifikasi: string | null;
  catatanOpname: string;
  statusKejelasanLokasi: StatusKejelasan;
  lokasiDitemukan: string | null;
}

interface StokSesi {
  id: string;
  nama: string;
  periode: string;
  gedung: string;
  status: StatusSesi;
  tglMulai: string;
  tglSelesai: string | null;
  tglVerifikasi: string | null;
  petugas: string[];
  verifikator: string | null;
  catatan: string;
  pengaju: string;
  items: OpnameItem[];
}

// ── Constants ─────────────────────────────────────────────────────────────────
const GEDUNG_LIST = ["Semua Kampus", "Kampus Cilibende", "Kampus Gunung Gede", "Kampus Baranangsiang", "Kampus Sukabumi"];
const UNIT_LIST = ["Direktorat TI", "Direktorat Sarana", "Dept. IKK", "Dept. Fisika", "BAUK", "Perpustakaan"];
const SUMBER_DANA_LIST = ["DIPA", "BLU", "PNBP", "Hibah", "Swadana"];

function fmtRupiah(v: number) {
  if (v >= 1_000_000_000) return `Rp ${(v / 1_000_000_000).toFixed(2)} M`;
  if (v >= 1_000_000)     return `Rp ${(v / 1_000_000).toFixed(1)} jt`;
  return "Rp " + new Intl.NumberFormat("id-ID").format(v);
}

// ── Asset → OpnameItem conversion ─────────────────────────────────────────────
function assetToOpnameItem(a: Asset): OpnameItem {
  const kat: StokKategori = (["PM","ATL","AL"] as string[]).includes(a.TipeAset ?? "") ? a.TipeAset as StokKategori : "PM";
  return {
    kodeAset:            a.id,
    kodeTagAset:         a.kode_tag_aset || a.id,
    namaAset:            a.Nama_Barang || a.id,
    merkTipe:            a.MerkType || "-",
    spesifikasi:         a.Spesifikasi || "-",
    kategori:            kat,
    tipeAset:            a.TipeAset || "-",
    gedung:              a.nama_gedung || "-",
    ruangan:             a.Nama_ruangan || a.nama_ruangan_standar || "-",
    unit:                a.Nama_unit || "-",
    pic:                 a.nama_pic || "-",
    tahunPerolehan:      parseInt(a.TahunBuku ?? "") || 2023,
    sumberDana:          a.SumberDana || "-",
    kondisiAset:         a.Kondisi || "Baik",
    nilaiPerolehan:      parseInt(a._harga_perolehan ?? "") || 0,
    nilaiBuku:           parseInt(a._nilai_buku ?? "") || 0,
    masaManfaat:         parseInt(a.Masa_manfaat ?? "") || 4,
    statusOpname:        "Belum Dicek",
    kondisiFisikOpname:  null,
    statusLokasiOpname:  null,
    diverifikasiOleh:    null,
    tanggalVerifikasi:   null,
    catatanOpname:       "",
    statusKejelasanLokasi: "Jelas",
    lokasiDitemukan:     null,
  };
}

function makeBlankItems(items: OpnameItem[]): OpnameItem[] {
  return items.map(i => ({
    ...i,
    statusOpname: "Belum Dicek",
    kondisiFisikOpname: null,
    statusLokasiOpname: null,
    diverifikasiOleh: null,
    tanggalVerifikasi: null,
    catatanOpname: "",
    statusKejelasanLokasi: "Jelas" as StatusKejelasan,
    lokasiDitemukan: null,
  }));
}

function mapOpnameStatus(raw: string | undefined): StatusOpname {
  if (raw === "Tidak Ditemukan" || raw === "Hilang") return "Tidak Ditemukan";
  if (raw === "Selisih") return "Selisih";
  if (raw === "Perlu Verifikasi" || raw === "Belum Dicek" || !raw) return "Belum Dicek";
  return "Terverifikasi";
}

function mapKondisiFisik(raw: string | undefined): KondisiFisikOpname | null {
  if (!raw || raw === "-") return null;
  if (raw === "Rusak Ringan") return "Rusak Ringan";
  if (raw === "Rusak Berat") return "Rusak Berat";
  if (raw === "Tidak Ditemukan") return "Tidak Ditemukan";
  return "Baik";
}

function mapLokasiOpname(raw: string | undefined): StatusLokasiOpname | null {
  if (!raw || raw === "-") return null;
  if (raw === "Tidak Sesuai" || raw === "Berbeda") return "Berbeda";
  if (raw === "Tidak Diketahui") return "Tidak Diketahui";
  return "Sesuai";
}

function periodeFromTanggal(t: string): string {
  const monthNames = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
  const d = new Date(t);
  if (isNaN(d.getTime())) return t;
  return `${monthNames[d.getMonth()]} ${d.getFullYear()}`;
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function KategoriBadge({ k }: { k: StokKategori }) {
  const cfg = {
    PM:  { bg: "bg-purple-50", text: "text-purple-700", icon: <Cpu size={10} /> },
    ATL: { bg: "bg-teal-50",   text: "text-teal-700",   icon: <Layers size={10} /> },
    AL:  { bg: "bg-indigo-50", text: "text-indigo-700", icon: <Car size={10} /> },
  }[k];
  return <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold ${cfg.bg} ${cfg.text}`}>{cfg.icon} {k}</span>;
}

function StatusOpnameBadge({ status }: { status: StatusOpname }) {
  const cfg: Record<StatusOpname, { bg: string; text: string; border: string }> = {
    "Terverifikasi":        { bg: "bg-green-50",  text: "text-green-700",  border: "border-green-200"  },
    "Belum Dicek":          { bg: "bg-gray-100",  text: "text-gray-500",   border: "border-gray-200"   },
    "Selisih":              { bg: "bg-blue-50",   text: "text-blue-700",   border: "border-blue-200"   },
    "Tidak Ditemukan":      { bg: "bg-red-50",    text: "text-red-700",    border: "border-red-200"    },
    "Tidak Ada Lokasi Jelas":{ bg: "bg-orange-50", text: "text-orange-700", border: "border-orange-200" },
  };
  const c = cfg[status];
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold border ${c.bg} ${c.text} ${c.border}`}>
      {status === "Terverifikasi"         && <CheckCircle2 size={10} />}
      {status === "Belum Dicek"           && <Clock size={10} />}
      {status === "Selisih"              && <TrendingDown size={10} />}
      {status === "Tidak Ditemukan"      && <Ban size={10} />}
      {status === "Tidak Ada Lokasi Jelas" && <AlertTriangle size={10} />}
      {status}
    </span>
  );
}

function KondisiFisikBadge({ kondisi }: { kondisi: KondisiFisikOpname }) {
  const cfg: Record<KondisiFisikOpname, string> = {
    "Baik":            "bg-green-50 text-green-700",
    "Rusak Ringan":    "bg-yellow-50 text-yellow-700",
    "Rusak Berat":     "bg-orange-50 text-orange-700",
    "Tidak Ditemukan": "bg-red-50 text-red-700",
  };
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium ${cfg[kondisi]}`}>{kondisi}</span>;
}

function StatusLokasiOpnameBadge({ status }: { status: StatusLokasiOpname }) {
  const cfg: Record<StatusLokasiOpname, string> = {
    "Sesuai":       "bg-green-50 text-green-700",
    "Berbeda":      "bg-blue-50 text-blue-700",
    "Tidak Diketahui": "bg-gray-100 text-gray-500",
  };
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium ${cfg[status]}`}>{status}</span>;
}

function StatusSesiBadge({ status }: { status: StatusSesi }) {
  const cfg = {
    Draft:        { bg: "bg-gray-100",   text: "text-gray-600",   border: "border-gray-200",   icon: <PenLine size={11} /> },
    Berlangsung:  { bg: "bg-blue-50",    text: "text-blue-700",   border: "border-blue-200",   icon: <RefreshCw size={11} /> },
    Selesai:      { bg: "bg-yellow-50",  text: "text-yellow-700", border: "border-yellow-200", icon: <Clock size={11} /> },
    Diverifikasi: { bg: "bg-green-50",   text: "text-green-700",  border: "border-green-200",  icon: <ShieldCheck size={11} /> },
  }[status];
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold border ${cfg.bg} ${cfg.text} ${cfg.border}`}>
      {cfg.icon} {status}
    </span>
  );
}

function deriveStatusOpname(kondisi: KondisiFisikOpname | "", lokasi: StatusLokasiOpname | ""): StatusOpname | null {
  if (!kondisi) return null;
  if (kondisi === "Tidak Ditemukan") return "Tidak Ditemukan";
  if (!lokasi) return null;
  if (lokasi === "Berbeda") return "Selisih";
  if (lokasi === "Tidak Diketahui") return "Tidak Ada Lokasi Jelas";
  return "Terverifikasi";
}

// ── Verifikasi Modal ──────────────────────────────────────────────────────────
function VerifikasiModal({ item, onClose, onSave }: {
  item: OpnameItem;
  onClose: () => void;
  onSave: (updates: Partial<OpnameItem>) => void;
}) {
  const [kondisi, setKondisi]     = useState<KondisiFisikOpname | "">(item.kondisiFisikOpname ?? "");
  const [lokasi, setLokasi]       = useState<StatusLokasiOpname | "">(item.statusLokasiOpname ?? "");
  const [lokasiDitemukan, setLokasiDitemukan] = useState(item.lokasiDitemukan ?? "");
  const [catatan, setCatatan]     = useState(item.catatanOpname);
  const [tidakJelas, setTidakJelas] = useState(item.statusKejelasanLokasi === "Tidak Jelas");

  const derivedStatus = deriveStatusOpname(kondisi, lokasi);
  const canSave = kondisi !== "" && lokasi !== "";

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-gray-900/50 backdrop-blur-sm">
      <div className="bg-white rounded-[12px] shadow-2xl w-full max-w-md overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-gray-900">Verifikasi Aset</h3>
            <p className="text-xs text-gray-400 mt-0.5">{item.kodeAset} · {item.namaAset}</p>
          </div>
          <button onClick={onClose} className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-md transition-colors"><X size={16} /></button>
        </div>

        <div className="p-5 space-y-4">
          {/* Asset info */}
          <div className="flex items-center gap-3 bg-gray-50 rounded-lg p-3">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${item.kategori === "PM" ? "bg-purple-100" : item.kategori === "ATL" ? "bg-teal-100" : "bg-indigo-100"}`}>
              {item.kategori === "PM"  && <Cpu size={15} className="text-purple-700" />}
              {item.kategori === "ATL" && <Layers size={15} className="text-teal-700" />}
              {item.kategori === "AL"  && <Car size={15} className="text-indigo-700" />}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-gray-900 truncate">{item.namaAset}</p>
              <p className="text-xs text-gray-500">{item.merkTipe} · {item.ruangan}</p>
            </div>
            <span className="text-[11px] font-mono text-gray-400 shrink-0">{item.kodeTagAset}</span>
          </div>

          {/* Kondisi Fisik */}
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-2">Kondisi Fisik <span className="text-red-500">*</span></label>
            <div className="grid grid-cols-2 gap-2">
              {(["Baik", "Rusak Ringan", "Rusak Berat", "Tidak Ditemukan"] as KondisiFisikOpname[]).map(k => (
                <button
                  key={k}
                  onClick={() => {
                    setKondisi(k);
                    if (k === "Tidak Ditemukan") { setLokasi("Tidak Diketahui"); setTidakJelas(true); }
                  }}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-semibold transition-all text-left ${kondisi === k ? "border-[#111827] bg-gray-50 shadow-sm" : "border-gray-200 text-gray-600 hover:border-gray-300"}`}
                >
                  <div className={`w-3 h-3 rounded-full border-2 flex-shrink-0 ${kondisi === k ? "border-[#111827] bg-[#111827]" : "border-gray-300"}`} />
                  {k}
                </button>
              ))}
            </div>
          </div>

          {/* Status Lokasi */}
          {kondisi !== "Tidak Ditemukan" && (
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-2">Status Lokasi <span className="text-red-500">*</span></label>
              <div className="space-y-1.5">
                {(["Sesuai", "Berbeda", "Tidak Diketahui"] as StatusLokasiOpname[]).map(l => (
                  <button
                    key={l}
                    onClick={() => setLokasi(l)}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-semibold transition-all text-left ${lokasi === l ? "border-[#111827] bg-gray-50" : "border-gray-200 text-gray-600 hover:border-gray-300"}`}
                  >
                    <div className={`w-3.5 h-3.5 rounded-full border-2 flex-shrink-0 flex items-center justify-center ${lokasi === l ? "border-[#111827]" : "border-gray-300"}`}>
                      {lokasi === l && <div className="w-1.5 h-1.5 rounded-full bg-[#111827]" />}
                    </div>
                    {l}
                    {l === "Berbeda" && <span className="ml-auto text-[10px] font-normal text-gray-400">Isi lokasi ditemukan di bawah</span>}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Lokasi Ditemukan */}
          {lokasi === "Berbeda" && (
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1.5">Lokasi Ditemukan</label>
              <input
                value={lokasiDitemukan}
                onChange={e => setLokasiDitemukan(e.target.value)}
                placeholder="Ruangan/gedung tempat aset ditemukan..."
                className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400"
              />
            </div>
          )}

          {/* Derived status */}
          {derivedStatus && (
            <div className="flex items-center justify-between p-3 bg-gray-50 border border-gray-200 rounded-lg">
              <span className="text-xs font-semibold text-gray-600">Status Opname:</span>
              <StatusOpnameBadge status={derivedStatus} />
            </div>
          )}

          {/* Tidak ada lokasi jelas toggle */}
          <div
            onClick={() => setTidakJelas(p => !p)}
            className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${tidakJelas ? "border-orange-300 bg-orange-50" : "border-gray-200 hover:bg-gray-50"}`}
          >
            <div className={`w-4 h-4 rounded border-2 flex items-center justify-center shrink-0 transition-colors ${tidakJelas ? "bg-orange-500 border-orange-500" : "border-gray-300"}`}>
              {tidakJelas && <Check size={10} className="text-white" />}
            </div>
            <span className="text-xs font-medium text-gray-700">Tandai sebagai Aset Tanpa Lokasi Jelas</span>
          </div>

          {/* Catatan */}
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1.5">Catatan Verifikasi</label>
            <textarea
              rows={2} value={catatan} onChange={e => setCatatan(e.target.value)}
              placeholder="Keterangan tambahan hasil verifikasi fisik..."
              className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400 resize-none"
            />
          </div>
        </div>

        <div className="px-5 py-4 border-t border-gray-100 flex gap-2">
          <button onClick={onClose} className="flex-1 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <button
            disabled={!canSave}
            onClick={() => {
              if (!canSave || !kondisi || !lokasi) return;
              const finalStatus: StatusOpname = tidakJelas && kondisi !== "Tidak Ditemukan"
                ? "Tidak Ada Lokasi Jelas"
                : derivedStatus ?? "Belum Dicek";
              onSave({
                statusOpname: finalStatus,
                kondisiFisikOpname: kondisi,
                statusLokasiOpname: lokasi,
                lokasiDitemukan: lokasi === "Berbeda" ? lokasiDitemukan || null : null,
                catatanOpname: catatan,
                statusKejelasanLokasi: tidakJelas ? "Tidak Jelas" : "Jelas",
              });
              onClose();
            }}
            className={`flex-1 py-2 text-sm font-semibold text-white rounded-lg transition-colors ${canSave ? "bg-[#111827] hover:bg-gray-800" : "bg-gray-300 cursor-not-allowed"}`}
          >
            Simpan Verifikasi
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Lembar Kerja Content ──────────────────────────────────────────────────────
function LembarKerjaContent({ items, sesiStatus, onVerifikasi }: {
  items: OpnameItem[];
  sesiStatus: StatusSesi;
  onVerifikasi: (kodeAset: string, updates: Partial<OpnameItem>) => void;
}) {
  const [filterUnit, setFilterUnit]       = useState("");
  const [filterKat, setFilterKat]         = useState<StokKategori | "">("");
  const [filterStatus, setFilterStatus]   = useState<StatusOpname | "">("");
  const [filterKondisi, setFilterKondisi] = useState<KondisiFisikOpname | "">("");
  const [filterGedung, setFilterGedung]   = useState("");
  const [filterPic, setFilterPic]         = useState("");
  const [searchQ, setSearchQ]             = useState("");
  const [verifyingItem, setVerifyingItem] = useState<OpnameItem | null>(null);
  const importRef = useRef<HTMLInputElement>(null);

  const handleExportExcel = () => {
    exportToExcel(
      filtered.map(i => ({
        "Kode Aset": i.kodeAset,
        "Kode Tag": i.kodeTagAset,
        "Nama Aset": i.namaAset,
        "Merk/Tipe": i.merkTipe,
        "Spesifikasi": i.spesifikasi,
        "Kategori": i.kategori,
        "Gedung": i.gedung,
        "Ruangan": i.ruangan,
        "PIC": i.pic,
        "Tahun Perolehan": i.tahunPerolehan,
        "Sumber Dana": i.sumberDana,
        "Kondisi": i.kondisiAset,
        "Nilai Perolehan": i.nilaiPerolehan,
        "Nilai Buku": i.nilaiBuku,
        "Masa Manfaat": i.masaManfaat,
        "Status Opname": i.statusOpname,
        "Kondisi Fisik": i.kondisiFisikOpname ?? "",
        "Status Lokasi": i.statusLokasiOpname ?? "",
        "Diverifikasi Oleh": i.diverifikasiOleh ?? "",
        "Tgl Verifikasi": i.tanggalVerifikasi ?? "",
      })),
      `opname-lembar-${new Date().toISOString().slice(0,10)}`,
      "Opname",
    );
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const rows = await importFromExcel(file);
      rows.forEach(row => {
        const kode = String(row["Kode Aset"] || row["kodeAset"] || "");
        if (!kode) return;
        const updates: Partial<OpnameItem> = {};
        if (row["Status Opname"]) updates.statusOpname = row["Status Opname"] as StatusOpname;
        if (row["Kondisi Fisik"]) updates.kondisiFisikOpname = row["Kondisi Fisik"] as KondisiFisikOpname;
        if (row["Catatan"]) updates.catatanOpname = String(row["Catatan"]);
        if (Object.keys(updates).length > 0) onVerifikasi(kode, updates);
      });
    } catch { /* ignore parse errors */ }
    e.target.value = "";
  };

  // KPIs
  const kpi = useMemo(() => ({
    total:         items.length,
    terverifikasi: items.filter(i => i.statusOpname === "Terverifikasi").length,
    belumDicek:    items.filter(i => i.statusOpname === "Belum Dicek").length,
    selisih:       items.filter(i => i.statusOpname === "Selisih").length,
    tidakDitemukan:items.filter(i => i.statusOpname === "Tidak Ditemukan").length,
    tanpaLokasi:   items.filter(i => i.statusKejelasanLokasi === "Tidak Jelas").length,
  }), [items]);

  // Progress org
  const pctOrg = kpi.total ? Math.round(kpi.terverifikasi / kpi.total * 100) : 0;

  // Progress per unit
  const unitProgress = useMemo(() => {
    return UNIT_LIST.map(unit => {
      const unitItems = items.filter(i => i.unit === unit);
      if (unitItems.length === 0) return null;
      const verified = unitItems.filter(i => i.statusOpname === "Terverifikasi").length;
      const pct = Math.round(verified / unitItems.length * 100);
      return { unit, total: unitItems.length, verified, pct };
    }).filter(Boolean) as { unit: string; total: number; verified: number; pct: number }[];
  }, [items]);

  // Unique filter values
  const gedungOpts = [...new Set(items.map(i => i.gedung))];
  const picOpts    = [...new Set(items.map(i => i.pic))];

  // Filtered items
  const filtered = useMemo(() => {
    const q = searchQ.toLowerCase();
    return items.filter(i => {
      if (filterUnit   && i.unit !== filterUnit) return false;
      if (filterKat    && i.kategori !== filterKat) return false;
      if (filterStatus && i.statusOpname !== filterStatus) return false;
      if (filterKondisi && i.kondisiFisikOpname !== filterKondisi) return false;
      if (filterGedung && i.gedung !== filterGedung) return false;
      if (filterPic    && i.pic !== filterPic) return false;
      if (q && !i.namaAset.toLowerCase().includes(q) && !i.kodeAset.toLowerCase().includes(q)
             && !i.kodeTagAset.toLowerCase().includes(q) && !i.merkTipe.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [items, filterUnit, filterKat, filterStatus, filterKondisi, filterGedung, filterPic, searchQ]);

  const canVerify = sesiStatus === "Berlangsung";

  return (
    <div className="flex-1 overflow-y-auto">
      {/* KPI Row */}
      <div className="px-6 py-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: "Total Aset Target",      value: kpi.total,          icon: <Target size={16} />,        bg: "bg-gray-50",    color: "#111827",  text: "text-gray-800" },
          { label: "Terverifikasi",           value: kpi.terverifikasi,  icon: <CheckCircle2 size={16} />,  bg: "bg-green-50",   color: "#15803D",  text: "text-green-700" },
          { label: "Belum Dicek",             value: kpi.belumDicek,     icon: <Clock size={16} />,         bg: "bg-gray-100",   color: "#4B5563",  text: "text-gray-600" },
          { label: "Selisih",                 value: kpi.selisih,        icon: <TrendingDown size={16} />,  bg: "bg-blue-50",    color: "#1D4ED8",  text: "text-blue-700" },
          { label: "Tidak Ditemukan",         value: kpi.tidakDitemukan, icon: <Ban size={16} />,           bg: "bg-red-50",     color: "#B91C1C",  text: "text-red-700" },
          { label: "Tanpa Lokasi Jelas",      value: kpi.tanpaLokasi,    icon: <AlertTriangle size={16} />, bg: "bg-orange-50",  color: "#C2410C",  text: "text-orange-700" },
        ].map(s => (
          <div key={s.label} className="bg-white border border-gray-200 rounded-xl p-3 shadow-sm">
            <div className={`w-8 h-8 rounded-lg ${s.bg} flex items-center justify-center mb-2`} style={{ color: s.color }}>
              {s.icon}
            </div>
            <p className={`text-xl font-bold ${s.text}`}>{s.value}</p>
            <p className="text-[10px] text-gray-500 leading-tight mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Progress Section */}
      <div className="px-6 pb-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Org progress */}
        <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-semibold text-gray-700">Progress Opname Organisasi</p>
            <span className="text-xs font-bold text-gray-900">{pctOrg}%</span>
          </div>
          <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden mb-2">
            <div className={`h-full rounded-full transition-all ${pctOrg === 100 ? "bg-green-500" : "bg-[#111827]"}`} style={{ width: `${pctOrg}%` }} />
          </div>
          <p className="text-[10px] text-gray-400">{kpi.terverifikasi} dari {kpi.total} aset terverifikasi</p>
        </div>

        {/* Per-unit progress */}
        <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm">
          <p className="text-xs font-semibold text-gray-700 mb-3">Progress per Unit</p>
          <div className="space-y-2">
            {unitProgress.map(u => (
              <div key={u.unit}>
                <div className="flex items-center justify-between text-[10px] mb-0.5">
                  <span className="text-gray-600 font-medium truncate max-w-[120px]">{u.unit}</span>
                  <span className="text-gray-400 ml-2 shrink-0">{u.verified}/{u.total} · {u.pct}%</span>
                </div>
                <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${u.pct === 100 ? "bg-green-500" : "bg-[#111827]"}`} style={{ width: `${u.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="px-6 pb-3">
        <div className="bg-white border border-gray-200 rounded-xl p-3 shadow-sm flex flex-wrap gap-2 items-center">
          <div className="relative min-w-[180px]">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              value={searchQ} onChange={e => setSearchQ(e.target.value)}
              placeholder="Cari kode, nama aset..."
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400"
            />
          </div>
          {[
            { label: "Unit", value: filterUnit, onChange: setFilterUnit, opts: UNIT_LIST },
            { label: "Lokasi", value: filterGedung, onChange: setFilterGedung, opts: gedungOpts },
          ].map(f => (
            <div key={f.label} className="relative">
              <select
                value={f.value} onChange={e => f.onChange(e.target.value)}
                className="text-xs border border-gray-200 rounded-lg pl-3 pr-7 py-1.5 bg-white outline-none appearance-none cursor-pointer text-gray-600 focus:ring-1 focus:ring-gray-400"
              >
                <option value="">Semua {f.label}</option>
                {f.opts.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
              <ChevronDown size={11} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            </div>
          ))}
          <div className="relative">
            <select
              value={filterKat} onChange={e => setFilterKat(e.target.value as StokKategori | "")}
              className="text-xs border border-gray-200 rounded-lg pl-3 pr-7 py-1.5 bg-white outline-none appearance-none cursor-pointer text-gray-600"
            >
              <option value="">Semua Kategori</option>
              {(["PM","ATL","AL"] as StokKategori[]).map(k => <option key={k} value={k}>{k}</option>)}
            </select>
            <ChevronDown size={11} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
          </div>
          <div className="relative">
            <select
              value={filterStatus} onChange={e => setFilterStatus(e.target.value as StatusOpname | "")}
              className="text-xs border border-gray-200 rounded-lg pl-3 pr-7 py-1.5 bg-white outline-none appearance-none cursor-pointer text-gray-600"
            >
              <option value="">Semua Status</option>
              {(["Terverifikasi","Belum Dicek","Selisih","Tidak Ditemukan","Tidak Ada Lokasi Jelas"] as StatusOpname[]).map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <ChevronDown size={11} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
          </div>
          <div className="relative">
            <select
              value={filterKondisi} onChange={e => setFilterKondisi(e.target.value as KondisiFisikOpname | "")}
              className="text-xs border border-gray-200 rounded-lg pl-3 pr-7 py-1.5 bg-white outline-none appearance-none cursor-pointer text-gray-600"
            >
              <option value="">Semua Kondisi Fisik</option>
              {(["Baik","Rusak Ringan","Rusak Berat","Tidak Ditemukan"] as KondisiFisikOpname[]).map(k => (
                <option key={k} value={k}>{k}</option>
              ))}
            </select>
            <ChevronDown size={11} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
          </div>
          <div className="relative">
            <select
              value={filterPic} onChange={e => setFilterPic(e.target.value)}
              className="text-xs border border-gray-200 rounded-lg pl-3 pr-7 py-1.5 bg-white outline-none appearance-none cursor-pointer text-gray-600"
            >
              <option value="">Semua PIC</option>
              {picOpts.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
            <ChevronDown size={11} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
          </div>
          <p className="text-[10px] text-gray-400 ml-auto">{filtered.length} aset</p>
          <button onClick={handleExportExcel} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Download size={12} /> Export Excel
          </button>
          <button onClick={() => importRef.current?.click()} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Upload size={12} /> Import
          </button>
          <input ref={importRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={handleImport} />
          <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#111827] rounded-lg hover:bg-gray-800 transition-colors">
            <Plus size={12} /> Tambah Data
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="px-6 pb-6">
        <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full" style={{ minWidth: "1600px" }}>
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50/50">
                  {[
                    "Kode Aset", "Nama Aset", "Merk / Tipe", "Spesifikasi",
                    "Thn Perolehan", "Sumber Dana", "Kondisi", "Lokasi",
                    "Penanggung Jawab", "Nilai Perolehan", "Nilai Buku",
                    "Masa Manfaat", "Status Opname", "Kondisi Fisik",
                    "Status Lokasi", "Diverifikasi Oleh", "Tgl Verifikasi", "Aksi",
                  ].map(h => (
                    <th key={h} className="px-3 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wider text-gray-400 whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={18} className="px-4 py-16 text-center">
                      <div className="flex flex-col items-center gap-2 text-gray-400">
                        <ClipboardList size={32} strokeWidth={1} />
                        <p className="text-sm font-medium">Tidak ada aset ditemukan</p>
                        <p className="text-xs">Coba ubah filter pencarian</p>
                      </div>
                    </td>
                  </tr>
                ) : filtered.map(item => (
                  <tr
                    key={item.kodeAset}
                    className={`transition-colors ${
                      item.statusOpname === "Terverifikasi"         ? "hover:bg-green-50/30" :
                      item.statusOpname === "Tidak Ditemukan"       ? "bg-red-50/20 hover:bg-red-50/40" :
                      item.statusOpname === "Selisih"              ? "bg-blue-50/20 hover:bg-blue-50/30" :
                      item.statusOpname === "Tidak Ada Lokasi Jelas"? "bg-orange-50/20 hover:bg-orange-50/30" :
                      "hover:bg-gray-50"
                    }`}
                  >
                    <td className="px-3 py-2.5">
                      <div>
                        <p className="text-xs font-mono font-semibold text-gray-700">{item.kodeAset}</p>
                        <p className="text-[10px] text-gray-400 font-mono">{item.kodeTagAset}</p>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 min-w-[140px]">
                      <p className="text-xs font-semibold text-gray-800 truncate max-w-[130px]">{item.namaAset}</p>
                      <KategoriBadge k={item.kategori} />
                    </td>
                    <td className="px-3 py-2.5 min-w-[130px]">
                      <p className="text-xs text-gray-600 truncate max-w-[120px]">{item.merkTipe}</p>
                    </td>
                    <td className="px-3 py-2.5 min-w-[160px]">
                      <p className="text-[10px] text-gray-500 truncate max-w-[150px]" title={item.spesifikasi}>{item.spesifikasi}</p>
                    </td>
                    <td className="px-3 py-2.5">
                      <p className="text-xs text-gray-600">{item.tahunPerolehan}</p>
                    </td>
                    <td className="px-3 py-2.5">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-gray-100 text-gray-600">{item.sumberDana}</span>
                    </td>
                    <td className="px-3 py-2.5">
                      <p className="text-xs text-gray-600">{item.kondisiAset}</p>
                    </td>
                    <td className="px-3 py-2.5 min-w-[120px]">
                      <p className="text-xs font-medium text-gray-700">{item.ruangan}</p>
                      <p className="text-[10px] text-gray-400">{item.gedung}</p>
                    </td>
                    <td className="px-3 py-2.5 min-w-[100px]">
                      <p className="text-xs text-gray-600 truncate max-w-[90px]">{item.pic}</p>
                    </td>
                    <td className="px-3 py-2.5">
                      <p className="text-xs font-semibold text-gray-800 whitespace-nowrap">{fmtRupiah(item.nilaiPerolehan)}</p>
                    </td>
                    <td className="px-3 py-2.5">
                      <p className="text-xs text-gray-600 whitespace-nowrap">{fmtRupiah(item.nilaiBuku)}</p>
                    </td>
                    <td className="px-3 py-2.5">
                      <p className="text-xs text-gray-600">{item.masaManfaat} thn</p>
                    </td>
                    <td className="px-3 py-2.5">
                      <StatusOpnameBadge status={item.statusOpname} />
                    </td>
                    <td className="px-3 py-2.5">
                      {item.kondisiFisikOpname
                        ? <KondisiFisikBadge kondisi={item.kondisiFisikOpname} />
                        : <span className="text-gray-300 text-xs">—</span>}
                    </td>
                    <td className="px-3 py-2.5">
                      {item.statusLokasiOpname
                        ? <StatusLokasiOpnameBadge status={item.statusLokasiOpname} />
                        : <span className="text-gray-300 text-xs">—</span>}
                    </td>
                    <td className="px-3 py-2.5">
                      <p className="text-xs text-gray-600 truncate max-w-[90px]">{item.diverifikasiOleh ?? "—"}</p>
                    </td>
                    <td className="px-3 py-2.5">
                      <p className="text-xs text-gray-500">{item.tanggalVerifikasi ?? "—"}</p>
                    </td>
                    <td className="px-3 py-2.5">
                      {canVerify && (
                        <button
                          onClick={() => setVerifyingItem(item)}
                          className={`flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                            item.statusOpname === "Belum Dicek"
                              ? "bg-[#111827] text-white hover:bg-gray-800"
                              : "border border-gray-200 text-gray-600 hover:bg-gray-50"
                          }`}
                        >
                          {item.statusOpname === "Belum Dicek" ? <><Check size={11} /> Verifikasi</> : <><PenLine size={11} /> Edit</>}
                        </button>
                      )}
                      {!canVerify && item.diverifikasiOleh && (
                        <p className="text-[10px] text-gray-400 whitespace-nowrap">{item.diverifikasiOleh}</p>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {verifyingItem && (
        <VerifikasiModal
          item={verifyingItem}
          onClose={() => setVerifyingItem(null)}
          onSave={updates => { onVerifikasi(verifyingItem.kodeAset, updates); setVerifyingItem(null); }}
        />
      )}
    </div>
  );
}

// ── Barcode Scanning Content ──────────────────────────────────────────────────
interface ScanHistoryEntry {
  kodeTag: string; namaAset: string; waktu: string; status: StatusOpname;
}

function BarcodeScanContent({ items, sesiStatus, onVerifikasi }: {
  items: OpnameItem[];
  sesiStatus: StatusSesi;
  onVerifikasi: (kodeAset: string, updates: Partial<OpnameItem>) => void;
}) {
  const [tagInput, setTagInput]           = useState("");
  const [scanResult, setScanResult]       = useState<OpnameItem | null>(null);
  const [notFound, setNotFound]           = useState(false);
  const [lokasiDitemukan, setLokDitemukan] = useState("");
  const [kondisiScan, setKondisiScan]     = useState<KondisiFisikOpname | "">("");
  const [lokasiScan, setLokasiScan]       = useState<StatusLokasiOpname | "">("");
  const [catatanScan, setCatatanScan]     = useState("");
  const [scanHistory, setScanHistory]     = useState<ScanHistoryEntry[]>([]);
  const [saveConfirm, setSaveConfirm]     = useState<StatusOpname | null>(null);
  const [cameraActive, setCameraActive]   = useState(false);

  const canVerify = sesiStatus === "Berlangsung";

  const doScanByCode = (code: string) => {
    const q = code.trim().toLowerCase();
    if (!q) return;
    const found = items.find(i =>
      i.kodeTagAset.toLowerCase() === q || i.kodeAset.toLowerCase() === q
    );
    if (found) {
      setScanResult(found);
      setNotFound(false);
      setKondisiScan(found.kondisiFisikOpname ?? "");
      setLokasiScan(found.statusLokasiOpname ?? "");
      setLokDitemukan(found.lokasiDitemukan ?? "");
      setCatatanScan(found.catatanOpname);
    } else {
      setScanResult(null);
      setNotFound(true);
    }
    setSaveConfirm(null);
  };

  const doScan = () => doScanByCode(tagInput);

  const handleBarcodeScan = (result: BarcodeScanResult) => {
    setTagInput(result.value);
    doScanByCode(result.value);
  };

  const doAction = (targetStatus: StatusOpname) => {
    if (!scanResult) return;
    const kondisi: KondisiFisikOpname = targetStatus === "Tidak Ditemukan"
      ? "Tidak Ditemukan"
      : (kondisiScan || "Baik");
    const lokasi: StatusLokasiOpname = targetStatus === "Tidak Ditemukan"
      ? "Tidak Diketahui"
      : targetStatus === "Selisih"
      ? "Berbeda"
      : (lokasiScan || "Sesuai");

    const updates: Partial<OpnameItem> = {
      statusOpname: targetStatus,
      kondisiFisikOpname: kondisi,
      statusLokasiOpname: lokasi,
      lokasiDitemukan: lokasi === "Berbeda" ? lokasiDitemukan || null : null,
      catatanOpname: catatanScan,
      statusKejelasanLokasi: targetStatus === "Tidak Ada Lokasi Jelas" ? "Tidak Jelas" : "Jelas",
    };
    onVerifikasi(scanResult.kodeAset, updates);
    setScanHistory(prev => [
      { kodeTag: scanResult.kodeTagAset, namaAset: scanResult.namaAset, waktu: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }), status: targetStatus },
      ...prev.slice(0, 9),
    ]);
    setSaveConfirm(targetStatus);
    setTimeout(() => {
      setScanResult(null);
      setSaveConfirm(null);
      setTagInput("");
    }, 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* Left: Scanner + Result */}
        <div className="lg:col-span-2 space-y-4">
          {/* Real Camera Scanner */}
          <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3 border-b border-gray-100 flex items-center gap-2">
              <QrCode size={14} className="text-blue-600" />
              <span className="text-sm font-semibold text-gray-700">Barcode / QR Scanner</span>
              <button
                onClick={() => setCameraActive(a => !a)}
                className={`ml-auto flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-full transition-all ${
                  cameraActive
                    ? "bg-red-100 text-red-600 hover:bg-red-200"
                    : "bg-green-100 text-green-700 hover:bg-green-200"
                }`}
              >
                <Camera size={11} />
                {cameraActive ? "Matikan Kamera" : "Aktifkan Kamera"}
              </button>
            </div>

            {cameraActive && (
              <BarcodeScanner
                active={cameraActive}
                onScan={handleBarcodeScan}
              />
            )}

            <div className="p-4">
              <p className="text-xs font-semibold text-gray-500 mb-2">Input manual kode tag / kode aset</p>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Hash size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    value={tagInput}
                    onChange={e => setTagInput(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && doScan()}
                    placeholder="Contoh: TAG-001 atau PM-001"
                    className="w-full pl-8 pr-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400"
                  />
                </div>
                <button
                  onClick={doScan}
                  className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-[#111827] rounded-lg hover:bg-gray-800 transition-colors"
                >
                  <QrCode size={14} /> Scan
                </button>
              </div>
            </div>
          </div>

          {/* Not found */}
          {notFound && !scanResult && (
            <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-200 rounded-xl">
              <AlertTriangle size={18} className="text-red-500 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-red-700">Aset tidak ditemukan di sistem</p>
                <p className="text-xs text-red-500 mt-0.5">Kode tag <strong>{tagInput}</strong> tidak terdaftar dalam sesi opname ini</p>
              </div>
            </div>
          )}

          {/* Save confirm */}
          {saveConfirm && (
            <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-xl">
              <CheckCircle2 size={18} className="text-green-600 shrink-0" />
              <p className="text-sm font-semibold text-green-700">Berhasil ditandai: <strong>{saveConfirm}</strong></p>
            </div>
          )}

          {/* Scan Result Card */}
          {scanResult && !saveConfirm && (
            <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
              <div className="px-5 py-3 border-b border-gray-100 flex items-center justify-between">
                <span className="text-sm font-semibold text-gray-700">Hasil Scan</span>
                <StatusOpnameBadge status={scanResult.statusOpname} />
              </div>

              <div className="p-5 space-y-4">
                {/* Asset basic info */}
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: "Kode Aset",       value: scanResult.kodeAset },
                    { label: "Kode Tag",         value: scanResult.kodeTagAset },
                    { label: "Nama Aset",        value: scanResult.namaAset },
                    { label: "Kategori",         value: scanResult.tipeAset },
                    { label: "Lokasi Sistem",    value: `${scanResult.ruangan} · ${scanResult.gedung}` },
                    { label: "PIC",              value: scanResult.pic },
                  ].map(r => (
                    <div key={r.label}>
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-0.5">{r.label}</p>
                      <p className="text-xs font-semibold text-gray-800">{r.value}</p>
                    </div>
                  ))}
                </div>

                {canVerify && (
                  <>
                    {/* Kondisi Fisik */}
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1.5">Kondisi Fisik Ditemukan</label>
                      <div className="flex gap-1.5 flex-wrap">
                        {(["Baik","Rusak Ringan","Rusak Berat"] as KondisiFisikOpname[]).map(k => (
                          <button
                            key={k}
                            onClick={() => setKondisiScan(k)}
                            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${kondisiScan === k ? "bg-[#111827] text-white border-[#111827]" : "border-gray-200 text-gray-600 hover:border-gray-300"}`}
                          >
                            {k}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Lokasi Ditemukan */}
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1.5">Lokasi Ditemukan <span className="text-gray-400 font-normal">(jika berbeda dari sistem)</span></label>
                      <input
                        value={lokasiDitemukan}
                        onChange={e => setLokDitemukan(e.target.value)}
                        placeholder="Kosongkan jika sesuai sistem..."
                        className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400"
                      />
                    </div>

                    {/* Catatan */}
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1.5">Catatan</label>
                      <input
                        value={catatanScan}
                        onChange={e => setCatatanScan(e.target.value)}
                        placeholder="Catatan hasil scan..."
                        className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400"
                      />
                    </div>

                    {/* Action Buttons */}
                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-gray-100">
                      <button
                        onClick={() => doAction("Terverifikasi")}
                        className="flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-white bg-green-600 rounded-lg hover:bg-green-700 transition-colors"
                      >
                        <CheckCircle2 size={13} /> Tandai Terverifikasi
                      </button>
                      <button
                        onClick={() => doAction("Selisih")}
                        className="flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        <TrendingDown size={13} /> Tandai Selisih
                      </button>
                      <button
                        onClick={() => doAction("Tidak Ditemukan")}
                        className="flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 transition-colors"
                      >
                        <Ban size={13} /> Tidak Ditemukan
                      </button>
                      <button
                        onClick={() => doAction(kondisiScan === "Tidak Ditemukan" ? "Tidak Ditemukan" : (lokasiDitemukan ? "Tidak Ada Lokasi Jelas" : "Terverifikasi"))}
                        className="flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <AlertCircle size={13} /> Simpan Catatan
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right: Scan History */}
        <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-100">
            <p className="text-sm font-semibold text-gray-700">Riwayat Scan Terakhir</p>
          </div>
          {scanHistory.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-12 text-gray-400">
              <QrCode size={28} strokeWidth={1} />
              <p className="text-xs">Belum ada riwayat scan</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {scanHistory.map((h, i) => (
                <div key={i} className="px-4 py-3 flex items-start gap-3">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-white text-xs font-bold ${
                    h.status === "Terverifikasi" ? "bg-green-500" :
                    h.status === "Tidak Ditemukan" ? "bg-red-500" :
                    h.status === "Selisih" ? "bg-blue-500" : "bg-orange-500"
                  }`}>
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-gray-800 truncate">{h.namaAset}</p>
                    <p className="text-[10px] font-mono text-gray-400">{h.kodeTag}</p>
                    <StatusOpnameBadge status={h.status} />
                  </div>
                  <p className="text-[10px] text-gray-400 shrink-0">{h.waktu}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Sesi Detail (with tabs) ───────────────────────────────────────────────────
function SesiDetail({ sesi, onClose, onVerifikasi, onUpdateStatus }: {
  sesi: StokSesi;
  onClose: () => void;
  onVerifikasi: (sesiId: string, kodeAset: string, updates: Partial<OpnameItem>) => void;
  onUpdateStatus: (sesiId: string, status: StatusSesi) => void;
}) {
  const [tab, setTab] = useState<"lembar" | "barcode">("lembar");

  const kpi = {
    terverifikasi: sesi.items.filter(i => i.statusOpname === "Terverifikasi").length,
    belumDicek: sesi.items.filter(i => i.statusOpname === "Belum Dicek").length,
  };
  const canStart  = sesi.status === "Draft";
  const canFinish = sesi.status === "Berlangsung" && kpi.belumDicek === 0;
  const canVerify = sesi.status === "Selesai";

  const handleVerifikasi = (kodeAset: string, updates: Partial<OpnameItem>) => {
    onVerifikasi(sesi.id, kodeAset, updates);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-gray-50">
      {/* Top bar */}
      <div className="bg-white border-b border-gray-200 px-6 py-3.5 flex items-center gap-4 shrink-0">
        <button onClick={onClose} className="p-2 text-gray-500 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors">
          <ChevronRight size={18} className="rotate-180" />
        </button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-sm font-bold text-gray-900 truncate">{sesi.nama}</h2>
            <StatusSesiBadge status={sesi.status} />
          </div>
          <p className="text-xs text-gray-500 mt-0.5">{sesi.id} · {sesi.periode} · {sesi.gedung}</p>
        </div>
        <div className="flex items-center gap-2 shrink-0 flex-wrap">
          {canStart  && <button onClick={() => onUpdateStatus(sesi.id, "Berlangsung")} className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-[#111827] rounded-lg hover:bg-gray-800 transition-colors"><RefreshCw size={14} /> Mulai Hitung</button>}
          {canFinish && <button onClick={() => onUpdateStatus(sesi.id, "Selesai")} className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-green-600 rounded-lg hover:bg-green-700 transition-colors"><CheckCircle2 size={14} /> Selesaikan</button>}
          {canVerify && <button onClick={() => onUpdateStatus(sesi.id, "Diverifikasi")} className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-[#111827] rounded-lg hover:bg-gray-800 transition-colors"><ShieldCheck size={14} /> Verifikasi</button>}
          <button className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"><Printer size={13} /> Cetak</button>
        </div>
      </div>

      {/* Tab Bar */}
      <div className="bg-white border-b border-gray-200 px-6 flex items-center gap-0.5 shrink-0">
        {([
          { key: "lembar", label: "Lembar Kerja Opname", icon: <ClipboardList size={14} /> },
          { key: "barcode", label: "Barcode Scanning", icon: <QrCode size={14} /> },
        ] as { key: "lembar" | "barcode"; label: string; icon: React.ReactNode }[]).map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-colors ${tab === t.key ? "border-[#111827] text-[#111827]" : "border-transparent text-gray-500 hover:text-gray-700"}`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {tab === "lembar" && (
        <LembarKerjaContent
          items={sesi.items}
          sesiStatus={sesi.status}
          onVerifikasi={handleVerifikasi}
        />
      )}
      {tab === "barcode" && (
        <BarcodeScanContent
          items={sesi.items}
          sesiStatus={sesi.status}
          onVerifikasi={handleVerifikasi}
        />
      )}
    </div>
  );
}

// ── New Session Modal ─────────────────────────────────────────────────────────
function NewSesiModal({ onClose, onSubmit, petugasList }: {
  onClose: () => void;
  onSubmit: (data: Omit<StokSesi, "id" | "items">) => void;
  petugasList: string[];
}) {
  const [step, setStep]         = useState(1);
  const [nama, setNama]         = useState("");
  const [periode, setPeriode]   = useState("");
  const [gedung, setGedung]     = useState("");
  const [katList, setKatList]   = useState<StokKategori[]>(["PM", "ATL", "AL"]);
  const [tglMulai, setTglMulai] = useState(new Date().toISOString().slice(0, 10));
  const [petugas, setPetugas]   = useState<string[]>([]);
  const [catatan, setCatatan]   = useState("");

  const toggleKat = (k: StokKategori) => setKatList(p => p.includes(k) ? p.filter(x => x !== k) : [...p, k]);
  const togglePetugas = (p: string) => setPetugas(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]);

  const canNext =
    (step === 1 && nama.trim() && periode.trim() && gedung && katList.length > 0) ||
    (step === 2 && petugas.length > 0 && tglMulai) ||
    step === 3;

  const STEPS = ["Informasi Sesi", "Petugas & Jadwal", "Konfirmasi"];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/40 backdrop-blur-sm">
      <div className="bg-white rounded-[12px] shadow-2xl w-full max-w-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-gray-900">Buat Sesi Stock Opname</h2>
            <p className="text-xs text-gray-500 mt-0.5">Langkah {step} dari 3 — {STEPS[step - 1]}</p>
          </div>
          <button onClick={onClose} className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-md transition-colors"><X size={18} /></button>
        </div>

        <div className="flex items-center px-6 pt-4 gap-2">
          {STEPS.map((label, i) => {
            const idx = i + 1; const done = idx < step; const active = idx === step;
            return (
              <React.Fragment key={label}>
                <div className="flex items-center gap-1.5">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${done || active ? "bg-[#111827] text-white" : "bg-gray-200 text-gray-500"}`}>{done ? <Check size={12} /> : idx}</div>
                  <span className={`text-xs font-medium hidden sm:block ${active ? "text-gray-900" : "text-gray-400"}`}>{label}</span>
                </div>
                {i < 2 && <div className={`flex-1 h-[1px] ${done ? "bg-[#111827]" : "bg-gray-200"}`} />}
              </React.Fragment>
            );
          })}
        </div>

        <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Nama Sesi <span className="text-red-500">*</span></label>
                <input value={nama} onChange={e => setNama(e.target.value)} placeholder="Contoh: Stock Opname Semester 2 2026"
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Periode <span className="text-red-500">*</span></label>
                <input value={periode} onChange={e => setPeriode(e.target.value)} placeholder="Contoh: Desember 2026"
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Cakupan Gedung <span className="text-red-500">*</span></label>
                <select value={gedung} onChange={e => setGedung(e.target.value)}
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none focus:ring-1 focus:ring-gray-400">
                  <option value="">Pilih cakupan...</option>
                  {GEDUNG_LIST.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-2">Kategori Aset yang Dihitung <span className="text-red-500">*</span></label>
                <div className="flex gap-2">
                  {([
                    { k: "PM" as StokKategori,  label: "Peralatan & Mesin",  icon: <Cpu size={14} />,    bg: "text-purple-600 bg-purple-50" },
                    { k: "ATL" as StokKategori, label: "Aset Tetap Lainnya", icon: <Layers size={14} />, bg: "text-teal-600 bg-teal-50"     },
                    { k: "AL" as StokKategori,  label: "Alat Angkutan",      icon: <Car size={14} />,    bg: "text-indigo-600 bg-indigo-50" },
                  ]).map(({ k, label, icon, bg }) => (
                    <button key={k} onClick={() => toggleKat(k)}
                      className={`flex-1 flex flex-col items-center gap-1.5 py-3 rounded-lg border transition-all text-xs font-semibold ${
                        katList.includes(k) ? `border-[#111827] ${bg} ring-1 ring-[#111827]/20` : "border-gray-200 text-gray-500 hover:border-gray-300"
                      }`}>
                      {icon} {k}
                      <span className="text-[9px] font-normal text-center leading-tight opacity-70">{label}</span>
                      {katList.includes(k) && <Check size={11} className="text-[#111827]" />}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Catatan</label>
                <textarea rows={2} value={catatan} onChange={e => setCatatan(e.target.value)}
                  placeholder="Tujuan atau catatan khusus sesi ini..."
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400 resize-none" />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-2">Petugas Penghitung <span className="text-red-500">*</span></label>
                <div className="space-y-1.5">
                  {petugasList.map(p => (
                    <div key={p} onClick={() => togglePetugas(p)}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg border cursor-pointer transition-all ${petugas.includes(p) ? "border-[#111827] bg-gray-50" : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"}`}>
                      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center shrink-0 transition-colors ${petugas.includes(p) ? "bg-[#111827] border-[#111827]" : "border-gray-300"}`}>
                        {petugas.includes(p) && <Check size={11} className="text-white" />}
                      </div>
                      <span className="text-sm text-gray-800">{p}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Rencana Tanggal Mulai <span className="text-red-500">*</span></label>
                <input type="date" value={tglMulai} onChange={e => setTglMulai(e.target.value)}
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400" />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <p className="text-sm text-gray-500">Periksa kembali sebelum sesi dibuat.</p>
              <div className="border border-gray-200 rounded-xl overflow-hidden divide-y divide-gray-100">
                {[
                  { label: "Nama Sesi",   value: nama },
                  { label: "Periode",     value: periode },
                  { label: "Cakupan",     value: gedung },
                  { label: "Kategori",    value: katList.join(", ") },
                  { label: "Petugas",     value: petugas.join(", ") },
                  { label: "Tgl Mulai",   value: tglMulai },
                  ...(catatan ? [{ label: "Catatan", value: catatan }] : []),
                ].map(({ label, value }) => (
                  <div key={label} className="flex gap-3 px-4 py-2.5">
                    <span className="text-xs text-gray-500 w-24 shrink-0">{label}</span>
                    <span className="text-xs font-semibold text-gray-800 flex-1">{value || "—"}</span>
                  </div>
                ))}
              </div>
              <div className="flex items-start gap-2 p-3 bg-blue-50 border border-blue-100 rounded-lg">
                <AlertCircle size={14} className="text-blue-500 mt-0.5 shrink-0" />
                <p className="text-xs text-blue-700">Sistem akan memuat seluruh daftar aset dari <strong>Data Aset</strong> sesuai kategori dan cakupan yang dipilih sebagai acuan opname.</p>
              </div>
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-100 flex justify-between">
          <button onClick={() => step > 1 ? setStep(s => s - 1) : onClose()}
            className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            {step === 1 ? "Batal" : "← Kembali"}
          </button>
          <button disabled={!canNext}
            onClick={() => step < 3 ? setStep(s => s + 1) : (onSubmit({ nama, periode, gedung, status: "Draft", tglMulai, tglSelesai: null, tglVerifikasi: null, petugas, verifikator: null, catatan, pengaju: "Salgado Ginting" }), onClose())}
            className={`px-5 py-2 text-sm font-semibold text-white rounded-lg transition-colors ${canNext ? "bg-[#111827] hover:bg-gray-800" : "bg-gray-300 cursor-not-allowed"}`}>
            {step < 3 ? "Lanjut →" : "Buat Sesi"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function StockOpnamePage({ topBar }: { topBar: React.ReactNode }) {
  const store = useDataStore();

  // Live store assets filtered to PM/ATL/AL (Stock Opname covers physical assets only)
  const masterItems = useMemo<OpnameItem[]>(
    () => store.assets
      .filter(a => (["PM", "ATL", "AL"] as string[]).includes(a.TipeAset ?? ""))
      .map(assetToOpnameItem),
    [store.assets],
  );

  const [localNewSessions, setLocalNewSessions] = useState<StokSesi[]>([]);

  const derivedSesiList = useMemo<StokSesi[]>(() => {
    const baseItems = masterItems;
    const records = store.stockOpnameRecords;
    const groups = new Map<string, typeof records>();
    for (const r of records) {
      const arr = groups.get(r.tanggal) || [];
      arr.push(r);
      groups.set(r.tanggal, arr);
    }
    const sorted = Array.from(groups.entries()).sort((a, b) => (a[0] < b[0] ? 1 : -1));
    const out: StokSesi[] = sorted.map(([tanggal, recs]) => {
      const recById = new Map(recs.map(r => [r.asset_id, r]));
      const petugasSet = Array.from(new Set(recs.map(r => r.diverifikasi_oleh).filter(Boolean)));
      const items: OpnameItem[] = baseItems.map(it => {
        const r = recById.get(it.kodeAset);
        if (!r) return it;
        return {
          ...it,
          statusOpname: mapOpnameStatus(r.status_opname),
          kondisiFisikOpname: mapKondisiFisik(r.kondisi_fisik),
          statusLokasiOpname: mapLokasiOpname(r.status_lokasi),
          diverifikasiOleh: r.diverifikasi_oleh || null,
          tanggalVerifikasi: r.tanggal,
          catatanOpname: r.catatan || "",
        };
      });
      const dt = new Date(tanggal);
      const ym = isNaN(dt.getTime())
        ? tanggal
        : `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}`;
      const firstId = recs.map(r => r.id).sort()[0] || `SO-${ym}`;
      const sesiId = firstId.startsWith("SO-") ? firstId.replace(/-\d+$/, `-${ym.replace("-", "")}`) : `SO-${ym}`;
      const allChecked = items.every(i => i.statusOpname !== "Belum Dicek");
      return {
        id: sesiId,
        nama: `Stock Opname ${periodeFromTanggal(tanggal)}`,
        periode: periodeFromTanggal(tanggal),
        gedung: "Semua Kampus",
        status: allChecked ? "Diverifikasi" : "Berlangsung",
        tglMulai: tanggal,
        tglSelesai: allChecked ? tanggal : null,
        tglVerifikasi: allChecked ? tanggal : null,
        petugas: petugasSet.length ? petugasSet : ["Tim Opname"],
        verifikator: allChecked ? petugasSet[0] || null : null,
        catatan: "",
        pengaju: petugasSet[0] || "Salgado Ginting",
        items,
      };
    });
    return out;
  }, [masterItems, store.stockOpnameRecords]);

  const sesiList = useMemo<StokSesi[]>(
    () => [...localNewSessions, ...derivedSesiList],
    [localNewSessions, derivedSesiList],
  );

  const petugasList = useMemo<string[]>(() => {
    return Array.from(new Set([
      ...store.stockOpnameRecords.map(r => r.diverifikasi_oleh),
      ...store.users.filter(u => u.role === "Operator Aset" || u.role === "Auditor").map(u => u.nama),
    ].filter(Boolean)));
  }, [store.stockOpnameRecords, store.users]);
  const [search, setSearch]     = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusSesi | "Semua">("Semua");
  const [openSesi, setOpenSesi] = useState<string | null>(null);
  const [showNew, setShowNew]   = useState(false);
  const [hoverId, setHoverId]   = useState<string | null>(null);

  const counts = useMemo(() => ({
    total:        sesiList.length,
    draft:        sesiList.filter(s => s.status === "Draft").length,
    berlangsung:  sesiList.filter(s => s.status === "Berlangsung").length,
    selesai:      sesiList.filter(s => s.status === "Selesai").length,
    diverifikasi: sesiList.filter(s => s.status === "Diverifikasi").length,
  }), [sesiList]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return sesiList.filter(s => {
      if (statusFilter !== "Semua" && s.status !== statusFilter) return false;
      if (q && !s.nama.toLowerCase().includes(q) && !s.id.toLowerCase().includes(q) && !s.gedung.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [sesiList, statusFilter, search]);

  const handleVerifikasi = (sesiId: string, kodeAset: string, updates: Partial<OpnameItem>) => {
    const today = new Date().toISOString().slice(0, 10);
    // Persist kondisi result back to the store asset record
    if (updates.kondisiFisikOpname) {
      store.recordStockOpname(kodeAset, { Kondisi: updates.kondisiFisikOpname });
    }
    setLocalNewSessions(prev => prev.map(s => {
      if (s.id !== sesiId) return s;
      return {
        ...s,
        items: s.items.map(i => {
          if (i.kodeAset !== kodeAset) return i;
          return {
            ...i, ...updates,
            diverifikasiOleh: updates.diverifikasiOleh ?? "Salgado Ginting",
            tanggalVerifikasi: updates.tanggalVerifikasi ?? today,
          };
        }),
      };
    }));
  };

  const handleUpdateStatus = (sesiId: string, status: StatusSesi) => {
    const today = new Date().toISOString().slice(0, 10);
    setLocalNewSessions(prev => prev.map(s => {
      if (s.id !== sesiId) return s;
      return {
        ...s, status,
        tglSelesai:    status === "Selesai"      ? today : s.tglSelesai,
        tglVerifikasi: status === "Diverifikasi" ? today : s.tglVerifikasi,
        verifikator:   status === "Diverifikasi" ? "Dr. Rudi Hartono" : s.verifikator,
      };
    }));
  };

  const handleNewSesi = (data: Omit<StokSesi, "id" | "items">) => {
    const newId = `SO-2026-LOC-${Date.now()}`;
    setLocalNewSessions(prev => [{ id: newId, ...data, items: makeBlankItems(masterItems) }, ...prev]);
  };

  const STATUS_TABS: Array<StatusSesi | "Semua"> = ["Semua", "Draft", "Berlangsung", "Selesai", "Diverifikasi"];
  const tabCount = (t: StatusSesi | "Semua") =>
    t === "Semua" ? counts.total : t === "Draft" ? counts.draft : t === "Berlangsung" ? counts.berlangsung : t === "Selesai" ? counts.selesai : counts.diverifikasi;

  const activeSesi = openSesi ? sesiList.find(s => s.id === openSesi) : null;
  if (activeSesi) {
    return (
      <SesiDetail
        sesi={activeSesi}
        onClose={() => setOpenSesi(null)}
        onVerifikasi={handleVerifikasi}
        onUpdateStatus={handleUpdateStatus}
      />
    );
  }

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-[#111827]">Stock Opname</h1>
            <p className="text-sm text-gray-500 mt-0.5">Verifikasi fisik aset PM, ATL, dan AL dengan barcode scanning dan lembar kerja opname.</p>
          </div>
          <button onClick={() => setShowNew(true)} className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-[#111827] rounded-lg hover:bg-gray-800 transition-colors shadow-sm">
            <Plus size={16} /> Buat Sesi Baru
          </button>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: "Total Sesi",    value: counts.total,        icon: <ClipboardList size={17} className="text-gray-600" />,  bg: "bg-gray-50",   color: "#111827" },
            { label: "Berlangsung",   value: counts.berlangsung,  icon: <RefreshCw size={17} className="text-blue-600" />,       bg: "bg-blue-50",   color: "#1D4ED8" },
            { label: "Selesai",       value: counts.selesai,      icon: <Clock size={17} className="text-yellow-600" />,         bg: "bg-yellow-50", color: "#B45309" },
            { label: "Diverifikasi",  value: counts.diverifikasi, icon: <ShieldCheck size={17} className="text-green-600" />,    bg: "bg-green-50",  color: "#15803D" },
          ].map(s => (
            <div key={s.label} className="bg-white border border-gray-200 rounded-xl p-4 flex items-center gap-3 shadow-sm">
              <div className={`w-10 h-10 rounded-lg ${s.bg} flex items-center justify-center shrink-0`}>{s.icon}</div>
              <div>
                <p className="text-xl font-bold" style={{ color: s.color }}>{s.value}</p>
                <p className="text-xs text-gray-500 leading-tight">{s.label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Session list */}
        <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-100 flex items-center gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari sesi, ID, kampus..."
                className="w-full pl-8 pr-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400" />
            </div>
            <button
              onClick={() => exportToExcel(filtered.map(s => ({
                "ID Sesi": s.id, "Nama Sesi": s.nama, "Status": s.status,
                "Periode": s.periode, "Gedung": s.gedung,
                "Total Aset": s.items.length,
                "Terverifikasi": s.items.filter(i => i.statusOpname === "Terverifikasi").length,
                "Belum Dicek": s.items.filter(i => i.statusOpname === "Belum Dicek").length,
                "Tidak Ditemukan": s.items.filter(i => i.statusOpname === "Tidak Ditemukan").length,
                "Tgl Mulai": s.tglMulai, "Tgl Selesai": s.tglSelesai ?? "",
              })), `stock-opname-${new Date().toISOString().slice(0,10)}`, "Sesi Opname")}
              className="ml-auto flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
              <Download size={14} /> Export
            </button>
          </div>

          <div className="flex items-center gap-0.5 px-5 pt-3 border-b border-gray-100 overflow-x-auto">
            {STATUS_TABS.map(tab => (
              <button key={tab} onClick={() => setStatusFilter(tab)}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold whitespace-nowrap border-b-2 transition-colors ${statusFilter === tab ? "border-[#111827] text-[#111827]" : "border-transparent text-gray-500 hover:text-gray-700"}`}>
                {tab}
                <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${statusFilter === tab ? "bg-[#111827] text-white" : "bg-gray-100 text-gray-500"}`}>{tabCount(tab)}</span>
              </button>
            ))}
          </div>

          <div className="divide-y divide-gray-50">
            {filtered.length === 0 ? (
              <div className="px-4 py-16 text-center">
                <div className="flex flex-col items-center gap-2 text-gray-400">
                  <ClipboardList size={32} strokeWidth={1} />
                  <p className="text-sm font-medium">Tidak ada sesi ditemukan</p>
                  <p className="text-xs">Buat sesi stock opname baru untuk memulai</p>
                </div>
              </div>
            ) : filtered.map(sesi => {
              const total = sesi.items.length;
              const terverifikasi = sesi.items.filter(i => i.statusOpname === "Terverifikasi").length;
              const pct = total ? Math.round(terverifikasi / total * 100) : 0;
              const selisih = sesi.items.filter(i => ["Selisih","Tidak Ditemukan","Tidak Ada Lokasi Jelas"].includes(i.statusOpname)).length;
              return (
                <div key={sesi.id} onMouseEnter={() => setHoverId(sesi.id)} onMouseLeave={() => setHoverId(null)}
                  className="px-5 py-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                      sesi.status === "Diverifikasi" ? "bg-green-100" : sesi.status === "Berlangsung" ? "bg-blue-100" : sesi.status === "Selesai" ? "bg-yellow-100" : "bg-gray-100"
                    }`}>
                      <ClipboardList size={17} className={
                        sesi.status === "Diverifikasi" ? "text-green-700" : sesi.status === "Berlangsung" ? "text-blue-700" : sesi.status === "Selesai" ? "text-yellow-700" : "text-gray-500"
                      } />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-bold text-gray-900">{sesi.nama}</p>
                        <StatusSesiBadge status={sesi.status} />
                        {selisih > 0 && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-red-50 text-red-600 border border-red-200">
                            <AlertTriangle size={10} /> {selisih} masalah
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-4 mt-1 text-xs text-gray-500 flex-wrap">
                        <span className="font-mono text-gray-400">{sesi.id}</span>
                        <span className="flex items-center gap-1"><Building size={10} /> {sesi.gedung}</span>
                        <span>Periode: {sesi.periode}</span>
                        <span>Mulai: {sesi.tglMulai}</span>
                        {sesi.tglVerifikasi && <span className="text-green-600 font-medium">✓ Diverifikasi: {sesi.tglVerifikasi}</span>}
                      </div>
                      <div className="mt-2.5 space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-500">Progress opname <span className="font-semibold text-gray-700">{pct}%</span></span>
                          <span className="text-gray-400">{terverifikasi}/{total} aset terverifikasi</span>
                        </div>
                        <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div className={`h-full rounded-full transition-all ${pct === 100 ? "bg-green-500" : "bg-[#111827]"}`} style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                      <div className="flex items-center gap-2 mt-2 flex-wrap">
                        {(["PM","ATL","AL"] as StokKategori[]).map(k => sesi.items.some(i => i.kategori === k) ? <KategoriBadge key={k} k={k} /> : null)}
                        <span className="text-[10px] text-gray-400">·</span>
                        <span className="text-[10px] text-gray-500">Petugas: {sesi.petugas.join(", ")}</span>
                      </div>
                    </div>

                    <div className={`flex items-center gap-2 shrink-0 transition-opacity ${hoverId === sesi.id ? "opacity-100" : "opacity-0"}`}>
                      <button onClick={() => setOpenSesi(sesi.id)}
                        className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-[#111827] text-white rounded-lg hover:bg-gray-800 transition-colors whitespace-nowrap">
                        {sesi.status === "Berlangsung" ? <><QrCode size={12} /> Mulai Opname</> : <><FileText size={12} /> Lihat Detail</>}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {showNew && <NewSesiModal onClose={() => setShowNew(false)} onSubmit={handleNewSesi} petugasList={petugasList} />}
    </main>
  );
}
