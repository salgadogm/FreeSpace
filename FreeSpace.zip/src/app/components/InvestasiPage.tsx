import React, { useState } from "react";
import { Search, Plus, Bell, MoreHorizontal, X, ChevronDown } from "lucide-react";
import {
  LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend
} from "recharts";

const fmtRp = (n: number) => "Rp" + n.toLocaleString("id-ID");

// ── Data ───────────────────────────────────────────────────────────────────────
const MARKET_CARDS = [
  { name: "IHSG",              value: "7.245,83", change: "+1,24%", up: true  },
  { name: "S&P 500",           value: "5.320,41", change: "+0,53%", up: true  },
  { name: "Nasdaq Composite",  value: "16.843,22",change: "-0,31%", up: false },
  { name: "USD/IDR",           value: "15.842",   change: "+0,18%", up: false },
];

const STOCK_DATA = [
  { kode: "BBCA",  nama: "Bank Central Asia",    harga: "9.450",  change: "+1,08%",  vol: "45,2 jt",  up: true  },
  { kode: "TLKM",  nama: "Telkom Indonesia",      harga: "3.220",  change: "-0,62%",  vol: "32,1 jt",  up: false },
  { kode: "ASII",  nama: "Astra International",   harga: "5.675",  change: "+0,89%",  vol: "28,8 jt",  up: true  },
  { kode: "GOTO",  nama: "Gojek Tokopedia",       harga: "62",     change: "-1,59%",  vol: "185,0 jt", up: false },
  { kode: "BMRI",  nama: "Bank Mandiri",           harga: "6.100",  change: "+0,41%",  vol: "22,5 jt",  up: true  },
];

const WATCHLIST_DATA = [
  { kode: "BBCA", nama: "Bank Central Asia",  harga: "9.450",  change: "+1,08%", target: "10.000", alert: true  },
  { kode: "GOTO", nama: "Gojek Tokopedia",    harga: "62",     change: "-1,59%", target: "80",     alert: false },
  { kode: "ASII", nama: "Astra International",harga: "5.675",  change: "+0,89%", target: "6.000",  alert: true  },
];

const PORTOFOLIO_DATA = [
  { kode: "BBCA", lot: 1,  avgPrice: "8.900",  currPrice: "9.450", mktVal: 945000,  gain: 55000,  ret: "+6,18%", up: true  },
  { kode: "TLKM", lot: 5,  avgPrice: "3.300",  currPrice: "3.220", mktVal: 1610000, gain: -40000, ret: "-2,42%", up: false },
  { kode: "ASII", lot: 2,  avgPrice: "5.500",  currPrice: "5.675", mktVal: 1135000, gain: 35000,  ret: "+3,18%", up: true  },
];

const TRANSAKSI_INV = [
  { tgl: "1 Jul 2026", aset: "BBCA", tipe: "Beli",   jumlah: "100 lembar", harga: "9.200", fee: "Rp2.000",   total: "Rp922.000"   },
  { tgl: "28 Jun 2026",aset: "TLKM", tipe: "Beli",   jumlah: "500 lembar", harga: "3.320", fee: "Rp8.300",   total: "Rp1.668.300" },
  { tgl: "15 Jun 2026",aset: "ASII", tipe: "Jual",   jumlah: "100 lembar", harga: "5.800", fee: "Rp1.450",   total: "Rp578.550"   },
  { tgl: "10 Jun 2026",aset: "REKSA",tipe: "Deposit", jumlah: "—",          harga: "—",     fee: "—",          total: "Rp500.000"   },
];

const PORTFOLIO_ALLOC = [
  { name: "BBCA", value: 945000,  color: "#3B82F6" },
  { name: "TLKM", value: 1610000, color: "#8B5CF6" },
  { name: "ASII", value: 1135000, color: "#22C55E" },
];

const PERFORMA_DATA = [
  { bln: "Feb", val: 2900000 },
  { bln: "Mar", val: 3050000 },
  { bln: "Apr", val: 2980000 },
  { bln: "Mei", val: 3100000 },
  { bln: "Jun", val: 3250000 },
  { bln: "Jul", val: 3400000 },
];

// ── SimulasiBadge ─────────────────────────────────────────────────────────────
function SimBadge() {
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-orange-600 bg-orange-50 border border-orange-200 px-2 py-0.5 rounded">
      Data Simulasi
    </span>
  );
}

// ── Stock Detail Drawer ────────────────────────────────────────────────────────
function StockDrawer({ stock, onClose }: { stock: typeof STOCK_DATA[0]; onClose: () => void }) {
  const miniData = [
    { d: "1", v: 9200 }, { d: "2", v: 9280 }, { d: "3", v: 9150 },
    { d: "4", v: 9320 }, { d: "5", v: 9450 },
  ];
  return (
    <>
      <div className="fixed inset-0 z-40 bg-black/20" onClick={onClose} />
      <div className="fixed top-0 right-0 h-screen w-80 bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-200">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-gray-900">{stock.kode}</h2>
            <p className="text-xs text-gray-500">{stock.nama}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100"><X size={16} className="text-gray-500" /></button>
        </div>
        <div className="p-5 space-y-4 flex-1 overflow-y-auto">
          <SimBadge />
          <div className="flex items-end gap-2">
            <span className="text-3xl font-bold text-gray-900">Rp{stock.harga}</span>
            <span className={`text-sm font-semibold ${stock.up ? "text-green-600" : "text-red-500"}`}>{stock.change}</span>
          </div>
          <div style={{ height: 100 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={miniData}>
                <Line type="monotone" dataKey="v" stroke={stock.up ? "#22C55E" : "#EF4444"} strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {[["Volume", stock.vol], ["Perubahan", stock.change], ["Harga Sim.", "Rp"+stock.harga], ["Kode", stock.kode]].map(([k, v]) => (
              <div key={k} className="bg-gray-50 rounded-lg p-2">
                <p className="text-gray-500">{k}</p>
                <p className="font-semibold text-gray-800 mt-0.5">{v}</p>
              </div>
            ))}
          </div>
          <button className="w-full py-2 bg-gray-900 text-white rounded-lg text-sm font-semibold hover:bg-black">
            + Tambah ke Watchlist
          </button>
        </div>
      </div>
    </>
  );
}

// ── Tab: Market ────────────────────────────────────────────────────────────────
function TabMarket() {
  const [selectedStock, setSelectedStock] = useState<typeof STOCK_DATA[0] | null>(null);
  const [market, setMarket] = useState("Indonesia");
  return (
    <div className="space-y-4">
      {selectedStock && <StockDrawer stock={selectedStock} onClose={() => setSelectedStock(null)} />}
      <div className="flex items-center gap-3">
        <SimBadge />
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-lg">
          {["Indonesia","Amerika Serikat"].map(m => (
            <button key={m} onClick={() => setMarket(m)}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${market === m ? "bg-white shadow-sm text-gray-900" : "text-gray-500"}`}>
              {m}
            </button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-4 gap-4">
        {MARKET_CARDS.map(c => (
          <div key={c.name} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
            <p className="text-xs text-gray-500 mb-1">{c.name}</p>
            <p className="text-lg font-bold text-gray-900">{c.value}</p>
            <p className={`text-xs font-semibold mt-0.5 ${c.up ? "text-green-600" : "text-red-500"}`}>{c.change}</p>
          </div>
        ))}
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-800">Daftar Saham</h3>
          <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 w-48">
            <Search size={13} className="text-gray-400" />
            <input className="text-xs flex-1 outline-none bg-transparent placeholder:text-gray-400" placeholder="Cari saham..." />
          </div>
        </div>
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              {["Kode","Nama Perusahaan","Harga (Sim.)","Perubahan","Volume","Action"].map(h => (
                <th key={h} className="px-4 py-2.5 text-left font-medium text-gray-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {STOCK_DATA.map(r => (
              <tr key={r.kode} className="border-b border-gray-50 hover:bg-gray-50 cursor-pointer" onClick={() => setSelectedStock(r)}>
                <td className="px-4 py-2.5 font-bold text-gray-900">{r.kode}</td>
                <td className="px-4 py-2.5 text-gray-700">{r.nama}</td>
                <td className="px-4 py-2.5 font-medium">Rp{r.harga}</td>
                <td className={`px-4 py-2.5 font-semibold ${r.up ? "text-green-600" : "text-red-500"}`}>{r.change}</td>
                <td className="px-4 py-2.5 text-gray-500">{r.vol}</td>
                <td className="px-4 py-2.5">
                  <button className="text-xs text-blue-600 hover:underline" onClick={e => { e.stopPropagation(); setSelectedStock(r); }}>Detail</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Tab: Watchlist ─────────────────────────────────────────────────────────────
function TabWatchlist() {
  const [items, setItems] = useState(WATCHLIST_DATA);
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-800">Watchlist Saya</h3>
          <button className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-900 text-white rounded-lg text-xs font-semibold">
            <Plus size={12} /> Tambah
          </button>
        </div>
        {items.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-sm text-gray-500">Watchlist masih kosong.</p>
            <button className="mt-3 px-4 py-2 bg-gray-900 text-white rounded-lg text-xs font-semibold">Tambah Watchlist</button>
          </div>
        ) : (
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                {["Kode","Nama","Harga (Sim.)","Perubahan Harian","Target Harga","Alert","Action"].map(h => (
                  <th key={h} className="px-4 py-2.5 text-left font-medium text-gray-500">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {items.map(r => (
                <tr key={r.kode} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="px-4 py-2.5 font-bold text-gray-900">{r.kode}</td>
                  <td className="px-4 py-2.5 text-gray-700">{r.nama}</td>
                  <td className="px-4 py-2.5 font-medium">Rp{r.harga}</td>
                  <td className={`px-4 py-2.5 font-semibold ${r.change.startsWith("+") ? "text-green-600" : "text-red-500"}`}>{r.change}</td>
                  <td className="px-4 py-2.5 text-gray-600">Rp{r.target}</td>
                  <td className="px-4 py-2.5">
                    <button
                      onClick={() => setItems(items.map(i => i.kode === r.kode ? { ...i, alert: !i.alert } : i))}
                      className={`p-1 rounded ${r.alert ? "text-amber-500" : "text-gray-300"}`}>
                      <Bell size={13} />
                    </button>
                  </td>
                  <td className="px-4 py-2.5">
                    <button onClick={() => setItems(items.filter(i => i.kode !== r.kode))}
                      className="text-xs text-red-500 hover:underline">Hapus</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ── Tab: Portofolio ────────────────────────────────────────────────────────────
function TabPortofolio() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Nilai Portofolio", value: "Rp3.400.000", color: "text-gray-900" },
          { label: "Modal",            value: "Rp3.150.000", color: "text-blue-600" },
          { label: "Unrealized Gain",  value: "Rp250.000",   color: "text-green-600" },
          { label: "Return",           value: "7,9%",         color: "text-green-600" },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-xs text-gray-500 mb-2">{c.label}</p>
            <p className={`text-2xl font-bold ${c.color}`}>{c.value}</p>
          </div>
        ))}
      </div>
      <div className="flex items-center gap-2 mb-2"><SimBadge /></div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">Alokasi Portofolio</h3>
          <div style={{ height: 160 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={PORTFOLIO_ALLOC} cx="50%" cy="50%" outerRadius={65} dataKey="value" stroke="none">
                  {PORTFOLIO_ALLOC.map((d, i) => <Cell key={i} fill={d.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-1.5">
            {PORTFOLIO_ALLOC.map(d => (
              <div key={d.name} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: d.color }} />
                <span className="text-xs text-gray-600 flex-1">{d.name}</span>
                <span className="text-xs font-semibold">{fmtRp(d.value)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">Performa Portofolio</h3>
          <ResponsiveContainer width="100%" height={160}>
            <LineChart data={PERFORMA_DATA}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" />
              <XAxis dataKey="bln" tick={{ fontSize: 11, fill: "#6B7280" }} />
              <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickFormatter={v => `${v/1000000}jt`} />
              <Tooltip formatter={(v: number) => fmtRp(v)} />
              <Line type="monotone" dataKey="val" name="Nilai" stroke="#3B82F6" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              {["Kode","Lot","Avg Price","Current Price","Market Value","Gain/Loss","Return"].map(h => (
                <th key={h} className="px-4 py-2.5 text-right first:text-left font-medium text-gray-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {PORTOFOLIO_DATA.map(r => (
              <tr key={r.kode} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-2.5 font-bold text-gray-900">{r.kode}</td>
                <td className="px-4 py-2.5 text-right text-gray-700">{r.lot}</td>
                <td className="px-4 py-2.5 text-right">Rp{r.avgPrice}</td>
                <td className="px-4 py-2.5 text-right">Rp{r.currPrice}</td>
                <td className="px-4 py-2.5 text-right font-medium">{fmtRp(r.mktVal)}</td>
                <td className={`px-4 py-2.5 text-right font-semibold ${r.up ? "text-green-600" : "text-red-500"}`}>
                  {r.gain >= 0 ? "+" : ""}{fmtRp(r.gain)}
                </td>
                <td className={`px-4 py-2.5 text-right font-semibold ${r.up ? "text-green-600" : "text-red-500"}`}>{r.ret}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Tab: Transaksi Investasi ───────────────────────────────────────────────────
function TabTransaksiInv() {
  const FILTER_TYPES = ["Semua","Beli","Jual","Dividen","Deposit","Withdrawal"];
  const [activeFilter, setActiveFilter] = useState("Semua");
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        {FILTER_TYPES.map(f => (
          <button key={f} onClick={() => setActiveFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
              activeFilter === f ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"
            }`}>{f}</button>
        ))}
        <button className="ml-auto flex items-center gap-1.5 px-4 py-1.5 bg-gray-900 text-white rounded-lg text-xs font-semibold">
          <Plus size={12} /> Tambah Transaksi Investasi
        </button>
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              {["Tanggal","Aset","Tipe","Jumlah","Harga (Sim.)","Fee","Total"].map(h => (
                <th key={h} className="px-4 py-2.5 text-left font-medium text-gray-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {TRANSAKSI_INV.map((r, i) => (
              <tr key={i} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-2.5 text-gray-500">{r.tgl}</td>
                <td className="px-4 py-2.5 font-bold text-gray-900">{r.aset}</td>
                <td className="px-4 py-2.5">
                  <span className={`text-[10px] font-semibold border px-1.5 py-0.5 rounded ${
                    r.tipe === "Beli" ? "bg-blue-50 text-blue-700 border-blue-200" :
                    r.tipe === "Jual" ? "bg-red-50 text-red-600 border-red-200" :
                    "bg-gray-50 text-gray-600 border-gray-200"}`}>{r.tipe}</span>
                </td>
                <td className="px-4 py-2.5 text-gray-700">{r.jumlah}</td>
                <td className="px-4 py-2.5 text-gray-700">{r.harga}</td>
                <td className="px-4 py-2.5 text-gray-500">{r.fee}</td>
                <td className="px-4 py-2.5 font-semibold text-gray-900">{r.total}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export function InvestasiPage({ topBar }: { topBar: React.ReactNode }) {
  const [activeTab, setActiveTab] = useState("market");
  const TABS = [
    { id: "market",    label: "Market" },
    { id: "watchlist", label: "Watchlist" },
    { id: "portofolio",label: "Portofolio" },
    { id: "transaksi", label: "Transaksi Investasi" },
  ];
  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-xl font-bold text-gray-900">Investasi</h1>
              <SimBadge />
            </div>
            <p className="text-sm text-gray-500">Pantau pasar, watchlist, portofolio, dan transaksi investasi.</p>
          </div>
        </div>

        <div className="flex items-center gap-0 border-b border-gray-200">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                activeTab === t.id ? "border-gray-900 text-gray-900" : "border-transparent text-gray-500 hover:text-gray-700"
              }`}>{t.label}</button>
          ))}
        </div>

        {activeTab === "market"    && <TabMarket />}
        {activeTab === "watchlist" && <TabWatchlist />}
        {activeTab === "portofolio"&& <TabPortofolio />}
        {activeTab === "transaksi" && <TabTransaksiInv />}
      </div>
    </main>
  );
}
