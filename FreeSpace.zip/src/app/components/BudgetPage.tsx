import React, { useState } from "react";
import { Plus, Copy, MoreHorizontal, TrendingUp, TrendingDown, X, Check } from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, Cell
} from "recharts";

const fmtRp = (n: number) => "Rp" + n.toLocaleString("id-ID");

// ── Budget Data ────────────────────────────────────────────────────────────────
const RENCANA = [
  { kat: "Makanan",       budget: 1200000, pct: "26,7%", catatan: "Termasuk kopi & snack" },
  { kat: "Transportasi",  budget: 900000,  pct: "20,0%", catatan: "Ojek & angkutan umum"  },
  { kat: "Pendidikan",    budget: 750000,  pct: "16,7%", catatan: "Buku & kursus online"  },
  { kat: "Tagihan",       budget: 600000,  pct: "13,3%", catatan: "Internet & listrik"    },
  { kat: "Hiburan",       budget: 450000,  pct: "10,0%", catatan: "Streaming & rekreasi"  },
  { kat: "Tabungan",      budget: 400000,  pct: "8,9%",  catatan: "Dana darurat"          },
  { kat: "Lainnya",       budget: 200000,  pct: "4,4%",  catatan: ""                      },
];

const REALISASI = [
  { kat: "Makanan",      budget: 1200000, realisasi: 1008000, sisa:  192000, pct: 84, status: "Mendekati Batas" },
  { kat: "Transportasi", budget:  900000, realisasi:  756000, sisa:  144000, pct: 84, status: "Mendekati Batas" },
  { kat: "Pendidikan",   budget:  750000, realisasi:  567000, sisa:  183000, pct: 76, status: "Aman"            },
  { kat: "Tagihan",      budget:  600000, realisasi:  252000, sisa:  348000, pct: 42, status: "Aman"            },
  { kat: "Hiburan",      budget:  450000, realisasi:  441000, sisa:    9000, pct: 98, status: "Mendekati Batas" },
  { kat: "Lainnya",      budget:  200000, realisasi:  126000, sisa:   74000, pct: 63, status: "Aman"            },
];

const EVALUASI_CHART = REALISASI.map(r => ({
  name: r.kat,
  Budget: r.budget / 1000,
  Aktual: r.realisasi / 1000,
}));

const INSIGHTS = [
  "Pengeluaran Hiburan telah mencapai 98% dari budget.",
  "Makanan dan Transportasi masing-masing telah menggunakan 84%.",
  "Total pengeluaran masih Rp1,35 juta di bawah budget.",
  "Pengeluaran bulan ini turun 6,8% dibanding Juni 2026.",
];

// ── Helpers ────────────────────────────────────────────────────────────────────
function StatusBadge({ s }: { s: string }) {
  const cfg: Record<string, string> = {
    "Aman":            "bg-green-50 text-green-700 border-green-200",
    "Mendekati Batas": "bg-amber-50 text-amber-700 border-amber-200",
    "Terlampaui":      "bg-red-50 text-red-600 border-red-200",
  };
  return (
    <span className={`text-[10px] font-semibold border px-1.5 py-0.5 rounded ${cfg[s] ?? cfg["Aman"]}`}>
      {s}
    </span>
  );
}

function progressColor(p: number) {
  if (p >= 95) return "bg-red-500";
  if (p >= 80) return "bg-amber-400";
  return "bg-green-500";
}

// ── Buat Budget Modal ──────────────────────────────────────────────────────────
function BuatBudgetModal({ onClose }: { onClose: () => void }) {
  const [saved, setSaved] = useState(false);
  const handleSave = () => { setSaved(true); setTimeout(onClose, 1000); };
  if (saved) return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="bg-white rounded-2xl p-10 flex flex-col items-center gap-3 shadow-2xl">
        <div className="w-14 h-14 rounded-full bg-green-100 flex items-center justify-center">
          <Check size={28} className="text-green-600" />
        </div>
        <p className="text-base font-bold text-gray-900">Budget Disimpan!</p>
      </div>
    </div>
  );
  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[460px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Buat Budget</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100"><X size={16} className="text-gray-500" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Kategori</label>
              <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                {RENCANA.map(r => <option key={r.kat}>{r.kat}</option>)}
                <option>Lainnya</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Nominal Budget</label>
              <input type="text" placeholder="Rp0" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Periode</label>
            <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
              <option>Juli 2026</option><option>Agustus 2026</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Catatan</label>
            <input type="text" placeholder="Catatan opsional..." className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900" />
          </div>
        </div>
        <div className="flex justify-end gap-3 px-6 py-4 border-t border-gray-100">
          <button onClick={onClose} className="px-4 py-2 text-sm text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Batal</button>
          <button onClick={handleSave} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black">Simpan Budget</button>
        </div>
      </div>
    </>
  );
}

// ── Tab: Rencana ───────────────────────────────────────────────────────────────
function TabRencana() {
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <span className="text-sm font-semibold text-gray-800">Juli 2026</span>
            <div className="flex gap-4 text-xs text-gray-500">
              <span>Total Pemasukan: <strong className="text-green-600">Rp6.500.000</strong></span>
              <span>Total Budget: <strong className="text-gray-800">Rp4.500.000</strong></span>
              <span>Dialokasikan: <strong className="text-gray-800">Rp4.500.000</strong></span>
              <span>Sisa: <strong className="text-blue-600">Rp0</strong></span>
            </div>
          </div>
        </div>
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              <th className="px-4 py-2.5 text-left font-medium text-gray-500">Kategori</th>
              <th className="px-4 py-2.5 text-right font-medium text-gray-500">Budget</th>
              <th className="px-4 py-2.5 text-right font-medium text-gray-500">% Alokasi</th>
              <th className="px-4 py-2.5 text-left font-medium text-gray-500">Catatan</th>
              <th className="px-4 py-2.5 text-center font-medium text-gray-500 w-10"></th>
            </tr>
          </thead>
          <tbody>
            {RENCANA.map(r => (
              <tr key={r.kat} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-2.5 font-medium text-gray-800">{r.kat}</td>
                <td className="px-4 py-2.5 text-right text-gray-700">{fmtRp(r.budget)}</td>
                <td className="px-4 py-2.5 text-right text-gray-500">{r.pct}</td>
                <td className="px-4 py-2.5 text-gray-400">{r.catatan}</td>
                <td className="px-4 py-2.5 text-center">
                  <button className="p-0.5 hover:bg-gray-200 rounded"><MoreHorizontal size={13} className="text-gray-400" /></button>
                </td>
              </tr>
            ))}
            <tr className="border-t-2 border-gray-200 bg-gray-50">
              <td className="px-4 py-2.5 font-bold text-gray-900">Total</td>
              <td className="px-4 py-2.5 text-right font-bold text-gray-900">Rp4.500.000</td>
              <td className="px-4 py-2.5 text-right font-bold text-gray-900">100%</td>
              <td colSpan={2}></td>
            </tr>
          </tbody>
        </table>
        <button className="mt-3 flex items-center gap-1.5 text-xs text-blue-600 hover:underline">
          <Plus size={12} /> Tambah Kategori
        </button>
      </div>
    </div>
  );
}

// ── Tab: Realisasi ─────────────────────────────────────────────────────────────
function TabRealisasi() {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      <table className="w-full text-xs">
        <thead>
          <tr className="bg-gray-50 border-b border-gray-100">
            <th className="px-4 py-3 text-left font-medium text-gray-500">Kategori</th>
            <th className="px-4 py-3 text-right font-medium text-gray-500">Budget</th>
            <th className="px-4 py-3 text-right font-medium text-gray-500">Realisasi</th>
            <th className="px-4 py-3 text-right font-medium text-gray-500">Sisa</th>
            <th className="px-4 py-3 text-left font-medium text-gray-500 w-36">Progress</th>
            <th className="px-4 py-3 text-left font-medium text-gray-500">Status</th>
          </tr>
        </thead>
        <tbody>
          {REALISASI.map(r => (
            <tr key={r.kat} className="border-b border-gray-50 hover:bg-gray-50">
              <td className="px-4 py-3 font-medium text-gray-800">{r.kat}</td>
              <td className="px-4 py-3 text-right text-gray-600">{fmtRp(r.budget)}</td>
              <td className="px-4 py-3 text-right text-gray-800 font-medium">{fmtRp(r.realisasi)}</td>
              <td className={`px-4 py-3 text-right font-medium ${r.sisa > 0 ? "text-green-600" : "text-red-500"}`}>{fmtRp(r.sisa)}</td>
              <td className="px-4 py-3">
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-1.5 rounded-full bg-gray-100 overflow-hidden">
                    <div className={`h-full rounded-full ${progressColor(r.pct)}`} style={{ width: `${r.pct}%` }} />
                  </div>
                  <span className="text-[10px] font-semibold text-gray-600 w-8">{r.pct}%</span>
                </div>
              </td>
              <td className="px-4 py-3"><StatusBadge s={r.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Tab: Evaluasi ──────────────────────────────────────────────────────────────
function TabEvaluasi() {
  return (
    <div className="space-y-4">
      {/* Bar Chart */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <h3 className="text-sm font-semibold text-gray-800 mb-4">Budget vs Aktual</h3>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={EVALUASI_CHART} barGap={4}>
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#6B7280" }} />
            <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickFormatter={v => `${v}rb`} />
            <Tooltip formatter={(v: number) => `Rp${v.toLocaleString("id-ID")}rb`} />
            <Legend />
            <Bar dataKey="Budget" fill="#E5E7EB" radius={[4,4,0,0]} />
            <Bar dataKey="Aktual" fill="#3B82F6"  radius={[4,4,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Insight */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-5">
        <h3 className="text-sm font-semibold text-amber-800 mb-3">Insight Otomatis</h3>
        <div className="space-y-2">
          {INSIGHTS.map((t, i) => (
            <div key={i} className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
              <p className="text-xs text-amber-800">{t}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Evaluasi Table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              <th className="px-4 py-3 text-left font-medium text-gray-500">Kategori</th>
              <th className="px-4 py-3 text-right font-medium text-gray-500">Budget</th>
              <th className="px-4 py-3 text-right font-medium text-gray-500">Aktual</th>
              <th className="px-4 py-3 text-right font-medium text-gray-500">Selisih</th>
              <th className="px-4 py-3 text-right font-medium text-gray-500">Variance %</th>
              <th className="px-4 py-3 text-left font-medium text-gray-500">Status</th>
            </tr>
          </thead>
          <tbody>
            {REALISASI.map(r => {
              const selisih = r.budget - r.realisasi;
              const variance = ((selisih / r.budget) * 100).toFixed(1);
              return (
                <tr key={r.kat} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium text-gray-800">{r.kat}</td>
                  <td className="px-4 py-3 text-right text-gray-600">{fmtRp(r.budget)}</td>
                  <td className="px-4 py-3 text-right text-gray-800">{fmtRp(r.realisasi)}</td>
                  <td className={`px-4 py-3 text-right font-medium ${selisih >= 0 ? "text-green-600" : "text-red-500"}`}>
                    {selisih >= 0 ? "+" : ""}{fmtRp(selisih)}
                  </td>
                  <td className={`px-4 py-3 text-right ${Number(variance) >= 0 ? "text-green-600" : "text-red-500"}`}>
                    {variance}%
                  </td>
                  <td className="px-4 py-3"><StatusBadge s={r.status} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export function BudgetPage({ topBar }: { topBar: React.ReactNode }) {
  const [activeTab, setActiveTab] = useState("rencana");
  const [showModal, setShowModal] = useState(false);

  const TABS = [
    { id: "rencana",   label: "Rencana"   },
    { id: "realisasi", label: "Realisasi" },
    { id: "evaluasi",  label: "Evaluasi"  },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      {showModal && <BuatBudgetModal onClose={() => setShowModal(false)} />}

      <div className="px-8 py-6 space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Budget</h1>
            <p className="text-sm text-gray-500 mt-1">Rencanakan batas pengeluaran dan pantau realisasinya.</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1.5 px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg text-sm font-semibold hover:bg-gray-50">
              <Copy size={14} /> Salin Bulan Sebelumnya
            </button>
            <button onClick={() => setShowModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-semibold hover:bg-black">
              <Plus size={14} /> Buat Budget
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-xs font-medium text-gray-500 mb-2">Total Budget</p>
            <p className="text-2xl font-bold text-gray-900">Rp4.500.000</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-xs font-medium text-gray-500 mb-2">Realisasi</p>
            <p className="text-2xl font-bold text-blue-600">Rp3.150.000</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-xs font-medium text-gray-500 mb-2">Sisa Budget</p>
            <p className="text-2xl font-bold text-green-600">Rp1.350.000</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-xs font-medium text-gray-500 mb-2">Penggunaan</p>
            <p className="text-2xl font-bold text-amber-600">70%</p>
            <div className="mt-2 h-1.5 rounded-full bg-gray-100 overflow-hidden">
              <div className="h-full rounded-full bg-amber-400" style={{ width: "70%" }} />
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-0 border-b border-gray-200">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                activeTab === t.id ? "border-gray-900 text-gray-900" : "border-transparent text-gray-500 hover:text-gray-700"
              }`}>
              {t.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === "rencana"   && <TabRencana />}
        {activeTab === "realisasi" && <TabRealisasi />}
        {activeTab === "evaluasi"  && <TabEvaluasi />}
      </div>
    </main>
  );
}
