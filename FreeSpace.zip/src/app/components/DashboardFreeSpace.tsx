import React, { useState } from "react";
import {
  TrendingUp, TrendingDown, Plus, ChevronDown, Calendar, Wallet,
  BookOpen, FileText, Calculator, Upload, Check, Target,
  ArrowLeftRight, Edit3, LayoutDashboard, Database,
  AlarmClock, Footprints
} from "lucide-react";
import {
  PieChart, Pie, Cell,
  Tooltip, ResponsiveContainer, Legend
} from "recharts";

// ── Formatters ─────────────────────────────────────────────────────────────────
const fmtRp = (n: number) =>
  "Rp" + n.toLocaleString("id-ID");

const fmtRpShort = (n: number) => {
  if (n >= 1_000_000) return `Rp${(n / 1_000_000).toFixed(2).replace(".", ",")} jt`;
  if (n >= 1_000) return `Rp${(n / 1_000).toFixed(0)} rb`;
  return `Rp${n}`;
};

// ── Status badge ───────────────────────────────────────────────────────────────
function AutoBadge() {
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-blue-600 bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded whitespace-nowrap">
      <Database size={9} /> Diperbarui Otomatis
    </span>
  );
}

// ── Summary Card ───────────────────────────────────────────────────────────────
function SummaryCard({
  label, value, desc, trend, trendUp, status, showBadge,
}: {
  label: string; value: string; desc?: string; trend?: string;
  trendUp?: boolean; status?: "positive" | "warning" | "danger" | "primary" | "purple";
  showBadge?: boolean;
}) {
  const trendColor =
    status === "positive" ? "text-green-500" :
    status === "warning"  ? "text-amber-500" :
    status === "danger"   ? "text-red-500"   :
    status === "primary"  ? "text-blue-600"  :
    status === "purple"   ? "text-purple-600": "text-gray-500";

  const valueColor =
    status === "positive" ? "text-gray-900" :
    status === "warning"  ? "text-amber-600" :
    status === "danger"   ? "text-red-600"   :
    status === "primary"  ? "text-blue-700"  :
    status === "purple"   ? "text-purple-700": "text-gray-900";

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex flex-col gap-2">
      <div className="flex items-start justify-between">
        <span className="text-xs font-medium text-gray-500">{label}</span>
        {showBadge && <AutoBadge />}
      </div>
      <p className={`text-2xl font-bold leading-tight ${valueColor}`}>{value}</p>
      {desc && <p className="text-xs text-gray-400">{desc}</p>}
      {trend && (
        <p className={`text-[11px] font-medium flex items-center gap-0.5 ${trendColor}`}>
          {trendUp !== undefined && (trendUp ? <TrendingUp size={11} /> : <TrendingDown size={11} />)}
          {trend}
        </p>
      )}
    </div>
  );
}

// ── Quick Add Dropdown ─────────────────────────────────────────────────────────
function QuickAdd() {
  const [open, setOpen] = useState(false);
  const items = [
    { label: "Tambah Transaksi",          icon: ArrowLeftRight },
    { label: "Tambah Aktivitas",           icon: Calendar },
    { label: "Tulis Jurnal",               icon: Edit3 },
    { label: "Mulai Membaca",              icon: BookOpen },
    { label: "Buat Jurnal Akuntansi",      icon: Calculator },
    { label: "Upload Bukti Transaksi",     icon: Upload },
  ];
  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-semibold hover:bg-black transition-colors"
      >
        <Plus size={15} />
        Quick Add
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="absolute right-0 mt-1.5 w-52 bg-white border border-gray-200 rounded-xl shadow-lg z-40 py-1.5 animate-in zoom-in-95 fade-in duration-100">
            {items.map(({ label, icon: Icon }) => (
              <button
                key={label}
                onClick={() => setOpen(false)}
                className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors text-left"
              >
                <Icon size={14} className="text-gray-400" />
                {label}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ── Filter Dropdown ────────────────────────────────────────────────────────────
function FilterDropdown({ value, options }: { value: string; options: string[] }) {
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(value);
  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-xs font-medium text-gray-700 hover:bg-gray-50 transition-colors"
      >
        {selected}
        <ChevronDown size={12} className="text-gray-400" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="absolute left-0 mt-1 w-44 bg-white border border-gray-200 rounded-lg shadow-lg z-40 py-1">
            {options.map(o => (
              <button key={o} onClick={() => { setSelected(o); setOpen(false); }}
                className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50">
                {o}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ── Insight List ──────────────────────────────────────────────────────────────
function InsightItem({ text, color }: { text: string; color: "green" | "orange" | "red" | "blue" }) {
  const dot: Record<string, string> = {
    green: "bg-green-500", orange: "bg-amber-500",
    red: "bg-red-500",     blue: "bg-blue-500",
  };
  return (
    <div className="flex items-start gap-2.5">
      <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${dot[color]}`} />
      <p className="text-sm text-gray-700 leading-relaxed">{text}</p>
    </div>
  );
}

// ── Charts ────────────────────────────────────────────────────────────────────
const DONUT_DATA = [
  { name: "Makanan",      value: 32, color: "#3B82F6" },
  { name: "Transportasi", value: 24, color: "#8B5CF6" },
  { name: "Pendidikan",   value: 18, color: "#22C55E" },
  { name: "Hiburan",      value: 14, color: "#F59E0B" },
  { name: "Lainnya",      value: 12, color: "#E5E7EB" },
];

const CATEGORY_DATA = [
  { name: "Makanan",       value: 1008000 },
  { name: "Transportasi",  value: 756000  },
  { name: "Pendidikan",    value: 567000  },
  { name: "Hiburan",       value: 441000  },
  { name: "Tagihan",       value: 252000  },
  { name: "Lainnya",       value: 126000  },
];

const WEEKLY_PROGRESS = [
  { label: "Aktivitas Harian", pct: 80, color: "#22C55E" },
  { label: "Budget Bulanan",   pct: 70, color: "#F59E0B" },
  { label: "Membaca Buku",     pct: 68, color: "#F59E0B" },
  { label: "Jurnal Harian",    pct: 57, color: "#F59E0B" },
  { label: "TOEFL Training",   pct: 45, color: "#EF4444" },
  { label: "Target Langkah",   pct: 74, color: "#F59E0B" },
];

function progressColor(p: number) {
  if (p >= 75) return "bg-green-500";
  if (p >= 50) return "bg-amber-400";
  return "bg-red-500";
}

function ChartDonut() {
  const total = "Rp3,15 jt";
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-800">Komposisi Pengeluaran</h3>
      </div>
      <div className="flex items-center gap-4">
        <div className="relative w-40 h-40 shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart id="donut-pengeluaran">
              <Pie data={DONUT_DATA} cx="50%" cy="50%" innerRadius={48} outerRadius={70}
                dataKey="value" stroke="none">
                {DONUT_DATA.map((d) => <Cell key={`donut-${d.name}`} fill={d.color} />)}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-sm font-bold text-gray-900">{total}</span>
            <span className="text-[10px] text-gray-400">Total</span>
          </div>
        </div>
        <div className="flex flex-col gap-1.5 flex-1">
          {DONUT_DATA.map(d => (
            <div key={d.name} className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: d.color }} />
              <span className="text-xs text-gray-600 flex-1">{d.name}</span>
              <span className="text-xs font-semibold text-gray-800">{d.value}%</span>
            </div>
          ))}
        </div>
      </div>
      <p className="text-[10px] text-gray-400">Data Juli 2026</p>
    </div>
  );
}

function ChartWeekly() {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex flex-col gap-3">
      <h3 className="text-sm font-semibold text-gray-800">Progress Mingguan</h3>
      <div className="flex flex-col gap-3">
        {WEEKLY_PROGRESS.map(({ label, pct }) => (
          <div key={label}>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-gray-600">{label}</span>
              <span className="text-xs font-semibold text-gray-800">{pct}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-gray-100 overflow-hidden">
              <div className={`h-full rounded-full ${progressColor(pct)}`} style={{ width: `${pct}%` }} />
            </div>
          </div>
        ))}
      </div>
      <p className="text-[10px] text-gray-400">Rata-rata progres keseluruhan 66%</p>
    </div>
  );
}

function ChartCategoryBar() {
  const maxVal = Math.max(...CATEGORY_DATA.map(d => d.value));
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex flex-col gap-3">
      <h3 className="text-sm font-semibold text-gray-800">Pengeluaran per Kategori</h3>
      <div className="space-y-2">
        {CATEGORY_DATA.map(d => (
          <div key={d.name}>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-gray-600 w-24 truncate">{d.name}</span>
              <span className="text-xs font-semibold text-gray-800">{fmtRp(d.value)}</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-2 rounded-full bg-blue-500 transition-all"
                style={{ width: `${(d.value / maxVal) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
      <p className="text-[10px] text-gray-400">6 kategori pengeluaran ditampilkan</p>
    </div>
  );
}

// ── Status Badge ───────────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: "Berjalan" | "Belum Mulai" | "Selesai" }) {
  const cfg: Record<string, string> = {
    Berjalan:     "bg-blue-50 text-blue-700 border-blue-200",
    "Belum Mulai":"bg-gray-50 text-gray-600 border-gray-200",
    Selesai:      "bg-green-50 text-green-700 border-green-200",
  };
  return (
    <span className={`text-[10px] font-semibold border px-1.5 py-0.5 rounded ${cfg[status]}`}>
      {status}
    </span>
  );
}

// ── Tables ─────────────────────────────────────────────────────────────────────
const AGENDA = [
  { aktivitas: "Review materi Akuntansi Keuangan", kategori: "Belajar",   waktu: "09.00", status: "Berjalan" as const },
  { aktivitas: "Mengerjakan latihan TOEFL",          kategori: "Belajar",   waktu: "11.00", status: "Belum Mulai" as const },
  { aktivitas: "Input pengeluaran harian",            kategori: "Keuangan",  waktu: "17.00", status: "Belum Mulai" as const },
  { aktivitas: "Membaca buku 20 halaman",             kategori: "Membaca",   waktu: "19.00", status: "Belum Mulai" as const },
  { aktivitas: "Tulis jurnal harian",                 kategori: "Jurnal",    waktu: "21.00", status: "Belum Mulai" as const },
];

const TRANSAKSI_RECENT = [
  { name: "Makan Siang",          kat: "Makanan",    tgl: "3 Jul 2026",  nominal: -35000 },
  { name: "Transportasi Kampus",  kat: "Transportasi",tgl: "3 Jul 2026", nominal: -22000 },
  { name: "Buku Akuntansi",       kat: "Pendidikan", tgl: "2 Jul 2026",  nominal: -185000 },
  { name: "Uang Saku Bulanan",    kat: "Pemasukan",  tgl: "1 Jul 2026",  nominal: 3000000 },
  { name: "Langganan Internet",   kat: "Tagihan",    tgl: "1 Jul 2026",  nominal: -150000 },
];

// ── Main Component ─────────────────────────────────────────────────────────────
export function DashboardFreeSpace({ topBar }: { topBar: React.ReactNode }) {
  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}

      <div className="px-8 py-6 space-y-6">
        {/* Page Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-sm text-gray-500 mt-1">
              Ringkasan aktivitas, keuangan, pembelajaran, dan progres pribadi.
            </p>
          </div>
          {/* Controls */}
          <div className="flex items-center gap-2 flex-wrap justify-end">
            <FilterDropdown value="Juli 2026"      options={["Juli 2026","Juni 2026","Mei 2026"]} />
            <FilterDropdown value="Semua Akun"     options={["Semua Akun","Bank Utama","E-Wallet"]} />
            <FilterDropdown value="Semua Kategori" options={["Semua Kategori","Makanan","Transportasi","Pendidikan"]} />
            <FilterDropdown value="Semua Modul"    options={["Semua Modul","Keuangan","Produktivitas","Library"]} />
            <QuickAdd />
          </div>
        </div>

        {/* Summary Cards Row 1 */}
        <div className="grid grid-cols-4 gap-4">
          <SummaryCard label="Saldo Bulan Ini"      value="Rp4,85 jt" desc="Saldo seluruh akun aktif"       trend="+8,4% dari bulan lalu"         trendUp status="positive" showBadge />
          <SummaryCard label="Pemasukan Bulan Ini"  value="Rp6,50 jt" desc="Total pemasukan Juli 2026"      trend="+5,2% dari bulan lalu"          trendUp status="positive" showBadge />
          <SummaryCard label="Pengeluaran Bulan Ini"value="Rp3,15 jt" desc="48,5% dari total pemasukan"     trend="Turun 6,8% dari bulan lalu"    trendUp status="positive" showBadge />
          <SummaryCard label="Sisa Budget"          value="Rp1,35 jt" desc="Dari budget Rp4,50 jt"          trend="70% budget digunakan"                 status="warning" showBadge />
        </div>

        {/* Summary Cards Row 2 */}
        <div className="grid grid-cols-4 gap-4">
          <SummaryCard label="Agenda Hari Ini"   value="5"     desc="2 aktivitas telah selesai"               status="primary" />
          <SummaryCard label="Deadline Terdekat" value="3"     desc="Deadline pertama jatuh tempo besok"      status="danger" />
          <SummaryCard label="Progress Membaca"  value="68%"   desc="124 dari 182 halaman"                    status="purple" />
          <SummaryCard label="Target Langkah"    value="7.420" desc="Dari target 10.000 langkah" trend="74,2% target tercapai" trendUp status="positive" />
        </div>

        {/* Ringkasan Hari Ini */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h2 className="text-sm font-semibold text-gray-800 mb-3">Ringkasan Hari Ini</h2>
          <div className="flex flex-col gap-2.5">
            <InsightItem color="green"  text="Kondisi keuangan bulan ini masih aman dengan sisa budget Rp1,35 juta." />
            <InsightItem color="orange" text="Pengeluaran terbesar berasal dari kategori Makanan sebesar 32%." />
            <InsightItem color="red"    text="Terdapat 3 aktivitas yang belum selesai dan satu deadline jatuh tempo besok." />
            <InsightItem color="blue"   text="Progress membaca telah mencapai 68% atau 124 dari 182 halaman." />
            <InsightItem color="orange" text="Jurnal harian hari ini belum diisi." />
            <InsightItem color="green"  text="Target langkah telah mencapai 7.420 dari 10.000 langkah." />
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-3 gap-4">
          <ChartDonut />
          <ChartWeekly />
          <ChartCategoryBar />
        </div>

        {/* Bottom Tables */}
        <div className="grid grid-cols-2 gap-4">
          {/* Agenda */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-gray-800">Agenda & Deadline Terdekat</h3>
              <button className="text-xs text-gray-500 hover:text-gray-800">Lihat Semua</button>
            </div>
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  <th className="px-4 py-2.5 text-left font-medium text-gray-500">Aktivitas</th>
                  <th className="px-3 py-2.5 text-left font-medium text-gray-500">Kategori</th>
                  <th className="px-3 py-2.5 text-left font-medium text-gray-500">Waktu</th>
                  <th className="px-3 py-2.5 text-left font-medium text-gray-500">Status</th>
                </tr>
              </thead>
              <tbody>
                {AGENDA.map((row, i) => (
                  <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-2.5 font-medium text-gray-800 truncate max-w-[140px]">{row.aktivitas}</td>
                    <td className="px-3 py-2.5 text-gray-500">{row.kategori}</td>
                    <td className="px-3 py-2.5 text-gray-500">{row.waktu}</td>
                    <td className="px-3 py-2.5"><StatusBadge status={row.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Transaksi Terbaru */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-gray-800">Transaksi Terbaru</h3>
              <button className="text-xs text-gray-500 hover:text-gray-800">Lihat Semua</button>
            </div>
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  <th className="px-4 py-2.5 text-left font-medium text-gray-500">Transaksi</th>
                  <th className="px-3 py-2.5 text-left font-medium text-gray-500">Kategori</th>
                  <th className="px-3 py-2.5 text-left font-medium text-gray-500">Tanggal</th>
                  <th className="px-3 py-2.5 text-right font-medium text-gray-500">Nominal</th>
                </tr>
              </thead>
              <tbody>
                {TRANSAKSI_RECENT.map((row, i) => (
                  <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-2.5 font-medium text-gray-800 truncate max-w-[120px]">{row.name}</td>
                    <td className="px-3 py-2.5 text-gray-500">{row.kat}</td>
                    <td className="px-3 py-2.5 text-gray-500">{row.tgl}</td>
                    <td className={`px-3 py-2.5 text-right font-semibold ${row.nominal > 0 ? "text-green-600" : "text-red-500"}`}>
                      {row.nominal > 0 ? "+" : ""}{fmtRp(row.nominal)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </main>
  );
}
