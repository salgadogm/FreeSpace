import React, { useState } from "react";
import {
  FilePlus, Upload, Search, MoreHorizontal, CheckCircle2,
  Star, Clock, X, ChevronLeft, ChevronRight, RefreshCw,
  Eye, Download, Copy, Archive, Trash2, Edit3, FileText,
  GripVertical, Plus, AlertCircle, History, LayoutTemplate,
  ArrowLeft, Undo2, Redo2, ZoomIn, ZoomOut, Maximize2,
} from "lucide-react";

// ── Types ──────────────────────────────────────────────────────────────────
type CVStatus = "Aktif" | "Draft" | "Diarsipkan";
type CVTab = "cv-saya" | "template" | "riwayat";
type EditorSection =
  | "Informasi Pribadi" | "Ringkasan Profesional" | "Pendidikan"
  | "Pengalaman" | "Organisasi" | "Proyek" | "Keahlian"
  | "Sertifikasi" | "Bahasa" | "Penghargaan" | "Referensi";

interface CVItem {
  id: number; nama: string; target: string; bahasa: string;
  template: string; kelengkapan: number; ats: number; status: CVStatus;
  updated: string;
}

// ── Data ─────────────────────────────────────────────────────────────────────
const CVS: CVItem[] = [
  { id: 1, nama: "CV Akuntansi 2026",       target: "Junior Accountant",  bahasa: "Bahasa Indonesia", template: "ATS Minimal",       kelengkapan: 92, ats: 82, status: "Aktif", updated: "2 Jul 2026" },
  { id: 2, nama: "CV Finance English",       target: "Finance Intern",     bahasa: "English",          template: "Professional",      kelengkapan: 85, ats: 76, status: "Draft", updated: "1 Jul 2026" },
  { id: 3, nama: "CV General Fresh Graduate",target: "Management Trainee", bahasa: "Bahasa Indonesia", template: "Clean",             kelengkapan: 78, ats: 71, status: "Draft", updated: "28 Jun 2026" },
];

const TEMPLATES = [
  { id: 1, nama: "ATS Minimal",       desc: "Bersih, satu kolom, maksimal kompatibilitas ATS.",             cols: "1 Kolom",   lang: ["Indonesia","English"], ats: true },
  { id: 2, nama: "Clean Professional",desc: "Desain profesional netral, satu kolom, mudah dibaca.",         cols: "1 Kolom",   lang: ["Indonesia","English"], ats: true },
  { id: 3, nama: "Modern Accounting", desc: "Dirancang untuk bidang akuntansi, struktur terorganisir.",     cols: "1 Kolom",   lang: ["Indonesia"],           ats: true },
  { id: 4, nama: "Classic Corporate", desc: "Format korporat klasik, formal, mudah dipindai ATS.",          cols: "1 Kolom",   lang: ["Indonesia","English"], ats: true },
  { id: 5, nama: "Simple Graduate",   desc: "Cocok untuk fresh graduate, tampilan sederhana dan jelas.",   cols: "1 Kolom",   lang: ["Indonesia","English"], ats: true },
];

const VERSIONS = [
  { ver: "v1.4", nama: "CV Akuntansi 2026", perubahan: "Memperbaiki pengalaman organisasi",          tgl: "2 Jul 2026, 20.15", sumber: "Manual" },
  { ver: "v1.3", nama: "CV Akuntansi 2026", perubahan: "Mengoptimalkan keyword Junior Accountant",   tgl: "2 Jul 2026, 18.42", sumber: "ATS Recommendation" },
  { ver: "v1.2", nama: "CV Akuntansi 2026", perubahan: "Menambahkan sertifikasi",                    tgl: "1 Jul 2026, 21.10", sumber: "Manual" },
  { ver: "v1.1", nama: "CV Akuntansi 2026", perubahan: "Draft awal CV",                              tgl: "30 Jun 2026, 09.00", sumber: "Manual" },
];

const EDITOR_SECTIONS: EditorSection[] = [
  "Informasi Pribadi","Ringkasan Profesional","Pendidikan","Pengalaman",
  "Organisasi","Proyek","Keahlian","Sertifikasi","Bahasa","Penghargaan","Referensi",
];

const SECTION_COMPLETENESS: Record<EditorSection, number> = {
  "Informasi Pribadi": 100, "Ringkasan Profesional": 90, "Pendidikan": 100,
  "Pengalaman": 85, "Organisasi": 80, "Proyek": 60, "Keahlian": 95,
  "Sertifikasi": 70, "Bahasa": 100, "Penghargaan": 40, "Referensi": 0,
};

// ── Helpers ───────────────────────────────────────────────────────────────────
function StatusBadge({ s }: { s: CVStatus }) {
  const cfg = {
    Aktif:       "bg-green-50 text-green-700",
    Draft:       "bg-amber-50 text-amber-600",
    Diarsipkan:  "bg-gray-100 text-gray-400",
  }[s];
  return <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${cfg}`}>{s}</span>;
}

function SummaryCard({ label, value, desc, color, icon: Icon }: {
  label: string; value: string | number; desc: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
          style={{ backgroundColor: color + "18", color }}>
          <Icon size={16} />
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 leading-tight">{value}</p>
      <p className="text-[11px] text-gray-400 leading-snug">{desc}</p>
    </div>
  );
}

function RowMenu({ items }: { items: { label: string; danger?: boolean; onClick: () => void }[] }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={e => { e.stopPropagation(); setOpen(!open); }}
        className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors">
        <MoreHorizontal size={14} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-gray-200 rounded-xl shadow-lg z-20 py-1">
            {items.map(item => (
              <button key={item.label} onClick={() => { item.onClick(); setOpen(false); }}
                className={`w-full flex items-center gap-2 px-3 py-2 text-xs transition-colors ${item.danger ? "text-red-600 hover:bg-red-50" : "text-gray-700 hover:bg-gray-50"}`}>
                {item.label}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ── Buat CV Modal ─────────────────────────────────────────────────────────────
function BuatCVModal({ onClose, showToast }: { onClose: () => void; showToast?: (m: string) => void }) {
  const [step, setStep] = useState(1);
  const [nama, setNama]     = useState("");
  const [target, setTarget] = useState("Junior Accountant");
  const [bahasa, setBahasa] = useState("Bahasa Indonesia");
  const [tmpl, setTmpl]     = useState("ATS Minimal");
  const [sumber, setSumber] = useState("Mulai dari Kosong");
  const [creating, setCreating] = useState(false);

  const handleCreate = () => {
    setCreating(true);
    setTimeout(() => { showToast?.("CV berhasil dibuat."); onClose(); }, 800);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[520px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div>
            <h2 className="text-sm font-bold text-gray-900">Buat CV Baru</h2>
            <p className="text-xs text-gray-400">Langkah {step} dari 3</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>

        {/* Step indicator */}
        <div className="flex items-center gap-2 px-5 pt-4">
          {["Informasi Awal","Pilih Sumber","Konfirmasi"].map((s, i) => (
            <React.Fragment key={s}>
              <div className={`flex items-center justify-center w-6 h-6 rounded-full text-[10px] font-bold shrink-0 ${step > i ? "bg-gray-900 text-white" : step === i+1 ? "border-2 border-gray-900 text-gray-900" : "bg-gray-100 text-gray-400"}`}>{i+1}</div>
              <span className={`text-xs ${step === i+1 ? "font-semibold text-gray-800" : "text-gray-400"}`}>{s}</span>
              {i < 2 && <div className={`flex-1 h-0.5 ${step > i+1 ? "bg-gray-900" : "bg-gray-100"}`} />}
            </React.Fragment>
          ))}
        </div>

        <div className="p-5 space-y-4">
          {step === 1 && (
            <>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Nama CV <span className="text-red-500">*</span></label>
                <input value={nama} onChange={e => setNama(e.target.value)} placeholder="contoh: CV Junior Accountant 2026"
                  className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Target Posisi</label>
                <input value={target} onChange={e => setTarget(e.target.value)}
                  className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">Bahasa</label>
                  <select value={bahasa} onChange={e => setBahasa(e.target.value)}
                    className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                    <option>Bahasa Indonesia</option><option>English</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">Template</label>
                  <select value={tmpl} onChange={e => setTmpl(e.target.value)}
                    className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                    {TEMPLATES.map(t => <option key={t.id}>{t.nama}</option>)}
                  </select>
                </div>
              </div>
            </>
          )}
          {step === 2 && (
            <div className="space-y-2">
              {["Mulai dari Kosong","Duplikat CV Lama","Import CV","Gunakan Data Profil"].map(s => (
                <button key={s} onClick={() => setSumber(s)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 text-left transition-all ${sumber === s ? "border-gray-900 bg-gray-50" : "border-gray-200 hover:border-gray-300"}`}>
                  <div className={`w-4 h-4 rounded-full border-2 shrink-0 ${sumber === s ? "bg-gray-900 border-gray-900" : "border-gray-300"}`} />
                  <span className="text-sm font-medium text-gray-800">{s}</span>
                </button>
              ))}
            </div>
          )}
          {step === 3 && (
            <div className="bg-gray-50 rounded-xl p-4 space-y-2">
              {[["Nama CV", nama || "–"],["Target Posisi", target],["Bahasa", bahasa],["Template", tmpl],["Sumber", sumber]].map(([k,v]) => (
                <div key={k} className="flex justify-between py-1 border-b border-gray-100 last:border-0">
                  <span className="text-xs text-gray-500">{k}</span>
                  <span className="text-xs font-medium text-gray-800">{v}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-between">
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <div className="flex gap-2">
            {step > 1 && <button onClick={() => setStep(step - 1)} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Kembali</button>}
            {step < 3
              ? <button onClick={() => setStep(step + 1)} disabled={step === 1 && !nama.trim()}
                  className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-50">Lanjutkan</button>
              : <button onClick={handleCreate} disabled={creating}
                  className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-70 flex items-center gap-2">
                  {creating ? <><RefreshCw size={13} className="animate-spin" /> Membuat...</> : "Buat CV"}
                </button>
            }
          </div>
        </div>
      </div>
    </>
  );
}

// ── CV Card ───────────────────────────────────────────────────────────────────
function CVCard({ cv, onEdit, showToast }: {
  cv: CVItem; onEdit: (cv: CVItem) => void; showToast?: (m: string) => void;
}) {
  return (
    <div className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:border-gray-300 hover:shadow-sm transition-all group">
      {/* Thumbnail */}
      <div className="h-32 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center border-b border-gray-100 relative">
        <FileText size={36} className="text-gray-300" />
        {cv.status === "Aktif" && (
          <span className="absolute top-2 left-2 text-[9px] font-bold bg-green-500 text-white px-1.5 py-0.5 rounded-full">AKTIF</span>
        )}
        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <RowMenu items={[
            { label: "Edit CV",        onClick: () => onEdit(cv) },
            { label: "Preview",        onClick: () => {} },
            { label: "Analisis ATS",   onClick: () => {} },
            { label: "Duplikat",       onClick: () => {} },
            { label: "Export PDF",     onClick: () => {} },
            { label: "Export Word",    onClick: () => {} },
            { label: "Jadikan CV Aktif",onClick: () => {} },
            { label: "Arsipkan",       onClick: () => {} },
            { label: "Hapus",          onClick: () => {}, danger: true },
          ]} />
        </div>
      </div>
      {/* Info */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-gray-900 truncate">{cv.nama}</p>
            <p className="text-xs text-gray-500 mt-0.5">{cv.target}</p>
          </div>
          <StatusBadge s={cv.status} />
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[10px]">
            <span className="text-gray-400">Kelengkapan</span>
            <span className="font-semibold text-gray-700">{cv.kelengkapan}%</span>
          </div>
          <div className="bg-gray-100 rounded-full h-1.5 overflow-hidden">
            <div className="h-1.5 rounded-full bg-gray-900 transition-all" style={{ width: `${cv.kelengkapan}%` }} />
          </div>
          <div className="flex items-center justify-between text-[10px] pt-1">
            <span className="text-gray-400">ATS Score</span>
            <span className={`font-bold ${cv.ats >= 80 ? "text-green-600" : cv.ats >= 70 ? "text-amber-600" : "text-red-500"}`}>{cv.ats}</span>
          </div>
          <div className="flex items-center justify-between text-[10px]">
            <span className="text-gray-400">{cv.bahasa} • {cv.template}</span>
            <span className="text-gray-300">{cv.updated}</span>
          </div>
        </div>
        <button onClick={() => onEdit(cv)}
          className="mt-3 w-full flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
          <Edit3 size={12} /> Edit CV
        </button>
      </div>
    </div>
  );
}

// ── CV Editor ─────────────────────────────────────────────────────────────────
function CVEditor({ cv, onBack }: { cv: CVItem; onBack: () => void }) {
  const [activeSection, setActiveSection] = useState<EditorSection>("Informasi Pribadi");
  const [autosaved, setAutosaved] = useState(true);
  const [zoom, setZoom] = useState(80);
  const [showExport, setShowExport] = useState(false);

  return (
    <div className="flex flex-col h-full">
      {/* Editor topbar */}
      <div className="bg-white border-b border-gray-200 px-4 py-2.5 flex items-center gap-3 shrink-0">
        <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-gray-800 transition-colors">
          <ArrowLeft size={14} /> CV Saya
        </button>
        <div className="w-px h-4 bg-gray-200" />
        <span className="text-sm font-semibold text-gray-900 flex-1">{cv.nama}</span>
        <span className="flex items-center gap-1 text-[10px] text-gray-400">
          {autosaved ? <><CheckCircle2 size={11} className="text-green-500" /> Tersimpan otomatis</> : <><RefreshCw size={11} className="animate-spin" /> Menyimpan...</>}
        </span>
        <div className="flex items-center gap-1">
          <button className="p-1.5 rounded hover:bg-gray-100 text-gray-400 transition-colors"><Undo2 size={14} /></button>
          <button className="p-1.5 rounded hover:bg-gray-100 text-gray-400 transition-colors"><Redo2 size={14} /></button>
        </div>
        <div className="w-px h-4 bg-gray-200" />
        <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50 transition-colors">
          <Eye size={12} /> Preview
        </button>
        <button onClick={() => setShowExport(true)}
          className="flex items-center gap-1.5 text-xs text-white bg-gray-900 px-3 py-1.5 rounded-lg hover:bg-black transition-colors">
          <Download size={12} /> Export
        </button>
      </div>

      {/* 3-column layout */}
      <div className="flex flex-1 overflow-hidden min-h-0">
        {/* Left: Section Navigator */}
        <div className="w-52 shrink-0 bg-white border-r border-gray-100 overflow-y-auto py-3 px-2">
          <p className="text-[9px] font-semibold uppercase tracking-widest text-gray-400 px-2 mb-2">Bagian CV</p>
          {EDITOR_SECTIONS.map(s => {
            const pct = SECTION_COMPLETENESS[s];
            const active = activeSection === s;
            return (
              <button key={s} onClick={() => setActiveSection(s)}
                className={`w-full flex items-center gap-2 px-2 py-2 rounded-lg text-left transition-colors mb-0.5 ${active ? "bg-gray-100" : "hover:bg-gray-50"}`}>
                <GripVertical size={12} className="text-gray-300 shrink-0 cursor-grab" />
                <div className="flex-1 min-w-0">
                  <span className={`text-xs ${active ? "font-semibold text-gray-900" : "text-gray-600"} truncate block`}>{s}</span>
                </div>
                {pct === 100
                  ? <CheckCircle2 size={11} className="text-green-500 shrink-0" />
                  : pct === 0
                  ? <div className="w-2.5 h-2.5 rounded-full border border-gray-300 shrink-0" />
                  : <span className="text-[9px] text-gray-400 shrink-0">{pct}%</span>
                }
              </button>
            );
          })}
          <button className="w-full flex items-center gap-2 px-2 py-2 rounded-lg text-left text-gray-400 hover:text-gray-600 transition-colors mt-2">
            <Plus size={12} /> <span className="text-xs">Tambah Bagian</span>
          </button>
        </div>

        {/* Center: Form editor */}
        <div className="flex-1 overflow-y-auto bg-gray-50 p-5 min-w-0">
          <h2 className="text-sm font-bold text-gray-900 mb-4">{activeSection}</h2>

          {activeSection === "Informasi Pribadi" && (
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                {[
                  ["Nama Lengkap","Salgado Ginting"],
                  ["Headline Profesional","Mahasiswa Akuntansi | Junior Accountant"],
                  ["Email","salgadoginting@example.com"],
                  ["Nomor Telepon","+62 812 3456 7890"],
                  ["Kota dan Negara","Bogor, Indonesia"],
                  ["LinkedIn","linkedin.com/in/salgadoginting"],
                ].map(([label, val]) => (
                  <div key={label}>
                    <label className="block text-xs font-medium text-gray-700 mb-1">{label}</label>
                    <input defaultValue={val} className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
                  </div>
                ))}
              </div>
              <div className="bg-blue-50 border border-blue-100 rounded-lg p-2.5 text-xs text-blue-700 flex items-start gap-1.5">
                <AlertCircle size={12} className="shrink-0 mt-0.5" />
                Masukkan hanya informasi yang relevan. Foto tidak wajib.
              </div>
            </div>
          )}

          {activeSection === "Ringkasan Profesional" && (
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 space-y-3">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-gray-500">40–80 kata dianjurkan</span>
                <span className="text-[10px] font-semibold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">Ideal</span>
              </div>
              <textarea rows={5} defaultValue="Mahasiswa Akuntansi semester akhir dengan pemahaman kuat dalam prinsip akuntansi dasar, analisis laporan keuangan, dan penggunaan Microsoft Excel. Terbiasa bekerja secara teliti dan terstruktur. Mencari posisi Junior Accountant untuk mengembangkan kemampuan dan berkontribusi bagi tim keuangan."
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none leading-relaxed" />
              <div className="flex gap-2">
                {["Buat Lebih Ringkas","Buat Lebih Profesional","Perbaiki Tata Bahasa"].map(a => (
                  <button key={a} className="flex items-center gap-1.5 text-xs text-purple-600 bg-purple-50 border border-purple-100 px-2.5 py-1.5 rounded-lg hover:bg-purple-100 transition-colors">
                    ✨ {a}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-gray-400">Hasil AI bersifat saran — Anda harus mengkonfirmasi sebelum diterapkan.</p>
            </div>
          )}

          {activeSection === "Pendidikan" && (
            <div className="space-y-3">
              <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-gray-800">Pendidikan 1</p>
                  <div className="flex gap-1">
                    <button className="text-xs text-gray-400 hover:text-gray-600 px-2 py-1 hover:bg-gray-100 rounded transition-colors">Duplikat</button>
                    <button className="text-xs text-red-400 hover:text-red-600 px-2 py-1 hover:bg-red-50 rounded transition-colors">Hapus</button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    ["Institusi","Universitas Contoh Indonesia"],
                    ["Program Studi","Akuntansi"],
                    ["Jenjang","S1"],
                    ["Lokasi","Bogor"],
                  ].map(([l,v]) => (
                    <div key={l}>
                      <label className="block text-xs font-medium text-gray-700 mb-1">{l}</label>
                      <input defaultValue={v} className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
                    </div>
                  ))}
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Tanggal Mulai</label>
                    <input type="month" defaultValue="2022-08" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Tanggal Selesai</label>
                    <input type="month" defaultValue="2026-07" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">IPK (opsional)</label>
                    <input defaultValue="3.72" type="number" step="0.01" max="4" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
                  </div>
                </div>
              </div>
              <button className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed border-gray-200 rounded-xl text-xs text-gray-500 hover:border-gray-300 hover:text-gray-700 transition-colors">
                <Plus size={13} /> Tambah Pendidikan
              </button>
            </div>
          )}

          {activeSection === "Pengalaman" && (
            <div className="space-y-3">
              <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 text-xs text-amber-700 flex items-start gap-1.5">
                <AlertCircle size={12} className="shrink-0 mt-0.5" />
                Gunakan kata kerja aktif dan hasil yang terukur. AI hanya membantu menyusun ulang informasi yang Anda berikan.
              </div>
              <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 space-y-3">
                <p className="text-xs font-semibold text-gray-800">Pengalaman 1</p>
                <div className="grid grid-cols-2 gap-3">
                  {[["Nama Perusahaan","PT Contoh Indonesia"],["Posisi","Magang Akuntansi"]].map(([l,v]) => (
                    <div key={l}>
                      <label className="block text-xs font-medium text-gray-700 mb-1">{l}</label>
                      <input defaultValue={v} className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
                    </div>
                  ))}
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Deskripsi (bullet)</label>
                  <textarea rows={4} defaultValue="• Membantu penyusunan laporan keuangan bulanan&#10;• Melakukan rekonsiliasi bank&#10;• Memverifikasi jurnal umum"
                    className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none font-mono" />
                </div>
                <button className="flex items-center gap-1.5 text-xs text-purple-600 bg-purple-50 border border-purple-100 px-2.5 py-1.5 rounded-lg hover:bg-purple-100 transition-colors">
                  ✨ Optimalkan Bullet
                </button>
              </div>
              <button className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed border-gray-200 rounded-xl text-xs text-gray-500 hover:border-gray-300 transition-colors">
                <Plus size={13} /> Tambah Pengalaman
              </button>
            </div>
          )}

          {activeSection === "Keahlian" && (
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 space-y-4">
              {[
                { group: "Accounting Skills", skills: ["Financial Reporting","General Ledger","Journal Entries","Financial Analysis","Budgeting","Tax Basics","Audit Basics"] },
                { group: "Software",           skills: ["Microsoft Excel","Microsoft Word","Google Sheets","Accounting Software"] },
                { group: "Soft Skills",        skills: ["Komunikasi","Kerja Tim","Manajemen Waktu","Detail-Oriented"] },
              ].map(g => (
                <div key={g.group}>
                  <p className="text-xs font-semibold text-gray-700 mb-2">{g.group}</p>
                  <div className="flex flex-wrap gap-2">
                    {g.skills.map(s => (
                      <span key={s} className="flex items-center gap-1.5 text-xs bg-gray-100 text-gray-700 px-3 py-1.5 rounded-lg">
                        {s} <button className="text-gray-400 hover:text-red-500 transition-colors"><X size={10} /></button>
                      </span>
                    ))}
                    <button className="text-xs text-gray-400 border border-dashed border-gray-200 px-3 py-1.5 rounded-lg hover:border-gray-300 hover:text-gray-600 transition-colors">+ Tambah</button>
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1.5">Jangan gunakan progress bar — cukup daftarkan skill yang Anda kuasai.</p>
                </div>
              ))}
            </div>
          )}

          {!["Informasi Pribadi","Ringkasan Profesional","Pendidikan","Pengalaman","Keahlian"].includes(activeSection) && (
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-8 text-center">
              <Plus size={24} className="text-gray-200 mx-auto mb-2" />
              <p className="text-sm text-gray-500 mb-3">Belum ada data untuk bagian <strong>{activeSection}</strong>.</p>
              <button className="inline-flex items-center gap-2 text-xs font-semibold text-white bg-gray-900 px-4 py-2 rounded-lg hover:bg-black transition-colors">
                <Plus size={13} /> Tambah {activeSection}
              </button>
            </div>
          )}
        </div>

        {/* Right: Preview */}
        <div className="w-72 shrink-0 bg-gray-100 border-l border-gray-200 flex flex-col overflow-hidden">
          {/* Preview controls */}
          <div className="bg-white border-b border-gray-200 px-3 py-2 flex items-center gap-2">
            <span className="text-xs text-gray-500 flex-1">Preview</span>
            <button onClick={() => setZoom(Math.max(50, zoom - 10))} className="p-1 rounded hover:bg-gray-100 text-gray-400"><ZoomOut size={12} /></button>
            <span className="text-[10px] font-mono text-gray-500 w-8 text-center">{zoom}%</span>
            <button onClick={() => setZoom(Math.min(150, zoom + 10))} className="p-1 rounded hover:bg-gray-100 text-gray-400"><ZoomIn size={12} /></button>
            <button className="p-1 rounded hover:bg-gray-100 text-gray-400"><Maximize2 size={12} /></button>
          </div>
          {/* A4 preview */}
          <div className="flex-1 overflow-y-auto p-3 flex justify-center">
            <div className="bg-white shadow-md rounded" style={{ width: `${(210 * zoom) / 100 * 0.75}px`, minHeight: `${(297 * zoom) / 100 * 0.75}px`, padding: `${(12 * zoom) / 100}px`, fontSize: `${(8 * zoom) / 100}px` }}>
              <div className="text-center pb-2 border-b border-gray-200 mb-2">
                <p className="font-bold" style={{ fontSize: `${(11 * zoom) / 100}px` }}>Salgado Ginting</p>
                <p className="text-gray-500" style={{ fontSize: `${(8 * zoom) / 100}px` }}>Mahasiswa Akuntansi | Junior Accountant</p>
                <p className="text-gray-400" style={{ fontSize: `${(7 * zoom) / 100}px` }}>salgadoginting@example.com • +62 812 3456 7890 • Bogor</p>
              </div>
              {["Ringkasan Profesional","Pendidikan","Pengalaman","Keahlian"].map(section => (
                <div key={section} className="mb-2">
                  <p className="font-bold border-b border-gray-300 pb-0.5 mb-1" style={{ fontSize: `${(8.5 * zoom) / 100}px` }}>{section.toUpperCase()}</p>
                  <div className="bg-gray-50 rounded" style={{ height: `${(20 * zoom) / 100}px` }} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Export Modal */}
      {showExport && (
        <>
          <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={() => setShowExport(false)} />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[420px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <h2 className="text-sm font-bold text-gray-900">Export CV</h2>
              <button onClick={() => setShowExport(false)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-2">Format</label>
                <div className="flex gap-2">
                  {["PDF","Word DOCX"].map(f => (
                    <button key={f} className="flex-1 py-2.5 text-xs font-semibold bg-gray-900 text-white rounded-lg">{f}</button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Nama File</label>
                <input defaultValue="Salgado_Ginting_CV_Junior_Accountant_2026" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
              </div>
              <div className="space-y-2">
                {[["ATS-Safe Mode","Menghapus elemen non-teks untuk kompatibilitas ATS"],["Include Hyperlinks","Menyertakan tautan LinkedIn dan portfolio"]].map(([label,desc]) => (
                  <label key={label} className="flex items-start gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="mt-0.5" />
                    <div>
                      <p className="text-xs font-medium text-gray-800">{label}</p>
                      <p className="text-[10px] text-gray-400">{desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>
            <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
              <button onClick={() => setShowExport(false)} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
              <button onClick={() => setShowExport(false)} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors flex items-center gap-2">
                <Download size={13} /> Export
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function CVBuilderPage({ topBar }: { topBar?: React.ReactNode }) {
  const [tab, setTab]           = useState<CVTab>("cv-saya");
  const [editingCV, setEditingCV] = useState<CVItem | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [search, setSearch]     = useState("");
  const [filterStatus, setFilterStatus] = useState("Semua Status");
  const showToast = (msg: string) => console.log(msg);

  // When editing, show full-page editor (replaces content area)
  if (editingCV) {
    return (
      <main className="flex-1 overflow-hidden bg-gray-50 min-w-0 flex flex-col">
        <CVEditor cv={editingCV} onBack={() => setEditingCV(null)} />
      </main>
    );
  }

  const filtered = CVS.filter(cv => {
    const q = search.toLowerCase();
    return (!q || cv.nama.toLowerCase().includes(q)) &&
      (filterStatus === "Semua Status" || cv.status === filterStatus);
  });

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">CV Builder</h1>
            <p className="text-xs text-gray-500 mt-0.5">Buat, kelola, dan export CV profesional yang ramah ATS.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
              <Upload size={13} /> Import CV
            </button>
            <button onClick={() => setShowCreate(true)}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors shadow-sm">
              <FilePlus size={13} /> Buat CV Baru
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <SummaryCard label="Total CV"          value={3}                   desc="Versi CV tersimpan"             color="#111827" icon={FileText} />
          <SummaryCard label="CV Aktif"           value="CV Akuntansi 2026"   desc="Diperbarui 2 Jul 2026"          color="#3B82F6" icon={Star} />
          <SummaryCard label="Kelengkapan"        value="92%"                 desc="2 bagian perlu dilengkapi"      color="#22C55E" icon={CheckCircle2} />
          <SummaryCard label="ATS Score Terakhir" value={82}                  desc="Cocok untuk Junior Accountant"  color="#22C55E" icon={FileSearch} />
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {([["cv-saya","CV Saya",FileText], ["template","Template",LayoutTemplate], ["riwayat","Riwayat Versi",History]] as const).map(([id, label, Icon]) => (
            <button key={id} onClick={() => setTab(id as CVTab)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${tab === id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              <Icon size={13} /> {label}
            </button>
          ))}
        </div>

        {/* CV Saya */}
        {tab === "cv-saya" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative flex-1 min-w-[200px]">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari nama CV..."
                  className="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-lg outline-none bg-white" />
              </div>
              <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
                className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
                {["Semua Status","Draft","Aktif","Diarsipkan"].map(s => <option key={s}>{s}</option>)}
              </select>
              <select className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
                {["Terakhir Diperbarui","Terbaru Dibuat","Nama A–Z","ATS Score Tertinggi"].map(s => <option key={s}>{s}</option>)}
              </select>
            </div>

            {filtered.length === 0 ? (
              <div className="bg-white border border-gray-200 rounded-xl p-12 text-center">
                <FilePlus size={32} className="text-gray-200 mx-auto mb-3" />
                <p className="text-sm font-semibold text-gray-700 mb-1">Belum ada CV</p>
                <p className="text-xs text-gray-400 mb-4">Buat CV pertama untuk mulai mempersiapkan lamaran kerja Anda.</p>
                <button onClick={() => setShowCreate(true)}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
                  <FilePlus size={13} /> Buat CV Baru
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-4">
                {filtered.map(cv => <CVCard key={cv.id} cv={cv} onEdit={setEditingCV} showToast={showToast} />)}
              </div>
            )}
          </div>
        )}

        {/* Template */}
        {tab === "template" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 flex-wrap">
              {["ATS Friendly","1 Kolom","2 Kolom","Bahasa Indonesia","English"].map(f => (
                <button key={f} className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-gray-600 transition-colors">{f}</button>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-4">
              {TEMPLATES.map(t => (
                <div key={t.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:border-gray-300 hover:shadow-sm transition-all group">
                  <div className="h-36 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center border-b border-gray-100">
                    <div className="bg-white shadow-sm rounded-lg p-3 w-28">
                      <div className="h-2 bg-gray-200 rounded mb-1.5 w-3/4 mx-auto" />
                      <div className="h-1 bg-gray-100 rounded mb-1" />
                      <div className="h-1 bg-gray-100 rounded mb-2 w-4/5" />
                      <div className="h-1.5 bg-gray-200 rounded mb-1" />
                      <div className="space-y-0.5">
                        {[1,2,3].map(i => <div key={i} className="h-1 bg-gray-100 rounded" />)}
                      </div>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-1 mb-1">
                      <p className="text-sm font-semibold text-gray-900">{t.nama}</p>
                      {t.ats && <span className="text-[9px] font-bold bg-green-50 text-green-600 px-1.5 py-0.5 rounded-full shrink-0">ATS Friendly</span>}
                    </div>
                    <p className="text-xs text-gray-500 mb-2">{t.desc}</p>
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-[10px] text-gray-400 bg-gray-100 px-2 py-0.5 rounded">{t.cols}</span>
                      {t.lang.map(l => <span key={l} className="text-[10px] text-gray-400 bg-gray-100 px-2 py-0.5 rounded">{l}</span>)}
                    </div>
                    <button onClick={() => setShowCreate(true)}
                      className="w-full py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
                      Gunakan Template
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Riwayat Versi */}
        {tab === "riwayat" && (
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50/70">
                  {["Versi","Nama CV","Perubahan","Tanggal","Sumber","Aksi"].map(h => (
                    <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {VERSIONS.map(v => (
                  <tr key={v.ver} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                    <td className="py-3 px-4">
                      <span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">{v.ver}</span>
                    </td>
                    <td className="py-3 px-4 text-xs font-medium text-gray-800">{v.nama}</td>
                    <td className="py-3 px-4 text-xs text-gray-600 max-w-[200px]"><span className="truncate block">{v.perubahan}</span></td>
                    <td className="py-3 px-4 text-xs text-gray-400 whitespace-nowrap">{v.tgl}</td>
                    <td className="py-3 px-4">
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${v.sumber === "Manual" ? "bg-gray-100 text-gray-600" : "bg-purple-50 text-purple-600"}`}>{v.sumber}</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1">
                        <button className="text-xs text-gray-500 border border-gray-200 px-2 py-1 rounded hover:bg-gray-50 transition-colors">Preview</button>
                        <button className="text-xs text-gray-500 border border-gray-200 px-2 py-1 rounded hover:bg-gray-50 transition-colors">Bandingkan</button>
                        <button className="text-xs text-blue-600 border border-blue-100 px-2 py-1 rounded hover:bg-blue-50 transition-colors">Pulihkan</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showCreate && <BuatCVModal onClose={() => setShowCreate(false)} showToast={showToast} />}
    </main>
  );
}

// Needed for SummaryCard icon
const FileSearch = ({ size, className }: { size?: number; className?: string }) => (
  <svg width={size || 16} height={size || 16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
    <polyline points="14 2 14 8 20 8" />
    <circle cx="11" cy="15" r="2" />
    <path d="m13.3 17.3 2.4 2.4" />
  </svg>
);
