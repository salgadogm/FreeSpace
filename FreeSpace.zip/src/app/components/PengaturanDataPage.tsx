import React, { useState } from "react";
import {
  Plus, Edit3, Trash2, MoreHorizontal, X, AlertTriangle,
  RefreshCw, CheckCircle2, Circle,
} from "lucide-react";

type DataTab = "keuangan" | "produktivitas" | "library" | "akuntansi";

// ── Helpers ───────────────────────────────────────────────────────────────────
function StatusBadge({ active }: { active: boolean }) {
  return (
    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${active ? "bg-green-50 text-green-600" : "bg-gray-100 text-gray-400"}`}>
      {active ? "Aktif" : "Nonaktif"}
    </span>
  );
}

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)}
      className={`w-9 h-5 rounded-full relative transition-colors shrink-0 ${value ? "bg-gray-900" : "bg-gray-200"}`}>
      <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${value ? "left-[18px]" : "left-0.5"}`} />
    </button>
  );
}

function SectionHeader({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
      {action && (
        <button onClick={onAction}
          className="flex items-center gap-1.5 text-xs font-semibold text-gray-700 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50 transition-colors">
          <Plus size={12} /> {action}
        </button>
      )}
    </div>
  );
}

function TableWrapper({ children }: { children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden mb-5">
      <div className="overflow-x-auto">
        <table className="w-full">{children}</table>
      </div>
    </div>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return <th className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap bg-gray-50/70 border-b border-gray-100">{children}</th>;
}

function Td({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <td className={`py-3 px-4 border-b border-gray-50 ${className}`}>{children}</td>;
}

function RowMenu({ items }: { items: { label: string; danger?: boolean; onClick: () => void }[] }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors"><MoreHorizontal size={14} /></button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 w-44 bg-white border border-gray-200 rounded-xl shadow-lg z-20 py-1 overflow-hidden">
            {items.map(item => (
              <button key={item.label} onClick={() => { item.onClick(); setOpen(false); }}
                className={`w-full flex items-center gap-2 px-3 py-2 text-xs transition-colors ${item.danger ? "text-red-600 hover:bg-red-50" : "text-gray-700 hover:bg-gray-50"}`}>
                {item.label}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ── Add Modal ─────────────────────────────────────────────────────────────────
function AddModal({ title, fields, onClose, showToast }: {
  title: string;
  fields: { label: string; type?: string; placeholder?: string; required?: boolean }[];
  onClose: () => void;
  showToast?: (msg: string) => void;
}) {
  const [saving, setSaving] = useState(false);
  const handleSave = () => {
    setSaving(true);
    setTimeout(() => { setSaving(false); showToast?.("Data berhasil disimpan."); onClose(); }, 700);
  };
  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[420px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">{title}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>
        <div className="p-5 space-y-3">
          {fields.map(f => (
            <div key={f.label}>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">
                {f.label} {f.required && <span className="text-red-500">*</span>}
              </label>
              <input type={f.type || "text"} placeholder={f.placeholder || f.label}
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
            </div>
          ))}
        </div>
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <button onClick={handleSave} disabled={saving}
            className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-70 flex items-center gap-2">
            {saving ? <><RefreshCw size={13} className="animate-spin" /> Menyimpan...</> : "Simpan"}
          </button>
        </div>
      </div>
    </>
  );
}

// ── TAB KEUANGAN ──────────────────────────────────────────────────────────────
const AKUN_DATA = [
  { id: 1, nama: "Bank Utama",  jenis: "Bank",           saldo: "Rp1.500.000", aktif: true,  default: true },
  { id: 2, nama: "E-Wallet",   jenis: "Dompet Digital",  saldo: "Rp500.000",  aktif: true,  default: false },
  { id: 3, nama: "Tunai",      jenis: "Kas",             saldo: "Rp250.000",  aktif: true,  default: false },
];

const KATEGORI_DATA = [
  { id: 1, nama: "Makanan",      tipe: "Pengeluaran", digunakan: 18, aktif: true },
  { id: 2, nama: "Transportasi", tipe: "Pengeluaran", digunakan: 12, aktif: true },
  { id: 3, nama: "Pendidikan",   tipe: "Pengeluaran", digunakan: 6,  aktif: true },
  { id: 4, nama: "Uang Saku",    tipe: "Pemasukan",   digunakan: 3,  aktif: true },
  { id: 5, nama: "Freelance",    tipe: "Pemasukan",   digunakan: 2,  aktif: true },
];

function KeuanganTab({ showToast }: { showToast?: (msg: string) => void }) {
  const [modal, setModal] = useState<"akun" | "kategori" | null>(null);

  return (
    <div className="space-y-6">
      {/* Akun & Sumber Dana */}
      <div>
        <SectionHeader title="Akun & Sumber Dana" action="Tambah Akun" onAction={() => setModal("akun")} />
        <TableWrapper>
          <thead><tr>{["Nama Akun","Jenis","Saldo Awal","Status","Default","Aksi"].map(h => <Th key={h}>{h}</Th>)}</tr></thead>
          <tbody>
            {AKUN_DATA.map(a => (
              <tr key={a.id} className="hover:bg-gray-50 transition-colors">
                <Td><span className="text-sm font-medium text-gray-800">{a.nama}</span></Td>
                <Td><span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded">{a.jenis}</span></Td>
                <Td><span className="text-sm text-gray-700">{a.saldo}</span></Td>
                <Td><StatusBadge active={a.aktif} /></Td>
                <Td>{a.default && <span className="text-[10px] font-semibold bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">Default</span>}</Td>
                <Td>
                  <RowMenu items={[
                    { label: "Edit", onClick: () => setModal("akun") },
                    { label: "Jadikan Default", onClick: () => {} },
                    { label: "Nonaktifkan", onClick: () => {} },
                  ]} />
                </Td>
              </tr>
            ))}
          </tbody>
        </TableWrapper>
      </div>

      {/* Kategori Transaksi */}
      <div>
        <SectionHeader title="Kategori Transaksi" action="Tambah Kategori" onAction={() => setModal("kategori")} />
        <TableWrapper>
          <thead><tr>{["Nama","Tipe","Digunakan","Status","Aksi"].map(h => <Th key={h}>{h}</Th>)}</tr></thead>
          <tbody>
            {KATEGORI_DATA.map(k => (
              <tr key={k.id} className="hover:bg-gray-50 transition-colors">
                <Td><span className="text-sm font-medium text-gray-800">{k.nama}</span></Td>
                <Td>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${k.tipe === "Pemasukan" ? "bg-green-50 text-green-600" : "bg-red-50 text-red-500"}`}>{k.tipe}</span>
                </Td>
                <Td><span className="text-xs text-gray-500">{k.digunakan} transaksi</span></Td>
                <Td><StatusBadge active={k.aktif} /></Td>
                <Td>
                  <RowMenu items={[
                    { label: "Edit", onClick: () => setModal("kategori") },
                    { label: "Gabungkan Kategori", onClick: () => {} },
                    { label: "Nonaktifkan", onClick: () => {} },
                    { label: "Hapus", onClick: () => {}, danger: true },
                  ]} />
                </Td>
              </tr>
            ))}
          </tbody>
        </TableWrapper>
        <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 flex items-start gap-2">
          <AlertTriangle size={13} className="text-amber-500 shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700">Kategori yang sudah digunakan oleh transaksi hanya dapat dinonaktifkan atau digabungkan, tidak dapat dihapus langsung.</p>
        </div>
      </div>

      {modal === "akun" && (
        <AddModal title="Tambah Akun" onClose={() => setModal(null)} showToast={showToast}
          fields={[
            { label: "Nama Akun", required: true },
            { label: "Jenis", placeholder: "Bank, Kas, Dompet Digital..." },
            { label: "Saldo Awal", type: "number" },
          ]} />
      )}
      {modal === "kategori" && (
        <AddModal title="Tambah Kategori" onClose={() => setModal(null)} showToast={showToast}
          fields={[
            { label: "Nama Kategori", required: true },
            { label: "Tipe", placeholder: "Pemasukan atau Pengeluaran" },
          ]} />
      )}
    </div>
  );
}

// ── TAB PRODUKTIVITAS ─────────────────────────────────────────────────────────
const KATEGORI_AKTIVITAS = [
  { id: 1, nama: "Belajar",   icon: "📚", warna: "#3B82F6", jumlah: 12, aktif: true },
  { id: 2, nama: "Keuangan",  icon: "💰", warna: "#22C55E", jumlah: 8,  aktif: true },
  { id: 3, nama: "Membaca",   icon: "📖", warna: "#8B5CF6", jumlah: 5,  aktif: true },
  { id: 4, nama: "Jurnal",    icon: "✏️", warna: "#F59E0B", jumlah: 4,  aktif: true },
  { id: 5, nama: "Pribadi",   icon: "🙂", warna: "#6B7280", jumlah: 3,  aktif: true },
  { id: 6, nama: "Kesehatan", icon: "💪", warna: "#0D9488", jumlah: 2,  aktif: true },
];

const TEMPLATE_JURNAL = [
  { id: 1, nama: "Refleksi Harian",    sections: "Mood, Cerita, Pelajaran, Refleksi", updated: "1 Jul 2026", aktif: true },
  { id: 2, nama: "Gratitude Journal",  sections: "Mood, Syukur, Pelajaran",           updated: "28 Jun 2026", aktif: true },
  { id: 3, nama: "Evaluasi Mingguan",  sections: "Pencapaian, Kendala, Rencana",      updated: "20 Jun 2026", aktif: true },
  { id: 4, nama: "Review Bulanan",     sections: "Statistik, Evaluasi, Target",       updated: "1 Jun 2026",  aktif: false },
];

function ProduktivitasTab({ showToast }: { showToast?: (msg: string) => void }) {
  const [target, setTarget] = useState({ langkah: "10.000", baca: "20", aktivitas: "5", jurnal: "21:00" });
  const [modal, setModal] = useState(false);

  return (
    <div className="space-y-6">
      {/* Kategori Aktivitas */}
      <div>
        <SectionHeader title="Kategori Aktivitas" action="Tambah Kategori" onAction={() => setModal(true)} />
        <TableWrapper>
          <thead><tr>{["Nama","Icon","Jumlah Aktivitas","Status","Aksi"].map(h => <Th key={h}>{h}</Th>)}</tr></thead>
          <tbody>
            {KATEGORI_AKTIVITAS.map(k => (
              <tr key={k.id} className="hover:bg-gray-50 transition-colors">
                <Td>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: k.warna }} />
                    <span className="text-sm font-medium text-gray-800">{k.nama}</span>
                  </div>
                </Td>
                <Td><span className="text-lg">{k.icon}</span></Td>
                <Td><span className="text-xs text-gray-500">{k.jumlah} aktivitas</span></Td>
                <Td><StatusBadge active={k.aktif} /></Td>
                <Td><RowMenu items={[
                  { label: "Edit", onClick: () => {} },
                  { label: "Nonaktifkan", onClick: () => {} },
                ]} /></Td>
              </tr>
            ))}
          </tbody>
        </TableWrapper>
      </div>

      {/* Template Jurnal */}
      <div>
        <SectionHeader title="Template Jurnal" action="Buat Template" />
        <TableWrapper>
          <thead><tr>{["Nama Template","Section","Diperbarui","Status","Aksi"].map(h => <Th key={h}>{h}</Th>)}</tr></thead>
          <tbody>
            {TEMPLATE_JURNAL.map(t => (
              <tr key={t.id} className="hover:bg-gray-50 transition-colors">
                <Td><span className="text-sm font-medium text-gray-800">{t.nama}</span></Td>
                <Td><span className="text-xs text-gray-500">{t.sections}</span></Td>
                <Td><span className="text-xs text-gray-400">{t.updated}</span></Td>
                <Td><StatusBadge active={t.aktif} /></Td>
                <Td><RowMenu items={[
                  { label: "Edit", onClick: () => {} },
                  { label: "Duplikat", onClick: () => {} },
                  { label: "Hapus", onClick: () => {}, danger: true },
                ]} /></Td>
              </tr>
            ))}
          </tbody>
        </TableWrapper>
      </div>

      {/* Target Default */}
      <div>
        <SectionHeader title="Target Default" />
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: "Target Langkah Harian", key: "langkah", suffix: "langkah" },
              { label: "Target Membaca Harian", key: "baca",    suffix: "halaman" },
              { label: "Target Aktivitas Selesai", key: "aktivitas", suffix: "aktivitas" },
              { label: "Waktu Pengingat Jurnal", key: "jurnal",  type: "time" },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">{f.label}</label>
                <div className="flex items-center gap-2">
                  <input type={f.type || "text"} value={target[f.key as keyof typeof target]}
                    onChange={e => setTarget({ ...target, [f.key]: e.target.value })}
                    className="flex-1 text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
                  {f.suffix && <span className="text-xs text-gray-400 shrink-0">{f.suffix}</span>}
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-end mt-4">
            <button onClick={() => showToast?.("Target berhasil disimpan.")}
              className="px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
              Simpan Target
            </button>
          </div>
        </div>
      </div>

      {modal && (
        <AddModal title="Tambah Kategori Aktivitas" onClose={() => setModal(false)} showToast={showToast}
          fields={[
            { label: "Nama Kategori", required: true },
            { label: "Warna", type: "color" },
          ]} />
      )}
    </div>
  );
}

// ── TAB LIBRARY ───────────────────────────────────────────────────────────────
const KATEGORI_BUKU = [
  { id: 1, nama: "Akuntansi",       jumlah: 8,  aktif: true },
  { id: 2, nama: "Keuangan",        jumlah: 5,  aktif: true },
  { id: 3, nama: "Produktivitas",   jumlah: 4,  aktif: true },
  { id: 4, nama: "Karier",          jumlah: 3,  aktif: true },
  { id: 5, nama: "Rohani",          jumlah: 2,  aktif: true },
  { id: 6, nama: "Pengembangan Diri",jumlah: 6, aktif: true },
  { id: 7, nama: "Lainnya",         jumlah: 1,  aktif: true },
];
const TAG_BUKU = ["Kuliah", "Referensi", "Favorit", "Ujian", "Dibaca Ulang"];

function LibraryTab({ showToast }: { showToast?: (msg: string) => void }) {
  const [cover, setCover] = useState("Gunakan halaman pertama");
  const [dupDetect, setDupDetect] = useState(true);
  const [tags, setTags] = useState(TAG_BUKU);
  const [tagInput, setTagInput] = useState("");

  return (
    <div className="space-y-6">
      <div>
        <SectionHeader title="Kategori Buku" action="Tambah Kategori" />
        <TableWrapper>
          <thead><tr>{["Nama","Jumlah Buku","Status","Aksi"].map(h => <Th key={h}>{h}</Th>)}</tr></thead>
          <tbody>
            {KATEGORI_BUKU.map(k => (
              <tr key={k.id} className="hover:bg-gray-50 transition-colors">
                <Td><span className="text-sm font-medium text-gray-800">{k.nama}</span></Td>
                <Td><span className="text-xs text-gray-500">{k.jumlah} buku</span></Td>
                <Td><StatusBadge active={k.aktif} /></Td>
                <Td><RowMenu items={[
                  { label: "Edit", onClick: () => {} },
                  { label: "Hapus", onClick: () => {}, danger: true },
                ]} /></Td>
              </tr>
            ))}
          </tbody>
        </TableWrapper>
      </div>

      <div>
        <SectionHeader title="Tag Buku" />
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
          <div className="flex flex-wrap gap-2 mb-3">
            {tags.map(t => (
              <span key={t} className="flex items-center gap-1.5 text-xs bg-gray-100 text-gray-700 px-3 py-1 rounded-full">
                {t}
                <button onClick={() => setTags(tags.filter(x => x !== t))} className="text-gray-400 hover:text-red-500 transition-colors"><X size={10} /></button>
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <input value={tagInput} onChange={e => setTagInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && tagInput.trim()) { setTags([...tags, tagInput.trim()]); setTagInput(""); }}}
              placeholder="Tambah tag baru..." className="flex-1 text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
            <button onClick={() => { if (tagInput.trim()) { setTags([...tags, tagInput.trim()]); setTagInput(""); }}}
              className="px-3 py-2 text-xs font-semibold text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Tambah</button>
          </div>
        </div>
      </div>

      <div>
        <SectionHeader title="Preferensi Upload" />
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between py-2 border-b border-gray-50">
            <div>
              <p className="text-sm font-medium text-gray-800">Cover Default</p>
              <p className="text-xs text-gray-500 mt-0.5">Cara menampilkan cover buku yang diunggah.</p>
            </div>
            <select value={cover} onChange={e => setCover(e.target.value)}
              className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none bg-white">
              {["Gunakan halaman pertama","Gunakan cover sistem","Tanya setiap upload"].map(o => <option key={o}>{o}</option>)}
            </select>
          </div>
          <div className="flex items-center justify-between py-2">
            <div>
              <p className="text-sm font-medium text-gray-800">Deteksi Duplikat</p>
              <p className="text-xs text-gray-500 mt-0.5">Peringatkan jika file yang diunggah sudah ada.</p>
            </div>
            <Toggle value={dupDetect} onChange={setDupDetect} />
          </div>
        </div>
      </div>
    </div>
  );
}

// ── TAB AKUNTANSI ─────────────────────────────────────────────────────────────
const DAFTAR_AKUN = [
  { id: 1, kode: "101", nama: "Kas",         tipe: "Aset",       normal: "Debit",  aktif: true },
  { id: 2, kode: "102", nama: "Bank",        tipe: "Aset",       normal: "Debit",  aktif: true },
  { id: 3, kode: "201", nama: "Utang",       tipe: "Liabilitas", normal: "Kredit", aktif: true },
  { id: 4, kode: "301", nama: "Modal",       tipe: "Ekuitas",    normal: "Kredit", aktif: true },
  { id: 5, kode: "401", nama: "Pendapatan",  tipe: "Pendapatan", normal: "Kredit", aktif: true },
  { id: 6, kode: "501", nama: "Beban",       tipe: "Beban",      normal: "Debit",  aktif: true },
];

const TEMPLATE_JA = ["Pembelian Tunai", "Pendapatan Tunai", "Pembayaran Tagihan", "Transfer Antar-Akun"];

function AkuntansiTab({ showToast }: { showToast?: (msg: string) => void }) {
  const [modal, setModal] = useState(false);
  const [periodeStatus, setPeriodeStatus] = useState("Terbuka");

  return (
    <div className="space-y-6">
      {/* Daftar Akun */}
      <div>
        <SectionHeader title="Daftar Akun" action="Tambah Akun" onAction={() => setModal(true)} />
        <TableWrapper>
          <thead><tr>{["Kode","Nama Akun","Tipe","Saldo Normal","Status","Aksi"].map(h => <Th key={h}>{h}</Th>)}</tr></thead>
          <tbody>
            {DAFTAR_AKUN.map(a => (
              <tr key={a.id} className="hover:bg-gray-50 transition-colors">
                <Td><span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">{a.kode}</span></Td>
                <Td><span className="text-sm font-medium text-gray-800">{a.nama}</span></Td>
                <Td><span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded">{a.tipe}</span></Td>
                <Td><span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${a.normal === "Debit" ? "bg-blue-50 text-blue-600" : "bg-green-50 text-green-600"}`}>{a.normal}</span></Td>
                <Td><StatusBadge active={a.aktif} /></Td>
                <Td><RowMenu items={[
                  { label: "Edit", onClick: () => setModal(true) },
                  { label: "Lihat Penggunaan", onClick: () => {} },
                  { label: "Nonaktifkan", onClick: () => {} },
                ]} /></Td>
              </tr>
            ))}
          </tbody>
        </TableWrapper>
        <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 text-xs text-blue-700">
          Akun sistem inti (101–501) tidak dapat dihapus untuk menjaga integritas data.
        </div>
      </div>

      {/* Periode Akuntansi */}
      <div>
        <SectionHeader title="Periode Akuntansi" />
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: "Tahun Aktif", value: "2026" },
              { label: "Bulan Aktif", value: "Juli" },
            ].map(f => (
              <div key={f.label}>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">{f.label}</label>
                <input defaultValue={f.value} className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
              </div>
            ))}
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Tanggal Mulai</label>
              <input type="date" defaultValue="2026-07-01" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Tanggal Akhir</label>
              <input type="date" defaultValue="2026-07-31" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
            </div>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-gray-100">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-gray-700">Status Periode</span>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${periodeStatus === "Terbuka" ? "bg-green-50 text-green-600" : periodeStatus === "Dikunci" ? "bg-amber-50 text-amber-600" : "bg-gray-100 text-gray-500"}`}>{periodeStatus}</span>
            </div>
            <div className="flex gap-2">
              {["Terbuka","Dikunci","Ditutup"].map(s => (
                <button key={s} onClick={() => setPeriodeStatus(s)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${periodeStatus === s ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Template Jurnal */}
      <div>
        <SectionHeader title="Template Jurnal Akuntansi" action="Tambah Template" />
        <div className="grid grid-cols-2 gap-3">
          {TEMPLATE_JA.map(t => (
            <div key={t} className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between hover:border-gray-300 transition-all">
              <span className="text-sm font-medium text-gray-800">{t}</span>
              <div className="flex gap-1">
                <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors"><Edit3 size={13} /></button>
                <button className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors"><Trash2 size={13} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {modal && (
        <AddModal title="Tambah Daftar Akun" onClose={() => setModal(false)} showToast={showToast}
          fields={[
            { label: "Kode Akun", required: true, placeholder: "Contoh: 601" },
            { label: "Nama Akun", required: true },
            { label: "Tipe Akun", placeholder: "Aset, Liabilitas, Ekuitas, Pendapatan, Beban" },
          ]} />
      )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function PengaturanDataPage({ topBar, showToast }: {
  topBar?: React.ReactNode;
  showToast?: (msg: string, type?: string) => void;
}) {
  const [tab, setTab] = useState<DataTab>("keuangan");

  const tabs: { id: DataTab; label: string }[] = [
    { id: "keuangan",     label: "Keuangan" },
    { id: "produktivitas",label: "Produktivitas" },
    { id: "library",      label: "Library" },
    { id: "akuntansi",    label: "Akuntansi" },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Pengaturan Data</h1>
          <p className="text-xs text-gray-500 mt-0.5">Kelola kategori, akun, template, dan data dasar yang digunakan FreeSpace.</p>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${tab === t.id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              {t.label}
            </button>
          ))}
        </div>

        {tab === "keuangan"      && <KeuanganTab     showToast={showToast} />}
        {tab === "produktivitas" && <ProduktivitasTab showToast={showToast} />}
        {tab === "library"       && <LibraryTab      showToast={showToast} />}
        {tab === "akuntansi"     && <AkuntansiTab    showToast={showToast} />}
      </div>
    </main>
  );
}
