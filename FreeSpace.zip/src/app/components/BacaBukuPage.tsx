import React, { useState, useEffect } from "react";
import {
  BookOpen, ChevronLeft, ChevronRight, ZoomIn, ZoomOut,
  Maximize2, Search, Bookmark, StickyNote, Highlighter,
  X, RotateCcw, Download, Menu, Layers, AlignLeft,
  CheckCircle2, RefreshCw, Clock, Star,
  Bold, Italic, List, Quote, Link,
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────
type ReaderView = "overview" | "reader";
type NoteTab = "catatan" | "highlight" | "ringkasan" | "insight";
type NavTab = "thumbnail" | "outline" | "bookmark";

// ── Data ─────────────────────────────────────────────────────────────────────
const READING_BOOKS = [
  { id: 1, judul: "Akuntansi Keuangan Menengah", progress: 68, lastPage: 124, total: 182, terakhir: "Hari ini, 20.15", sesi: "27 menit", kategori: "Akuntansi" },
  { id: 2, judul: "Analisis Laporan Keuangan",   progress: 35, lastPage: 75,  total: 215, terakhir: "1 Jul 2026",     sesi: "22 menit", kategori: "Keuangan" },
  { id: 3, judul: "Persiapan Karier Akuntansi",  progress: 12, lastPage: 23,  total: 198, terakhir: "29 Jun 2026",   sesi: "16 menit", kategori: "Karier" },
  { id: 4, judul: "Manajemen Keuangan Pribadi",  progress: 8,  lastPage: 12,  total: 156, terakhir: "30 Jun 2026",   sesi: "14 menit", kategori: "Keuangan" },
];

const READING_HISTORY = [
  { tgl: "3 Jul 2026", buku: "Akuntansi Keuangan Menengah", halaman: "118–124", durasi: "27 menit", catatan: 2, progress: "68%" },
  { tgl: "2 Jul 2026", buku: "Akuntansi Keuangan Menengah", halaman: "106–117", durasi: "34 menit", catatan: 3, progress: "64%" },
  { tgl: "1 Jul 2026", buku: "Analisis Laporan Keuangan",   halaman: "68–75",   durasi: "22 menit", catatan: 1, progress: "35%" },
  { tgl: "30 Jun 2026",buku: "Persiapan Karier Akuntansi",  halaman: "18–23",   durasi: "16 menit", catatan: 0, progress: "12%" },
];

const HIGHLIGHTS = [
  { id: 1, teks: "Jurnal penyesuaian diperlukan untuk mencatat pendapatan dan beban yang belum dicatat.", hal: 118, color: "#FEF9C3", colorName: "Kuning" },
  { id: 2, teks: "Beban akrual adalah beban yang sudah terjadi tetapi belum dibayar.", hal: 120, color: "#D1FAE5", colorName: "Hijau" },
  { id: 3, teks: "Pendapatan diterima dimuka diakui sebagai kewajiban hingga jasa diselesaikan.", hal: 123, color: "#DBEAFE", colorName: "Biru" },
];

// ── Helpers ──────────────────────────────────────────────────────────────────
function SummaryCard({ label, value, desc, color, icon: Icon }: {
  label: string; value: string | number; desc: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: color + "18", color }}>
          <Icon size={16} />
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 leading-tight">{value}</p>
      <p className="text-[11px] text-gray-400 leading-snug">{desc}</p>
    </div>
  );
}

// ── Placeholder PDF Page ──────────────────────────────────────────────────────
function PDFPage({ page, zoom }: { page: number; zoom: number }) {
  const scale = zoom / 100;
  return (
    <div className="mx-auto bg-white shadow-lg rounded-sm overflow-hidden"
      style={{ width: `${595 * scale}px`, minHeight: `${842 * scale}px`, padding: `${40 * scale}px` }}>
      <div style={{ fontSize: `${scale * 11}px`, lineHeight: `${scale * 18}px` }} className="text-gray-800">
        <p className="font-bold text-center mb-4" style={{ fontSize: `${scale * 14}px` }}>
          BAB 5 — JURNAL PENYESUAIAN
        </p>
        <p className="font-semibold mb-2" style={{ fontSize: `${scale * 12}px` }}>5.1 Pengertian Jurnal Penyesuaian</p>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Jurnal penyesuaian adalah jurnal yang dibuat pada akhir periode akuntansi untuk menyesuaikan saldo akun-akun tertentu agar sesuai dengan kondisi yang sebenarnya. Jurnal ini diperlukan karena adanya perbedaan antara pencatatan kas dan pengakuan pendapatan atau beban.
        </p>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Terdapat dua jenis jurnal penyesuaian yang sering dijumpai dalam praktik akuntansi perusahaan jasa maupun dagang, yaitu penyesuaian berbasis kas dan penyesuaian berbasis akrual.
        </p>
        <div className="my-4 border border-gray-200 rounded overflow-hidden" style={{ fontSize: `${scale * 10}px` }}>
          <div className="bg-gray-50 px-3 py-2 font-semibold border-b border-gray-200">Tabel 5.1 Jenis-Jenis Penyesuaian</div>
          {[["Beban Dibayar Dimuka","Aset → Beban","Saat manfaat digunakan"],["Beban Akrual","Beban → Utang","Saat beban terjadi"],["Pendapatan Diterima Dimuka","Utang → Pendapatan","Saat jasa diselesaikan"],["Pendapatan Akrual","Piutang → Pendapatan","Saat pendapatan timbul"]].map(([nama, efek, waktu]) => (
            <div key={nama} className="grid grid-cols-3 px-3 py-2 border-b border-gray-100 last:border-0">
              <span>{nama}</span><span className="text-gray-500">{efek}</span><span className="text-gray-400">{waktu}</span>
            </div>
          ))}
        </div>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Pada dasarnya, setiap penyesuaian akan melibatkan setidaknya satu akun neraca dan satu akun laporan laba rugi. Hal ini penting untuk memastikan bahwa laporan keuangan yang dihasilkan mencerminkan kondisi keuangan yang wajar.
        </p>
        <p className="font-semibold mb-2" style={{ fontSize: `${scale * 12}px` }}>5.2 Beban Akrual</p>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Beban akrual adalah beban yang sudah terjadi tetapi belum dicatat karena belum adanya transaksi kas. Contoh umum adalah beban gaji yang terutang pada akhir periode. Pencatatannya dilakukan dengan mendebit akun Beban Gaji dan mengkredit akun Utang Gaji.
        </p>
        <div className="text-center text-gray-300 mt-8" style={{ fontSize: `${scale * 9}px` }}>— {page} —</div>
      </div>
    </div>
  );
}

// ── PDF Reader ────────────────────────────────────────────────────────────────
function PDFReader({ book, onBack }: {
  book: { judul: string; lastPage: number; total: number };
  onBack: () => void;
}) {
  const [page, setPage]       = useState(book.lastPage);
  const [zoom, setZoom]       = useState(100);
  const [noteTab, setNoteTab] = useState<NoteTab>("catatan");
  const [navTab, setNavTab]   = useState<NavTab>("thumbnail");
  const [leftOpen, setLeftOpen] = useState(true);
  const [rightOpen, setRightOpen] = useState(true);
  const [noteText, setNoteText] = useState("");
  const [sessionTime, setSessionTime] = useState(0);
  const [showBookmark, setShowBookmark] = useState(false);
  const [bookmarks, setBookmarks] = useState([{ page: 118, label: "Konsep penting" }, { page: 120, label: "Beban akrual" }]);
  const [showSelection, setShowSelection] = useState(false);
  const [selPos, setSelPos]   = useState({ x: 0, y: 0 });

  useEffect(() => {
    const t = setInterval(() => setSessionTime(s => s + 1), 1000);
    return () => clearInterval(t);
  }, []);

  const fmt = (s: number) => `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
  const progress = Math.round((page / book.total) * 100);

  const handleTextSelection = (e: React.MouseEvent) => {
    const sel = window.getSelection();
    if (sel && sel.toString().length > 3) {
      setSelPos({ x: e.clientX, y: e.clientY });
      setShowSelection(true);
    } else {
      setShowSelection(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-100">
      {/* Reader Toolbar */}
      <div className="bg-white border-b border-gray-200 px-3 py-2 flex items-center gap-2 shrink-0 z-10">
        <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-gray-800 transition-colors mr-1">
          <ChevronLeft size={15} /> Baca Buku
        </button>
        <div className="w-px h-4 bg-gray-200" />
        <span className="text-xs font-semibold text-gray-800 flex-1 truncate max-w-[200px]">{book.judul}</span>

        <div className="flex items-center gap-1 border-l border-gray-200 pl-2">
          <button onClick={() => setPage(Math.max(1, page - 1))} className="p-1.5 rounded hover:bg-gray-100 text-gray-400"><ChevronLeft size={14} /></button>
          <div className="flex items-center gap-1">
            <input value={page} onChange={e => setPage(Math.min(book.total, Math.max(1, Number(e.target.value) || 1)))}
              className="w-12 text-center text-xs font-mono border border-gray-200 rounded px-1 py-1 outline-none" />
            <span className="text-xs text-gray-400">/ {book.total}</span>
          </div>
          <button onClick={() => setPage(Math.min(book.total, page + 1))} className="p-1.5 rounded hover:bg-gray-100 text-gray-400"><ChevronRight size={14} /></button>
        </div>

        <div className="flex items-center gap-1 border-l border-gray-200 pl-2">
          <button onClick={() => setZoom(Math.max(50, zoom - 10))} className="p-1.5 rounded hover:bg-gray-100 text-gray-400" title="Zoom Out"><ZoomOut size={14} /></button>
          <span className="text-xs font-mono text-gray-500 w-10 text-center">{zoom}%</span>
          <button onClick={() => setZoom(Math.min(200, zoom + 10))} className="p-1.5 rounded hover:bg-gray-100 text-gray-400" title="Zoom In"><ZoomIn size={14} /></button>
          <button onClick={() => setZoom(100)} className="p-1.5 rounded hover:bg-gray-100 text-gray-400 text-[10px] font-mono" title="Fit Width">FW</button>
        </div>

        <div className="flex items-center gap-1 border-l border-gray-200 pl-2">
          <button className="p-1.5 rounded hover:bg-gray-100 text-gray-400" title="Cari dalam PDF"><Search size={14} /></button>
          <button onClick={() => setShowBookmark(true)} className="p-1.5 rounded hover:bg-gray-100 text-gray-400" title="Bookmark Halaman"><Bookmark size={14} /></button>
          <button onClick={() => setRightOpen(!rightOpen)} className="p-1.5 rounded hover:bg-gray-100 text-gray-400" title="Catatan"><StickyNote size={14} /></button>
          <button className="p-1.5 rounded hover:bg-gray-100 text-gray-400" title="Fullscreen"><Maximize2 size={14} /></button>
        </div>

        <span className="flex items-center gap-1 text-[10px] text-gray-400 border-l border-gray-200 pl-2 ml-auto">
          <Clock size={10} /> {fmt(sessionTime)}
        </span>
      </div>

      {/* Progress bar */}
      <div className="h-1 bg-gray-200 shrink-0">
        <div className="h-1 bg-blue-500 transition-all" style={{ width: `${progress}%` }} />
      </div>

      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Left Nav Panel */}
        {leftOpen && (
          <div className="w-44 shrink-0 bg-white border-r border-gray-200 flex flex-col overflow-hidden">
            <div className="flex items-center border-b border-gray-100 p-1 gap-0.5">
              {([["thumbnail","Halaman",Layers],["outline","Outline",AlignLeft],["bookmark","Bookmark",Bookmark]] as const).map(([id, label, Icon]) => (
                <button key={id} onClick={() => setNavTab(id)}
                  className={`flex-1 flex items-center justify-center py-1.5 rounded text-[10px] font-semibold transition-colors ${navTab === id ? "bg-gray-100 text-gray-900" : "text-gray-400 hover:text-gray-600"}`}
                  title={label}>
                  <Icon size={12} />
                </button>
              ))}
              <button onClick={() => setLeftOpen(false)} className="p-1 text-gray-300 hover:text-gray-500 ml-auto"><X size={12} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
              {navTab === "thumbnail" && Array.from({ length: Math.min(8, book.total) }, (_, i) => i + 117).map(p => (
                <button key={p} onClick={() => setPage(p)}
                  className={`w-full text-left rounded-lg overflow-hidden border transition-all ${p === page ? "border-blue-500 ring-1 ring-blue-300" : "border-gray-200 hover:border-gray-300"}`}>
                  <div className="bg-white h-20 flex items-center justify-center">
                    <div className="text-[8px] text-gray-300 leading-relaxed px-2 py-1">
                      <div className="h-1 bg-gray-200 rounded mb-0.5 w-3/4" />
                      <div className="h-1 bg-gray-100 rounded mb-0.5" />
                      <div className="h-1 bg-gray-100 rounded mb-0.5 w-4/5" />
                    </div>
                  </div>
                  <div className="text-center text-[9px] text-gray-400 py-0.5 border-t border-gray-100">{p}</div>
                </button>
              ))}
              {navTab === "outline" && (
                <div className="space-y-1">
                  {["Bab 1 — Pendahuluan","Bab 2 — Siklus Akuntansi","Bab 3 — Jurnal Umum","Bab 4 — Buku Besar","Bab 5 — Penyesuaian","Bab 6 — Laporan Keuangan"].map((c, i) => (
                    <button key={c} className={`w-full text-left text-[10px] px-2 py-1.5 rounded transition-colors ${i === 4 ? "bg-blue-50 text-blue-700 font-semibold" : "text-gray-600 hover:bg-gray-50"}`}>{c}</button>
                  ))}
                </div>
              )}
              {navTab === "bookmark" && bookmarks.map(bm => (
                <button key={bm.page} onClick={() => setPage(bm.page)}
                  className="w-full text-left px-2 py-2 rounded-lg hover:bg-gray-50 transition-colors border border-gray-100">
                  <p className="text-[10px] font-semibold text-gray-700">Hal. {bm.page}</p>
                  <p className="text-[9px] text-gray-400">{bm.label}</p>
                </button>
              ))}
            </div>
          </div>
        )}
        {!leftOpen && (
          <button onClick={() => setLeftOpen(true)} className="w-8 shrink-0 bg-white border-r border-gray-200 flex items-center justify-center hover:bg-gray-50 transition-colors">
            <Menu size={14} className="text-gray-400" />
          </button>
        )}

        {/* Main Canvas */}
        <div className="flex-1 overflow-auto p-6 relative" onMouseUp={handleTextSelection}>
          <PDFPage page={page} zoom={zoom} />
        </div>

        {/* Selection Toolbar */}
        {showSelection && (
          <>
            <div className="fixed inset-0 z-20" onClick={() => setShowSelection(false)} />
            <div className="fixed z-30 bg-white border border-gray-200 rounded-xl shadow-xl px-2 py-1.5 flex items-center gap-1"
              style={{ left: selPos.x - 100, top: selPos.y - 50 }}>
              {[["🟡","Kuning"],["🟢","Hijau"],["🔵","Biru"],["🟣","Ungu"]].map(([emoji, color]) => (
                <button key={color} onClick={() => setShowSelection(false)} title={color}
                  className="w-6 h-6 rounded-full text-sm flex items-center justify-center hover:scale-110 transition-transform">{emoji}</button>
              ))}
              <div className="w-px h-4 bg-gray-200 mx-0.5" />
              <button onClick={() => { setRightOpen(true); setNoteTab("catatan"); setShowSelection(false); }}
                className="p-1 rounded hover:bg-gray-100 text-gray-500 text-[10px] flex items-center gap-1">
                <StickyNote size={11} /> Catatan
              </button>
            </div>
          </>
        )}

        {/* Right Notes Panel */}
        {rightOpen && (
          <div className="w-72 shrink-0 bg-white border-l border-gray-200 flex flex-col overflow-hidden">
            <div className="flex items-center border-b border-gray-100 p-1 gap-0.5">
              {([["catatan","Catatan"],["highlight","Highlight"],["ringkasan","Ringkasan"],["insight","Insight"]] as const).map(([id, label]) => (
                <button key={id} onClick={() => setNoteTab(id)}
                  className={`flex-1 py-1.5 rounded text-[9px] font-semibold transition-colors ${noteTab === id ? "bg-gray-100 text-gray-900" : "text-gray-400 hover:text-gray-600"}`}>
                  {label}
                </button>
              ))}
              <button onClick={() => setRightOpen(false)} className="p-1 text-gray-300 hover:text-gray-500"><X size={12} /></button>
            </div>

            <div className="flex-1 overflow-y-auto p-3">
              {noteTab === "catatan" && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-semibold text-gray-500 bg-blue-50 text-blue-700 px-2 py-0.5 rounded">Halaman {page}</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-1 mb-1.5 flex-wrap">
                      {[Bold, Italic, List, Quote, Link].map((Icon, i) => (
                        <button key={i} className="p-1 rounded hover:bg-gray-100 text-gray-400 transition-colors"><Icon size={11} /></button>
                      ))}
                    </div>
                    <textarea value={noteText} onChange={e => setNoteText(e.target.value)}
                      rows={5} placeholder="Tuliskan catatan dari halaman ini..."
                      className="w-full text-xs px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none leading-relaxed" />
                  </div>
                  <button className="w-full py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
                    Simpan Catatan
                  </button>
                  <div className="space-y-2 pt-2 border-t border-gray-100">
                    <p className="text-[10px] font-semibold text-gray-500">CATATAN SEBELUMNYA</p>
                    {[
                      { hal: 120, teks: "Beban akrual — sudah terjadi, belum dibayar.", tgl: "3 Jul" },
                      { hal: 118, teks: "Penyesuaian diperlukan pada akhir periode.", tgl: "3 Jul" },
                    ].map(n => (
                      <div key={n.hal} className="bg-gray-50 rounded-lg p-2.5">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[9px] font-semibold text-blue-600">Hal. {n.hal}</span>
                          <span className="text-[9px] text-gray-400">{n.tgl}</span>
                        </div>
                        <p className="text-[10px] text-gray-600 leading-relaxed">{n.teks}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {noteTab === "highlight" && (
                <div className="space-y-2">
                  <p className="text-[10px] font-semibold text-gray-500 mb-2">26 HIGHLIGHT</p>
                  {HIGHLIGHTS.map(h => (
                    <div key={h.id} className="rounded-lg p-2.5 border border-gray-100" style={{ borderLeftColor: "#" + h.colorName.charCodeAt(0).toString(16), borderLeftWidth: 3 }}>
                      <p className="text-[10px] leading-relaxed text-gray-700 mb-1.5" style={{ backgroundColor: h.color, padding: "2px 4px", borderRadius: 3 }}>"{h.teks}"</p>
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] text-gray-400">Hal. {h.hal} • {h.colorName}</span>
                        <button className="text-[9px] text-red-400 hover:text-red-600 transition-colors">Hapus</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {noteTab === "ringkasan" && (
                <div className="space-y-3">
                  {[["Halaman Aktif","Ringkasan singkat halaman ini..."],["Chapter Ini","Bab 5 membahas jurnal penyesuaian..."],["Buku Ini","Ringkasan keseluruhan buku..."]].map(([label, ph]) => (
                    <div key={label}>
                      <p className="text-[10px] font-semibold text-gray-600 mb-1">{label}</p>
                      <textarea rows={3} placeholder={ph} className="w-full text-xs px-2.5 py-2 border border-gray-200 rounded-lg outline-none resize-none" />
                    </div>
                  ))}
                  <p className="text-[9px] text-gray-400">Isi ringkasan secara manual. AI dapat membantu merapikan setelah Anda meminta.</p>
                </div>
              )}

              {noteTab === "insight" && (
                <div className="space-y-3">
                  {["Ide Utama","Hal Baru yang Dipelajari","Penerapan","Pertanyaan Lanjutan","Kesimpulan Pribadi"].map(f => (
                    <div key={f}>
                      <p className="text-[10px] font-semibold text-gray-600 mb-1">{f}</p>
                      <textarea rows={2} placeholder={`${f}...`} className="w-full text-xs px-2.5 py-2 border border-gray-200 rounded-lg outline-none resize-none" />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Bookmark modal */}
      {showBookmark && (
        <>
          <div className="fixed inset-0 z-50 bg-black/30" onClick={() => setShowBookmark(false)} />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[340px] bg-white rounded-2xl shadow-2xl p-5">
            <h3 className="text-sm font-bold text-gray-900 mb-3">Bookmark Halaman {page}</h3>
            <input placeholder="Label opsional (contoh: Konsep penting)" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none mb-3" />
            <div className="flex gap-2 justify-end">
              <button onClick={() => setShowBookmark(false)} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
              <button onClick={() => { setBookmarks([...bookmarks, { page, label: "Halaman " + page }]); setShowBookmark(false); }}
                className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
                Simpan Bookmark
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ── Reading Overview ──────────────────────────────────────────────────────────
function ReadingOverview({ onOpenReader, topBar }: {
  onOpenReader: (book: { judul: string; lastPage: number; total: number }) => void;
  topBar?: React.ReactNode;
}) {
  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Baca Buku</h1>
            <p className="text-xs text-gray-500 mt-0.5">Lanjutkan membaca, mencatat, dan menyimpan insight dari buku Anda.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
              Pilih Buku
            </button>
            <button onClick={() => onOpenReader(READING_BOOKS[0])}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors shadow-sm">
              <BookOpen size={13} /> Lanjutkan Membaca
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <SummaryCard label="Buku Aktif"       value={4}       desc="Sedang dalam proses membaca"     color="#3B82F6" icon={BookOpen} />
          <SummaryCard label="Halaman Bulan Ini" value={426}    desc="Target bulan 600 halaman"        color="#8B5CF6" icon={Star} />
          <SummaryCard label="Waktu Membaca"     value="14j 35m" desc="Selama Juli 2026"              color="#F59E0B" icon={Clock} />
          <SummaryCard label="Streak Membaca"    value="8 Hari" desc="Pertahankan konsistensi"        color="#22C55E" icon={CheckCircle2} />
        </div>

        {/* Featured book */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Terakhir Dibaca</p>
          <div className="flex items-start gap-5">
            <div className="w-24 h-32 rounded-xl bg-blue-50 flex flex-col items-center justify-center shrink-0">
              <span className="text-xl font-bold text-blue-700">AK</span>
              <BookOpen size={16} className="text-blue-400 mt-1" />
            </div>
            <div className="flex-1">
              <h2 className="text-base font-bold text-gray-900 mb-1">Akuntansi Keuangan Menengah</h2>
              <p className="text-xs text-gray-500 mb-3">Modul Pembelajaran Pribadi • 182 halaman</p>
              <div className="mb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-500">Progress Membaca</span>
                  <span className="text-xs font-bold text-gray-800">124 / 182 halaman (68%)</span>
                </div>
                <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-2.5 rounded-full bg-blue-500" style={{ width: "68%" }} />
                </div>
              </div>
              <p className="text-xs text-gray-400 mb-4">Terakhir dibaca hari ini, 20.15 • Sesi terakhir 27 menit</p>
              <div className="flex gap-2">
                <button onClick={() => onOpenReader(READING_BOOKS[0])}
                  className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
                  <BookOpen size={13} /> Lanjutkan Halaman 124
                </button>
                <button className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <StickyNote size={13} /> Buka Catatan
                </button>
                <button className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <RotateCcw size={13} /> Mulai dari Awal
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Sedang Dibaca */}
        <div>
          <h3 className="text-sm font-semibold text-gray-800 mb-3">Sedang Dibaca</h3>
          <div className="grid grid-cols-4 gap-4">
            {READING_BOOKS.map(b => (
              <div key={b.id} className="bg-white border border-gray-200 rounded-xl p-4 hover:border-gray-300 hover:shadow-sm transition-all">
                <div className="w-full h-20 rounded-lg bg-blue-50 flex items-center justify-center mb-3">
                  <span className="text-sm font-bold text-blue-700">{b.judul.split(" ").slice(0,2).map(w=>w[0]).join("")}</span>
                </div>
                <p className="text-xs font-semibold text-gray-900 mb-1 leading-tight line-clamp-2">{b.judul}</p>
                <div className="mb-2">
                  <div className="flex justify-between text-[10px] mb-0.5">
                    <span className="text-gray-400">Hal. {b.lastPage}/{b.total}</span>
                    <span className="font-semibold text-gray-700">{b.progress}%</span>
                  </div>
                  <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-1.5 rounded-full bg-blue-500" style={{ width: `${b.progress}%` }} />
                  </div>
                </div>
                <button onClick={() => onOpenReader(b)}
                  className="w-full py-1.5 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
                  Lanjutkan
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Riwayat */}
        <div>
          <h3 className="text-sm font-semibold text-gray-800 mb-3">Riwayat Membaca</h3>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50/70">
                  {["Tanggal","Buku","Halaman","Durasi","Catatan","Progress"].map(h => (
                    <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {READING_HISTORY.map((r, i) => (
                  <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                    <td className="py-3 px-4 text-xs text-gray-600">{r.tgl}</td>
                    <td className="py-3 px-4 text-xs font-medium text-gray-800">{r.buku}</td>
                    <td className="py-3 px-4 text-xs text-gray-500">Hal. {r.halaman}</td>
                    <td className="py-3 px-4 text-xs text-gray-500">{r.durasi}</td>
                    <td className="py-3 px-4">
                      {r.catatan > 0
                        ? <span className="text-[10px] font-semibold bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">{r.catatan} catatan</span>
                        : <span className="text-[10px] text-gray-300">—</span>
                      }
                    </td>
                    <td className="py-3 px-4 text-xs font-semibold text-gray-700">{r.progress}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </main>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function BacaBukuPage({ topBar }: { topBar?: React.ReactNode }) {
  const [readerBook, setReaderBook] = useState<{ judul: string; lastPage: number; total: number } | null>(null);

  if (readerBook) {
    return (
      <main className="flex-1 overflow-hidden min-w-0 flex flex-col">
        <PDFReader book={readerBook} onBack={() => setReaderBook(null)} />
      </main>
    );
  }
  return <ReadingOverview topBar={topBar} onOpenReader={setReaderBook} />;
}
