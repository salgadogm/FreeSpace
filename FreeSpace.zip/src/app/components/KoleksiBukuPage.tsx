import React, { useState } from "react";
import {
  Upload, Tag, Search, Filter, Grid3X3, List, Star,
  MoreHorizontal, BookOpen, X, RefreshCw, CheckCircle2,
  AlertCircle, Bookmark, FileText, Clock, StickyNote,
  ChevronRight, Eye, Download, Archive, Trash2, Edit3,
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────
type BookStatus = "Belum Dibaca" | "Sedang Dibaca" | "Selesai" | "Diarsipkan";
type BookTab = "semua" | "dibaca" | "selesai" | "favorit" | "arsip";
type ViewMode = "grid" | "list";

interface Book {
  id: number; judul: string; penulis: string; kategori: string;
  halaman: number; progress: number; status: BookStatus;
  favorit: boolean; terakhirDibaca?: string; catatan: number;
  highlight: number; bookmark: number;
}

// ── Data ──────────────────────────────────────────────────────────────────────
const BOOKS: Book[] = [
  { id:1, judul:"Akuntansi Keuangan Menengah",   penulis:"Modul Pembelajaran Pribadi", kategori:"Akuntansi",     halaman:182, progress:68,  status:"Sedang Dibaca", favorit:true,  terakhirDibaca:"3 Jul 2026, 20.15", catatan:8,  highlight:12, bookmark:4 },
  { id:2, judul:"Dasar-Dasar Akuntansi",          penulis:"Materi Kuliah",              kategori:"Akuntansi",     halaman:240, progress:100, status:"Selesai",       favorit:true,  terakhirDibaca:"28 Jun 2026",       catatan:6,  highlight:9,  bookmark:2 },
  { id:3, judul:"Analisis Laporan Keuangan",      penulis:"Bahan Belajar",              kategori:"Keuangan",      halaman:215, progress:35,  status:"Sedang Dibaca", favorit:false, terakhirDibaca:"1 Jul 2026",        catatan:4,  highlight:5,  bookmark:1 },
  { id:4, judul:"Manajemen Keuangan Pribadi",     penulis:"Koleksi Pribadi",            kategori:"Keuangan",      halaman:156, progress:8,   status:"Sedang Dibaca", favorit:false, terakhirDibaca:"30 Jun 2026",       catatan:0,  highlight:0,  bookmark:0 },
  { id:5, judul:"Strategi Belajar Efektif",       penulis:"Koleksi Pribadi",            kategori:"Produktivitas", halaman:134, progress:100, status:"Selesai",       favorit:true,  terakhirDibaca:"20 Jun 2026",       catatan:3,  highlight:4,  bookmark:2 },
  { id:6, judul:"Persiapan Karier Akuntansi",     penulis:"Koleksi Pribadi",            kategori:"Karier",        halaman:198, progress:12,  status:"Sedang Dibaca", favorit:false, terakhirDibaca:"29 Jun 2026",       catatan:1,  highlight:0,  bookmark:1 },
  { id:7, judul:"Catatan Refleksi Harian",        penulis:"Koleksi Pribadi",            kategori:"Rohani",        halaman:120, progress:100, status:"Selesai",       favorit:true,  terakhirDibaca:"15 Jun 2026",       catatan:5,  highlight:3,  bookmark:0 },
  { id:8, judul:"Audit dan Pengendalian Internal",penulis:"Materi Kuliah",              kategori:"Akuntansi",     halaman:260, progress:0,   status:"Belum Dibaca",  favorit:false, terakhirDibaca:undefined,           catatan:0,  highlight:0,  bookmark:0 },
];

const KATEGORI_COLORS: Record<string, { bg: string; color: string }> = {
  Akuntansi:         { bg: "#DBEAFE", color: "#1D4ED8" },
  Keuangan:          { bg: "#DCFCE7", color: "#15803D" },
  Produktivitas:     { bg: "#EDE9FE", color: "#6D28D9" },
  Karier:            { bg: "#FEF3C7", color: "#B45309" },
  Rohani:            { bg: "#FCE7F3", color: "#9D174D" },
  "Pengembangan Diri":{ bg: "#CCFBF1", color: "#0F766E" },
  Lainnya:           { bg: "#F3F4F6", color: "#374151" },
};

// ── Helpers ───────────────────────────────────────────────────────────────────
function StatusBadge({ s }: { s: BookStatus }) {
  const cfg: Record<BookStatus, string> = {
    "Belum Dibaca":  "bg-gray-100 text-gray-500",
    "Sedang Dibaca": "bg-blue-50 text-blue-700",
    "Selesai":       "bg-green-50 text-green-700",
    "Diarsipkan":    "bg-gray-100 text-gray-400",
  };
  return <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${cfg[s]}`}>{s}</span>;
}

function KategoriBadge({ k }: { k: string }) {
  const cfg = KATEGORI_COLORS[k] ?? KATEGORI_COLORS["Lainnya"];
  return <span className="text-[10px] font-medium px-2 py-0.5 rounded-full" style={{ backgroundColor: cfg.bg, color: cfg.color }}>{k}</span>;
}

function SummaryCard({ label, value, desc, color, icon: Icon }: {
  label: string; value: string | number; desc: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: color + "18", color }}>
          <Icon size={16} />
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 leading-tight">{value}</p>
      <p className="text-[11px] text-gray-400 leading-snug">{desc}</p>
    </div>
  );
}

// ── Cover Placeholder ─────────────────────────────────────────────────────────
function BookCover({ judul, kategori, className = "" }: { judul: string; kategori: string; className?: string }) {
  const cfg = KATEGORI_COLORS[kategori] ?? KATEGORI_COLORS["Lainnya"];
  const initials = judul.split(" ").slice(0, 2).map(w => w[0]).join("").toUpperCase();
  return (
    <div className={`flex flex-col items-center justify-center rounded-lg ${className}`}
      style={{ backgroundColor: cfg.bg }}>
      <span className="text-lg font-bold" style={{ color: cfg.color }}>{initials}</span>
      <FileText size={16} style={{ color: cfg.color + "80" }} className="mt-1" />
    </div>
  );
}

// ── Book Card (Grid) ──────────────────────────────────────────────────────────
function BookCard({ book, onDetail, onFavorite, onOpen }: {
  book: Book; onDetail: (b: Book) => void; onFavorite: (id: number) => void; onOpen: (b: Book) => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <div className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:border-gray-300 hover:shadow-sm transition-all group">
      {/* Cover */}
      <div className="relative cursor-pointer" onClick={() => onDetail(book)}>
        <BookCover judul={book.judul} kategori={book.kategori} className="h-36 w-full" />
        <button onClick={e => { e.stopPropagation(); onFavorite(book.id); }}
          className={`absolute top-2 right-2 p-1.5 rounded-full bg-white/90 shadow-sm transition-colors ${book.favorit ? "text-amber-400" : "text-gray-300 hover:text-amber-400"}`}>
          <Star size={13} fill={book.favorit ? "currentColor" : "none"} />
        </button>
        {book.status === "Sedang Dibaca" && (
          <div className="absolute bottom-0 left-0 right-0 bg-white/90 px-3 py-1.5">
            <div className="flex items-center justify-between mb-0.5">
              <span className="text-[9px] text-gray-500">Progress</span>
              <span className="text-[9px] font-semibold text-gray-700">{book.progress}%</span>
            </div>
            <div className="h-1 bg-gray-200 rounded-full overflow-hidden">
              <div className="h-1 rounded-full bg-blue-500" style={{ width: `${book.progress}%` }} />
            </div>
          </div>
        )}
        {book.status === "Selesai" && (
          <div className="absolute top-2 left-2">
            <CheckCircle2 size={18} className="text-green-500 bg-white rounded-full" />
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-3">
        <p className="text-xs font-semibold text-gray-900 truncate mb-0.5">{book.judul}</p>
        <p className="text-[10px] text-gray-400 truncate mb-2">{book.penulis}</p>
        <div className="flex items-center justify-between">
          <KategoriBadge k={book.kategori} />
          <div className="relative">
            <button onClick={e => { e.stopPropagation(); setMenuOpen(!menuOpen); }}
              className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 opacity-0 group-hover:opacity-100 transition-all">
              <MoreHorizontal size={13} />
            </button>
            {menuOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
                <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-gray-200 rounded-xl shadow-lg z-20 py-1">
                  {[
                    ["Buka Buku", () => { onOpen(book); setMenuOpen(false); }],
                    ["Lihat Detail", () => { onDetail(book); setMenuOpen(false); }],
                    ["Tambah ke Favorit", () => { onFavorite(book.id); setMenuOpen(false); }],
                    ["Rename", () => setMenuOpen(false)],
                    ["Arsipkan", () => setMenuOpen(false)],
                    ["Hapus", () => setMenuOpen(false), true],
                  ].map(([label, action, danger]) => (
                    <button key={label as string} onClick={action as () => void}
                      className={`w-full flex items-center gap-2 px-3 py-2 text-xs transition-colors ${danger ? "text-red-600 hover:bg-red-50" : "text-gray-700 hover:bg-gray-50"}`}>
                      {label as string}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
        <button onClick={() => onOpen(book)}
          className="mt-2.5 w-full flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
          <BookOpen size={11} /> {book.progress > 0 && book.status !== "Selesai" ? "Lanjutkan" : "Buka Buku"}
        </button>
      </div>
    </div>
  );
}

// ── Detail Drawer ─────────────────────────────────────────────────────────────
function DetailDrawer({ book, onClose, onOpen }: { book: Book; onClose: () => void; onOpen: (b: Book) => void }) {
  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/30" onClick={onClose} />
      <div className="fixed top-0 right-0 h-screen w-[380px] bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-300">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900 flex-1 mr-2 truncate">{book.judul}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 shrink-0"><X size={16} /></button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          <div className="flex gap-4">
            <BookCover judul={book.judul} kategori={book.kategori} className="w-20 h-28 shrink-0" />
            <div className="flex-1 min-w-0 space-y-1.5">
              <KategoriBadge k={book.kategori} />
              <StatusBadge s={book.status} />
              <p className="text-xs text-gray-500">{book.penulis}</p>
              <p className="text-xs text-gray-400">{book.halaman} halaman • PDF</p>
            </div>
          </div>

          {book.status !== "Belum Dibaca" && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-gray-600">Progress Membaca</span>
                <span className="text-xs font-bold text-gray-800">{book.progress}%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-2 rounded-full bg-blue-500" style={{ width: `${book.progress}%` }} />
              </div>
            </div>
          )}

          <div className="grid grid-cols-3 gap-3">
            {[
              { icon: StickyNote, label: "Catatan", val: book.catatan, color: "#3B82F6" },
              { icon: Bookmark,   label: "Highlight", val: book.highlight, color: "#F59E0B" },
              { icon: Bookmark,   label: "Bookmark", val: book.bookmark, color: "#8B5CF6" },
            ].map(s => (
              <div key={s.label} className="bg-gray-50 rounded-xl p-3 text-center">
                <p className="text-lg font-bold" style={{ color: s.color }}>{s.val}</p>
                <p className="text-[10px] text-gray-400">{s.label}</p>
              </div>
            ))}
          </div>

          {[
            { label: "Terakhir Dibaca", value: book.terakhirDibaca ?? "Belum pernah dibaca" },
            { label: "Ukuran File", value: "~8.4 MB" },
            { label: "Ditambahkan", value: "10 Jun 2026" },
          ].map(r => (
            <div key={r.label} className="flex justify-between py-2 border-b border-gray-50">
              <span className="text-xs text-gray-500">{r.label}</span>
              <span className="text-xs font-medium text-gray-800 text-right">{r.value}</span>
            </div>
          ))}

          {book.terakhirDibaca && (
            <div className="bg-gray-50 rounded-xl p-3">
              <p className="text-[10px] font-semibold text-gray-500 mb-1.5">Aktivitas Terakhir</p>
              <p className="text-xs text-gray-700">Terakhir dibaca pada halaman {Math.round(book.halaman * book.progress / 100)}</p>
              <p className="text-[10px] text-gray-400 mt-0.5">{book.terakhirDibaca} • Durasi sesi 27 menit</p>
            </div>
          )}
        </div>
        <div className="px-5 py-4 border-t border-gray-100 space-y-2">
          <button onClick={() => onOpen(book)}
            className="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-semibold text-white bg-gray-900 rounded-xl hover:bg-black transition-colors">
            <BookOpen size={15} /> {book.progress > 0 ? `Lanjutkan Halaman ${Math.round(book.halaman * book.progress / 100)}` : "Mulai Membaca"}
          </button>
          <div className="flex gap-2">
            <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"><Download size={12} /> Download</button>
            <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"><Archive size={12} /> Arsip</button>
            <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-red-500 border border-red-100 rounded-lg hover:bg-red-50 transition-colors"><Trash2 size={12} /> Hapus</button>
          </div>
        </div>
      </div>
    </>
  );
}

// ── Upload Modal ──────────────────────────────────────────────────────────────
function UploadModal({ onClose, showToast }: { onClose: () => void; showToast?: (m: string) => void }) {
  const [step, setStep] = useState<"drop"|"form"|"uploading"|"success">("drop");
  const [dragging, setDragging] = useState(false);
  const [judul, setJudul] = useState("");
  const [kategori, setKategori] = useState("Akuntansi");

  const handleFileSelect = () => setStep("form");
  const handleUpload = () => {
    setStep("uploading");
    setTimeout(() => { setStep("success"); }, 1500);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-0 right-0 h-screen w-[480px] bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-300">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Upload Buku</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-5 space-y-4">
          {step === "drop" && (
            <>
              <div onDragOver={e => { e.preventDefault(); setDragging(true); }}
                onDragLeave={() => setDragging(false)}
                onDrop={e => { e.preventDefault(); setDragging(false); handleFileSelect(); }}
                onClick={handleFileSelect}
                className={`border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-colors ${dragging ? "border-gray-900 bg-gray-50" : "border-gray-200 hover:border-gray-300"}`}>
                <Upload size={32} className="text-gray-300 mx-auto mb-3" />
                <p className="text-sm font-semibold text-gray-700 mb-1">Seret file PDF ke sini</p>
                <p className="text-xs text-gray-400 mb-3">atau klik untuk memilih file</p>
                <span className="text-xs text-gray-500 bg-gray-100 px-3 py-1.5 rounded-lg">PDF • Maks. 50 MB per file</span>
              </div>
              <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 text-xs text-blue-700 flex items-start gap-2">
                <AlertCircle size={13} className="shrink-0 mt-0.5" />
                Pastikan Anda hanya mengunggah dokumen yang dimiliki atau memiliki izin untuk digunakan.
              </div>
            </>
          )}

          {step === "form" && (
            <>
              <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-xl p-3">
                <CheckCircle2 size={16} className="text-green-600 shrink-0" />
                <div>
                  <p className="text-xs font-semibold text-green-700">Akuntansi_Keuangan_Menengah.pdf</p>
                  <p className="text-[10px] text-green-600">8.4 MB • PDF • 182 halaman terdeteksi</p>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Judul Buku <span className="text-red-500">*</span></label>
                <input value={judul} onChange={e => setJudul(e.target.value)} defaultValue="Akuntansi Keuangan Menengah"
                  className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Penulis</label>
                <input defaultValue="Modul Pembelajaran Pribadi" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">Kategori</label>
                  <select value={kategori} onChange={e => setKategori(e.target.value)} className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                    {["Akuntansi","Keuangan","Produktivitas","Karier","Rohani","Pengembangan Diri","Lainnya"].map(k => <option key={k}>{k}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">Bahasa</label>
                  <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                    <option>Bahasa Indonesia</option><option>English</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Tag</label>
                <input placeholder="kuliah, akuntansi, ujian..." className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Cover Buku</label>
                <div className="flex gap-2">
                  {["Halaman Pertama","Upload Manual","Cover Default"].map(o => (
                    <button key={o} className="flex-1 py-2 text-xs font-semibold rounded-lg border text-gray-600 border-gray-200 hover:bg-gray-50 transition-colors">{o}</button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Status Awal</label>
                <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                  {["Belum Dibaca","Sedang Dibaca","Selesai"].map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked />
                <span className="text-xs text-gray-700">Mulai membaca setelah upload selesai</span>
              </label>
            </>
          )}

          {step === "uploading" && (
            <div className="flex flex-col items-center py-16 space-y-4">
              <RefreshCw size={32} className="text-gray-400 animate-spin" />
              <p className="text-sm font-semibold text-gray-700">Mengunggah buku...</p>
              <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                <div className="h-2 bg-gray-900 rounded-full animate-pulse" style={{ width: "65%" }} />
              </div>
              <p className="text-xs text-gray-400">Memproses PDF — jangan tutup halaman ini</p>
            </div>
          )}

          {step === "success" && (
            <div className="flex flex-col items-center py-16 space-y-4 text-center">
              <div className="w-16 h-16 rounded-2xl bg-green-50 flex items-center justify-center">
                <CheckCircle2 size={32} className="text-green-600" />
              </div>
              <p className="text-base font-bold text-gray-900">Buku Berhasil Diunggah</p>
              <p className="text-xs text-gray-500">Buku telah ditambahkan ke koleksi Anda dan siap untuk dibaca.</p>
              <button onClick={() => { showToast?.("Buku berhasil diunggah."); onClose(); }}
                className="px-6 py-2.5 text-sm font-semibold text-white bg-gray-900 rounded-xl hover:bg-black transition-colors">
                Buka Koleksi
              </button>
            </div>
          )}
        </div>

        {(step === "form") && (
          <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
            <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
            <button onClick={handleUpload} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors flex items-center gap-2">
              <Upload size={13} /> Upload Buku
            </button>
          </div>
        )}
      </div>
    </>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function KoleksiBukuPage({ topBar, onOpenReader }: {
  topBar?: React.ReactNode;
  onOpenReader?: (book: Book) => void;
}) {
  const [tab, setTab]           = useState<BookTab>("semua");
  const [view, setView]         = useState<ViewMode>("grid");
  const [search, setSearch]     = useState("");
  const [filterKat, setFilterKat] = useState("Semua Kategori");
  const [filterStatus, setFilterStatus] = useState("Semua Status");
  const [showUpload, setShowUpload] = useState(false);
  const [detailBook, setDetailBook] = useState<Book | null>(null);
  const [books, setBooks]       = useState<Book[]>(BOOKS);
  const showToast               = (msg: string) => console.log(msg);

  const toggleFavorite = (id: number) => setBooks(bs => bs.map(b => b.id === id ? { ...b, favorit: !b.favorit } : b));

  const filtered = books.filter(b => {
    const q = search.toLowerCase();
    const matchQ = !q || b.judul.toLowerCase().includes(q) || b.penulis.toLowerCase().includes(q) || b.kategori.toLowerCase().includes(q);
    const matchK = filterKat === "Semua Kategori" || b.kategori === filterKat;
    const matchS = filterStatus === "Semua Status" || b.status === filterStatus;
    const matchTab = tab === "semua" ? true : tab === "dibaca" ? b.status === "Sedang Dibaca" : tab === "selesai" ? b.status === "Selesai" : tab === "favorit" ? b.favorit : b.status === "Diarsipkan";
    return matchQ && matchK && matchS && matchTab;
  });

  const TABS: { id: BookTab; label: string; count: number }[] = [
    { id: "semua",   label: "Semua Buku",    count: books.length },
    { id: "dibaca",  label: "Sedang Dibaca", count: books.filter(b => b.status === "Sedang Dibaca").length },
    { id: "selesai", label: "Selesai",       count: books.filter(b => b.status === "Selesai").length },
    { id: "favorit", label: "Favorit",       count: books.filter(b => b.favorit).length },
    { id: "arsip",   label: "Arsip",         count: books.filter(b => b.status === "Diarsipkan").length },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Koleksi Buku</h1>
            <p className="text-xs text-gray-500 mt-0.5">Kelola, organisir, dan temukan seluruh koleksi buku digital Anda.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
              <Tag size={13} /> Kelola Kategori
            </button>
            <button onClick={() => setShowUpload(true)}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors shadow-sm">
              <Upload size={13} /> Upload Buku
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <SummaryCard label="Total Koleksi"    value={18} desc="Buku tersimpan dalam library"    color="#111827" icon={BookOpen} />
          <SummaryCard label="Sedang Dibaca"    value={4}  desc="Buku dengan progres aktif"       color="#3B82F6" icon={Eye} />
          <SummaryCard label="Selesai Dibaca"   value={7}  desc="Buku telah diselesaikan"         color="#22C55E" icon={CheckCircle2} />
          <SummaryCard label="Halaman Bulan Ini" value={426} desc="Dibaca selama Juli 2026"       color="#8B5CF6" icon={FileText} />
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${tab === t.id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              {t.label}
              <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${tab === t.id ? "bg-gray-100 text-gray-700" : "bg-white/0 text-gray-400"}`}>{t.count}</span>
            </button>
          ))}
        </div>

        {/* Filter Toolbar */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari judul, penulis, atau tag..."
              className="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-lg outline-none bg-white focus:ring-1 focus:ring-gray-300" />
          </div>
          <select value={filterKat} onChange={e => setFilterKat(e.target.value)} className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
            <option>Semua Kategori</option>
            {["Akuntansi","Keuangan","Produktivitas","Karier","Rohani","Pengembangan Diri","Lainnya"].map(k => <option key={k}>{k}</option>)}
          </select>
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
            <option>Semua Status</option>
            {["Belum Dibaca","Sedang Dibaca","Selesai","Diarsipkan"].map(s => <option key={s}>{s}</option>)}
          </select>
          <select className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
            {["Terakhir Dibaca","Terbaru Ditambahkan","Judul A–Z","Progress Tertinggi"].map(s => <option key={s}>{s}</option>)}
          </select>
          <div className="flex gap-1 border border-gray-200 rounded-lg overflow-hidden bg-white">
            <button onClick={() => setView("grid")} className={`px-2.5 py-2 transition-colors ${view === "grid" ? "bg-gray-900 text-white" : "text-gray-400 hover:bg-gray-50"}`}><Grid3X3 size={14} /></button>
            <button onClick={() => setView("list")} className={`px-2.5 py-2 transition-colors ${view === "list" ? "bg-gray-900 text-white" : "text-gray-400 hover:bg-gray-50"}`}><List size={14} /></button>
          </div>
          <button onClick={() => { setSearch(""); setFilterKat("Semua Kategori"); setFilterStatus("Semua Status"); }}
            className="flex items-center gap-1 text-xs text-gray-500 hover:text-gray-700 px-2.5 py-2 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors">
            <Filter size={12} /> Reset
          </button>
        </div>

        {/* Content */}
        {filtered.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-xl p-12 text-center">
            <BookOpen size={32} className="text-gray-200 mx-auto mb-3" />
            <p className="text-sm font-semibold text-gray-700 mb-1">Koleksi buku masih kosong</p>
            <p className="text-xs text-gray-400 mb-4">Upload buku PDF pertama untuk mulai membangun library pribadi Anda.</p>
            <button onClick={() => setShowUpload(true)}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
              <Upload size={13} /> Upload Buku
            </button>
          </div>
        ) : view === "grid" ? (
          <div className="grid grid-cols-4 gap-4">
            {filtered.map(b => (
              <BookCard key={b.id} book={b} onDetail={setDetailBook} onFavorite={toggleFavorite} onOpen={b => onOpenReader?.(b)} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50/70">
                  {["Buku","Penulis","Kategori","Progress","Halaman","Terakhir Dibaca","Status","Aksi"].map(h => (
                    <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(b => (
                  <tr key={b.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => setDetailBook(b)}>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <BookCover judul={b.judul} kategori={b.kategori} className="w-8 h-10 shrink-0" />
                        <span className="text-xs font-medium text-gray-800 max-w-[180px] truncate">{b.judul}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-xs text-gray-500">{b.penulis}</td>
                    <td className="py-3 px-4"><KategoriBadge k={b.kategori} /></td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                          <div className="h-1.5 rounded-full bg-blue-500" style={{ width: `${b.progress}%` }} />
                        </div>
                        <span className="text-xs text-gray-600">{b.progress}%</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-xs text-gray-500">{b.halaman}</td>
                    <td className="py-3 px-4 text-xs text-gray-400">{b.terakhirDibaca ?? "—"}</td>
                    <td className="py-3 px-4"><StatusBadge s={b.status} /></td>
                    <td className="py-3 px-4" onClick={e => e.stopPropagation()}>
                      <button onClick={() => onOpenReader?.(b)} className="text-xs text-gray-600 border border-gray-200 px-2.5 py-1 rounded-lg hover:bg-gray-50 transition-colors">Buka</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showUpload && <UploadModal onClose={() => setShowUpload(false)} showToast={showToast} />}
      {detailBook && <DetailDrawer book={detailBook} onClose={() => setDetailBook(null)} onOpen={b => { setDetailBook(null); onOpenReader?.(b); }} />}
    </main>
  );
}
