import React, { useState } from "react";
import { AlertCircle, Check, Plus, Trash2, Download, FileText, ChevronRight } from "lucide-react";

const fmtRp = (n: number) => "Rp" + n.toLocaleString("id-ID");

// ── Stepper Header ─────────────────────────────────────────────────────────────
const STEPS = [
  { id: 1, label: "Data Wajib Pajak" },
  { id: 2, label: "Penghasilan" },
  { id: 3, label: "Harta & Utang" },
  { id: 4, label: "Perhitungan" },
  { id: 5, label: "Review & Export" },
];

function StepperHeader({ current }: { current: number }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
      <div className="flex items-center">
        {STEPS.map((s, i) => (
          <React.Fragment key={s.id}>
            <div className="flex flex-col items-center gap-1">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2 transition-colors ${
                s.id < current  ? "bg-gray-900 border-gray-900 text-white" :
                s.id === current? "bg-white border-gray-900 text-gray-900" :
                                  "bg-white border-gray-300 text-gray-400"
              }`}>
                {s.id < current ? <Check size={14} /> : s.id}
              </div>
              <span className={`text-[10px] font-medium whitespace-nowrap ${s.id <= current ? "text-gray-900" : "text-gray-400"}`}>
                {s.label}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div className={`flex-1 h-0.5 mx-2 mb-4 ${s.id < current ? "bg-gray-900" : "bg-gray-200"}`} />
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

// ── Step 1: Data Wajib Pajak ───────────────────────────────────────────────────
function Step1({ onNext }: { onNext: () => void }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-5">
      <h2 className="text-sm font-bold text-gray-900">Data Wajib Pajak</h2>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1.5">Nama Lengkap</label>
          <input type="text" defaultValue="Salgado Ginting" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900" />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1.5">NPWP / NIK</label>
          <input type="text" placeholder="16 digit" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900" />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1.5">Status PTKP</label>
          <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
            <option>TK/0 — Tidak Kawin, Tanpa Tanggungan</option>
            <option>TK/1 — Tidak Kawin, 1 Tanggungan</option>
            <option>K/0 — Kawin, Tanpa Tanggungan</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1.5">Status Perkawinan</label>
          <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
            <option>Belum Kawin</option><option>Kawin</option><option>Cerai</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1.5">Jumlah Tanggungan</label>
          <input type="number" defaultValue="0" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900" />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1.5">Tahun Pajak</label>
          <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
            <option>2025</option><option>2024</option>
          </select>
        </div>
        <div className="col-span-2">
          <label className="block text-xs font-medium text-gray-700 mb-1.5">Alamat</label>
          <textarea rows={2} defaultValue="Bogor, Jawa Barat" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900 resize-none" />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1.5">Nomor Telepon</label>
          <input type="tel" defaultValue="+62 812 3456 7890" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900" />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1.5">Email</label>
          <input type="email" defaultValue="salgadoginting@apps.ipb.ac.id" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-900" />
        </div>
      </div>
      <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
        <button className="px-4 py-2 text-sm text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Simpan Draft</button>
        <button onClick={onNext} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black flex items-center gap-1.5">
          Lanjutkan <ChevronRight size={14} />
        </button>
      </div>
    </div>
  );
}

// ── Step 2: Penghasilan ────────────────────────────────────────────────────────
function Step2({ onNext, onPrev }: { onNext: () => void; onPrev: () => void }) {
  const SECTIONS = [
    "Penghasilan dari Pekerjaan",
    "Penghasilan Usaha",
    "Penghasilan Lainnya",
    "Penghasilan Final",
    "Penghasilan Bukan Objek Pajak",
    "Kredit Pajak",
    "Bukti Potong",
  ];
  const [open, setOpen] = useState(0);
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-4">
      <h2 className="text-sm font-bold text-gray-900">Penghasilan</h2>
      <div className="space-y-2">
        {SECTIONS.map((s, i) => (
          <div key={s} className="border border-gray-200 rounded-lg overflow-hidden">
            <button
              onClick={() => setOpen(open === i ? -1 : i)}
              className="w-full flex items-center justify-between px-4 py-3 text-sm font-medium text-gray-800 hover:bg-gray-50"
            >
              {s}
              <ChevronRight size={14} className={`text-gray-400 transition-transform ${open === i ? "rotate-90" : ""}`} />
            </button>
            {open === i && (
              <div className="px-4 py-3 border-t border-gray-100 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Keterangan</label>
                    <input type="text" placeholder="Contoh: Gaji, Honorarium..." className="w-full text-sm px-3 py-1.5 border border-gray-200 rounded-lg outline-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Jumlah (Rp)</label>
                    <input type="text" placeholder="Rp0" className="w-full text-sm px-3 py-1.5 border border-gray-200 rounded-lg outline-none" />
                  </div>
                </div>
                {s === "Bukti Potong" && (
                  <div className="border-2 border-dashed border-gray-200 rounded-lg p-4 text-center text-xs text-gray-400 cursor-pointer hover:border-gray-400">
                    Upload Bukti Potong (PDF / JPG)
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="flex justify-between gap-2 pt-2 border-t border-gray-100">
        <button onClick={onPrev} className="px-4 py-2 text-sm text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Kembali</button>
        <div className="flex gap-2">
          <button className="px-4 py-2 text-sm text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Simpan Draft</button>
          <button onClick={onNext} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black flex items-center gap-1.5">
            Lanjutkan <ChevronRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Step 3: Harta & Utang ──────────────────────────────────────────────────────
const HARTA_INIT = [
  { jenis: "Rekening Bank", tahun: "2024", nilai: "4850000", ket: "Bank Utama" },
  { jenis: "Laptop",        tahun: "2023", nilai: "1600000", ket: "" },
];
const UTANG_INIT = [
  { pemberi: "Teman A", tahun: "2025", saldo: "200000", ket: "Pinjaman buku" },
];

function Step3({ onNext, onPrev }: { onNext: () => void; onPrev: () => void }) {
  const [harta, setHarta] = useState(HARTA_INIT);
  const [utang, setUtang] = useState(UTANG_INIT);
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-5">
      <h2 className="text-sm font-bold text-gray-900">Harta & Utang</h2>

      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-semibold text-gray-700">Daftar Harta</p>
          <button onClick={() => setHarta([...harta, { jenis: "", tahun: "2025", nilai: "0", ket: "" }])}
            className="text-xs text-blue-600 hover:underline flex items-center gap-1"><Plus size={11} /> Tambah Harta</button>
        </div>
        <table className="w-full text-xs border border-gray-200 rounded-lg overflow-hidden">
          <thead><tr className="bg-gray-50 border-b border-gray-200">
            {["Jenis Harta","Tahun Perolehan","Nilai (Rp)","Keterangan",""].map(h => <th key={h} className="px-3 py-2 text-left font-medium text-gray-500">{h}</th>)}
          </tr></thead>
          <tbody>
            {harta.map((r, i) => (
              <tr key={i} className="border-b border-gray-100">
                <td className="px-2 py-1.5"><input value={r.jenis} onChange={e => setHarta(harta.map((x,j) => j===i?{...x,jenis:e.target.value}:x))} className="w-full text-xs px-2 py-1 border border-gray-200 rounded outline-none" /></td>
                <td className="px-2 py-1.5"><input value={r.tahun} onChange={e => setHarta(harta.map((x,j) => j===i?{...x,tahun:e.target.value}:x))} className="w-20 text-xs px-2 py-1 border border-gray-200 rounded outline-none" /></td>
                <td className="px-2 py-1.5"><input value={r.nilai} onChange={e => setHarta(harta.map((x,j) => j===i?{...x,nilai:e.target.value}:x))} className="w-28 text-xs px-2 py-1 border border-gray-200 rounded outline-none text-right" /></td>
                <td className="px-2 py-1.5"><input value={r.ket} onChange={e => setHarta(harta.map((x,j) => j===i?{...x,ket:e.target.value}:x))} className="w-full text-xs px-2 py-1 border border-gray-200 rounded outline-none" /></td>
                <td className="px-2 py-1.5"><button onClick={() => setHarta(harta.filter((_,j) => j!==i))} className="p-0.5 text-gray-400 hover:text-red-500"><Trash2 size={12} /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-semibold text-gray-700">Daftar Utang</p>
          <button onClick={() => setUtang([...utang, { pemberi: "", tahun: "2025", saldo: "0", ket: "" }])}
            className="text-xs text-blue-600 hover:underline flex items-center gap-1"><Plus size={11} /> Tambah Utang</button>
        </div>
        <table className="w-full text-xs border border-gray-200 rounded-lg overflow-hidden">
          <thead><tr className="bg-gray-50 border-b border-gray-200">
            {["Pemberi Pinjaman","Tahun Pinjaman","Saldo Akhir (Rp)","Keterangan",""].map(h => <th key={h} className="px-3 py-2 text-left font-medium text-gray-500">{h}</th>)}
          </tr></thead>
          <tbody>
            {utang.map((r, i) => (
              <tr key={i} className="border-b border-gray-100">
                <td className="px-2 py-1.5"><input value={r.pemberi} onChange={e => setUtang(utang.map((x,j) => j===i?{...x,pemberi:e.target.value}:x))} className="w-full text-xs px-2 py-1 border border-gray-200 rounded outline-none" /></td>
                <td className="px-2 py-1.5"><input value={r.tahun} onChange={e => setUtang(utang.map((x,j) => j===i?{...x,tahun:e.target.value}:x))} className="w-20 text-xs px-2 py-1 border border-gray-200 rounded outline-none" /></td>
                <td className="px-2 py-1.5"><input value={r.saldo} onChange={e => setUtang(utang.map((x,j) => j===i?{...x,saldo:e.target.value}:x))} className="w-28 text-xs px-2 py-1 border border-gray-200 rounded outline-none text-right" /></td>
                <td className="px-2 py-1.5"><input value={r.ket} onChange={e => setUtang(utang.map((x,j) => j===i?{...x,ket:e.target.value}:x))} className="w-full text-xs px-2 py-1 border border-gray-200 rounded outline-none" /></td>
                <td className="px-2 py-1.5"><button onClick={() => setUtang(utang.filter((_,j) => j!==i))} className="p-0.5 text-gray-400 hover:text-red-500"><Trash2 size={12} /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex justify-between gap-2 pt-2 border-t border-gray-100">
        <button onClick={onPrev} className="px-4 py-2 text-sm text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Kembali</button>
        <button onClick={onNext} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black flex items-center gap-1.5">Lanjutkan <ChevronRight size={14} /></button>
      </div>
    </div>
  );
}

// ── Step 4: Perhitungan ────────────────────────────────────────────────────────
function Step4({ onNext, onPrev }: { onNext: () => void; onPrev: () => void }) {
  const penghasilan = 6500000 * 12;
  const ptkp = 54000000;
  const pkp = penghasilan - ptkp;
  const pph = pkp * 0.05;
  const kreditPajak = 0;
  const kurangBayar = pph - kreditPajak;

  const items = [
    { label: "Penghasilan Neto",       value: fmtRp(penghasilan),  color: "" },
    { label: "PTKP (TK/0)",            value: `(${fmtRp(ptkp)})`,  color: "text-red-500" },
    { label: "Penghasilan Kena Pajak", value: fmtRp(pkp),          color: "" },
    { label: "PPh Terutang (Tarif 5%)",value: fmtRp(pph),          color: "text-red-500" },
    { label: "Kredit Pajak",           value: fmtRp(kreditPajak),  color: "" },
    { label: "Kurang Bayar",           value: fmtRp(kurangBayar),  color: "text-amber-600 font-bold" },
  ];

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-5">
      <h2 className="text-sm font-bold text-gray-900">Estimasi Perhitungan SPT</h2>
      <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2">
        <AlertCircle size={14} className="text-amber-600 mt-0.5 shrink-0" />
        <p className="text-xs text-amber-800">Hasil merupakan estimasi berdasarkan data yang dimasukkan pengguna. Konsultasikan dengan konsultan pajak untuk kepastian.</p>
      </div>
      <div className="max-w-md space-y-0">
        {items.map((item, i) => (
          <div key={i} className={`flex justify-between py-3 border-b border-gray-100 text-sm ${i === items.length - 1 ? "border-t-2 border-gray-200 mt-2 font-bold" : ""}`}>
            <span className="text-gray-700">{item.label}</span>
            <span className={item.color || "text-gray-900"}>{item.value}</span>
          </div>
        ))}
      </div>
      <div className="flex justify-between gap-2 pt-2 border-t border-gray-100">
        <button onClick={onPrev} className="px-4 py-2 text-sm text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Kembali</button>
        <button onClick={onNext} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black flex items-center gap-1.5">Review <ChevronRight size={14} /></button>
      </div>
    </div>
  );
}

// ── Step 5: Review & Export ────────────────────────────────────────────────────
function Step5({ onPrev }: { onPrev: () => void }) {
  const [status, setStatus] = useState<"Draft" | "Siap Ditinjau" | "Selesai">("Draft");
  const CHECKLIST = [
    { label: "Data wajib pajak lengkap",       done: true  },
    { label: "Penghasilan lengkap",             done: true  },
    { label: "Harta dan utang lengkap",         done: true  },
    { label: "Dokumen pendukung tersedia",      done: false },
    { label: "Perhitungan telah diperiksa",    done: true  },
  ];

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-gray-900">Review & Export</h2>
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500">Status:</span>
          {(["Draft","Siap Ditinjau","Selesai"] as const).map(s => (
            <button key={s} onClick={() => setStatus(s)}
              className={`text-xs font-semibold px-2.5 py-1 rounded border transition-colors ${status === s
                ? s === "Draft" ? "bg-gray-100 text-gray-700 border-gray-300"
                  : s === "Siap Ditinjau" ? "bg-amber-100 text-amber-700 border-amber-300"
                  : "bg-green-100 text-green-700 border-green-300"
                : "bg-white text-gray-400 border-gray-200"}`}>
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl">
        <p className="text-xs text-blue-800 font-medium">
          Fitur ini membantu menyiapkan dan menghitung data SPT. Pengiriman resmi tetap dilakukan melalui kanal resmi Direktorat Jenderal Pajak.
        </p>
      </div>

      <div>
        <p className="text-xs font-semibold text-gray-700 mb-3">Checklist Validasi</p>
        <div className="space-y-2">
          {CHECKLIST.map((c, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg border border-gray-100">
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${c.done ? "bg-green-500 border-green-500" : "border-gray-300"}`}>
                {c.done && <Check size={11} className="text-white" />}
              </div>
              <span className={`text-sm ${c.done ? "text-gray-700" : "text-gray-400"}`}>{c.label}</span>
              {!c.done && <span className="ml-auto text-xs text-amber-600 font-medium">Perlu Dilengkapi</span>}
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 pt-2 border-t border-gray-100">
        <button onClick={onPrev} className="px-4 py-2 text-sm text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Kembali dan Perbaiki</button>
        <div className="flex items-center gap-2">
          <button className="px-4 py-2 text-sm text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Simpan Draft</button>
          <button className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700">
            <Download size={14} /> Export PDF
          </button>
          <button className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-green-600 rounded-lg hover:bg-green-700">
            <Download size={14} /> Export Excel
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export function SPTPage({ topBar }: { topBar: React.ReactNode }) {
  const [step, setStep] = useState(1);

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-6">
        <div>
          <h1 className="text-xl font-bold text-gray-900">SPT Orang Pribadi</h1>
          <p className="text-sm text-gray-500 mt-1">Siapkan data dan estimasi perhitungan SPT Tahunan pribadi.</p>
        </div>

        <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl flex items-start gap-2">
          <AlertCircle size={14} className="text-blue-600 mt-0.5 shrink-0" />
          <p className="text-xs text-blue-700">
            Fitur ini membantu menyiapkan dan menghitung data SPT. Pengiriman resmi tetap dilakukan melalui kanal resmi Direktorat Jenderal Pajak.
          </p>
        </div>

        <StepperHeader current={step} />

        {step === 1 && <Step1 onNext={() => setStep(2)} />}
        {step === 2 && <Step2 onNext={() => setStep(3)} onPrev={() => setStep(1)} />}
        {step === 3 && <Step3 onNext={() => setStep(4)} onPrev={() => setStep(2)} />}
        {step === 4 && <Step4 onNext={() => setStep(5)} onPrev={() => setStep(3)} />}
        {step === 5 && <Step5 onPrev={() => setStep(4)} />}
      </div>
    </main>
  );
}
