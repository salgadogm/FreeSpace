import React, { useState, useMemo } from "react";
import {
  Download, Search, Filter, X, Clock, Edit3, Sparkles,
  LogIn, Shield, ChevronDown, MoreHorizontal, ExternalLink,
  Copy, Trash2, RefreshCw, CheckCircle2, AlertTriangle,
  ArrowUpDown, Monitor,
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────
type HistoryTab = "semua" | "perubahan" | "ai" | "login";
type AktivitasJenis = "Tambah" | "Ubah" | "Hapus" | "Buka" | "Export" | "Import" | "Upload" | "Login" | "Logout" | "Bantuan AI" | "Backup" | "Restore";
type StatusType = "Berhasil" | "Gagal" | "Dibatalkan" | "Menunggu";
type ModulType = "Dashboard" | "Keuangan" | "Produktivitas" | "Library" | "Karier" | "Pengaturan" | "Sistem" | "Akuntansi";

interface HistoryItem {
  id: number;
  waktu: string;
  modul: ModulType;
  aktivitas: AktivitasJenis;
  item: string;
  ringkasan: string;
  status: StatusType;
  sumber: string;
}

interface PerubahanItem {
  id: number;
  waktu: string;
  modul: ModulType;
  jenis: AktivitasJenis;
  item: string;
  sebelum: string;
  sesudah: string;
  status: StatusType;
}

interface AIItem {
  id: number;
  waktu: string;
  modul: ModulType;
  provider: string;
  tindakan: string;
  input: string;
  hasil: string;
  status: string;
}

interface LoginItem {
  id: number;
  waktu: string;
  aktivitas: string;
  perangkat: string;
  browser: string;
  ip: string;
  lokasi: string;
  status: StatusType;
}

// ── Data Simulasi ─────────────────────────────────────────────────────────────
const HISTORY_DATA: HistoryItem[] = [
  { id: 1, waktu: "08.12", modul: "Sistem",        aktivitas: "Login",       item: "Akun Pengguna",     ringkasan: "Berhasil masuk ke FreeSpace",                              status: "Berhasil", sumber: "Web" },
  { id: 2, waktu: "08.35", modul: "Keuangan",      aktivitas: "Tambah",      item: "Transaksi",         ringkasan: "Menambahkan pengeluaran Makan Siang sebesar Rp35.000",     status: "Berhasil", sumber: "Manual" },
  { id: 3, waktu: "09.10", modul: "Produktivitas", aktivitas: "Ubah",        item: "Aktivitas",         ringkasan: "Mengubah jadwal Review Akuntansi menjadi pukul 10.00",     status: "Berhasil", sumber: "Manual" },
  { id: 4, waktu: "10.25", modul: "Library",       aktivitas: "Buka",        item: "Buku",              ringkasan: "Melanjutkan membaca Akuntansi Keuangan Menengah hal. 124", status: "Berhasil", sumber: "PDF Reader" },
  { id: 5, waktu: "11.40", modul: "Library",       aktivitas: "Tambah",      item: "Catatan",           ringkasan: "Menyimpan catatan Konsep Jurnal Penyesuaian",              status: "Berhasil", sumber: "Manual" },
  { id: 6, waktu: "13.15", modul: "Keuangan",      aktivitas: "Bantuan AI",  item: "Jurnal Akuntansi",  ringkasan: "Memproses bukti transaksi dan menghasilkan draft jurnal",   status: "Berhasil", sumber: "Gemini Vision" },
  { id: 7, waktu: "14.05", modul: "Produktivitas", aktivitas: "Ubah",        item: "Steps Tracker",     ringkasan: "Memperbarui langkah harian menjadi 7.420",                 status: "Berhasil", sumber: "Input Manual" },
  { id: 8, waktu: "15.20", modul: "Pengaturan",    aktivitas: "Ubah",        item: "Preferensi",        ringkasan: "Mengubah format tanggal menjadi DD MMM YYYY",              status: "Berhasil", sumber: "Web" },
  { id: 9, waktu: "16.00", modul: "Keuangan",      aktivitas: "Export",      item: "Laporan",           ringkasan: "Mengekspor laporan keuangan Juni 2026 ke Excel",           status: "Berhasil", sumber: "Web" },
  { id: 10, waktu:"16.45", modul: "Produktivitas", aktivitas: "Tambah",      item: "Jurnal Harian",     ringkasan: "Menyimpan draft jurnal harian 3 Juli 2026",                status: "Berhasil", sumber: "Web" },
];

const PERUBAHAN_DATA: PerubahanItem[] = [
  { id: 1, waktu: "08.35", modul: "Keuangan",      jenis: "Tambah", item: "Transaksi — Makan Siang",    sebelum: "—",           sesudah: "Rp35.000",     status: "Berhasil" },
  { id: 2, waktu: "09.10", modul: "Produktivitas", jenis: "Ubah",   item: "Aktivitas — Review Akuntansi",sebelum: "09.00",        sesudah: "10.00",        status: "Berhasil" },
  { id: 3, waktu: "11.40", modul: "Library",       jenis: "Tambah", item: "Catatan — Jurnal Penyesuaian",sebelum: "—",           sesudah: "Draft disimpan",status: "Berhasil" },
  { id: 4, waktu: "14.05", modul: "Produktivitas", jenis: "Ubah",   item: "Steps Tracker",               sebelum: "6.890",       sesudah: "7.420",        status: "Berhasil" },
  { id: 5, waktu: "15.20", modul: "Pengaturan",    jenis: "Ubah",   item: "Preferensi — Format Tanggal", sebelum: "DD/MM/YYYY",  sesudah: "DD MMM YYYY",  status: "Berhasil" },
  { id: 6, waktu: "15.55", modul: "Keuangan",      jenis: "Ubah",   item: "Budget — Makanan",            sebelum: "Rp1.000.000", sesudah: "Rp1.200.000",  status: "Berhasil" },
  { id: 7, waktu: "16.45", modul: "Produktivitas", jenis: "Tambah", item: "Jurnal Harian",               sebelum: "—",           sesudah: "Draft 3 Jul",  status: "Berhasil" },
];

const AI_DATA: AIItem[] = [
  { id: 1, waktu: "13.15", modul: "Keuangan",  provider: "Gemini", tindakan: "Analisis Bukti Transaksi", input: "Struk makan siang",  hasil: "Draft jurnal dibuat", status: "Disetujui Pengguna" },
  { id: 2, waktu: "10.50", modul: "Library",   provider: "Grok",   tindakan: "Ringkas Teks Terpilih",   input: "Halaman 124",         hasil: "Ringkasan disimpan ke catatan", status: "Berhasil" },
  { id: 3, waktu: "09.30", modul: "Karier",    provider: "Gemini", tindakan: "Analisis CV",              input: "CV Akuntansi 2026",   hasil: "ATS score 82%",       status: "Berhasil" },
];

const LOGIN_DATA: LoginItem[] = [
  { id: 1, waktu: "3 Jul 2026, 08.12",  aktivitas: "Login",  perangkat: "Windows Laptop", browser: "Chrome",  ip: "10.0.1.45", lokasi: "Jakarta, Indonesia", status: "Berhasil" },
  { id: 2, waktu: "2 Jul 2026, 20.35",  aktivitas: "Login",  perangkat: "iPad",           browser: "Safari",  ip: "10.0.1.20", lokasi: "Jakarta, Indonesia", status: "Berhasil" },
  { id: 3, waktu: "2 Jul 2026, 08.05",  aktivitas: "Login",  perangkat: "Windows Laptop", browser: "Chrome",  ip: "10.0.1.45", lokasi: "Jakarta, Indonesia", status: "Berhasil" },
  { id: 4, waktu: "1 Jul 2026, 07.50",  aktivitas: "Login",  perangkat: "Windows Laptop", browser: "Chrome",  ip: "10.0.1.45", lokasi: "Jakarta, Indonesia", status: "Berhasil" },
];

// ── Config ────────────────────────────────────────────────────────────────────
const JENIS_CFG: Record<AktivitasJenis, { color: string; bg: string }> = {
  Tambah:      { color: "#22C55E", bg: "#DCFCE7" },
  Ubah:        { color: "#F59E0B", bg: "#FEF3C7" },
  Hapus:       { color: "#EF4444", bg: "#FEE2E2" },
  Buka:        { color: "#6B7280", bg: "#F3F4F6" },
  Export:      { color: "#8B5CF6", bg: "#EDE9FE" },
  Import:      { color: "#0D9488", bg: "#CCFBF1" },
  Upload:      { color: "#3B82F6", bg: "#DBEAFE" },
  Login:       { color: "#3B82F6", bg: "#DBEAFE" },
  Logout:      { color: "#6B7280", bg: "#F3F4F6" },
  "Bantuan AI":{ color: "#8B5CF6", bg: "#EDE9FE" },
  Backup:      { color: "#0D9488", bg: "#CCFBF1" },
  Restore:     { color: "#F59E0B", bg: "#FEF3C7" },
};

const STATUS_CFG: Record<StatusType, { color: string; bg: string }> = {
  Berhasil:   { color: "#22C55E", bg: "#DCFCE7" },
  Gagal:      { color: "#EF4444", bg: "#FEE2E2" },
  Dibatalkan: { color: "#9CA3AF", bg: "#F3F4F6" },
  Menunggu:   { color: "#F59E0B", bg: "#FEF3C7" },
};

const MODUL_LIST: ModulType[] = ["Dashboard","Keuangan","Produktivitas","Library","Karier","Pengaturan","Sistem","Akuntansi"];
const JENIS_LIST: AktivitasJenis[] = ["Tambah","Ubah","Hapus","Buka","Export","Import","Upload","Login","Logout","Bantuan AI","Backup","Restore"];

// ── Badges ────────────────────────────────────────────────────────────────────
function JenisBadge({ j }: { j: AktivitasJenis }) {
  const c = JENIS_CFG[j];
  return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold"
    style={{ color: c.color, backgroundColor: c.bg }}>{j}</span>;
}

function StatusBadge({ s }: { s: StatusType | string }) {
  const c = STATUS_CFG[s as StatusType] ?? { color: "#3B82F6", bg: "#DBEAFE" };
  return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold"
    style={{ color: c.color, backgroundColor: c.bg }}>{s}</span>;
}

function ModulBadge({ m }: { m: ModulType }) {
  return <span className="text-xs text-gray-600 bg-gray-100 px-2 py-0.5 rounded font-medium">{m}</span>;
}

// ── Summary Card ──────────────────────────────────────────────────────────────
function SummaryCard({ label, value, desc, color, icon: Icon }: {
  label: string; value: string | number; desc: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
          style={{ backgroundColor: color + "18", color }}>
          <Icon size={16} />
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 leading-tight">{value}</p>
      <p className="text-[11px] text-gray-400 leading-snug">{desc}</p>
    </div>
  );
}

// ── Detail Drawer ─────────────────────────────────────────────────────────────
function DetailDrawer({ item, onClose }: { item: HistoryItem | null; onClose: () => void }) {
  if (!item) return null;
  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/30" onClick={onClose} />
      <div className="fixed top-0 right-0 h-screen w-[380px] bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-300">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Detail Aktivitas</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
          <div className="flex gap-2 flex-wrap">
            <JenisBadge j={item.aktivitas} />
            <StatusBadge s={item.status} />
          </div>
          {[
            { label: "Waktu",     value: `3 Juli 2026, ${item.waktu}` },
            { label: "Modul",     value: item.modul },
            { label: "Aktivitas", value: item.aktivitas },
            { label: "Item",      value: item.item },
            { label: "Ringkasan", value: item.ringkasan },
            { label: "Sumber",    value: item.sumber },
          ].map(r => (
            <div key={r.label} className="flex justify-between py-2 border-b border-gray-50 gap-4">
              <span className="text-xs text-gray-500 shrink-0">{r.label}</span>
              <span className="text-xs font-medium text-gray-800 text-right">{r.value}</span>
            </div>
          ))}
          <div className="bg-gray-50 rounded-lg p-3 text-[10px] text-gray-400">
            Referensi internal: FS-LOG-{String(item.id).padStart(6, "0")}
          </div>
        </div>
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2">
          <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <ExternalLink size={12} /> Buka Item
          </button>
          <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Copy size={12} /> Salin Detail
          </button>
          <button onClick={onClose}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
            Tutup
          </button>
        </div>
      </div>
    </>
  );
}

// ── Export Modal ──────────────────────────────────────────────────────────────
function ExportModal({ onClose, onExport }: { onClose: () => void; onExport: () => void }) {
  const [format, setFormat] = useState("Excel");
  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[440px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Unduh History</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>
        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Dari Tanggal</label>
              <input type="date" defaultValue="2026-07-01" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Sampai Tanggal</label>
              <input type="date" defaultValue="2026-07-03" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Modul</label>
            <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
              <option>Semua Modul</option>
              {MODUL_LIST.map(m => <option key={m}>{m}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Format</label>
            <div className="flex gap-2">
              {["CSV", "Excel", "PDF"].map(f => (
                <button key={f} onClick={() => setFormat(f)}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors ${format === f ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"}`}>
                  {f}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <button onClick={onExport}
            className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors flex items-center gap-2">
            <Download size={14} /> Unduh
          </button>
        </div>
      </div>
    </>
  );
}

// ── Row action menu ───────────────────────────────────────────────────────────
function RowMenu({ onDetail }: { onDetail: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={e => { e.stopPropagation(); setOpen(!open); }}
        className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors">
        <MoreHorizontal size={14} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 w-44 bg-white border border-gray-200 rounded-xl shadow-lg z-20 py-1">
            {[
              ["Lihat Detail", () => { onDetail(); setOpen(false); }],
              ["Buka Item Terkait", () => setOpen(false)],
              ["Salin Detail", () => setOpen(false)],
            ].map(([label, action]) => (
              <button key={label as string} onClick={e => { e.stopPropagation(); (action as () => void)(); }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 transition-colors">
                {label as string}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ── Filter Bar ────────────────────────────────────────────────────────────────
function FilterBar({ search, setSearch, modul, setModul, jenis, setJenis, status, setStatus, onReset }: {
  search: string; setSearch: (v: string) => void;
  modul: string; setModul: (v: string) => void;
  jenis: string; setJenis: (v: string) => void;
  status: string; setStatus: (v: string) => void;
  onReset: () => void;
}) {
  return (
    <div className="flex items-center gap-2 flex-wrap">
      <div className="relative flex-1 min-w-[200px]">
        <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari aktivitas atau item..."
          className="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 bg-white" />
      </div>
      <select value={modul} onChange={e => setModul(e.target.value)}
        className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
        <option value="">Semua Modul</option>
        {MODUL_LIST.map(m => <option key={m}>{m}</option>)}
      </select>
      <select value={jenis} onChange={e => setJenis(e.target.value)}
        className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
        <option value="">Semua Aktivitas</option>
        {JENIS_LIST.map(j => <option key={j}>{j}</option>)}
      </select>
      <select value={status} onChange={e => setStatus(e.target.value)}
        className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
        <option value="">Semua Status</option>
        {["Berhasil","Gagal","Dibatalkan","Menunggu"].map(s => <option key={s}>{s}</option>)}
      </select>
      <button onClick={onReset}
        className="flex items-center gap-1 text-xs text-gray-500 hover:text-gray-700 px-2.5 py-2 border border-gray-200 rounded-lg bg-white hover:bg-gray-50 transition-colors">
        <Filter size={12} /> Reset
      </button>
    </div>
  );
}

// ── Semua Aktivitas Tab ───────────────────────────────────────────────────────
function SemuaAktivitasTab({ onDetail }: { onDetail: (item: HistoryItem) => void }) {
  const [search, setSearch] = useState("");
  const [modul, setModul] = useState("");
  const [jenis, setJenis] = useState("");
  const [status, setStatus] = useState("");

  const filtered = useMemo(() => HISTORY_DATA.filter(h => {
    const q = search.toLowerCase();
    return (
      (h.ringkasan.toLowerCase().includes(q) || h.item.toLowerCase().includes(q) || !q) &&
      (!modul || h.modul === modul) &&
      (!jenis  || h.aktivitas === jenis) &&
      (!status || h.status === status)
    );
  }), [search, modul, jenis, status]);

  const reset = () => { setSearch(""); setModul(""); setJenis(""); setStatus(""); };

  return (
    <div className="space-y-4">
      <FilterBar {...{ search, setSearch, modul, setModul, jenis, setJenis, status, setStatus, onReset: reset }} />
      <p className="text-xs text-gray-400">{filtered.length} aktivitas ditemukan • 3 Juli 2026</p>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full" style={{ minWidth: 900 }}>
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/70">
                {["Waktu","Modul","Aktivitas","Item","Ringkasan","Status","Sumber",""].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(h => (
                <tr key={h.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors cursor-pointer"
                  onClick={() => onDetail(h)}>
                  <td className="py-3 px-4 text-xs font-mono text-gray-500 whitespace-nowrap">{h.waktu}</td>
                  <td className="py-3 px-4"><ModulBadge m={h.modul} /></td>
                  <td className="py-3 px-4"><JenisBadge j={h.aktivitas} /></td>
                  <td className="py-3 px-4 text-xs text-gray-700 whitespace-nowrap">{h.item}</td>
                  <td className="py-3 px-4 text-xs text-gray-600 max-w-[240px]"><span className="truncate block">{h.ringkasan}</span></td>
                  <td className="py-3 px-4"><StatusBadge s={h.status} /></td>
                  <td className="py-3 px-4 text-xs text-gray-500 whitespace-nowrap">{h.sumber}</td>
                  <td className="py-3 px-4" onClick={e => e.stopPropagation()}><RowMenu onDetail={() => onDetail(h)} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="py-12 text-center">
            <Clock size={28} className="text-gray-200 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Belum ada aktivitas yang sesuai filter.</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Perubahan Data Tab ────────────────────────────────────────────────────────
function PerubahanDataTab() {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input placeholder="Cari perubahan data..." className="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 bg-white" />
        </div>
        <select className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
          <option>Semua Modul</option>
          {MODUL_LIST.map(m => <option key={m}>{m}</option>)}
        </select>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full" style={{ minWidth: 900 }}>
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/70">
                {["Waktu","Modul","Jenis","Item","Nilai Sebelumnya","Nilai Setelahnya","Status",""].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {PERUBAHAN_DATA.map(p => (
                <tr key={p.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4 text-xs font-mono text-gray-500">{p.waktu}</td>
                  <td className="py-3 px-4"><ModulBadge m={p.modul} /></td>
                  <td className="py-3 px-4"><JenisBadge j={p.jenis} /></td>
                  <td className="py-3 px-4 text-xs text-gray-700 max-w-[180px]"><span className="truncate block">{p.item}</span></td>
                  <td className="py-3 px-4">
                    {p.sebelum === "—"
                      ? <span className="text-xs text-gray-300">—</span>
                      : <span className="text-xs text-red-500 bg-red-50 px-2 py-0.5 rounded line-through">{p.sebelum}</span>
                    }
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-xs text-green-700 bg-green-50 px-2 py-0.5 rounded font-medium">{p.sesudah}</span>
                  </td>
                  <td className="py-3 px-4"><StatusBadge s={p.status} /></td>
                  <td className="py-3 px-4"><RowMenu onDetail={() => {}} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Aktivitas AI Tab ──────────────────────────────────────────────────────────
function AktivitasAITab() {
  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 flex items-center gap-2">
        <Sparkles size={14} className="text-blue-500 shrink-0" />
        <p className="text-xs text-blue-700">AI hanya memproses data setelah diminta pengguna. Tidak ada data yang dikirim tanpa persetujuan.</p>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full" style={{ minWidth: 850 }}>
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/70">
                {["Waktu","Modul","Provider","Tindakan","Input","Hasil","Status",""].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {AI_DATA.map(a => (
                <tr key={a.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4 text-xs font-mono text-gray-500">{a.waktu}</td>
                  <td className="py-3 px-4"><ModulBadge m={a.modul} /></td>
                  <td className="py-3 px-4">
                    <span className="text-xs font-semibold bg-purple-50 text-purple-700 px-2 py-0.5 rounded-full">{a.provider}</span>
                  </td>
                  <td className="py-3 px-4 text-xs text-gray-700">{a.tindakan}</td>
                  <td className="py-3 px-4 text-xs text-gray-500">{a.input}</td>
                  <td className="py-3 px-4 text-xs text-gray-700">{a.hasil}</td>
                  <td className="py-3 px-4"><StatusBadge s={a.status} /></td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1">
                      <button className="p-1 rounded hover:bg-gray-100 text-gray-400 transition-colors" title="Lihat Detail"><ExternalLink size={12} /></button>
                      <button className="p-1 rounded hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors" title="Hapus Riwayat AI"><Trash2 size={12} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Login & Keamanan Tab ──────────────────────────────────────────────────────
function LoginKeamananTab() {
  const summaryStats = [
    { label: "Login Berhasil", value: 4, color: "#22C55E" },
    { label: "Login Gagal",    value: 0, color: "#EF4444" },
    { label: "Perangkat Aktif",value: 2, color: "#3B82F6" },
    { label: "Mencurigakan",   value: 0, color: "#F59E0B" },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-4">
        {summaryStats.map(s => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 text-center">
            <p className="text-2xl font-bold" style={{ color: s.color }}>{s.value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full" style={{ minWidth: 850 }}>
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/70">
                {["Waktu","Aktivitas","Perangkat","Browser","IP","Lokasi Perkiraan","Status",""].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {LOGIN_DATA.map(l => (
                <tr key={l.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4 text-xs text-gray-600 whitespace-nowrap">{l.waktu}</td>
                  <td className="py-3 px-4"><JenisBadge j={l.aktivitas as AktivitasJenis} /></td>
                  <td className="py-3 px-4 text-xs text-gray-700">{l.perangkat}</td>
                  <td className="py-3 px-4 text-xs text-gray-500">{l.browser}</td>
                  <td className="py-3 px-4 text-xs font-mono text-gray-500">{l.ip}</td>
                  <td className="py-3 px-4 text-xs text-gray-500">{l.lokasi}</td>
                  <td className="py-3 px-4"><StatusBadge s={l.status} /></td>
                  <td className="py-3 px-4">
                    <div className="flex gap-1">
                      <button className="text-[10px] font-medium text-gray-500 border border-gray-200 px-2 py-1 rounded hover:bg-gray-50 transition-colors whitespace-nowrap">Lihat Detail</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <p className="text-[10px] text-gray-400">Lokasi merupakan perkiraan berdasarkan alamat IP. Tidak dijamin akurat.</p>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function HistoryPage({ topBar }: { topBar?: React.ReactNode }) {
  const [tab, setTab] = useState<HistoryTab>("semua");
  const [detailItem, setDetailItem] = useState<HistoryItem | null>(null);
  const [showExport, setShowExport] = useState(false);
  const { showToast } = { showToast: (msg: string) => console.log(msg) };

  const tabs = [
    { id: "semua" as const,      label: "Semua Aktivitas", icon: Clock },
    { id: "perubahan" as const,  label: "Perubahan Data",  icon: Edit3 },
    { id: "ai" as const,         label: "Aktivitas AI",    icon: Sparkles },
    { id: "login" as const,      label: "Login & Keamanan",icon: Shield },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">History</h1>
            <p className="text-xs text-gray-500 mt-0.5">Lihat riwayat aktivitas dan perubahan penting di seluruh FreeSpace.</p>
          </div>
          <button onClick={() => setShowExport(true)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm shrink-0">
            <Download size={13} /> Unduh History
          </button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-5 gap-4">
          <SummaryCard label="Aktivitas Hari Ini"   value={18}     desc="Tercatat pada 3 Juli 2026"         color="#111827" icon={Clock} />
          <SummaryCard label="Perubahan Data"        value={7}      desc="Tambah, ubah, dan hapus data"      color="#F59E0B" icon={Edit3} />
          <SummaryCard label="Aktivitas AI"          value={3}      desc="Permintaan diproses hari ini"       color="#8B5CF6" icon={Sparkles} />
          <SummaryCard label="Login Terakhir"        value="08.12"  desc="Chrome pada Windows"               color="#22C55E" icon={LogIn} />
          <SummaryCard label="Peringatan Keamanan"   value={0}      desc="Tidak ada aktivitas mencurigakan"  color="#22C55E" icon={Shield} />
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${tab === t.id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              <t.icon size={13} /> {t.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {tab === "semua"     && <SemuaAktivitasTab onDetail={setDetailItem} />}
        {tab === "perubahan" && <PerubahanDataTab />}
        {tab === "ai"        && <AktivitasAITab />}
        {tab === "login"     && <LoginKeamananTab />}
      </div>

      {detailItem && <DetailDrawer item={detailItem} onClose={() => setDetailItem(null)} />}
      {showExport && <ExportModal onClose={() => setShowExport(false)} onExport={() => { setShowExport(false); }} />}
    </main>
  );
}
