import React, { useState } from "react";
import { Plus, Upload, X, Check, Bot, AlertCircle, ChevronDown, MoreHorizontal } from "lucide-react";

const fmtRp = (n: number) => "Rp" + n.toLocaleString("id-ID");

// ── Types ──────────────────────────────────────────────────────────────────────
type JurnalStatus = "Draft" | "Menunggu Review" | "Disetujui" | "Diposting" | "Ditolak";
type JurnalSumber = "Manual" | "Transaksi" | "AI Receipt" | "Penyesuaian";

// ── Shared Badge ───────────────────────────────────────────────────────────────
function StatusBadge({ s }: { s: JurnalStatus }) {
  const cfg: Record<JurnalStatus, string> = {
    Draft:             "bg-gray-100 text-gray-600 border-gray-200",
    "Menunggu Review": "bg-amber-50 text-amber-700 border-amber-200",
    Disetujui:         "bg-green-50 text-green-700 border-green-200",
    Diposting:         "bg-blue-50 text-blue-700 border-blue-200",
    Ditolak:           "bg-red-50 text-red-600 border-red-200",
  };
  return <span className={`text-[10px] font-semibold border px-1.5 py-0.5 rounded ${cfg[s]}`}>{s}</span>;
}

function SumberBadge({ s }: { s: JurnalSumber }) {
  const cfg: Record<JurnalSumber, string> = {
    Manual:       "bg-gray-50 text-gray-700",
    Transaksi:    "bg-blue-50 text-blue-700",
    "AI Receipt": "bg-purple-50 text-purple-700",
    Penyesuaian:  "bg-amber-50 text-amber-700",
  };
  return <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${cfg[s]}`}>{s}</span>;
}

// ── Jurnal Data ────────────────────────────────────────────────────────────────
const JURNAL_DATA: Array<{ no: string; tgl: string; ket: string; sumber: JurnalSumber; debit: number; kredit: number; status: JurnalStatus }> = [
  { no: "JNL-001", tgl: "3 Jul 2026",  ket: "Makan Siang",             sumber: "Transaksi",  debit: 35000,   kredit: 35000,   status: "Diposting" },
  { no: "JNL-002", tgl: "3 Jul 2026",  ket: "Transportasi Kampus",      sumber: "Transaksi",  debit: 22000,   kredit: 22000,   status: "Diposting" },
  { no: "JNL-003", tgl: "2 Jul 2026",  ket: "Buku Akuntansi",           sumber: "AI Receipt", debit: 185000,  kredit: 185000,  status: "Disetujui" },
  { no: "JNL-004", tgl: "1 Jul 2026",  ket: "Uang Saku Bulanan",        sumber: "Manual",     debit: 3000000, kredit: 3000000, status: "Diposting" },
  { no: "JNL-005", tgl: "1 Jul 2026",  ket: "Langganan Internet",       sumber: "Transaksi",  debit: 150000,  kredit: 150000,  status: "Diposting" },
  { no: "JNL-006", tgl: "30 Jun 2026", ket: "Freelance Input Data",     sumber: "Manual",     debit: 750000,  kredit: 750000,  status: "Menunggu Review" },
  { no: "JNL-007", tgl: "28 Jun 2026", ket: "Penyesuaian Akhir Bulan",  sumber: "Penyesuaian",debit: 50000,   kredit: 50000,   status: "Draft" },
];

// ── Buku Besar Data ────────────────────────────────────────────────────────────
const BB_DATA = [
  { tgl: "1 Jul 2026",  ref: "JNL-004", ket: "Uang Saku Bulanan",   debit: 3000000, kredit: 0,      saldo: 3000000 },
  { tgl: "1 Jul 2026",  ref: "JNL-005", ket: "Langganan Internet",  debit: 0,       kredit: 150000, saldo: 2850000 },
  { tgl: "2 Jul 2026",  ref: "JNL-003", ket: "Buku Akuntansi",      debit: 0,       kredit: 185000, saldo: 2665000 },
  { tgl: "3 Jul 2026",  ref: "JNL-001", ket: "Makan Siang",         debit: 0,       kredit: 35000,  saldo: 2630000 },
  { tgl: "3 Jul 2026",  ref: "JNL-002", ket: "Transportasi Kampus", debit: 0,       kredit: 22000,  saldo: 2608000 },
];

// ── Neraca Saldo Data ──────────────────────────────────────────────────────────
const NS_DATA = [
  { kode: "1-1001", nama: "Kas",             debit: 4850000, kredit: 0       },
  { kode: "1-1002", nama: "Bank",            debit: 2350000, kredit: 0       },
  { kode: "2-1001", nama: "Utang Usaha",     debit: 0,       kredit: 2200000 },
  { kode: "3-1001", nama: "Ekuitas",         debit: 0,       kredit: 3000000 },
  { kode: "4-1001", nama: "Pendapatan",      debit: 0,       kredit: 6500000 },
  { kode: "5-1001", nama: "Beban Makanan",   debit: 1008000, kredit: 0       },
  { kode: "5-1002", nama: "Beban Transport", debit: 756000,  kredit: 0       },
  { kode: "5-1003", nama: "Beban Pendidikan",debit: 567000,  kredit: 0       },
  { kode: "5-1004", nama: "Beban Tagihan",   debit: 252000,  kredit: 0       },
];

// ── Modal Jurnal Manual ────────────────────────────────────────────────────────
function JurnalModal({ onClose }: { onClose: () => void }) {
  const [lines, setLines] = useState([
    { akun: "Kas",           deskripsi: "", debit: "0",      kredit: "0" },
    { akun: "Pendapatan",    deskripsi: "", debit: "0",      kredit: "0" },
  ]);
  const [saved, setSaved] = useState(false);

  const totalDebit  = lines.reduce((s, l) => s + (parseInt(l.debit.replace(/\D/g, "")) || 0), 0);
  const totalKredit = lines.reduce((s, l) => s + (parseInt(l.kredit.replace(/\D/g, "")) || 0), 0);
  const balanced = totalDebit === totalKredit && totalDebit > 0;

  const addLine = () => setLines([...lines, { akun: "", deskripsi: "", debit: "0", kredit: "0" }]);
  const removeLine = (i: number) => setLines(lines.filter((_, idx) => idx !== i));

  if (saved) return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="bg-white rounded-2xl p-10 flex flex-col items-center gap-3 shadow-2xl">
        <div className="w-14 h-14 rounded-full bg-green-100 flex items-center justify-center"><Check size={28} className="text-green-600" /></div>
        <p className="text-base font-bold text-gray-900">Jurnal Disimpan!</p>
      </div>
    </div>
  );

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[680px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 sticky top-0 bg-white">
          <h2 className="text-sm font-bold text-gray-900">Buat Jurnal Manual</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100"><X size={16} className="text-gray-500" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Tanggal</label>
              <input type="date" defaultValue="2026-07-03" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">No. Referensi</label>
              <input type="text" placeholder="Auto" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Lampiran</label>
              <button className="w-full text-sm px-3 py-2 border border-gray-200 border-dashed rounded-lg text-gray-400 hover:bg-gray-50 flex items-center gap-2">
                <Upload size={13} /> Upload
              </button>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Keterangan</label>
            <input type="text" placeholder="Keterangan jurnal..." className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
          </div>

          {/* Journal Lines */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-medium text-gray-700">Baris Jurnal</p>
            </div>
            <table className="w-full text-xs border border-gray-200 rounded-lg overflow-hidden">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="px-3 py-2 text-left font-medium text-gray-500">Akun</th>
                  <th className="px-3 py-2 text-left font-medium text-gray-500">Deskripsi</th>
                  <th className="px-3 py-2 text-right font-medium text-gray-500">Debit</th>
                  <th className="px-3 py-2 text-right font-medium text-gray-500">Kredit</th>
                  <th className="w-8"></th>
                </tr>
              </thead>
              <tbody>
                {lines.map((l, i) => (
                  <tr key={i} className="border-b border-gray-100">
                    <td className="px-2 py-1.5">
                      <select value={l.akun} onChange={e => setLines(lines.map((x, j) => j === i ? {...x, akun: e.target.value} : x))}
                        className="w-full text-xs px-2 py-1 border border-gray-200 rounded outline-none bg-white">
                        {["Kas","Bank","Utang Usaha","Pendapatan","Beban Makanan","Beban Transport","Beban Pendidikan"].map(a => <option key={a}>{a}</option>)}
                      </select>
                    </td>
                    <td className="px-2 py-1.5">
                      <input value={l.deskripsi} onChange={e => setLines(lines.map((x, j) => j === i ? {...x, deskripsi: e.target.value} : x))}
                        className="w-full text-xs px-2 py-1 border border-gray-200 rounded outline-none" placeholder="Deskripsi..." />
                    </td>
                    <td className="px-2 py-1.5">
                      <input value={l.debit} onChange={e => setLines(lines.map((x, j) => j === i ? {...x, debit: e.target.value} : x))}
                        className="w-full text-xs px-2 py-1 border border-gray-200 rounded outline-none text-right" />
                    </td>
                    <td className="px-2 py-1.5">
                      <input value={l.kredit} onChange={e => setLines(lines.map((x, j) => j === i ? {...x, kredit: e.target.value} : x))}
                        className="w-full text-xs px-2 py-1 border border-gray-200 rounded outline-none text-right" />
                    </td>
                    <td className="px-2 py-1.5">
                      <button onClick={() => removeLine(i)} className="p-0.5 hover:bg-red-50 rounded text-gray-400 hover:text-red-500">
                        <X size={13} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-gray-50 border-t-2 border-gray-200">
                  <td colSpan={2} className="px-3 py-2 font-semibold text-xs text-gray-700">Total</td>
                  <td className="px-3 py-2 text-right font-bold text-xs">{fmtRp(totalDebit)}</td>
                  <td className="px-3 py-2 text-right font-bold text-xs">{fmtRp(totalKredit)}</td>
                  <td></td>
                </tr>
                <tr>
                  <td colSpan={5} className="px-3 py-2">
                    <div className="flex items-center gap-2">
                      {balanced
                        ? <span className="text-xs text-green-600 font-semibold flex items-center gap-1"><Check size={12} /> Seimbang</span>
                        : <span className="text-xs text-red-500 font-semibold">Selisih: {fmtRp(Math.abs(totalDebit - totalKredit))}</span>
                      }
                    </div>
                  </td>
                </tr>
              </tfoot>
            </table>
            <button onClick={addLine} className="mt-2 text-xs text-blue-600 hover:underline flex items-center gap-1">
              <Plus size={12} /> Tambah Baris
            </button>
          </div>
        </div>
        <div className="flex justify-end gap-3 px-6 py-4 border-t border-gray-100">
          <button onClick={onClose} className="px-4 py-2 text-sm text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Batal</button>
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Simpan Draft</button>
          <button
            disabled={!balanced}
            onClick={() => { if (balanced) { setSaved(true); setTimeout(onClose, 1200); } }}
            className={`px-4 py-2 text-sm font-semibold rounded-lg transition-colors ${balanced ? "bg-gray-900 text-white hover:bg-black" : "bg-gray-200 text-gray-400 cursor-not-allowed"}`}>
            Posting Jurnal
          </button>
        </div>
      </div>
    </>
  );
}

// ── AI Flow Modal ──────────────────────────────────────────────────────────────
function AIFlowModal({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState<"upload" | "processing" | "result" | "review">("upload");
  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[520px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Upload Bukti Transaksi</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100"><X size={16} className="text-gray-500" /></button>
        </div>
        <div className="p-6">
          {step === "upload" && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-200 rounded-xl p-10 text-center cursor-pointer hover:border-blue-300 hover:bg-blue-50/30 transition-colors"
                onClick={() => { setStep("processing"); setTimeout(() => setStep("result"), 2000); }}>
                <Upload size={28} className="text-gray-400 mx-auto mb-3" />
                <p className="text-sm font-medium text-gray-700 mb-1">Klik atau seret file ke sini</p>
                <p className="text-xs text-gray-400">JPG, PNG, PDF — maks. 10 MB</p>
              </div>
              <p className="text-xs text-gray-400 text-center">AI akan membaca dan membuat draft jurnal otomatis dari bukti transaksi.</p>
            </div>
          )}
          {step === "processing" && (
            <div className="py-12 flex flex-col items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-purple-50 flex items-center justify-center">
                <Bot size={28} className="text-purple-600 animate-pulse" />
              </div>
              <p className="text-sm font-semibold text-gray-800">AI sedang membaca bukti transaksi.</p>
              <p className="text-xs text-gray-500">Mohon tunggu...</p>
              <div className="flex gap-1.5">
                {[0,1,2].map(i => <div key={i} className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" style={{ animationDelay: `${i*0.2}s` }} />)}
              </div>
            </div>
          )}
          {step === "result" && (
            <div className="space-y-4">
              <div className="p-3 bg-purple-50 border border-purple-200 rounded-xl flex items-start gap-2">
                <Bot size={14} className="text-purple-600 mt-0.5" />
                <p className="text-xs text-purple-800">Draft jurnal berhasil dibuat. Periksa dan setujui sebelum diposting.</p>
              </div>
              <div className="space-y-2 text-xs">
                {[
                  ["Merchant",    "Toko Buku Gramedia"],
                  ["Tanggal",     "2 Jul 2026"],
                  ["Nominal",     "Rp185.000"],
                  ["Pajak",       "—"],
                  ["Kategori",    "Pendidikan"],
                  ["Akun Debit",  "Beban Pendidikan"],
                  ["Akun Kredit", "Kas"],
                ].map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between py-1.5 border-b border-gray-50">
                    <span className="text-gray-500">{k}</span>
                    <span className="font-semibold text-gray-800">{v}</span>
                  </div>
                ))}
                <div className="flex items-center justify-between py-1.5">
                  <span className="text-gray-500">Confidence</span>
                  <div className="flex items-center gap-2">
                    <div className="h-1.5 w-24 rounded-full bg-gray-100 overflow-hidden">
                      <div className="h-full rounded-full bg-green-500" style={{ width: "92%" }} />
                    </div>
                    <span className="font-semibold text-green-600">92%</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={onClose} className="flex-1 py-2 text-xs font-semibold text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Tolak</button>
                <button onClick={onClose} className="flex-1 py-2 text-xs font-semibold text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Edit</button>
                <button onClick={onClose} className="flex-1 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black">Setujui & Posting</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// ── Tab: Jurnal ────────────────────────────────────────────────────────────────
function TabJurnal() {
  const [showJurnal, setShowJurnal] = useState(false);
  const [showAI, setShowAI] = useState(false);
  return (
    <div className="space-y-4">
      {showJurnal && <JurnalModal onClose={() => setShowJurnal(false)} />}
      {showAI     && <AIFlowModal onClose={() => setShowAI(false)} />}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Total Jurnal",           value: "48" },
          { label: "Draft AI",               value: "3"  },
          { label: "Menunggu Persetujuan",   value: "2"  },
          { label: "Jurnal Tidak Seimbang",  value: "0"  },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-xs text-gray-500 mb-2">{c.label}</p>
            <p className="text-2xl font-bold text-gray-900">{c.value}</p>
          </div>
        ))}
      </div>
      <div className="flex items-center gap-2">
        <button onClick={() => setShowAI(true)} className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-50 border border-purple-200 text-purple-700 rounded-lg text-xs font-semibold hover:bg-purple-100">
          <Bot size={12} /> Review Jurnal AI
        </button>
        <button onClick={() => setShowAI(true)} className="flex items-center gap-1.5 px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg text-sm font-semibold hover:bg-gray-50">
          <Upload size={14} /> Upload Bukti Transaksi
        </button>
        <button onClick={() => setShowJurnal(true)} className="ml-auto flex items-center gap-1.5 px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-semibold hover:bg-black">
          <Plus size={14} /> Buat Jurnal
        </button>
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              {["No. Jurnal","Tanggal","Keterangan","Sumber","Total Debit","Total Kredit","Status",""].map(h => (
                <th key={h} className="px-4 py-2.5 text-left font-medium text-gray-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {JURNAL_DATA.map(r => (
              <tr key={r.no} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-2.5 font-mono font-medium text-gray-700">{r.no}</td>
                <td className="px-4 py-2.5 text-gray-500">{r.tgl}</td>
                <td className="px-4 py-2.5 text-gray-800">{r.ket}</td>
                <td className="px-4 py-2.5"><SumberBadge s={r.sumber} /></td>
                <td className="px-4 py-2.5 text-right">{fmtRp(r.debit)}</td>
                <td className="px-4 py-2.5 text-right">{fmtRp(r.kredit)}</td>
                <td className="px-4 py-2.5"><StatusBadge s={r.status} /></td>
                <td className="px-3 py-2.5"><button className="p-0.5 hover:bg-gray-200 rounded"><MoreHorizontal size={13} className="text-gray-400" /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Tab: Buku Besar ────────────────────────────────────────────────────────────
function TabBukuBesar() {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <select className="text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
          <option>Kas dan Bank</option><option>Pendapatan</option><option>Beban</option>
        </select>
        <select className="text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
          <option>Juli 2026</option><option>Juni 2026</option>
        </select>
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold text-gray-800">Kas dan Bank</p>
            <p className="text-xs text-gray-500">Saldo Awal: Rp1.500.000</p>
          </div>
          <p className="text-sm font-bold text-green-600">Saldo Akhir: Rp2.608.000</p>
        </div>
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              {["Tanggal","Referensi","Keterangan","Debit","Kredit","Saldo"].map(h => (
                <th key={h} className="px-4 py-2.5 text-right first:text-left font-medium text-gray-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {BB_DATA.map((r, i) => (
              <tr key={i} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-2.5 text-gray-500">{r.tgl}</td>
                <td className="px-4 py-2.5 font-mono text-gray-600">{r.ref}</td>
                <td className="px-4 py-2.5 text-gray-800">{r.ket}</td>
                <td className="px-4 py-2.5 text-right text-green-600">{r.debit > 0 ? fmtRp(r.debit) : "—"}</td>
                <td className="px-4 py-2.5 text-right text-red-500">{r.kredit > 0 ? fmtRp(r.kredit) : "—"}</td>
                <td className="px-4 py-2.5 text-right font-semibold text-gray-900">{fmtRp(r.saldo)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Tab: Neraca Saldo ──────────────────────────────────────────────────────────
function TabNeracaSaldo() {
  const [seg, setSeg] = useState("sebelum");
  const totalD = NS_DATA.reduce((s, r) => s + r.debit, 0);
  const totalK = NS_DATA.reduce((s, r) => s + r.kredit, 0);
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-lg w-fit">
        {[["sebelum","Sebelum Penyesuaian"],["setelah","Setelah Penyesuaian"],["penutupan","Setelah Penutupan"]].map(([id, label]) => (
          <button key={id} onClick={() => setSeg(id)}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${seg === id ? "bg-white shadow-sm text-gray-900" : "text-gray-500"}`}>
            {label}
          </button>
        ))}
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              <th className="px-4 py-2.5 text-left font-medium text-gray-500">Kode Akun</th>
              <th className="px-4 py-2.5 text-left font-medium text-gray-500">Nama Akun</th>
              <th className="px-4 py-2.5 text-right font-medium text-gray-500">Debit</th>
              <th className="px-4 py-2.5 text-right font-medium text-gray-500">Kredit</th>
            </tr>
          </thead>
          <tbody>
            {NS_DATA.map(r => (
              <tr key={r.kode} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-2.5 font-mono text-gray-600">{r.kode}</td>
                <td className="px-4 py-2.5 text-gray-800">{r.nama}</td>
                <td className="px-4 py-2.5 text-right">{r.debit > 0 ? fmtRp(r.debit) : "—"}</td>
                <td className="px-4 py-2.5 text-right">{r.kredit > 0 ? fmtRp(r.kredit) : "—"}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-gray-200 bg-gray-50">
              <td colSpan={2} className="px-4 py-2.5 font-bold text-gray-900">Total</td>
              <td className="px-4 py-2.5 text-right font-bold">{fmtRp(totalD)}</td>
              <td className="px-4 py-2.5 text-right font-bold">{fmtRp(totalK)}</td>
            </tr>
            <tr>
              <td colSpan={4} className="px-4 py-2.5">
                {totalD === totalK
                  ? <span className="text-xs text-green-600 font-semibold flex items-center gap-1"><Check size={12} /> Neraca Seimbang</span>
                  : <span className="text-xs text-red-500 font-semibold">Tidak Seimbang — Selisih: {fmtRp(Math.abs(totalD - totalK))}</span>
                }
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}

// ── Tab: Penyesuaian ───────────────────────────────────────────────────────────
function TabPenyesuaian() {
  const [showJurnal, setShowJurnal] = useState(false);
  const CHECKLIST = [
    { label: "Jurnal penyesuaian telah dibuat", done: false },
    { label: "Kertas kerja telah diisi",        done: false },
    { label: "Jurnal penutup telah dibuat",     done: false },
    { label: "Saldo akun nominal telah nol",   done: false },
    { label: "Saldo laba ditahan diperbarui",  done: false },
  ];
  return (
    <div className="space-y-4">
      {showJurnal && <JurnalModal onClose={() => setShowJurnal(false)} />}
      <div className="flex items-center justify-between">
        <div className="flex bg-gray-100 p-1 rounded-lg gap-1">
          {["Jurnal Penyesuaian","Kertas Kerja","Jurnal Penutup","Riwayat Penutupan"].map(s => (
            <button key={s} className="px-3 py-1.5 rounded-md text-xs text-gray-500 hover:bg-white hover:shadow-sm">{s}</button>
          ))}
        </div>
        <button onClick={() => setShowJurnal(true)}
          className="flex items-center gap-1.5 px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-semibold hover:bg-black">
          <Plus size={14} /> Buat Penyesuaian
        </button>
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <h3 className="text-sm font-semibold text-gray-800 mb-4">Checklist Penutupan Periode — Juli 2026</h3>
        <div className="space-y-3">
          {CHECKLIST.map((c, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg border border-gray-100">
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${c.done ? "bg-green-500 border-green-500" : "border-gray-300"}`}>
                {c.done && <Check size={11} className="text-white" />}
              </div>
              <span className={`text-sm ${c.done ? "line-through text-gray-400" : "text-gray-700"}`}>{c.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Tab: Laporan Keuangan ──────────────────────────────────────────────────────
function TabLaporan() {
  const [innerTab, setInnerTab] = useState("labarugi");
  const INNER_TABS = [
    { id: "labarugi",    label: "Laba Rugi" },
    { id: "ekuitas",     label: "Perubahan Ekuitas" },
    { id: "posisi",      label: "Posisi Keuangan" },
    { id: "aruskaslab",  label: "Arus Kas" },
  ];
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {INNER_TABS.map(t => (
            <button key={t.id} onClick={() => setInnerTab(t.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${innerTab === t.id ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"}`}>
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">
            Dibentuk dari Jurnal yang Telah Diposting
          </span>
          <select className="text-xs px-2 py-1.5 border border-gray-200 rounded-lg outline-none"><option>Juli 2026</option></select>
          <button className="flex items-center gap-1 px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-xs text-gray-700 hover:bg-gray-50">Export PDF</button>
          <button className="flex items-center gap-1 px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-xs text-gray-700 hover:bg-gray-50">Export Excel</button>
        </div>
      </div>

      {innerTab === "labarugi" && (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 max-w-lg">
          <h3 className="text-base font-bold text-gray-900 mb-1 text-center">Laporan Laba Rugi</h3>
          <p className="text-xs text-gray-500 text-center mb-4">Periode: 1 – 31 Juli 2026</p>
          <div className="space-y-2 text-sm">
            <div className="font-semibold text-gray-700 border-b border-gray-200 pb-1">Pendapatan</div>
            <div className="flex justify-between pl-4"><span>Pendapatan Usaha</span><span>Rp6.500.000</span></div>
            <div className="flex justify-between font-semibold border-t border-gray-100 pt-1"><span>Total Pendapatan</span><span className="text-green-600">Rp6.500.000</span></div>
            <div className="font-semibold text-gray-700 border-b border-gray-200 pb-1 mt-3">Beban</div>
            <div className="flex justify-between pl-4"><span>Beban Makanan</span><span>Rp1.008.000</span></div>
            <div className="flex justify-between pl-4"><span>Beban Transportasi</span><span>Rp756.000</span></div>
            <div className="flex justify-between pl-4"><span>Beban Pendidikan</span><span>Rp567.000</span></div>
            <div className="flex justify-between pl-4"><span>Beban Tagihan</span><span>Rp252.000</span></div>
            <div className="flex justify-between pl-4"><span>Beban Lainnya</span><span>Rp567.000</span></div>
            <div className="flex justify-between font-semibold border-t border-gray-100 pt-1"><span>Total Beban</span><span className="text-red-500">Rp3.150.000</span></div>
            <div className="flex justify-between font-bold text-base border-t-2 border-gray-300 pt-2 mt-2"><span>Laba Bersih</span><span className="text-green-600">Rp3.350.000</span></div>
          </div>
        </div>
      )}
      {innerTab !== "labarugi" && (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-12 flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center">
            <AlertCircle size={20} className="text-gray-400" />
          </div>
          <p className="text-sm text-gray-500">Laporan {INNER_TABS.find(t => t.id === innerTab)?.label} akan tersedia setelah jurnal diposting.</p>
        </div>
      )}
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export function AkuntansiPage({ topBar }: { topBar: React.ReactNode }) {
  const [activeTab, setActiveTab] = useState("jurnal");
  const TABS = [
    { id: "jurnal",    label: "Jurnal" },
    { id: "buku",      label: "Buku Besar" },
    { id: "neraca",    label: "Neraca Saldo" },
    { id: "penyesuaian",label:"Penyesuaian" },
    { id: "laporan",   label: "Laporan Keuangan" },
  ];
  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-6">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Akuntansi</h1>
          <p className="text-sm text-gray-500 mt-1">Kelola pencatatan double-entry hingga laporan keuangan.</p>
        </div>
        <div className="flex items-center gap-0 border-b border-gray-200">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${activeTab === t.id ? "border-gray-900 text-gray-900" : "border-transparent text-gray-500 hover:text-gray-700"}`}>
              {t.label}
            </button>
          ))}
        </div>
        {activeTab === "jurnal"      && <TabJurnal />}
        {activeTab === "buku"        && <TabBukuBesar />}
        {activeTab === "neraca"      && <TabNeracaSaldo />}
        {activeTab === "penyesuaian" && <TabPenyesuaian />}
        {activeTab === "laporan"     && <TabLaporan />}
      </div>
    </main>
  );
}
