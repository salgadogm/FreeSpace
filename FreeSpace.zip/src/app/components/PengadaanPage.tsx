import React, { useState, useMemo } from "react";
import { useDataStore, type ProcurementRequest } from "./DataStore";
import { exportToExcel } from "./excelUtils";
import {
  ShoppingCart, Search, Download, Plus, X, ChevronDown, Clock,
  CheckCircle2, XCircle, MapPin, User, Building,
  Check, FileText, Cpu, Car, Layers, Package, Send,
  AlertCircle, CircleDollarSign, Truck, BadgeCheck,
  PenLine, ThumbsUp, ThumbsDown, ChevronRight,
  Upload, Paperclip, Trash2, Lightbulb, ArrowRight,
  Eye,
} from "lucide-react";

// ── Types ──────────────────────────────────────────────────────────────────────
type PengadaanKategori = "PM" | "ATB" | "ATL" | "AL";
type PengadaanStatus   =
  | "Draft"
  | "Menunggu Persetujuan"
  | "Disetujui"
  | "Dalam Pengadaan"
  | "Selesai"
  | "Ditolak";
type PengadaanMetode =
  | "Pembelian Langsung"
  | "e-Purchasing"
  | "Tender / Lelang"
  | "Penunjukan Langsung"
  | "Hibah / Bantuan";
type SumberDana       = "DIPA" | "BLU" | "PNBP" | "Hibah" | "Swadana";
type SumberKebutuhan  = "Ruangan kekurangan aset" | "Aset rusak" | "Penggantian aset" | "Permintaan unit";

interface DokumenItem { nama: string; ukuran: string; }
interface TimelineItem { tanggal: string; aksi: string; oleh: string; catatan?: string; }

interface PengadaanRecord {
  id: string;
  nama: string;
  spesifikasi: string;
  kategori: PengadaanKategori;
  tipeAset: string;
  jumlah: number;
  satuan: string;
  gedung: string;
  ruangan: string;
  pic: string;
  metode: PengadaanMetode;
  sumberDana: SumberDana;
  vendor: string;
  anggaranEstimasi: number;
  anggaranRealisasi: number | null;
  status: PengadaanStatus;
  tglAjuan: string;
  tglPersetujuan: string | null;
  tglRealisasi: string | null;
  catatan: string;
  pengaju: string;
  approver: string | null;
  alasanKebutuhan: string;
  sumberKebutuhan: SumberKebutuhan[];
  rekomendasiSistem: string | null;
  dokumen: DokumenItem[];
  timeline: TimelineItem[];
  noPolisi?: string;
  noRangka?: string;
  masaBerlaku?: string;
}

// ── Conversion: store request → local rich record ──────────────────────────────
function procToRecord(p: ProcurementRequest): PengadaanRecord {
  const pStatus: PengadaanStatus = p.status === "Selesai" ? "Selesai"
    : p.status === "Disetujui" ? "Disetujui"
    : p.status === "Ditolak"   ? "Ditolak"
    : p.status === "Dalam Pengadaan" ? "Dalam Pengadaan"
    : p.status === "Menunggu Persetujuan" ? "Menunggu Persetujuan"
    : "Draft";
  const kategori = (["PM","ATB","ATL","AL"] as string[]).includes(p.jenis_aset) ? p.jenis_aset as PengadaanKategori : "PM";
  return {
    id: p.id,
    nama: p.nama_barang,
    spesifikasi: "-",
    kategori,
    tipeAset: KATEGORI_TIPE[kategori]?.[0] || "-",
    jumlah: p.jumlah,
    satuan: "Unit",
    gedung: "Kampus Cilibende",
    ruangan: "-",
    pic: "Salgado Ginting",
    metode: "Pembelian Langsung",
    sumberDana: "DIPA",
    vendor: "-",
    anggaranEstimasi: p.estimasi_biaya,
    anggaranRealisasi: p.status === "Selesai" ? p.estimasi_biaya : null,
    status: pStatus,
    tglAjuan: p.tanggal,
    tglPersetujuan: p.status === "Disetujui" || p.status === "Selesai" ? p.tanggal : null,
    tglRealisasi: p.status === "Selesai" ? p.tanggal : null,
    catatan: p.alasan,
    pengaju: "Salgado Ginting",
    approver: p.status === "Disetujui" || p.status === "Selesai" ? "Dr. Rudi Hartono" : null,
    alasanKebutuhan: p.alasan,
    sumberKebutuhan: ["Permintaan unit"],
    rekomendasiSistem: null,
    dokumen: [],
    timeline: [
      { tanggal: p.tanggal, aksi: "Draft Dibuat", oleh: "Salgado Ginting" },
      ...(p.status !== "Draft" ? [{ tanggal: p.tanggal, aksi: "Dikirim untuk Persetujuan", oleh: "Salgado Ginting", catatan: p.alasan }] : []),
      ...(["Disetujui","Selesai","Dalam Pengadaan"].includes(p.status) ? [{ tanggal: p.tanggal, aksi: "Disetujui", oleh: "Dr. Rudi Hartono" }] : []),
      ...(p.status === "Selesai" ? [{ tanggal: p.tanggal, aksi: "Pengadaan Selesai", oleh: "Salgado Ginting" }] : []),
    ],
  };
}

// ── Master data ───────────────────────────────────────────────────────────────
const GEDUNG_LIST = [
  "Kampus Cilibende", "Kampus Gunung Gede",
  "Kampus Baranangsiang", "Kampus Sukabumi",
];

const RUANGAN_MAP: Record<string, string[]> = {
  "Kampus Cilibende":     ["Ruang Server A", "Ruang Server B", "Ruang Admin", "Ruang IT", "Lab Komputer 1", "Lab Komputer 2", "Ruang Dosen", "Ruang Rapat", "Garasi Utama", "Gudang Utama"],
  "Kampus Gunung Gede":  ["Ruang TU", "Ruang Dosen", "Lab Fisika", "Garasi", "Gudang"],
  "Kampus Baranangsiang":["Ruang Server", "Ruang Admin", "Ruang Kuliah A1", "Lab Kimia"],
  "Kampus Sukabumi":     ["Ruang TU", "Lab Jaringan", "Gudang"],
};

const PIC_MASTER = [
  "Andi Firmansyah", "Budi Santoso", "Siti Rahayu",
  "Joko Prayitno", "Dr. Rudi Hartono", "Prof. Ani Wijayanti", "Salgado Ginting",
];

const VENDOR_LIST = [
  "CV. Indomedia Komputer", "PT. Datascrip Indonesia", "PT. Epson Indonesia",
  "CV. Mitra Teknik", "PT. Toyota Astra Motor", "PT. Astra Honda Motor",
  "PT. Microsoft Indonesia", "PT. Telkom Solution", "CV. Maju Jaya Elektronik",
  "PT. Daikin Airconditioning", "UD. Meubel Jati Murni",
];

const KATEGORI_TIPE: Record<PengadaanKategori, string[]> = {
  PM:  ["Komputer & Laptop", "Printer & Scanner", "Server & Networking", "UPS & Power", "CCTV & Keamanan", "Alat Ukur & Lab", "Perangkat Audio Visual"],
  ATB: ["Lisensi Software", "Hak Paten", "Lisensi Aplikasi Bisnis", "Domain & Hosting", "Sertifikat Digital"],
  ATL: ["AC & Pendingin", "Furnitur Kantor", "Proyektor & Layar", "Lemari & Rak", "Alat Kebersihan", "Peralatan Dapur"],
  AL:  ["Kendaraan Roda 4", "Kendaraan Roda 2", "Kendaraan Niaga", "Alat Berat"],
};

const SATUAN_LIST = ["Unit", "Buah", "Set", "Lisensi", "Lembar", "Meter", "Kg"];
const SUMBER_KEBUTUHAN_OPTS: SumberKebutuhan[] = ["Ruangan kekurangan aset", "Aset rusak", "Penggantian aset", "Permintaan unit"];


// ── Helpers ───────────────────────────────────────────────────────────────────
const fmtRupiah = (v: number) => "Rp " + new Intl.NumberFormat("id-ID").format(v);

function KategoriBadge({ kategori }: { kategori: PengadaanKategori }) {
  const cfg = {
    PM:  { bg: "bg-purple-50", text: "text-purple-700", icon: <Cpu size={10} /> },
    ATB: { bg: "bg-sky-50",    text: "text-sky-700",    icon: <FileText size={10} /> },
    ATL: { bg: "bg-teal-50",   text: "text-teal-700",   icon: <Layers size={10} /> },
    AL:  { bg: "bg-indigo-50", text: "text-indigo-700", icon: <Car size={10} /> },
  }[kategori];
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold ${cfg.bg} ${cfg.text}`}>
      {cfg.icon} {kategori}
    </span>
  );
}

function StatusBadge({ status }: { status: PengadaanStatus }) {
  const cfg: Record<PengadaanStatus, { bg: string; text: string; border: string; icon: React.ReactNode }> = {
    Draft:                 { bg: "bg-gray-100",   text: "text-gray-600",   border: "border-gray-200",   icon: <PenLine size={11} /> },
    "Menunggu Persetujuan":{ bg: "bg-yellow-50",  text: "text-yellow-700", border: "border-yellow-200", icon: <Clock size={11} /> },
    Disetujui:             { bg: "bg-blue-50",    text: "text-blue-700",   border: "border-blue-200",   icon: <BadgeCheck size={11} /> },
    "Dalam Pengadaan":     { bg: "bg-orange-50",  text: "text-orange-700", border: "border-orange-200", icon: <Truck size={11} /> },
    Selesai:               { bg: "bg-green-50",   text: "text-green-700",  border: "border-green-200",  icon: <CheckCircle2 size={11} /> },
    Ditolak:               { bg: "bg-red-50",     text: "text-red-700",    border: "border-red-200",    icon: <XCircle size={11} /> },
  };
  const c = cfg[status];
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold border ${c.bg} ${c.text} ${c.border}`}>
      {c.icon} {status}
    </span>
  );
}

function MetodeBadge({ metode }: { metode: PengadaanMetode }) {
  const cfg: Record<PengadaanMetode, string> = {
    "Pembelian Langsung": "bg-gray-100 text-gray-600",
    "e-Purchasing":       "bg-cyan-50 text-cyan-700",
    "Tender / Lelang":    "bg-amber-50 text-amber-700",
    "Penunjukan Langsung":"bg-violet-50 text-violet-700",
    "Hibah / Bantuan":    "bg-pink-50 text-pink-700",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium ${cfg[metode]}`}>
      {metode}
    </span>
  );
}

// ── Detail Drawer ─────────────────────────────────────────────────────────────
function DetailDrawer({ record, onClose, onAction }: {
  record: PengadaanRecord;
  onClose: () => void;
  onAction: (id: string, status: PengadaanStatus, catatan?: string, realisasi?: number) => void;
}) {
  const [confirm, setConfirm]           = useState<PengadaanStatus | null>(null);
  const [catatan, setCatatan]           = useState("");
  const [realisasiInput, setRealisasiInput] = useState("");

  const handleConfirm = () => {
    if (!confirm) return;
    onAction(record.id, confirm, catatan, realisasiInput ? Number(realisasiInput) : undefined);
    setConfirm(null);
    setCatatan("");
    setRealisasiInput("");
  };

  const nextActions: Array<{ label: string; status: PengadaanStatus; color: string }> = [];
  if (record.status === "Draft")                  nextActions.push({ label: "Kirim untuk Persetujuan", status: "Menunggu Persetujuan", color: "bg-[#111827] hover:bg-gray-800" });
  if (record.status === "Menunggu Persetujuan") {
    nextActions.push({ label: "Setujui",  status: "Disetujui", color: "bg-green-600 hover:bg-green-700" });
    nextActions.push({ label: "Tolak",    status: "Ditolak",   color: "bg-red-600 hover:bg-red-700" });
  }
  if (record.status === "Disetujui")              nextActions.push({ label: "Mulai Pengadaan", status: "Dalam Pengadaan", color: "bg-orange-600 hover:bg-orange-700" });
  if (record.status === "Dalam Pengadaan")        nextActions.push({ label: "Tandai Selesai",  status: "Selesai",         color: "bg-green-600 hover:bg-green-700" });

  const selisihAnggaran = record.anggaranRealisasi !== null
    ? record.anggaranEstimasi - record.anggaranRealisasi
    : null;

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-gray-900/40 backdrop-blur-sm" />
      <div className="fixed top-0 right-0 h-full z-50 w-[560px] bg-white shadow-2xl flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between shrink-0">
          <div>
            <p className="text-xs font-mono text-gray-400">{record.id}</p>
            <h2 className="text-base font-bold text-gray-900 mt-0.5 leading-tight">{record.nama}</h2>
          </div>
          <div className="flex items-center gap-2">
            <StatusBadge status={record.status} />
            <button onClick={onClose} className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-md transition-colors"><X size={18} /></button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Asset card */}
          <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#111827] flex items-center justify-center shrink-0">
              <ShoppingCart size={18} className="text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-sm font-bold text-gray-900">{record.nama}</p>
                <KategoriBadge kategori={record.kategori} />
              </div>
              <p className="text-xs text-gray-500 mt-0.5">{record.tipeAset} · {record.jumlah} {record.satuan}</p>
              <p className="text-xs text-gray-600 mt-1.5 leading-relaxed">{record.spesifikasi}</p>
            </div>
          </div>

          {/* Sumber kebutuhan chips */}
          {record.sumberKebutuhan.length > 0 && (
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-2">Sumber Kebutuhan</p>
              <div className="flex flex-wrap gap-1.5">
                {record.sumberKebutuhan.map(s => (
                  <span key={s} className="inline-flex items-center px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-gray-100 text-gray-700 border border-gray-200">{s}</span>
                ))}
              </div>
            </div>
          )}

          {/* Alasan kebutuhan */}
          <div className="bg-yellow-50 border border-yellow-100 rounded-xl p-4">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-yellow-600 mb-1.5">Alasan Kebutuhan</p>
            <p className="text-xs text-gray-800 leading-relaxed">{record.alasanKebutuhan}</p>
          </div>

          {/* Rekomendasi sistem */}
          {record.rekomendasiSistem && (
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 flex items-start gap-2.5">
              <Lightbulb size={14} className="text-blue-500 shrink-0 mt-0.5" />
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wider text-blue-500 mb-1">Rekomendasi Sistem</p>
                <p className="text-xs text-blue-800 leading-relaxed">{record.rekomendasiSistem}</p>
              </div>
            </div>
          )}

          {/* Info grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gray-50 border border-gray-100 rounded-xl p-3 space-y-2">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400">Tujuan & PIC</p>
              <div className="flex items-center gap-1.5"><Building size={12} className="text-gray-400 shrink-0" /><span className="text-xs text-gray-700">{record.gedung}</span></div>
              <div className="flex items-center gap-1.5"><MapPin size={12} className="text-gray-400 shrink-0" /><span className="text-xs text-gray-700">{record.ruangan}</span></div>
              <div className="flex items-center gap-1.5"><User size={12} className="text-gray-400 shrink-0" /><span className="text-xs text-gray-700">{record.pic}</span></div>
            </div>
            <div className="bg-gray-50 border border-gray-100 rounded-xl p-3 space-y-2">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400">Info Pengadaan</p>
              <div className="flex items-center gap-1.5"><Package size={12} className="text-gray-400 shrink-0" /><span className="text-xs text-gray-700">{record.metode}</span></div>
              <div className="flex items-center gap-1.5"><Truck size={12} className="text-gray-400 shrink-0" /><span className="text-xs text-gray-700 truncate">{record.vendor}</span></div>
              <div className="flex items-center gap-1.5"><FileText size={12} className="text-gray-400 shrink-0" /><span className="text-xs text-gray-700">{record.sumberDana}</span></div>
            </div>
          </div>

          {/* Estimasi vs Realisasi */}
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-2">Estimasi vs Realisasi Anggaran</p>
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-blue-50 border border-blue-100 rounded-xl px-3 py-3">
                <p className="text-[9px] font-semibold uppercase tracking-wider text-blue-400 mb-1">Estimasi</p>
                <p className="text-sm font-bold text-blue-700">{fmtRupiah(record.anggaranEstimasi)}</p>
              </div>
              <div className={`rounded-xl px-3 py-3 border ${record.anggaranRealisasi !== null ? "bg-green-50 border-green-200" : "bg-gray-50 border-gray-100"}`}>
                <p className="text-[9px] font-semibold uppercase tracking-wider text-gray-400 mb-1">Realisasi</p>
                <p className="text-sm font-bold text-gray-800">{record.anggaranRealisasi !== null ? fmtRupiah(record.anggaranRealisasi) : "—"}</p>
              </div>
              <div className={`rounded-xl px-3 py-3 border ${selisihAnggaran !== null ? selisihAnggaran >= 0 ? "bg-green-50 border-green-100" : "bg-red-50 border-red-100" : "bg-gray-50 border-gray-100"}`}>
                <p className="text-[9px] font-semibold uppercase tracking-wider text-gray-400 mb-1">Selisih</p>
                <p className={`text-sm font-bold ${selisihAnggaran !== null ? selisihAnggaran >= 0 ? "text-green-700" : "text-red-700" : "text-gray-400"}`}>
                  {selisihAnggaran !== null ? fmtRupiah(Math.abs(selisihAnggaran)) : "—"}
                </p>
              </div>
            </div>
          </div>

          {/* Category-specific */}
          {(record.noPolisi || record.noRangka) && (
            <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-3 space-y-1.5">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-indigo-400">Data Kendaraan</p>
              {record.noPolisi && <p className="text-xs text-indigo-800"><span className="text-gray-500 mr-2">No. Polisi:</span>{record.noPolisi}</p>}
              {record.noRangka && <p className="text-xs text-indigo-800"><span className="text-gray-500 mr-2">No. Rangka:</span>{record.noRangka}</p>}
            </div>
          )}
          {record.masaBerlaku && (
            <div className="bg-sky-50 border border-sky-100 rounded-xl p-3">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-sky-400 mb-1">Masa Berlaku Lisensi</p>
              <p className="text-xs text-sky-800">{record.masaBerlaku}</p>
            </div>
          )}

          {/* Dokumen pendukung */}
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-2">Dokumen Pendukung</p>
            {record.dokumen.length === 0 ? (
              <p className="text-xs text-gray-400 italic">Tidak ada dokumen</p>
            ) : (
              <div className="space-y-1.5">
                {record.dokumen.map((d, i) => (
                  <div key={i} className="flex items-center gap-2.5 p-2.5 bg-gray-50 border border-gray-100 rounded-lg">
                    <Paperclip size={13} className="text-gray-400 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-gray-700 truncate">{d.nama}</p>
                      <p className="text-[10px] text-gray-400">{d.ukuran}</p>
                    </div>
                    <button className="text-xs text-blue-600 hover:text-blue-800 font-medium shrink-0">Unduh</button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Timeline */}
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-3">Timeline Persetujuan</p>
            <div className="space-y-0">
              {record.timeline.map((t, i) => (
                <div key={i} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 border-2 text-white ${
                      t.aksi.includes("Selesai") || t.aksi === "Disetujui" ? "bg-green-500 border-green-500" :
                      t.aksi === "Ditolak" ? "bg-red-500 border-red-500" :
                      i === record.timeline.length - 1 ? "bg-[#111827] border-[#111827]" : "bg-gray-300 border-gray-300"
                    }`}>
                      {t.aksi.includes("Selesai") || t.aksi === "Disetujui" ? <CheckCircle2 size={12} /> :
                       t.aksi === "Ditolak" ? <XCircle size={12} /> : <div className="w-2 h-2 rounded-full bg-white" />}
                    </div>
                    {i < record.timeline.length - 1 && <div className="w-0.5 h-6 bg-gray-200 my-1" />}
                  </div>
                  <div className="pb-4 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-xs font-semibold text-gray-800">{t.aksi}</p>
                      <p className="text-[10px] text-gray-400">{t.tanggal}</p>
                    </div>
                    <p className="text-[10px] text-gray-500">oleh {t.oleh}</p>
                    {t.catatan && <p className="text-[10px] text-gray-600 mt-0.5 italic">{t.catatan}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pengaju / Approver */}
          <div className="flex items-center gap-6 text-xs text-gray-500 pb-1">
            <span>Pengaju: <strong className="text-gray-800">{record.pengaju}</strong></span>
            {record.approver && <span>Disetujui oleh: <strong className="text-gray-800">{record.approver}</strong></span>}
          </div>
        </div>

        {/* Footer: actions */}
        {nextActions.length > 0 && (
          <div className="border-t border-gray-100 px-6 py-4 space-y-3 shrink-0">
            {!confirm && (
              <div className="flex gap-2">
                {nextActions.map(a => (
                  <button
                    key={a.status}
                    onClick={() => setConfirm(a.status)}
                    className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-semibold text-white rounded-lg transition-colors ${a.color}`}
                  >
                    {a.status === "Menunggu Persetujuan" && <Send size={13} />}
                    {a.status === "Disetujui"           && <ThumbsUp size={13} />}
                    {a.status === "Ditolak"             && <ThumbsDown size={13} />}
                    {a.status === "Dalam Pengadaan"     && <Truck size={13} />}
                    {a.status === "Selesai"             && <CheckCircle2 size={13} />}
                    {a.label}
                  </button>
                ))}
              </div>
            )}
            {confirm && (
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 space-y-3">
                <p className="text-sm font-semibold text-gray-800">
                  Konfirmasi: {confirm === "Menunggu Persetujuan" ? "Kirim Pengajuan" : confirm}
                </p>
                {confirm === "Selesai" && (
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Realisasi Anggaran (Rp)</label>
                    <input
                      type="number" value={realisasiInput} onChange={e => setRealisasiInput(e.target.value)}
                      placeholder="0"
                      className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400"
                    />
                  </div>
                )}
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Catatan (opsional)</label>
                  <textarea
                    rows={2} value={catatan} onChange={e => setCatatan(e.target.value)}
                    placeholder="Catatan tambahan..."
                    className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400 resize-none"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleConfirm}
                    className={`flex-1 py-2 text-sm font-semibold text-white rounded-lg transition-colors ${
                      confirm === "Ditolak" ? "bg-red-600 hover:bg-red-700" : confirm === "Selesai" ? "bg-green-600 hover:bg-green-700" : "bg-[#111827] hover:bg-gray-800"
                    }`}
                  >Konfirmasi</button>
                  <button onClick={() => setConfirm(null)} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
}

// ── New Pengadaan Modal (4-step wizard) ───────────────────────────────────────
function NewPengadaanModal({ onClose, onSubmit }: {
  onClose: () => void;
  onSubmit: (data: Omit<PengadaanRecord, "id">) => void;
}) {
  const [step, setStep] = useState(1);

  // Step 1
  const [kategori, setKategori]       = useState<PengadaanKategori | "">("");
  const [tipeAset, setTipeAset]       = useState("");
  const [nama, setNama]               = useState("");
  const [spesifikasi, setSpesifikasi] = useState("");
  const [jumlah, setJumlah]           = useState(1);
  const [satuan, setSatuan]           = useState("Unit");

  // Step 2
  const [gedung, setGedung]           = useState("");
  const [ruangan, setRuangan]         = useState("");
  const [pic, setPic]                 = useState("");
  const [noPolisi, setNoPolisi]       = useState("");
  const [noRangka, setNoRangka]       = useState("");
  const [masaBerlaku, setMasaBerlaku] = useState("");

  // Step 3
  const [metode, setMetode]           = useState<PengadaanMetode | "">("");
  const [sumberDana, setSumberDana]   = useState<SumberDana | "">("");
  const [vendor, setVendor]           = useState("");
  const [anggaran, setAnggaran]       = useState("");
  const [alasan, setAlasan]           = useState("");
  const [sumberList, setSumberList]   = useState<SumberKebutuhan[]>([]);
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);

  const ruanganList = gedung ? (RUANGAN_MAP[gedung] ?? []) : [];
  const tipeList    = kategori ? KATEGORI_TIPE[kategori] : [];

  const toggleSumber = (s: SumberKebutuhan) =>
    setSumberList(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    setUploadedFiles(prev => [...prev, ...files.map(f => f.name)]);
  };

  const canNext =
    (step === 1 && kategori && tipeAset && nama.trim() && spesifikasi.trim() && jumlah > 0) ||
    (step === 2 && gedung && ruangan && pic) ||
    (step === 3 && metode && sumberDana && vendor && anggaran) ||
    step === 4;

  const STEPS = ["Kategori & Barang", "Lokasi & PIC", "Anggaran & Alasan", "Konfirmasi"];

  const handleSubmit = () => {
    if (!kategori || !metode || !sumberDana) return;
    onSubmit({
      nama, spesifikasi, kategori, tipeAset, jumlah, satuan,
      gedung, ruangan, pic,
      metode, sumberDana, vendor,
      anggaranEstimasi: Number(anggaran),
      anggaranRealisasi: null,
      status: "Draft",
      tglAjuan: new Date().toISOString().slice(0, 10),
      tglPersetujuan: null, tglRealisasi: null,
      catatan: alasan,
      pengaju: "Salgado Ginting", approver: null,
      alasanKebutuhan: alasan,
      sumberKebutuhan: sumberList,
      rekomendasiSistem: null,
      dokumen: uploadedFiles.map(f => ({ nama: f, ukuran: "—" })),
      timeline: [{ tanggal: new Date().toISOString().slice(0, 10), aksi: "Draft Dibuat", oleh: "Salgado Ginting" }],
      ...(kategori === "AL" ? { noPolisi, noRangka } : {}),
      ...(kategori === "ATB" ? { masaBerlaku } : {}),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/40 backdrop-blur-sm">
      <div className="bg-white rounded-[12px] shadow-2xl w-full max-w-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-gray-900">Buat Pengajuan Pengadaan</h2>
            <p className="text-xs text-gray-500 mt-0.5">Langkah {step} dari 4 — {STEPS[step - 1]}</p>
          </div>
          <button onClick={onClose} className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-md transition-colors"><X size={18} /></button>
        </div>

        {/* Step indicator */}
        <div className="flex items-center px-6 pt-4 gap-1.5">
          {STEPS.map((label, i) => {
            const idx = i + 1; const done = idx < step; const active = idx === step;
            return (
              <React.Fragment key={label}>
                <div className="flex flex-col items-center gap-1">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${done || active ? "bg-[#111827] text-white" : "bg-gray-200 text-gray-500"}`}>
                    {done ? <Check size={12} /> : idx}
                  </div>
                  <span className={`text-[10px] font-medium text-center hidden sm:block ${active ? "text-gray-900" : "text-gray-400"}`}>{label}</span>
                </div>
                {i < 3 && <div className={`flex-1 h-[1px] mb-4 ${done ? "bg-[#111827]" : "bg-gray-200"}`} />}
              </React.Fragment>
            );
          })}
        </div>

        <div className="p-6 space-y-4 max-h-[58vh] overflow-y-auto">
          {/* ── Step 1: Kategori & Barang ── */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-2">Kategori Aset <span className="text-red-500">*</span></label>
                <div className="grid grid-cols-2 gap-2">
                  {([
                    { kat: "PM"  as PengadaanKategori, label: "Peralatan & Mesin",  icon: <Cpu size={18} />,     color: "text-purple-600", bg: "bg-purple-50", activeBorder: "border-purple-500 ring-1 ring-purple-300" },
                    { kat: "ATB" as PengadaanKategori, label: "Aset Tak Berwujud",  icon: <FileText size={18} />,color: "text-sky-600",    bg: "bg-sky-50",    activeBorder: "border-sky-500 ring-1 ring-sky-300" },
                    { kat: "ATL" as PengadaanKategori, label: "Aset Tetap Lainnya", icon: <Layers size={18} />,  color: "text-teal-600",   bg: "bg-teal-50",   activeBorder: "border-teal-500 ring-1 ring-teal-300" },
                    { kat: "AL"  as PengadaanKategori, label: "Alat Angkutan",      icon: <Car size={18} />,     color: "text-indigo-600", bg: "bg-indigo-50", activeBorder: "border-indigo-500 ring-1 ring-indigo-300" },
                  ]).map(({ kat, label, icon, color, bg, activeBorder }) => (
                    <button
                      key={kat}
                      onClick={() => { setKategori(kat); setTipeAset(""); }}
                      className={`flex items-center gap-3 p-3 rounded-lg border text-left transition-all ${kategori === kat ? `${activeBorder} ${bg}` : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"}`}
                    >
                      <div className={`w-8 h-8 rounded-lg ${bg} flex items-center justify-center shrink-0 ${color}`}>{icon}</div>
                      <div>
                        <p className="text-xs font-bold text-gray-900">{kat}</p>
                        <p className="text-[10px] text-gray-500 leading-tight">{label}</p>
                      </div>
                      {kategori === kat && <Check size={13} className="ml-auto text-gray-700 shrink-0" />}
                    </button>
                  ))}
                </div>
              </div>

              {kategori && (
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Tipe Aset <span className="text-red-500">*</span></label>
                  <select
                    value={tipeAset} onChange={e => setTipeAset(e.target.value)}
                    className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none focus:ring-1 focus:ring-gray-400"
                  >
                    <option value="">Pilih tipe aset...</option>
                    {tipeList.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Nama Barang <span className="text-red-500">*</span></label>
                <input
                  value={nama} onChange={e => setNama(e.target.value)}
                  placeholder="Contoh: Laptop Dell Latitude 5540"
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Spesifikasi Teknis <span className="text-red-500">*</span></label>
                <textarea
                  rows={3} value={spesifikasi} onChange={e => setSpesifikasi(e.target.value)}
                  placeholder="Tuliskan spesifikasi detail barang yang dibutuhkan..."
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400 resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Jumlah <span className="text-red-500">*</span></label>
                  <input
                    type="number" min={1} value={jumlah} onChange={e => setJumlah(Number(e.target.value))}
                    className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Satuan</label>
                  <select
                    value={satuan} onChange={e => setSatuan(e.target.value)}
                    className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none focus:ring-1 focus:ring-gray-400"
                  >
                    {SATUAN_LIST.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* ── Step 2: Lokasi & PIC ── */}
          {step === 2 && (
            <div className="space-y-4">
              <p className="text-sm text-gray-500">Tentukan lokasi penempatan aset setelah pengadaan selesai.</p>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Gedung / Kampus Tujuan <span className="text-red-500">*</span></label>
                <select
                  value={gedung} onChange={e => { setGedung(e.target.value); setRuangan(""); }}
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none focus:ring-1 focus:ring-gray-400"
                >
                  <option value="">Pilih gedung...</option>
                  {GEDUNG_LIST.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Ruangan <span className="text-red-500">*</span></label>
                <select
                  value={ruangan} onChange={e => setRuangan(e.target.value)} disabled={!gedung}
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none focus:ring-1 focus:ring-gray-400 disabled:bg-gray-50 disabled:text-gray-400"
                >
                  <option value="">Pilih ruangan...</option>
                  {ruanganList.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Penanggung Jawab (PIC) <span className="text-red-500">*</span></label>
                <select
                  value={pic} onChange={e => setPic(e.target.value)}
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none focus:ring-1 focus:ring-gray-400"
                >
                  <option value="">Pilih PIC...</option>
                  {PIC_MASTER.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>

              {kategori === "AL" && (
                <div className="space-y-3 p-3 bg-indigo-50 border border-indigo-100 rounded-lg">
                  <p className="text-xs font-semibold text-indigo-700">Data Kendaraan (opsional)</p>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">No. Polisi</label>
                      <input value={noPolisi} onChange={e => setNoPolisi(e.target.value)} placeholder="—" className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400" />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">No. Rangka</label>
                      <input value={noRangka} onChange={e => setNoRangka(e.target.value)} placeholder="—" className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400" />
                    </div>
                  </div>
                </div>
              )}

              {kategori === "ATB" && (
                <div className="p-3 bg-sky-50 border border-sky-100 rounded-lg space-y-2">
                  <p className="text-xs font-semibold text-sky-700">Data Lisensi</p>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Masa Berlaku Hingga</label>
                    <input type="date" value={masaBerlaku} onChange={e => setMasaBerlaku(e.target.value)} className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400" />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── Step 3: Anggaran & Alasan ── */}
          {step === 3 && (
            <div className="space-y-4">
              {/* Metode */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-2">Metode Pengadaan <span className="text-red-500">*</span></label>
                <div className="space-y-1.5">
                  {([
                    { value: "Pembelian Langsung" as PengadaanMetode, desc: "Nilai pengadaan s.d. Rp 200 juta" },
                    { value: "e-Purchasing"        as PengadaanMetode, desc: "Melalui katalog elektronik LKPP" },
                    { value: "Tender / Lelang"     as PengadaanMetode, desc: "Nilai pengadaan di atas Rp 200 juta" },
                    { value: "Penunjukan Langsung" as PengadaanMetode, desc: "Keadaan tertentu sesuai Perpres 16/2018" },
                    { value: "Hibah / Bantuan"     as PengadaanMetode, desc: "Dari pemerintah pusat atau pihak ketiga" },
                  ]).map(({ value, desc }) => (
                    <div
                      key={value}
                      onClick={() => setMetode(value)}
                      className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-all ${metode === value ? "border-[#111827] bg-gray-50 shadow-sm" : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"}`}
                    >
                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 ${metode === value ? "border-[#111827]" : "border-gray-300"}`}>
                        {metode === value && <div className="w-2 h-2 rounded-full bg-[#111827]" />}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-gray-900">{value}</p>
                        <p className="text-[10px] text-gray-500">{desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Sumber Dana <span className="text-red-500">*</span></label>
                  <select
                    value={sumberDana} onChange={e => setSumberDana(e.target.value as SumberDana)}
                    className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none focus:ring-1 focus:ring-gray-400"
                  >
                    <option value="">Pilih...</option>
                    {(["DIPA", "BLU", "PNBP", "Hibah", "Swadana"] as SumberDana[]).map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Estimasi Anggaran (Rp) <span className="text-red-500">*</span></label>
                  <input
                    type="number" min={0} value={anggaran} onChange={e => setAnggaran(e.target.value)}
                    placeholder="0"
                    className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Vendor / Penyedia <span className="text-red-500">*</span></label>
                <select
                  value={vendor} onChange={e => setVendor(e.target.value)}
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none focus:ring-1 focus:ring-gray-400"
                >
                  <option value="">Pilih vendor...</option>
                  {VENDOR_LIST.map(v => <option key={v} value={v}>{v}</option>)}
                  <option value="Lainnya">Lainnya (isi manual)</option>
                </select>
                {vendor === "Lainnya" && (
                  <input
                    className="w-full mt-2 text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400"
                    placeholder="Nama vendor..."
                    onChange={e => setVendor(e.target.value)}
                  />
                )}
              </div>

              {/* Sumber Kebutuhan */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-2">Sumber Kebutuhan</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {SUMBER_KEBUTUHAN_OPTS.map(s => (
                    <div
                      key={s}
                      onClick={() => toggleSumber(s)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-lg border cursor-pointer transition-all ${sumberList.includes(s) ? "border-[#111827] bg-gray-50" : "border-gray-200 hover:bg-gray-50"}`}
                    >
                      <div className={`w-4 h-4 rounded border-2 flex items-center justify-center shrink-0 ${sumberList.includes(s) ? "bg-[#111827] border-[#111827]" : "border-gray-300"}`}>
                        {sumberList.includes(s) && <Check size={10} className="text-white" />}
                      </div>
                      <span className="text-xs text-gray-700 leading-tight">{s}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Alasan Kebutuhan */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Alasan Kebutuhan</label>
                <textarea
                  rows={3} value={alasan} onChange={e => setAlasan(e.target.value)}
                  placeholder="Jelaskan alasan dan urgensi pengadaan barang ini..."
                  className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-gray-400 resize-none"
                />
              </div>

              {/* Upload dokumen */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Upload Dokumen Pendukung</label>
                <label className="flex items-center justify-center gap-2 w-full py-3 border-2 border-dashed border-gray-200 rounded-lg cursor-pointer hover:border-gray-300 hover:bg-gray-50 transition-colors">
                  <Upload size={14} className="text-gray-400" />
                  <span className="text-xs text-gray-500">Klik untuk pilih file (PDF, DOCX, XLSX)</span>
                  <input type="file" multiple accept=".pdf,.docx,.xlsx" className="hidden" onChange={handleFileChange} />
                </label>
                {uploadedFiles.length > 0 && (
                  <div className="mt-2 space-y-1.5">
                    {uploadedFiles.map((f, i) => (
                      <div key={i} className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg border border-gray-100">
                        <Paperclip size={11} className="text-gray-400 shrink-0" />
                        <span className="text-xs text-gray-700 flex-1 truncate">{f}</span>
                        <button onClick={() => setUploadedFiles(prev => prev.filter((_, j) => j !== i))} className="text-gray-400 hover:text-red-500 transition-colors">
                          <Trash2 size={11} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── Step 4: Review ── */}
          {step === 4 && (
            <div className="space-y-4">
              <p className="text-sm text-gray-500">Periksa kembali detail pengajuan sebelum disimpan sebagai Draft.</p>
              <div className="border border-gray-200 rounded-xl overflow-hidden divide-y divide-gray-100">
                {[
                  { label: "Nama Barang",   value: nama },
                  { label: "Kategori",      value: `${kategori} — ${tipeAset}` },
                  { label: "Jumlah",        value: `${jumlah} ${satuan}` },
                  { label: "Spesifikasi",   value: spesifikasi },
                  { label: "Lokasi",        value: `${gedung} — ${ruangan}` },
                  { label: "PIC",           value: pic },
                  { label: "Metode",        value: metode },
                  { label: "Sumber Dana",   value: sumberDana },
                  { label: "Estimasi",      value: anggaran ? fmtRupiah(Number(anggaran)) : "—" },
                  { label: "Vendor",        value: vendor },
                  ...(sumberList.length > 0 ? [{ label: "Sumber Kebutuhan", value: sumberList.join(", ") }] : []),
                  ...(alasan ? [{ label: "Alasan", value: alasan }] : []),
                  ...(uploadedFiles.length > 0 ? [{ label: "Dokumen", value: `${uploadedFiles.length} file` }] : []),
                  ...(kategori === "AL" && noPolisi ? [{ label: "No. Polisi", value: noPolisi }] : []),
                  ...(kategori === "ATB" && masaBerlaku ? [{ label: "Masa Berlaku", value: masaBerlaku }] : []),
                ].map(({ label, value }) => (
                  <div key={label} className="flex gap-3 px-4 py-2.5">
                    <span className="text-xs text-gray-500 w-28 shrink-0">{label}</span>
                    <span className="text-xs font-semibold text-gray-800 flex-1">{value || "—"}</span>
                  </div>
                ))}
              </div>
              <div className="flex items-start gap-2 p-3 bg-blue-50 border border-blue-100 rounded-lg">
                <AlertCircle size={14} className="text-blue-500 mt-0.5 shrink-0" />
                <p className="text-xs text-blue-700">Pengajuan akan disimpan sebagai <strong>Draft</strong>. Anda perlu mengirimkannya untuk mendapatkan persetujuan dari atasan.</p>
              </div>
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-100 flex justify-between">
          <button
            onClick={() => step > 1 ? setStep(s => s - 1) : onClose()}
            className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            {step === 1 ? "Batal" : "← Kembali"}
          </button>
          <button
            disabled={!canNext}
            onClick={() => step < 4 ? setStep(s => s + 1) : handleSubmit()}
            className={`px-5 py-2 text-sm font-semibold text-white rounded-lg transition-colors ${canNext ? "bg-[#111827] hover:bg-gray-800" : "bg-gray-300 cursor-not-allowed"}`}
          >
            {step < 4 ? "Lanjut →" : "Simpan Draft"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function PengadaanPage({ topBar }: { topBar: React.ReactNode }) {
  const store = useDataStore();
  // Overlay for status / field updates against store-derived records (keyed by id)
  const [localOverlay, setLocalOverlay] = useState<Record<string, Partial<PengadaanRecord>>>({});
  // New procurements created locally via the wizard (not pushed to store schema)
  const [localNewPengadaan, setLocalNewPengadaan] = useState<PengadaanRecord[]>([]);

  const records: PengadaanRecord[] = useMemo(() => {
    const merged = store.procurementRequests.map(p => {
      const base = procToRecord(p);
      const ov = localOverlay[base.id];
      if (!ov) return base;
      return {
        ...base,
        ...ov,
        timeline: ov.timeline ?? base.timeline,
        sumberKebutuhan: ov.sumberKebutuhan ?? base.sumberKebutuhan,
        dokumen: ov.dokumen ?? base.dokumen,
      };
    });
    return [...localNewPengadaan, ...merged];
  }, [store.procurementRequests, localOverlay, localNewPengadaan]);

  const [search, setSearch]     = useState("");
  const [statusFilter, setStatusFilter] = useState<PengadaanStatus | "Semua">("Semua");
  const [katFilter, setKatFilter]     = useState<PengadaanKategori | "">("");
  const [metodeFilter, setMetodeFilter] = useState<PengadaanMetode | "">("");
  const [showNew, setShowNew]   = useState(false);
  const [drawerId, setDrawerId] = useState<string | null>(null);
  const [hoverId, setHoverId]   = useState<string | null>(null);

  const drawerRecord = drawerId ? records.find(r => r.id === drawerId) ?? null : null;

  const counts = useMemo(() => ({
    total:       records.length,
    menunggu:    records.filter(r => r.status === "Menunggu Persetujuan").length,
    dalamProses: records.filter(r => r.status === "Dalam Pengadaan").length,
    selesai:     records.filter(r => r.status === "Selesai").length,
    ditolak:     records.filter(r => r.status === "Ditolak").length,
    pm:          records.filter(r => r.kategori === "PM").length,
    atb:         records.filter(r => r.kategori === "ATB").length,
    atl:         records.filter(r => r.kategori === "ATL").length,
    al:          records.filter(r => r.kategori === "AL").length,
    totalEst:    records.reduce((s, r) => s + r.anggaranEstimasi, 0),
    totalReal:   records.reduce((s, r) => s + (r.anggaranRealisasi ?? 0), 0),
  }), [records]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return records.filter(r => {
      if (statusFilter !== "Semua" && r.status !== statusFilter) return false;
      if (katFilter && r.kategori !== katFilter) return false;
      if (metodeFilter && r.metode !== metodeFilter) return false;
      if (q && !r.nama.toLowerCase().includes(q) && !r.id.toLowerCase().includes(q) &&
          !r.vendor.toLowerCase().includes(q) && !r.tipeAset.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [records, statusFilter, katFilter, metodeFilter, search]);

  const handleAction = (id: string, status: PengadaanStatus, catatan?: string, realisasi?: number) => {
    const today = new Date().toISOString().slice(0, 10);
    const actionLabel: Partial<Record<PengadaanStatus, string>> = {
      "Menunggu Persetujuan": "Dikirim untuk Persetujuan",
      "Disetujui":            "Disetujui",
      "Ditolak":              "Ditolak",
      "Dalam Pengadaan":      "Mulai Pengadaan",
      "Selesai":              "Pengadaan Selesai",
    };
    const byApprover = ["Disetujui","Ditolak"].includes(status);
    const current = records.find(r => r.id === id);
    const newEntry: TimelineItem = {
      tanggal: today,
      aksi: actionLabel[status] ?? status,
      oleh: byApprover ? "Dr. Rudi Hartono" : "Salgado Ginting",
      catatan: catatan?.trim() || undefined,
    };
    const isLocalNew = localNewPengadaan.some(r => r.id === id);

    if (status === "Selesai" && !isLocalNew) {
      // completeProcurement handles store mutation + appendActivity
      store.completeProcurement(id);
    } else {
      store.appendActivity({
        pengguna: byApprover ? "Dr. Rudi Hartono" : "Salgado Ginting",
        role: byApprover ? "Pejabat Berwenang" : "Admin Sistem",
        menu: "Pengadaan",
        aksi: `Pengadaan ${id} – status diubah menjadi ${status}`,
        target_type: "Procurement",
        target_id: id,
        status: "Berhasil",
        jenis: "pengadaan",
      });
    }

    if (isLocalNew) {
      setLocalNewPengadaan(prev => prev.map(r => r.id !== id ? r : {
        ...r, status,
        tglPersetujuan: status === "Disetujui" ? today : r.tglPersetujuan,
        tglRealisasi:   status === "Selesai"   ? today : r.tglRealisasi,
        anggaranRealisasi: realisasi ?? r.anggaranRealisasi,
        approver: byApprover ? "Dr. Rudi Hartono" : r.approver,
        timeline: [...r.timeline, newEntry],
      }));
    } else {
      setLocalOverlay(prev => {
        const existing = prev[id] ?? {};
        const baseTimeline = existing.timeline ?? (current?.timeline ?? []);
        return {
          ...prev,
          [id]: {
            ...existing,
            status,
            tglPersetujuan: status === "Disetujui" ? today : existing.tglPersetujuan,
            tglRealisasi:   status === "Selesai"   ? today : existing.tglRealisasi,
            anggaranRealisasi: realisasi ?? existing.anggaranRealisasi,
            approver: byApprover ? "Dr. Rudi Hartono" : existing.approver,
            timeline: [...baseTimeline, newEntry],
          },
        };
      });
    }
  };

  const handleSubmit = (data: Omit<PengadaanRecord, "id">) => {
    const existingCount = store.procurementRequests.length + localNewPengadaan.length;
    const newId = `PGD-2026-${String(existingCount + 1).padStart(3, "0")}`;
    store.appendActivity({
      pengguna: "Salgado Ginting",
      role: "Admin Sistem",
      menu: "Pengadaan",
      aksi: `Pengadaan ${newId} – ${data.nama} diajukan`,
      target_type: "Procurement",
      target_id: newId,
      status: "Berhasil",
      jenis: "pengadaan",
    });
    setLocalNewPengadaan(prev => [{ id: newId, ...data }, ...prev]);
  };

  const STATUS_TABS: Array<PengadaanStatus | "Semua"> = [
    "Semua", "Draft", "Menunggu Persetujuan", "Disetujui", "Dalam Pengadaan", "Selesai", "Ditolak",
  ];
  const tabCount = (tab: PengadaanStatus | "Semua") => {
    if (tab === "Semua")               return counts.total;
    if (tab === "Draft")               return records.filter(r => r.status === "Draft").length;
    if (tab === "Menunggu Persetujuan")return counts.menunggu;
    if (tab === "Disetujui")           return records.filter(r => r.status === "Disetujui").length;
    if (tab === "Dalam Pengadaan")     return counts.dalamProses;
    if (tab === "Selesai")             return counts.selesai;
    return counts.ditolak;
  };

  const CAT_CARDS = [
    { kat: "PM"  as PengadaanKategori, label: "Peralatan & Mesin",  count: counts.pm,  icon: <Cpu size={15} className="text-purple-600" />, bg: "bg-purple-50", text: "text-purple-700" },
    { kat: "ATB" as PengadaanKategori, label: "Aset Tak Berwujud",  count: counts.atb, icon: <FileText size={15} className="text-sky-600" />, bg: "bg-sky-50",   text: "text-sky-700" },
    { kat: "ATL" as PengadaanKategori, label: "Aset Tetap Lainnya", count: counts.atl, icon: <Layers size={15} className="text-teal-600" />, bg: "bg-teal-50",  text: "text-teal-700" },
    { kat: "AL"  as PengadaanKategori, label: "Alat Angkutan",      count: counts.al,  icon: <Car size={15} className="text-indigo-600" />, bg: "bg-indigo-50", text: "text-indigo-700" },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">
        {/* Title */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-[#111827]">Pengadaan Aset</h1>
            <p className="text-sm text-gray-500 mt-0.5">Kelola pengajuan dan proses pengadaan seluruh kategori aset IPB SV.</p>
          </div>
          <button
            onClick={() => setShowNew(true)}
            className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-[#111827] rounded-lg hover:bg-gray-800 transition-colors shadow-sm"
          >
            <Plus size={16} /> Buat Pengajuan
          </button>
        </div>

        {/* 5 KPI cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          {[
            { label: "Total Pengajuan",      value: counts.total,       icon: <ShoppingCart size={17} className="text-gray-600" />,  bg: "bg-gray-50",   color: "#111827" },
            { label: "Menunggu Persetujuan", value: counts.menunggu,    icon: <Clock size={17} className="text-yellow-600" />,        bg: "bg-yellow-50", color: "#B45309" },
            { label: "Dalam Pengadaan",      value: counts.dalamProses, icon: <Truck size={17} className="text-orange-600" />,        bg: "bg-orange-50", color: "#C2410C" },
            { label: "Selesai",              value: counts.selesai,     icon: <CheckCircle2 size={17} className="text-green-600" />,  bg: "bg-green-50",  color: "#15803D" },
            { label: "Ditolak",              value: counts.ditolak,     icon: <XCircle size={17} className="text-red-600" />,         bg: "bg-red-50",    color: "#B91C1C" },
          ].map(s => (
            <div key={s.label} className="bg-white border border-gray-200 rounded-xl p-4 flex items-center gap-3 shadow-sm">
              <div className={`w-10 h-10 rounded-lg ${s.bg} flex items-center justify-center shrink-0`}>{s.icon}</div>
              <div>
                <p className="text-xl font-bold" style={{ color: s.color }}>{s.value}</p>
                <p className="text-xs text-gray-500 leading-tight">{s.label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Budget summary + Category cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-1 bg-white border border-gray-200 rounded-xl p-5 shadow-sm space-y-3">
            <p className="text-xs font-semibold uppercase tracking-wider text-gray-400 flex items-center gap-2"><CircleDollarSign size={14} /> Ringkasan Anggaran</p>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <p className="text-xs text-gray-500">Total Estimasi</p>
                <p className="text-sm font-bold text-gray-800">{fmtRupiah(counts.totalEst)}</p>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-xs text-gray-500">Total Realisasi</p>
                <p className="text-sm font-bold text-green-700">{fmtRupiah(counts.totalReal)}</p>
              </div>
              <div className="h-[1px] bg-gray-100 my-1" />
              <div className="flex justify-between items-center">
                <p className="text-xs text-gray-500">Selisih</p>
                <p className={`text-sm font-bold ${counts.totalReal > 0 && counts.totalReal < counts.totalEst ? "text-green-600" : "text-gray-500"}`}>
                  {counts.totalReal > 0 ? fmtRupiah(counts.totalEst - counts.totalReal) : "—"}
                </p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-3">
            {CAT_CARDS.map(c => (
              <button
                key={c.kat}
                onClick={() => setKatFilter(prev => prev === c.kat ? "" : c.kat)}
                className={`bg-white border rounded-xl p-3 flex flex-col gap-1.5 shadow-sm transition-all text-left ${katFilter === c.kat ? "border-[#111827] ring-1 ring-[#111827]" : "border-gray-200 hover:border-gray-300"}`}
              >
                <div className={`w-8 h-8 rounded-lg ${c.bg} flex items-center justify-center`}>{c.icon}</div>
                <p className={`text-lg font-bold ${c.text}`}>{c.count}</p>
                <p className="text-[10px] text-gray-500 leading-tight">{c.label}</p>
                {katFilter === c.kat && <Check size={12} className="text-gray-700 mt-auto" />}
              </button>
            ))}
          </div>
        </div>

        {/* Table card */}
        <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
          {/* Filter bar */}
          <div className="px-5 py-3 border-b border-gray-100 flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="relative flex-1 min-w-0">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Cari nama barang, ID, vendor..."
                className="w-full pl-8 pr-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400"
              />
            </div>
            <div className="relative shrink-0">
              <select
                value={metodeFilter}
                onChange={e => setMetodeFilter(e.target.value as PengadaanMetode | "")}
                className="text-sm border border-gray-200 rounded-lg pl-3 pr-8 py-2 bg-white outline-none focus:ring-1 focus:ring-gray-400 appearance-none cursor-pointer"
              >
                <option value="">Semua Metode</option>
                {(["Pembelian Langsung","e-Purchasing","Tender / Lelang","Penunjukan Langsung","Hibah / Bantuan"] as PengadaanMetode[]).map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            </div>
            <button
              onClick={() => exportToExcel(filtered.map(r => ({
                "ID": r.id, "Nama Barang": r.nama, "Kategori": r.kategori,
                "Jumlah": r.jumlah, "Satuan": r.satuan, "Status": r.status,
                "Metode": r.metode, "Vendor": r.vendor ?? "",
                "Anggaran Estimasi": r.anggaranEstimasi,
                "Anggaran Realisasi": r.anggaranRealisasi ?? 0,
                "Tgl Ajuan": r.tglAjuan, "Tgl Realisasi": r.tglRealisasi ?? "",
                "Pengaju": r.pengaju, "Catatan": r.catatan,
              })), `pengadaan-${new Date().toISOString().slice(0,10)}`, "Pengadaan")}
              className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors shrink-0">
              <Download size={14} /> Export
            </button>
          </div>

          {/* Status tabs */}
          <div className="flex items-center gap-0.5 px-5 pt-3 border-b border-gray-100 overflow-x-auto">
            {STATUS_TABS.map(tab => (
              <button
                key={tab}
                onClick={() => setStatusFilter(tab)}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold whitespace-nowrap border-b-2 transition-colors ${statusFilter === tab ? "border-[#111827] text-[#111827]" : "border-transparent text-gray-500 hover:text-gray-700"}`}
              >
                {tab}
                <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${statusFilter === tab ? "bg-[#111827] text-white" : "bg-gray-100 text-gray-500"}`}>
                  {tabCount(tab)}
                </span>
              </button>
            ))}
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100">
                  {["ID", "Barang", "Kategori", "Jumlah", "Metode", "Vendor", "Est. Anggaran", "Tgl Ajuan", "Status", "Aksi"].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-gray-400">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="px-4 py-16 text-center">
                      <div className="flex flex-col items-center gap-2 text-gray-400">
                        <ShoppingCart size={32} strokeWidth={1} />
                        <p className="text-sm font-medium">Tidak ada data pengadaan</p>
                        <p className="text-xs">Coba ubah filter atau buat pengajuan baru</p>
                      </div>
                    </td>
                  </tr>
                ) : filtered.map(r => (
                  <tr
                    key={r.id}
                    onMouseEnter={() => setHoverId(r.id)}
                    onMouseLeave={() => setHoverId(null)}
                    className="hover:bg-gray-50 transition-colors"
                  >
                    <td className="px-4 py-3"><span className="text-xs font-mono font-semibold text-gray-700">{r.id}</span></td>
                    <td className="px-4 py-3 max-w-[160px]">
                      <p className="text-xs font-semibold text-gray-800 truncate">{r.nama}</p>
                      <p className="text-[10px] text-gray-400 truncate">{r.tipeAset}</p>
                    </td>
                    <td className="px-4 py-3"><KategoriBadge kategori={r.kategori} /></td>
                    <td className="px-4 py-3"><p className="text-xs text-gray-700">{r.jumlah} {r.satuan}</p></td>
                    <td className="px-4 py-3"><MetodeBadge metode={r.metode} /></td>
                    <td className="px-4 py-3 max-w-[130px]"><p className="text-xs text-gray-600 truncate">{r.vendor}</p></td>
                    <td className="px-4 py-3">
                      <p className="text-xs font-semibold text-gray-800">{fmtRupiah(r.anggaranEstimasi)}</p>
                      {r.anggaranRealisasi && (
                        <p className="text-[10px] text-green-600">Real: {fmtRupiah(r.anggaranRealisasi)}</p>
                      )}
                    </td>
                    <td className="px-4 py-3"><p className="text-xs text-gray-500">{r.tglAjuan}</p></td>
                    <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                    <td className="px-4 py-3">
                      <div className={`flex items-center gap-1 transition-opacity ${hoverId === r.id ? "opacity-100" : "opacity-0"}`}>
                        <button
                          onClick={() => setDrawerId(r.id)}
                          title="Detail"
                          className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-md transition-colors"
                        >
                          <Eye size={14} />
                        </button>
                        {r.status === "Draft" && (
                          <button onClick={() => handleAction(r.id, "Menunggu Persetujuan")} title="Kirim"
                            className="p-1.5 text-blue-400 hover:text-blue-700 hover:bg-blue-50 rounded-md transition-colors">
                            <Send size={14} />
                          </button>
                        )}
                        {r.status === "Menunggu Persetujuan" && (
                          <>
                            <button onClick={() => handleAction(r.id, "Disetujui")} title="Setujui" className="p-1.5 text-green-500 hover:text-green-700 hover:bg-green-50 rounded-md transition-colors"><CheckCircle2 size={14} /></button>
                            <button onClick={() => handleAction(r.id, "Ditolak")}   title="Tolak"   className="p-1.5 text-red-400 hover:text-red-700 hover:bg-red-50 rounded-md transition-colors"><XCircle size={14} /></button>
                          </>
                        )}
                        {r.status === "Disetujui" && (
                          <button onClick={() => handleAction(r.id, "Dalam Pengadaan")} title="Mulai" className="p-1.5 text-orange-400 hover:text-orange-700 hover:bg-orange-50 rounded-md transition-colors"><Truck size={14} /></button>
                        )}
                        {r.status === "Dalam Pengadaan" && (
                          <button onClick={() => handleAction(r.id, "Selesai")} title="Selesai" className="p-1.5 text-green-500 hover:text-green-700 hover:bg-green-50 rounded-md transition-colors"><CheckCircle2 size={14} /></button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
            <p className="text-xs text-gray-400">
              Menampilkan <span className="font-semibold text-gray-700">{filtered.length}</span> dari <span className="font-semibold text-gray-700">{records.length}</span> pengajuan
            </p>
            <div className="flex items-center gap-1.5">
              <button className="px-3 py-1 text-xs font-medium text-gray-500 border border-gray-200 rounded-md hover:bg-gray-50 transition-colors">← Prev</button>
              <button className="px-3 py-1 text-xs font-medium bg-[#111827] text-white rounded-md">1</button>
              <button className="px-3 py-1 text-xs font-medium text-gray-500 border border-gray-200 rounded-md hover:bg-gray-50 transition-colors">Next →</button>
            </div>
          </div>
        </div>
      </div>

      {showNew      && <NewPengadaanModal onClose={() => setShowNew(false)} onSubmit={handleSubmit} />}
      {drawerRecord && <DetailDrawer record={drawerRecord} onClose={() => setDrawerId(null)} onAction={handleAction} />}
    </main>
  );
}
