import React, { useState } from "react";
import { RefreshCw, CheckCircle2, AlertTriangle, X } from "lucide-react";
import { useApp } from "./AppContext";

// ── Types ─────────────────────────────────────────────────────────────────────
type Tema = "Terang" | "Gelap" | "Ikuti Sistem";
type Kepadatan = "Nyaman" | "Normal" | "Ringkas";
type UkuranTeks = "Kecil" | "Normal" | "Besar";

// ── Setting Row ───────────────────────────────────────────────────────────────
function SettingRow({ label, desc, children }: {
  label: string; desc?: string; children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between py-4 border-b border-gray-100 last:border-0 gap-4">
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-gray-800">{label}</p>
        {desc && <p className="text-xs text-gray-500 mt-0.5">{desc}</p>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

// ── Toggle ────────────────────────────────────────────────────────────────────
function Toggle({ value, onChange, disabled }: { value: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <button onClick={() => !disabled && onChange(!value)} disabled={disabled}
      className={`w-10 h-6 rounded-full relative transition-colors ${value ? "bg-gray-900" : "bg-gray-200"} ${disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}>
      <span className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ${value ? "left-5" : "left-1"}`} />
    </button>
  );
}

// ── Section Card ──────────────────────────────────────────────────────────────
function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      <div className="px-5 py-3.5 border-b border-gray-100 bg-gray-50/50">
        <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
      </div>
      <div className="px-5 divide-y divide-gray-50">{children}</div>
    </div>
  );
}

// ── Segmented Control ─────────────────────────────────────────────────────────
function SegmentedControl<T extends string>({ options, value, onChange }: {
  options: T[]; value: T; onChange: (v: T) => void;
}) {
  return (
    <div className="flex bg-gray-100 p-1 rounded-lg gap-0.5">
      {options.map(o => (
        <button key={o} onClick={() => onChange(o)}
          className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${value === o ? "bg-white shadow-sm text-gray-900" : "text-gray-500 hover:text-gray-700"}`}>
          {o}
        </button>
      ))}
    </div>
  );
}

// ── Reset Confirmation ────────────────────────────────────────────────────────
function ResetConfirmModal({ onClose, onConfirm }: { onClose: () => void; onConfirm: () => void }) {
  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[420px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200 p-6">
        <h3 className="text-base font-bold text-gray-900 mb-2">Kembalikan Preferensi Default?</h3>
        <p className="text-sm text-gray-500 mb-5">Seluruh preferensi tampilan dan regional akan dikembalikan ke pengaturan awal.</p>
        <div className="flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <button onClick={onConfirm} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">Kembalikan Default</button>
        </div>
      </div>
    </>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function PreferensiPage({ topBar, showToast }: {
  topBar?: React.ReactNode;
  showToast?: (msg: string, type?: string) => void;
}) {
  const { language, setLanguage } = useApp();

  // Tampilan
  const [tema, setTema]           = useState<Tema>("Terang");
  const [kepadatan, setKepadatan] = useState<Kepadatan>("Normal");
  const [ukuranTeks, setUkuranTeks] = useState<UkuranTeks>("Normal");
  const [sidebar, setSidebar]     = useState("Ingat Kondisi Terakhir");
  const [animasi, setAnimasi]     = useState(true);

  // Bahasa & Regional — bahasa terhubung langsung ke AppContext
  const [matauang, setMataUang]   = useState("IDR — Rupiah Indonesia");
  const [formatAngka, setFormatAngka] = useState("1.250.000,00");
  const [formatTgl, setFormatTgl] = useState("3 Jul 2026");
  const [formatWaktu, setFormatWaktu] = useState("24 Jam");
  const [zonawaktu, setZonaWaktu] = useState("Asia/Jakarta — GMT+7");
  const [hariPertama, setHariPertama] = useState("Senin");

  // Aksesibilitas
  const [kontras, setKontras]     = useState(false);
  const [kurangiAnim, setKurangiAnim] = useState(false);
  const [perbesarKlik, setPerbesarKlik] = useState(true);
  const [garisFokus, setGarisFokus] = useState(true);

  const [unsaved, setUnsaved]     = useState(false);
  const [saving, setSaving]       = useState(false);
  const [showReset, setShowReset] = useState(false);

  const markDirty = () => setUnsaved(true);

  const handleSave = () => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setUnsaved(false);
      const namaLang = language === "en" ? "English" : "Bahasa Indonesia";
      showToast?.(`Preferensi berhasil diperbarui. Bahasa: ${namaLang}`);
    }, 700);
  };

  const handleReset = () => {
    setTema("Terang");
    setKepadatan("Normal");
    setUkuranTeks("Normal");
    setSidebar("Ingat Kondisi Terakhir");
    setAnimasi(true);
    setLanguage("id");
    setMataUang("IDR — Rupiah Indonesia");
    setFormatAngka("1.250.000,00");
    setFormatTgl("3 Jul 2026");
    setFormatWaktu("24 Jam");
    setZonaWaktu("Asia/Jakarta — GMT+7");
    setHariPertama("Senin");
    setKontras(false);
    setKurangiAnim(false);
    setPerbesarKlik(true);
    setGarisFokus(true);
    setShowReset(false);
    setUnsaved(false);
    showToast?.("Preferensi dikembalikan ke default.");
  };

  const change = <T,>(setter: (v: T) => void) => (v: T) => { setter(v); markDirty(); };

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Preferensi</h1>
            <p className="text-xs text-gray-500 mt-0.5">Sesuaikan tampilan dan pengalaman penggunaan FreeSpace.</p>
          </div>
          {unsaved && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-lg text-xs font-medium text-amber-700">
              <AlertTriangle size={12} /> Perubahan belum disimpan
            </div>
          )}
        </div>

        {/* Section 1 — Tampilan */}
        <SectionCard title="Tampilan & Antarmuka">
          <SettingRow label="Tema Visual" desc="Pilih tema warna untuk tampilan FreeSpace.">
            <SegmentedControl<Tema> options={["Terang","Gelap","Ikuti Sistem"]} value={tema} onChange={change(setTema)} />
          </SettingRow>
          <SettingRow label="Kepadatan Tampilan" desc="Mengatur jarak antarbaris, card, dan elemen antarmuka.">
            <SegmentedControl<Kepadatan> options={["Nyaman","Normal","Ringkas"]} value={kepadatan} onChange={change(setKepadatan)} />
          </SettingRow>
          <SettingRow label="Ukuran Teks" desc="Memengaruhi ukuran teks pada seluruh halaman.">
            <SegmentedControl<UkuranTeks> options={["Kecil","Normal","Besar"]} value={ukuranTeks} onChange={change(setUkuranTeks)} />
          </SettingRow>
          <SettingRow label="Perilaku Sidebar" desc="Mengatur cara sidebar menampilkan dirinya sendiri.">
            <select value={sidebar} onChange={e => { setSidebar(e.target.value); markDirty(); }}
              className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none bg-white">
              {["Selalu Terbuka","Collapse Otomatis pada Layar Kecil","Ingat Kondisi Terakhir"].map(o => <option key={o}>{o}</option>)}
            </select>
          </SettingRow>
          <SettingRow label="Animasi Antarmuka" desc="Menggunakan transisi ringan saat berpindah halaman dan membuka panel.">
            <Toggle value={animasi} onChange={change(setAnimasi)} />
          </SettingRow>
        </SectionCard>

        {/* Section 2 — Bahasa & Regional */}
        <SectionCard title="Bahasa & Regional">
          <SettingRow label="Bahasa" desc="Bahasa yang digunakan pada antarmuka FreeSpace.">
            <select value={language} onChange={e => { setLanguage(e.target.value as "id" | "en"); markDirty(); }}
              className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none bg-white">
              <option value="id">Bahasa Indonesia</option>
              <option value="en">English</option>
            </select>
          </SettingRow>
          <SettingRow label="Mata Uang">
            <select value={matauang} onChange={e => { setMataUang(e.target.value); markDirty(); }}
              className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none bg-white">
              <option>IDR — Rupiah Indonesia</option>
              <option>USD — Dollar Amerika</option>
            </select>
          </SettingRow>
          <SettingRow label="Format Angka">
            <select value={formatAngka} onChange={e => { setFormatAngka(e.target.value); markDirty(); }}
              className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none bg-white">
              <option>1.250.000,00</option>
              <option>1,250,000.00</option>
            </select>
          </SettingRow>
          <SettingRow label="Format Tanggal">
            <select value={formatTgl} onChange={e => { setFormatTgl(e.target.value); markDirty(); }}
              className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none bg-white">
              {["3 Jul 2026","03/07/2026","2026-07-03","Jumat, 3 Juli 2026"].map(o => <option key={o}>{o}</option>)}
            </select>
          </SettingRow>
          <SettingRow label="Format Waktu">
            <SegmentedControl options={["24 Jam","12 Jam"]} value={formatWaktu} onChange={change(setFormatWaktu)} />
          </SettingRow>
          <SettingRow label="Zona Waktu">
            <select value={zonawaktu} onChange={e => { setZonaWaktu(e.target.value); markDirty(); }}
              className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none bg-white">
              <option>Asia/Jakarta — GMT+7</option>
              <option>Asia/Makassar — GMT+8</option>
              <option>Asia/Jayapura — GMT+9</option>
            </select>
          </SettingRow>
          <SettingRow label="Hari Pertama Minggu">
            <SegmentedControl options={["Senin","Minggu"]} value={hariPertama} onChange={change(setHariPertama)} />
          </SettingRow>
        </SectionCard>

        {/* Section 3 — Aksesibilitas */}
        <SectionCard title="Aksesibilitas">
          <SettingRow label="Kontras Tinggi" desc="Meningkatkan kontras warna untuk keterbacaan lebih baik.">
            <Toggle value={kontras} onChange={change(setKontras)} />
          </SettingRow>
          <SettingRow label="Kurangi Animasi" desc="Menonaktifkan atau mengurangi efek transisi.">
            <Toggle value={kurangiAnim} onChange={change(setKurangiAnim)} />
          </SettingRow>
          <SettingRow label="Perbesar Area Klik" desc="Memperbesar area interaksi tanpa mengubah ukuran visual elemen.">
            <Toggle value={perbesarKlik} onChange={change(setPerbesarKlik)} />
          </SettingRow>
          <SettingRow label="Garis Fokus Keyboard" desc="Menampilkan indikator fokus saat navigasi menggunakan keyboard.">
            <Toggle value={garisFokus} onChange={change(setGarisFokus)} />
          </SettingRow>
        </SectionCard>

        {/* Save Bar */}
        <div className="flex items-center justify-end gap-3 pb-4">
          <button onClick={() => setShowReset(true)}
            className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            Kembalikan Default
          </button>
          <button onClick={handleSave} disabled={saving || !unsaved}
            className="px-5 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-50 flex items-center gap-2">
            {saving
              ? <><RefreshCw size={14} className="animate-spin" /> Menyimpan...</>
              : <><CheckCircle2 size={14} /> Simpan Perubahan</>
            }
          </button>
        </div>
      </div>

      {showReset && <ResetConfirmModal onClose={() => setShowReset(false)} onConfirm={handleReset} />}
    </main>
  );
}
