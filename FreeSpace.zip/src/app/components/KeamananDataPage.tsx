import React, { useState } from "react";
import {
  Shield, Smartphone, Lock, X, RefreshCw, Eye, EyeOff,
  Download, Upload, AlertTriangle, CheckCircle2, Trash2,
  Plus, Monitor, LogOut, Clock,
} from "lucide-react";

type SecurityTab = "keamanan" | "sesi" | "backup" | "import-export";

// ── Shared ────────────────────────────────────────────────────────────────────
function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)}
      className={`w-10 h-6 rounded-full relative transition-colors shrink-0 ${value ? "bg-gray-900" : "bg-gray-200"}`}>
      <span className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ${value ? "left-5" : "left-1"}`} />
    </button>
  );
}

function SectionCard({ title, children, className = "" }: {
  title: string; children: React.ReactNode; className?: string;
}) {
  return (
    <div className={`bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden ${className}`}>
      <div className="px-5 py-3.5 border-b border-gray-100 bg-gray-50/50">
        <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
      </div>
      <div className="px-5 py-4 space-y-4">{children}</div>
    </div>
  );
}

function SettingRow({ label, desc, children }: { label: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <p className="text-sm font-medium text-gray-800">{label}</p>
        {desc && <p className="text-xs text-gray-500 mt-0.5">{desc}</p>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

// ── Password Strength ─────────────────────────────────────────────────────────
function PasswordStrength({ pw }: { pw: string }) {
  const checks = [
    { label: "Minimal 12 karakter", ok: pw.length >= 12 },
    { label: "Huruf besar", ok: /[A-Z]/.test(pw) },
    { label: "Huruf kecil", ok: /[a-z]/.test(pw) },
    { label: "Angka", ok: /\d/.test(pw) },
    { label: "Simbol", ok: /[^a-zA-Z0-9]/.test(pw) },
  ];
  const score = checks.filter(c => c.ok).length;
  const strength = score <= 1 ? "Sangat Lemah" : score <= 2 ? "Lemah" : score <= 3 ? "Cukup" : score <= 4 ? "Kuat" : "Sangat Kuat";
  const colors = ["bg-red-500","bg-red-400","bg-amber-400","bg-green-400","bg-green-600"];

  return pw ? (
    <div className="space-y-2 mt-2">
      <div className="flex gap-1">
        {[0,1,2,3,4].map(i => (
          <div key={i} className={`flex-1 h-1.5 rounded-full ${i < score ? colors[score-1] : "bg-gray-100"}`} />
        ))}
      </div>
      <p className="text-xs text-gray-500">Kekuatan: <span className="font-semibold">{strength}</span></p>
      <div className="grid grid-cols-2 gap-1">
        {checks.map(c => (
          <div key={c.label} className="flex items-center gap-1.5 text-[10px]">
            <span className={c.ok ? "text-green-500" : "text-gray-300"}>✓</span>
            <span className={c.ok ? "text-gray-700" : "text-gray-400"}>{c.label}</span>
          </div>
        ))}
      </div>
    </div>
  ) : null;
}

// ── Change Password Modal ─────────────────────────────────────────────────────
function ChangePasswordModal({ onClose, showToast }: { onClose: () => void; showToast?: (msg: string) => void }) {
  const [cur, setCur]   = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showCur, setShowCur] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const handleSave = () => {
    if (!cur) { setError("Password saat ini wajib diisi."); return; }
    if (newPw !== confirm) { setError("Konfirmasi password tidak cocok."); return; }
    if (newPw.length < 12) { setError("Password baru minimal 12 karakter."); return; }
    setSaving(true);
    setTimeout(() => { setSaving(false); showToast?.("Password berhasil diubah."); onClose(); }, 800);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[440px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Ubah Password</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>
        <div className="p-5 space-y-3">
          {error && <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-lg p-3 text-xs text-red-600"><AlertTriangle size={13} />{error}</div>}
          {[
            { label: "Password Saat Ini", val: cur, set: setCur, show: showCur, toggle: () => setShowCur(!showCur) },
            { label: "Password Baru",     val: newPw, set: setNewPw, show: showNew, toggle: () => setShowNew(!showNew) },
          ].map(f => (
            <div key={f.label}>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">{f.label}</label>
              <div className="relative">
                <input type={f.show ? "text" : "password"} value={f.val} onChange={e => f.set(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full text-sm px-3 py-2 pr-10 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
                <button onClick={f.toggle} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  {f.show ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>
          ))}
          {newPw && <PasswordStrength pw={newPw} />}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Konfirmasi Password Baru</label>
            <input type="password" value={confirm} onChange={e => setConfirm(e.target.value)} placeholder="••••••••••••"
              className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
          </div>
        </div>
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <button onClick={handleSave} disabled={saving}
            className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-70 flex items-center gap-2">
            {saving ? <><RefreshCw size={13} className="animate-spin" /> Menyimpan...</> : "Ubah Password"}
          </button>
        </div>
      </div>
    </>
  );
}

// ── TAB KEAMANAN ──────────────────────────────────────────────────────────────
function KeamananTab({ showToast }: { showToast?: (msg: string) => void }) {
  const [showPwModal, setShowPwModal] = useState(false);
  const [loginNotif, setLoginNotif]   = useState(true);
  const [blokir, setBlokir]           = useState(true);

  return (
    <div className="space-y-5">
      {/* Password */}
      <SectionCard title="Password">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-700">Terakhir diubah: <span className="font-medium">18 Juni 2026</span></p>
            <p className="text-xs text-gray-400 mt-0.5">Kami menyarankan password yang kuat dan unik.</p>
          </div>
          <button onClick={() => setShowPwModal(true)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Lock size={13} /> Ubah Password
          </button>
        </div>
      </SectionCard>

      {/* 2FA */}
      <SectionCard title="Verifikasi Dua Langkah (2FA)">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center">
              <Shield size={18} className="text-green-600" />
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-800">Aktif — Authenticator App</p>
              <p className="text-xs text-green-600 mt-0.5 flex items-center gap-1"><CheckCircle2 size={11} /> Akun Anda dilindungi dengan 2FA</p>
            </div>
          </div>
          <div className="flex gap-2">
            {["Lihat Recovery Codes","Buat Ulang Codes"].map(a => (
              <button key={a} className="px-3 py-1.5 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">{a}</button>
            ))}
            <button className="px-3 py-1.5 text-xs font-semibold text-red-500 border border-red-100 rounded-lg hover:bg-red-50 transition-colors">Nonaktifkan 2FA</button>
          </div>
        </div>
      </SectionCard>

      {/* Login Protection */}
      <SectionCard title="Proteksi Login">
        <SettingRow label="Notifikasi login perangkat baru" desc="Email notifikasi dikirim setiap kali ada login dari perangkat yang tidak dikenal.">
          <Toggle value={loginNotif} onChange={setLoginNotif} />
        </SettingRow>
        <div className="border-t border-gray-50 pt-4">
          <SettingRow label="Blokir sementara setelah login gagal" desc="Akun diblokir sementara setelah 5 percobaan login gagal.">
            <Toggle value={blokir} onChange={setBlokir} />
          </SettingRow>
        </div>
        <div className="grid grid-cols-2 gap-4 border-t border-gray-50 pt-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Session Timeout</label>
            <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
              <option>8 jam</option>
              <option>24 jam</option>
              <option>7 hari</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Remember This Device</label>
            <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
              <option>30 hari</option>
              <option>14 hari</option>
              <option>7 hari</option>
            </select>
          </div>
        </div>
      </SectionCard>

      {showPwModal && <ChangePasswordModal onClose={() => setShowPwModal(false)} showToast={showToast} />}
    </div>
  );
}

// ── TAB SESI AKTIF ────────────────────────────────────────────────────────────
const SESSIONS = [
  { id: 1, perangkat: "Windows Laptop", browser: "Chrome", lokasi: "Jakarta, Indonesia", ip: "10.0.1.45", terakhir: "Sekarang",           current: true },
  { id: 2, perangkat: "iPad",           browser: "Safari", lokasi: "Jakarta, Indonesia", ip: "10.0.1.20", terakhir: "2 Jul 2026, 20.35", current: false },
];

function SesiAktifTab({ showToast }: { showToast?: (msg: string) => void }) {
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Monitor size={16} className="text-gray-500" />
          <span className="text-sm font-semibold text-gray-800">2 Sesi Aktif</span>
        </div>
        <button onClick={() => showToast?.("Sesi berhasil dikeluarkan.")}
          className="text-xs font-semibold text-red-500 border border-red-100 px-3 py-1.5 rounded-lg hover:bg-red-50 transition-colors">
          Keluar dari Semua Perangkat Lain
        </button>
      </div>

      <div className="space-y-3">
        {SESSIONS.map(s => (
          <div key={s.id}
            className={`bg-white border rounded-xl p-4 flex items-center gap-4 ${s.current ? "border-gray-900 shadow-sm" : "border-gray-200"}`}>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${s.current ? "bg-gray-900" : "bg-gray-100"}`}>
              <Smartphone size={18} className={s.current ? "text-white" : "text-gray-500"} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-sm font-semibold text-gray-900">{s.perangkat}</p>
                {s.current && <span className="text-[10px] font-bold bg-gray-900 text-white px-2 py-0.5 rounded-full">Saat Ini</span>}
              </div>
              <p className="text-xs text-gray-500 mt-0.5">{s.browser} • {s.lokasi}</p>
              <p className="text-xs text-gray-400">IP: {s.ip} • {s.terakhir}</p>
            </div>
            {!s.current && (
              <div className="flex gap-2 shrink-0">
                <button onClick={() => showToast?.("Sesi berhasil dikeluarkan.")}
                  className="flex items-center gap-1.5 text-xs font-semibold text-gray-600 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50 transition-colors">
                  <LogOut size={12} /> Keluar
                </button>
                <button className="flex items-center gap-1.5 text-xs font-semibold text-red-500 border border-red-100 px-3 py-1.5 rounded-lg hover:bg-red-50 transition-colors">
                  Bukan Saya
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── TAB BACKUP & RESTORE ──────────────────────────────────────────────────────
const BACKUP_HISTORY = [
  { tanggal: "3 Jul 2026, 02.00", jenis: "Otomatis", ukuran: "48,6 MB", status: "Berhasil" },
  { tanggal: "2 Jul 2026, 02.00", jenis: "Otomatis", ukuran: "47,9 MB", status: "Berhasil" },
  { tanggal: "1 Jul 2026, 14.30", jenis: "Manual",   ukuran: "47,5 MB", status: "Berhasil" },
  { tanggal: "30 Jun 2026, 02.00",jenis: "Otomatis", ukuran: "46,8 MB", status: "Berhasil" },
];

function BackupTab({ showToast }: { showToast?: (msg: string) => void }) {
  const [backupAuto, setBackupAuto] = useState(true);
  const [frekuensi, setFrekuensi]   = useState("Harian");
  const [waktu, setWaktu]           = useState("02:00");
  const [retensi, setRetensi]       = useState("14");
  const [creating, setCreating]     = useState(false);
  const [showRestore, setShowRestore] = useState(false);
  const [restoreStep, setRestoreStep] = useState(1);
  const [restoreConfirm, setRestoreConfirm] = useState(false);
  const [restorePw, setRestorePw]   = useState("");

  const createBackup = () => {
    setCreating(true);
    setTimeout(() => { setCreating(false); showToast?.("Backup berhasil dibuat."); }, 1500);
  };

  return (
    <div className="space-y-5">
      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Backup Otomatis", value: "Aktif",     desc: "Berjalan setiap hari pukul 02.00", color: "#22C55E" },
          { label: "Backup Terakhir", value: "3 Jul 2026",desc: "Pukul 02.00",                      color: "#111827" },
          { label: "Ukuran Backup",   value: "48,6 MB",   desc: "Database dan file metadata",       color: "#3B82F6" },
          { label: "Status",          value: "Berhasil",  desc: "Tidak ada masalah ditemukan",      color: "#22C55E" },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
            <p className="text-xs text-gray-500 mb-1">{c.label}</p>
            <p className="text-lg font-bold" style={{ color: c.color }}>{c.value}</p>
            <p className="text-[10px] text-gray-400 mt-0.5">{c.desc}</p>
          </div>
        ))}
      </div>

      {/* Auto Backup Settings */}
      <SectionCard title="Pengaturan Backup Otomatis">
        <SettingRow label="Backup Otomatis" desc="Berjalan otomatis sesuai jadwal yang ditentukan.">
          <Toggle value={backupAuto} onChange={setBackupAuto} />
        </SettingRow>
        {backupAuto && (
          <div className="grid grid-cols-3 gap-4 border-t border-gray-50 pt-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Frekuensi</label>
              <select value={frekuensi} onChange={e => setFrekuensi(e.target.value)}
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                {["Harian","Mingguan","Bulanan"].map(f => <option key={f}>{f}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Waktu</label>
              <input type="time" value={waktu} onChange={e => setWaktu(e.target.value)}
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Retensi</label>
              <select value={retensi} onChange={e => setRetensi(e.target.value)}
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                {["7","14","30"].map(r => <option key={r} value={r}>Simpan {r} backup terakhir</option>)}
              </select>
            </div>
          </div>
        )}
      </SectionCard>

      {/* Manual Backup */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold text-gray-800">Buat Backup Sekarang</p>
          <p className="text-xs text-gray-500 mt-0.5">Mencakup data aplikasi, pengaturan, catatan, dan metadata file.</p>
        </div>
        <button onClick={createBackup} disabled={creating}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-70">
          {creating ? <><RefreshCw size={12} className="animate-spin" /> Memproses...</> : <><Download size={12} /> Buat Backup</>}
        </button>
      </div>

      {/* Backup History */}
      <div>
        <h3 className="text-sm font-semibold text-gray-800 mb-3">Riwayat Backup</h3>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/70">
                {["Tanggal","Jenis","Ukuran","Status","Aksi"].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {BACKUP_HISTORY.map((b, i) => (
                <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4 text-xs text-gray-600">{b.tanggal}</td>
                  <td className="py-3 px-4">
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${b.jenis === "Manual" ? "bg-purple-50 text-purple-600" : "bg-gray-100 text-gray-500"}`}>{b.jenis}</span>
                  </td>
                  <td className="py-3 px-4 text-xs text-gray-500">{b.ukuran}</td>
                  <td className="py-3 px-4">
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-green-50 text-green-600">{b.status}</span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex gap-1">
                      <button className="p-1.5 text-xs text-gray-500 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors" onClick={() => setShowRestore(true)}>Restore</button>
                      <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors"><Download size={12} /></button>
                      <button className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors"><Trash2 size={12} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Restore Multi-step Modal */}
      {showRestore && (
        <>
          <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={() => { setShowRestore(false); setRestoreStep(1); }} />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[480px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div>
                <h2 className="text-sm font-bold text-gray-900">Restore Backup</h2>
                <p className="text-xs text-gray-400">Langkah {restoreStep} dari 4</p>
              </div>
              <button onClick={() => { setShowRestore(false); setRestoreStep(1); }} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
            </div>
            <div className="p-5">
              {/* Step indicator */}
              <div className="flex items-center gap-2 mb-5">
                {["Pilih","Detail","Peringatan","Konfirmasi"].map((s, i) => (
                  <React.Fragment key={s}>
                    <div className={`flex items-center justify-center w-6 h-6 rounded-full text-[10px] font-bold ${restoreStep > i ? "bg-gray-900 text-white" : restoreStep === i+1 ? "border-2 border-gray-900 text-gray-900" : "bg-gray-100 text-gray-400"}`}>{i+1}</div>
                    {i < 3 && <div className={`flex-1 h-0.5 ${restoreStep > i+1 ? "bg-gray-900" : "bg-gray-100"}`} />}
                  </React.Fragment>
                ))}
              </div>

              {restoreStep === 1 && (
                <div className="space-y-3">
                  <p className="text-xs text-gray-600 font-medium">Pilih backup yang akan direstore:</p>
                  {BACKUP_HISTORY.slice(0,2).map((b, i) => (
                    <div key={i} className={`border rounded-xl p-3 cursor-pointer transition-all ${i === 0 ? "border-gray-900 bg-gray-50" : "border-gray-200 hover:border-gray-300"}`}>
                      <p className="text-xs font-semibold text-gray-800">{b.tanggal}</p>
                      <p className="text-[10px] text-gray-400">{b.jenis} • {b.ukuran}</p>
                    </div>
                  ))}
                </div>
              )}
              {restoreStep === 2 && (
                <div className="space-y-2">
                  <p className="text-xs font-medium text-gray-700 mb-2">Detail Backup Terpilih</p>
                  {[["Tanggal","3 Jul 2026, 02.00"],["Ukuran","48,6 MB"],["Isi","Data aplikasi, pengaturan, catatan, metadata"]].map(([k,v]) => (
                    <div key={k} className="flex justify-between py-1.5 border-b border-gray-50">
                      <span className="text-xs text-gray-500">{k}</span>
                      <span className="text-xs font-medium text-gray-800">{v}</span>
                    </div>
                  ))}
                </div>
              )}
              {restoreStep === 3 && (
                <div className="space-y-3">
                  <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
                    <AlertTriangle size={16} className="text-red-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold text-red-700">Peringatan</p>
                      <p className="text-xs text-red-600 mt-1">Data saat ini akan digantikan oleh isi backup. Proses ini tidak dapat dibatalkan setelah dimulai.</p>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">Password</label>
                    <input type="password" value={restorePw} onChange={e => setRestorePw(e.target.value)} placeholder="Masukkan password untuk melanjutkan"
                      className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none" />
                  </div>
                </div>
              )}
              {restoreStep === 4 && (
                <div className="space-y-3">
                  <div className="flex items-start gap-2">
                    <input type="checkbox" id="chkRestore" checked={restoreConfirm} onChange={e => setRestoreConfirm(e.target.checked)} className="mt-0.5" />
                    <label htmlFor="chkRestore" className="text-xs text-gray-700">Saya memahami bahwa data saat ini dapat diganti oleh isi backup.</label>
                  </div>
                </div>
              )}
            </div>
            <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
              <button onClick={() => restoreStep > 1 ? setRestoreStep(restoreStep-1) : setShowRestore(false)}
                className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                {restoreStep === 1 ? "Batal" : "Kembali"}
              </button>
              <button
                onClick={() => {
                  if (restoreStep < 4) setRestoreStep(restoreStep+1);
                  else { setShowRestore(false); setRestoreStep(1); setRestoreConfirm(false); showToast?.("Restore berhasil diselesaikan."); }
                }}
                disabled={restoreStep === 4 && !restoreConfirm}
                className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-50">
                {restoreStep === 4 ? "Mulai Restore" : "Lanjut"}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ── TAB IMPORT & EXPORT ───────────────────────────────────────────────────────
function ImportExportTab({ showToast }: { showToast?: (msg: string) => void }) {
  const [sertakanFile, setSertakanFile] = useState(true);
  const [exportFormat, setExportFormat] = useState("ZIP");
  const [exportModul, setExportModul]   = useState("Semua Data");
  const [preparing, setPreparing]       = useState(false);
  const [ready, setReady]               = useState(false);

  const createExport = () => {
    setPreparing(true); setReady(false);
    setTimeout(() => { setPreparing(false); setReady(true); }, 1500);
  };

  return (
    <div className="space-y-5">
      {/* Export */}
      <SectionCard title="Export Data FreeSpace">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Pilihan Modul</label>
            <select value={exportModul} onChange={e => setExportModul(e.target.value)}
              className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
              {["Semua Data","Keuangan","Produktivitas","Library","Karier","History","Pengaturan"].map(m => <option key={m}>{m}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Format</label>
            <div className="flex gap-2">
              {["ZIP","JSON","CSV","Excel"].map(f => (
                <button key={f} onClick={() => setExportFormat(f)}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors ${exportFormat === f ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"}`}>{f}</button>
              ))}
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between border-t border-gray-50 pt-3">
          <div className="flex items-center gap-2">
            <input type="checkbox" id="inclFile" checked={sertakanFile} onChange={e => setSertakanFile(e.target.checked)} />
            <label htmlFor="inclFile" className="text-xs text-gray-700">Sertakan file upload</label>
          </div>
          <button onClick={createExport} disabled={preparing}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors disabled:opacity-70">
            {preparing ? <><RefreshCw size={12} className="animate-spin" /> Mempersiapkan...</> : <><Upload size={12} /> Buat File Export</>}
          </button>
        </div>
        {ready && (
          <div className="bg-green-50 border border-green-200 rounded-xl p-3 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-green-700"><CheckCircle2 size={14} /> File export siap diunduh</div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-green-600">Tersedia 24 jam</span>
              <button onClick={() => showToast?.("Export berhasil diunduh.")}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-green-600 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-1">
                <Download size={11} /> Unduh
              </button>
            </div>
          </div>
        )}
      </SectionCard>

      {/* Import */}
      <SectionCard title="Import Data">
        <div className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center hover:border-gray-300 transition-colors cursor-pointer">
          <Upload size={24} className="text-gray-300 mx-auto mb-2" />
          <p className="text-sm text-gray-500 mb-1">Seret file ke sini atau <span className="text-gray-700 underline">pilih file</span></p>
          <p className="text-xs text-gray-400">CSV, Excel, JSON, atau ZIP backup FreeSpace</p>
        </div>
        <div className="border border-gray-100 rounded-xl p-3">
          <p className="text-xs font-semibold text-gray-700 mb-1.5">Alur Import</p>
          <div className="flex items-center gap-2 flex-wrap">
            {["Pilih File","Validasi","Mapping","Preview","Konfirmasi"].map((s, i) => (
              <React.Fragment key={s}>
                <span className="text-[10px] text-gray-500 bg-gray-50 px-2 py-1 rounded">{s}</span>
                {i < 4 && <span className="text-gray-300 text-xs">→</span>}
              </React.Fragment>
            ))}
          </div>
        </div>
      </SectionCard>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function KeamananDataPage({ topBar, showToast }: {
  topBar?: React.ReactNode;
  showToast?: (msg: string, type?: string) => void;
}) {
  const [tab, setTab] = useState<SecurityTab>("keamanan");

  const tabs: { id: SecurityTab; label: string; icon: React.ElementType }[] = [
    { id: "keamanan",       label: "Keamanan",        icon: Shield },
    { id: "sesi",           label: "Sesi Aktif",       icon: Monitor },
    { id: "backup",         label: "Backup & Restore", icon: Clock },
    { id: "import-export",  label: "Import & Export",  icon: Upload },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Keamanan & Data</h1>
          <p className="text-xs text-gray-500 mt-0.5">Kelola keamanan akun, sesi aktif, backup, serta data pribadi Anda.</p>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                tab === t.id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"
              }`}>
              <t.icon size={13} /> {t.label}
            </button>
          ))}
        </div>

        {tab === "keamanan"      && <KeamananTab      showToast={showToast} />}
        {tab === "sesi"          && <SesiAktifTab      showToast={showToast} />}
        {tab === "backup"        && <BackupTab         showToast={showToast} />}
        {tab === "import-export" && <ImportExportTab   showToast={showToast} />}
      </div>
    </main>
  );
}
