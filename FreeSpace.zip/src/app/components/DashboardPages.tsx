import React, { useState, useMemo } from "react";
import {
  BarChart2, TrendingUp, TrendingDown, AlertTriangle, CheckCircle2,
  Clock, Wrench, AlertCircle, Calendar, Lightbulb,
  Building, MapPin, Database, ChevronDown,
  CircleDollarSign, Package, Car, Cpu,
  RefreshCw, FileText, ArrowUpRight, XCircle, Download,
  Search, Filter, Info, ShieldCheck, Activity, Upload,
} from "lucide-react";
import { useDataStore, getOpnameStatus, getMaintenanceStatus, computeReplacementPriority } from "./DataStore";

// ── Formatting helpers ───────────────────────────────────────────────────────
const fmtNum = (n: number) => n.toLocaleString("id-ID");
const fmtPct = (n: number) => `${n.toFixed(1).replace(".", ",")}%`;
const fmtRupiahShort = (n: number) => {
  if (n >= 1_000_000_000) return `Rp ${(n / 1_000_000_000).toFixed(1).replace(".", ",")} M`;
  if (n >= 1_000_000)     return `Rp ${(n / 1_000_000).toFixed(1).replace(".", ",")} jt`;
  if (n >= 1_000)         return `Rp ${(n / 1_000).toFixed(0)} rb`;
  return `Rp ${n}`;
};

// ── Palette ───────────────────────────────────────────────────────────────────
const GREEN  = "#22C55E";
const AMBER  = "#F59E0B";
const RED    = "#EF4444";
const BLUE   = "#3B82F6";
const PURPLE = "#8B5CF6";
const P      = "#111827";

// ── Shared UI helpers ─────────────────────────────────────────────────────────

function SisBadge() {
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-blue-600 bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded whitespace-nowrap">
      <Database size={9} /> Dihitung Sistem
    </span>
  );
}

function RekSistem({
  level, children,
}: { level: "Tinggi" | "Sedang" | "Rendah"; children: React.ReactNode }) {
  const cfg = {
    Tinggi: { bg: "bg-green-50", border: "border-green-200", text: "text-green-700", pill: "bg-green-100 text-green-700 border-green-200" },
    Sedang: { bg: "bg-amber-50", border: "border-amber-200", text: "text-amber-700", pill: "bg-amber-100 text-amber-700 border-amber-200" },
    Rendah: { bg: "bg-gray-50",  border: "border-gray-200",  text: "text-gray-600",  pill: "bg-gray-100 text-gray-600 border-gray-200"  },
  }[level];
  return (
    <div className={`rounded-xl border ${cfg.border} ${cfg.bg} p-4 flex items-start gap-3`}>
      <Lightbulb size={15} className={`${cfg.text} shrink-0 mt-0.5`} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500">Rekomendasi Sistem</span>
          <span className={`text-[10px] font-bold border px-1.5 py-0.5 rounded ${cfg.pill}`}>Tingkat: {level}</span>
        </div>
        <p className={`text-sm leading-relaxed ${cfg.text}`}>{children}</p>
      </div>
    </div>
  );
}

function KpiStat({
  label, value, sub, badge = false, trend, up,
}: { label: string; value: string; sub?: string; badge?: boolean; trend?: string; up?: boolean }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
      <div className="flex items-start justify-between gap-2 mb-2">
        <span className="text-xs font-medium text-gray-500 leading-snug">{label}</span>
        {badge && <SisBadge />}
      </div>
      <p className="text-2xl font-bold text-gray-900 leading-tight">{value}</p>
      {sub && <p className="text-xs text-gray-400 mt-1">{sub}</p>}
      {trend && (
        <p className={`text-[11px] font-medium mt-1.5 flex items-center gap-0.5 ${up ? "text-green-500" : "text-red-500"}`}>
          {up ? <TrendingUp size={11} /> : <TrendingDown size={11} />} {trend}
        </p>
      )}
    </div>
  );
}

function HBarChart({ data, maxVal }: {
  data: { label: string; value: number; color?: string }[]; maxVal: number;
}) {
  return (
    <div className="space-y-2.5">
      {data.map((d, i) => {
        const pct = Math.round((d.value / maxVal) * 100);
        const colors = [BLUE, PURPLE, AMBER, GREEN, "#EC4899", "#06B6D4"];
        const c = d.color ?? colors[i % colors.length];
        return (
          <div key={d.label} className="flex items-center gap-3">
            <span className="w-40 text-xs text-gray-600 shrink-0 text-right truncate">{d.label}</span>
            <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: c }} />
            </div>
            <span className="w-14 text-xs font-semibold text-gray-700 shrink-0 text-right">{d.value.toLocaleString("id")}</span>
          </div>
        );
      })}
    </div>
  );
}

function EmptyState({ msg }: { msg?: string }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-10 flex flex-col items-center justify-center gap-3 shadow-sm min-h-[200px]">
      <BarChart2 size={28} className="text-gray-200" />
      <p className="text-sm text-gray-400">{msg ?? "Data belum tersedia"}</p>
    </div>
  );
}

function THead({ cols }: { cols: string[] }) {
  return (
    <thead>
      <tr className="border-b border-gray-100 bg-gray-50/50">
        {cols.map(c => (
          <th key={c} className="px-4 py-2.5 text-[11px] font-semibold text-gray-400 uppercase tracking-wider text-left">{c}</th>
        ))}
      </tr>
    </thead>
  );
}

function SoftBadge({ label, color }: { label: string; color: "green" | "amber" | "red" | "blue" | "purple" | "gray" }) {
  const cfg = {
    green:  "bg-green-50 text-green-700 border-green-200",
    amber:  "bg-amber-50 text-amber-700 border-amber-200",
    red:    "bg-red-50 text-red-700 border-red-200",
    blue:   "bg-blue-50 text-blue-700 border-blue-200",
    purple: "bg-purple-50 text-purple-700 border-purple-200",
    gray:   "bg-gray-100 text-gray-600 border-gray-200",
  }[color];
  return <span className={`text-[11px] font-semibold px-2 py-0.5 rounded border ${cfg}`}>{label}</span>;
}

// ── EKSEKUTIF ─────────────────────────────────────────────────────────────────

function arcPath(
  cx: number, cy: number, R: number, r: number,
  startAngle: number, endAngle: number
): string {
  const cos = Math.cos, sin = Math.sin;
  const x1 = cx + R * cos(startAngle), y1 = cy + R * sin(startAngle);
  const x2 = cx + R * cos(endAngle),   y2 = cy + R * sin(endAngle);
  const x3 = cx + r * cos(endAngle),   y3 = cy + r * sin(endAngle);
  const x4 = cx + r * cos(startAngle), y4 = cy + r * sin(startAngle);
  const large = (endAngle - startAngle) > Math.PI ? 1 : 0;
  return `M${x1},${y1} A${R},${R},0,${large},1,${x2},${y2} L${x3},${y3} A${r},${r},0,${large},0,${x4},${y4} Z`;
}

function DonutChart({ segments, total, centerLabel }: {
  segments: { value: number; color: string; label: string }[];
  total: number; centerLabel: string;
}) {
  const cx = 80, cy = 80, R = 65, r = 44;
  let angle = -Math.PI / 2;
  const paths = segments.map(seg => {
    const end = angle + (seg.value / total) * 2 * Math.PI;
    const d = arcPath(cx, cy, R, r, angle, end);
    angle = end;
    return { d, color: seg.color };
  });
  return (
    <svg viewBox="0 0 160 160" className="w-full h-full">
      {paths.map((p, i) => (
        <path key={i} d={p.d} fill={p.color} />
      ))}
      <circle cx={cx} cy={cy} r={r - 1} fill="white" />
      <text x={cx} y={cy - 7} textAnchor="middle" fontSize={20} fontWeight="bold" fill="#111827">
        {total.toLocaleString("id")}
      </text>
      <text x={cx} y={cy + 10} textAnchor="middle" fontSize={9} fill="#9CA3AF">{centerLabel}</text>
    </svg>
  );
}

const FILTER_SELECT_CLS = "text-xs border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 outline-none focus:ring-1 focus:ring-gray-300 cursor-pointer";

export function EksekutifPage({ topBar }: { topBar: React.ReactNode }) {
  const [tahun, setTahun]     = useState("2026");
  const [unit, setUnit]       = useState("semua");
  const [kampus, setKampus]   = useState("semua");
  const [kategori, setKategori] = useState("semua");

  const store = useDataStore();
  const totalAset    = store.computeTotalAssets();
  const totalBookVal = store.computeTotalBookValue();
  const totalAcqVal  = store.computeTotalAcquisitionValue();
  const opnameProg   = store.computeStockOpnameProgress();
  const overdueMaint = store.computeMaintenanceOverdue();
  const tanpaLokasi  = store.computeAssetsWithoutClearLocation();
  const kondisiBreakdown = store.computeKondisiBreakdown();
  const perluPerhatian = kondisiBreakdown.find(k => k.label === "Perlu Monitoring")?.value ?? 0;
  const prioritasGantiCount = store.computeReplacementCandidates().length;

  const kondisiSeg = [
    { label: "Baik",            value: kondisiBreakdown.find(k => k.label === "Baik")?.value ?? 0,            color: GREEN },
    { label: "Perlu Perbaikan", value: (kondisiBreakdown.find(k => k.label === "Perlu Monitoring")?.value ?? 0) + (kondisiBreakdown.find(k => k.label === "Rusak Ringan")?.value ?? 0), color: AMBER },
    { label: "Rusak Berat",     value: kondisiBreakdown.find(k => k.label === "Rusak Berat")?.value ?? 0,     color: RED   },
  ];

  // Compute opname progress per unit from store assets
  const opnameUnit = useMemo(() => {
    const unitMap = new Map<string, { total: number; done: number }>();
    store.assets.forEach(a => {
      const unit = (a.Nama_unit || "Tidak Diketahui").substring(0, 28);
      const cur = unitMap.get(unit) || { total: 0, done: 0 };
      cur.total++;
      if (getOpnameStatus(a) === "Terverifikasi") cur.done++;
      unitMap.set(unit, cur);
    });
    return Array.from(unitMap.entries())
      .map(([unit, { total, done }]) => ({
        unit,
        total,
        done,
        pct: total === 0 ? 0 : Math.round((done / total) * 100),
      }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 7);
  }, [store.assets]);

  // Top units by asset count from store
  const topUnitAset = store.computeTopUnits(6);

  // Top maintenance cost per unit from store
  const topMaintRaw = store.computeTopMaintenanceCost(5);
  const maintCost = useMemo(() => topMaintRaw.map(m => {
    const lastMaintDate = store.assets
      .filter(a => a.Nama_unit === m.unit && a.tanggal_maintenance_terakhir && a.tanggal_maintenance_terakhir !== "-")
      .reduce((latest, a) => (a.tanggal_maintenance_terakhir > latest ? a.tanggal_maintenance_terakhir : latest), "");
    const formatted = lastMaintDate
      ? new Date(lastMaintDate).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" })
      : "—";
    return { unit: m.unit, biaya: m.biaya, freq: m.freq, lastMaint: formatted };
  }), [topMaintRaw, store.assets]);

  // Replacement candidates from store
  const replacementCandidates = store.computeReplacementCandidates(6);
  const prioritasGanti = useMemo(() => replacementCandidates.map(a => {
    const sisa = parseInt(a._sisa_masa_manfaat_bulan || "0") || 0;
    const skor = Math.round(computeReplacementPriority(a));
    const sisaLabel = sisa <= 0
      ? `Lewat ${Math.abs(Math.ceil(-sisa / 12))} thn`
      : sisa <= 6 ? `< 6 bulan` : `${Math.floor(sisa / 12)} thn`;
    return {
      id: a.id,
      nama: a.Nama_Barang || a.id,
      kat: (a.TipeAset || "PM") as "PM" | "ATL" | "ATB" | "AL",
      sisaMasa: sisaLabel,
      skorRisiko: skor,
      rekomen: skor >= 80 ? "Ganti Segera" : "Rencanakan",
    };
  }), [replacementCandidates]);

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* ── Header + Filters ── */}
        <div className="flex items-start justify-between gap-6">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Dashboard Eksekutif</h1>
            <p className="text-sm text-gray-500 mt-0.5">Ringkasan strategis aset Sekolah Vokasi IPB.</p>
          </div>
          <div className="flex items-center gap-2 shrink-0 flex-wrap justify-end">
            <select value={tahun} onChange={e => setTahun(e.target.value)} className={FILTER_SELECT_CLS}>
              {["2024","2025","2026"].map(y => <option key={y}>{y}</option>)}
            </select>
            <select value={kampus} onChange={e => setKampus(e.target.value)} className={FILTER_SELECT_CLS}>
              <option value="semua">Semua Kampus</option>
              <option value="cilibende">Cilibende</option>
              <option value="gunung-gede">Gunung Gede</option>
              <option value="baranangsiang">Baranangsiang</option>
            </select>
            <select value={unit} onChange={e => setUnit(e.target.value)} className={FILTER_SELECT_CLS}>
              <option value="semua">Semua Unit</option>
              <option value="tif">Teknik Informatika</option>
              <option value="agb">Agribisnis</option>
              <option value="eko">Ekowisata</option>
            </select>
            <select value={kategori} onChange={e => setKategori(e.target.value)} className={FILTER_SELECT_CLS}>
              <option value="semua">Semua Kategori</option>
              <option value="pm">Peralatan & Mesin</option>
              <option value="atb">Aset Tak Berwujud</option>
              <option value="atl">Aset Tetap Lainnya</option>
              <option value="al">Alat Angkutan</option>
            </select>
            <button className="flex items-center gap-1.5 bg-gray-900 text-white border border-gray-800 px-3 py-1.5 rounded-lg text-xs hover:bg-black transition-colors">
              <Download size={12} /> Export
            </button>
          </div>
        </div>

        {/* ── KPI Cards — Row 1 ── */}
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Total Aset"             value={fmtNum(totalAset)}              sub="Seluruh kampus & kategori"       badge trend="+48 vs bulan lalu" up />
          <KpiStat label="Total Nilai Buku"        value={fmtRupiahShort(totalBookVal)}   sub="Setelah penyusutan berjalan"     badge trend="-2,1% vs semester lalu" />
          <KpiStat label="Total Nilai Perolehan"   value={fmtRupiahShort(totalAcqVal)}    sub="Harga perolehan kumulatif"       badge />
          <KpiStat label="Progress Stock Opname"   value={fmtPct(opnameProg.pct)}          sub={`${fmtNum(opnameProg.done)} dari ${fmtNum(opnameProg.total)} terverifikasi`} badge trend="+4,2% vs bulan lalu" up />
        </div>

        {/* ── KPI Cards — Row 2 ── */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-start justify-between gap-2 mb-2">
              <span className="text-xs font-medium text-gray-500 leading-snug">Aset Perlu Perhatian</span>
              <SisBadge />
            </div>
            <p className="text-2xl font-bold text-amber-600 leading-tight">{fmtNum(perluPerhatian)}</p>
            <p className="text-xs text-gray-400 mt-1">Kondisi perlu perbaikan</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-start justify-between gap-2 mb-2">
              <span className="text-xs font-medium text-gray-500 leading-snug">Maintenance Overdue</span>
              <SisBadge />
            </div>
            <p className="text-2xl font-bold text-red-600 leading-tight">{fmtNum(overdueMaint)}</p>
            <p className="text-xs text-gray-400 mt-1">Melewati jadwal maintenance</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-start justify-between gap-2 mb-2">
              <span className="text-xs font-medium text-gray-500 leading-snug">Aset Tanpa Lokasi Jelas</span>
              <SisBadge />
            </div>
            <p className="text-2xl font-bold text-purple-600 leading-tight">{fmtNum(tanpaLokasi)}</p>
            <p className="text-xs text-gray-400 mt-1">Status lokasi tidak terverifikasi</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-start justify-between gap-2 mb-2">
              <span className="text-xs font-medium text-gray-500 leading-snug">Prioritas Penggantian</span>
              <SisBadge />
            </div>
            <p className="text-2xl font-bold leading-tight" style={{ color: RED }}>{fmtNum(prioritasGantiCount)}</p>
            <p className="text-xs text-gray-400 mt-1">Skor risiko ≥ 70 — segera diganti</p>
          </div>
        </div>

        {/* ── Executive Summary Card ── */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-3">
            <Activity size={15} className="text-gray-500" />
            <span className="text-sm font-semibold text-gray-800">Ringkasan Eksekutif</span>
            <span className="ml-auto text-[10px] font-semibold text-blue-600 bg-blue-50 border border-blue-100 px-2 py-0.5 rounded">Dihitung Sistem</span>
          </div>
          {(() => {
            const topUnit = topUnitAset[0];
            const baikPct = totalAset > 0 ? ((kondisiBreakdown.find(k => k.label === "Baik")?.value ?? 0) / totalAset * 100) : 0;
            const lowestOpname = opnameUnit.length > 0 ? [...opnameUnit].sort((a, b) => a.pct - b.pct)[0] : null;
            return (
              <div className="grid grid-cols-3 gap-6">
                <div className="space-y-2.5">
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-gray-400 mt-1.5 shrink-0" />
                    <p className="text-xs text-gray-600 leading-relaxed">
                      Organisasi memiliki <span className="font-semibold text-gray-900">{fmtNum(totalAset)} aset</span> dengan total nilai perolehan <span className="font-semibold text-gray-900">{fmtRupiahShort(totalAcqVal)}</span> dan nilai buku berjalan <span className="font-semibold text-gray-900">{fmtRupiahShort(totalBookVal)}</span>.
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-400 mt-1.5 shrink-0" />
                    <p className="text-xs text-gray-600 leading-relaxed">
                      Kondisi aset dominan: <span className="font-semibold text-green-700">Baik ({baikPct.toFixed(1).replace(".", ",")}%)</span>. Unit dengan aset terbanyak: <span className="font-semibold text-gray-900">{topUnit?.unit ?? "—"}</span> ({fmtNum(topUnit?.value ?? 0)} unit).
                    </p>
                  </div>
                </div>
                <div className="space-y-2.5">
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                    <p className="text-xs text-gray-600 leading-relaxed">
                      Progress stock opname saat ini <span className="font-semibold text-amber-700">{fmtPct(opnameProg.pct)}</span>.{lowestOpname ? <> Unit dengan progress terendah: <span className="font-semibold text-gray-900">{lowestOpname.unit} ({lowestOpname.pct}%)</span>.</> : null}
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 shrink-0" />
                    <p className="text-xs text-gray-600 leading-relaxed">
                      Terdapat <span className="font-semibold text-red-700">{fmtNum(overdueMaint)} aset overdue maintenance</span> dan <span className="font-semibold text-red-700">{fmtNum(prioritasGantiCount)} aset prioritas penggantian</span> berdasarkan skor risiko sistem.
                    </p>
                  </div>
                </div>
                <div className="space-y-2.5">
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5 shrink-0" />
                    <p className="text-xs text-gray-600 leading-relaxed">
                      <span className="font-semibold text-gray-900">{fmtNum(tanpaLokasi)} aset</span> belum memiliki lokasi terverifikasi — menghambat akurasi audit dan laporan BMN.
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5 shrink-0" />
                    <p className="text-xs text-gray-600 leading-relaxed">
                      Rekomendasi prioritas: percepat opname unit dengan progress &lt;60%, verifikasi lokasi aset, dan rencanakan anggaran penggantian aset risiko tinggi Q3 2026.
                    </p>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>

        {/* ── Charts Row ── */}
        <div className="grid grid-cols-3 gap-5">

          {/* Donut — Kondisi Aset */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-gray-800">Kondisi Aset</span>
              <SisBadge />
            </div>
            <div className="flex items-center gap-4">
              <div className="w-[130px] h-[130px] shrink-0">
                <DonutChart segments={kondisiSeg} total={totalAset} centerLabel="Total Aset" />
              </div>
              <div className="flex-1 space-y-2.5">
                {kondisiSeg.map(k => (
                  <div key={k.label} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: k.color }} />
                    <span className="text-[11px] text-gray-500 flex-1">{k.label}</span>
                    <span className="text-[11px] font-bold text-gray-800">{k.value.toLocaleString("id")}</span>
                    <span className="text-[10px] text-gray-400 w-10 text-right">
                      {(totalAset > 0 ? (k.value / totalAset) * 100 : 0).toFixed(1)}%
                    </span>
                  </div>
                ))}
                <div className="pt-2 border-t border-gray-100">
                  <p className="text-[10px] text-gray-400">Data per 1 Juni 2026</p>
                </div>
              </div>
            </div>
          </div>

          {/* Stock Opname Progress per Unit */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-gray-800">Progress Opname per Unit</span>
              <SisBadge />
            </div>
            <div className="space-y-2.5">
              {opnameUnit.map(u => {
                const c = u.pct >= 80 ? GREEN : u.pct >= 60 ? AMBER : RED;
                return (
                  <div key={u.unit} className="flex items-center gap-2.5">
                    <span className="text-[11px] text-gray-600 w-36 shrink-0 truncate">{u.unit}</span>
                    <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all" style={{ width: `${u.pct}%`, backgroundColor: c }} />
                    </div>
                    <span className="text-[11px] font-semibold w-7 text-right shrink-0" style={{ color: c }}>{u.pct}%</span>
                  </div>
                );
              })}
            </div>
            <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between">
              <span className="text-[10px] text-gray-400">Total: {fmtNum(opnameProg.done)} / {fmtNum(opnameProg.total)} terverifikasi</span>
              <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full">{fmtPct(opnameProg.pct)}</span>
            </div>
          </div>

          {/* Top Unit dengan Aset Terbanyak */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-gray-800">Top Unit — Jumlah Aset</span>
              <SisBadge />
            </div>
            <HBarChart data={topUnitAset.map(d => ({ label: d.unit, value: d.value }))} maxVal={Math.max(1, ...topUnitAset.map(d => d.value))} />
            <div className="mt-3 pt-3 border-t border-gray-100">
              <p className="text-[10px] text-gray-400">6 dari {">"}20 unit terdaftar ditampilkan</p>
            </div>
          </div>
        </div>

        {/* ── Tables Row ── */}
        <div className="grid grid-cols-2 gap-5">

          {/* Top Biaya Maintenance */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-gray-800">Top Biaya Maintenance</span>
              <SisBadge />
            </div>
            <table className="w-full text-left">
              <THead cols={["Unit", "Total Biaya", "Frek.", "Terakhir"]} />
              <tbody className="divide-y divide-gray-50">
                {maintCost.map((r, i) => (
                  <tr key={r.unit} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-gray-400 w-4">#{i + 1}</span>
                        <span className="text-xs font-medium text-gray-800">{r.unit}</span>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-xs font-semibold text-gray-800">
                      Rp {(r.biaya / 1_000_000).toFixed(1)} jt
                    </td>
                    <td className="px-4 py-2.5 text-xs text-gray-500">{r.freq}x</td>
                    <td className="px-4 py-2.5 text-xs text-gray-400">{r.lastMaint}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Aset Prioritas Penggantian */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-gray-800">Aset Prioritas Penggantian</span>
              <SisBadge />
            </div>
            <table className="w-full text-left">
              <THead cols={["Aset", "Sisa Masa", "Skor", "Rekomendasi"]} />
              <tbody className="divide-y divide-gray-50">
                {prioritasGanti.map(r => (
                  <tr key={r.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-4 py-2.5">
                      <div>
                        <p className="text-xs font-medium text-gray-800 truncate max-w-[160px]">{r.nama}</p>
                        <p className="text-[10px] font-mono text-gray-400 mt-0.5">{r.id} · {r.kat}</p>
                      </div>
                    </td>
                    <td className="px-4 py-2.5">
                      <span className="text-[10px] font-semibold text-red-600 bg-red-50 border border-red-100 px-1.5 py-0.5 rounded">
                        {r.sisaMasa}
                      </span>
                    </td>
                    <td className="px-4 py-2.5">
                      <span className="text-xs font-bold" style={{ color: r.skorRisiko >= 85 ? RED : r.skorRisiko >= 75 ? AMBER : GREEN }}>
                        {r.skorRisiko}
                      </span>
                    </td>
                    <td className="px-4 py-2.5">
                      <SoftBadge
                        label={r.rekomen}
                        color={r.rekomen === "Ganti Segera" ? "red" : "amber"}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="mt-2 pt-2 border-t border-gray-100">
              <p className="text-[10px] text-gray-400">Skor risiko dihitung dari: masa manfaat, kondisi fisik, dan frekuensi kerusakan.</p>
            </div>
          </div>
        </div>

        {/* ── Rekomendasi Sistem ── */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-gray-800">Rekomendasi Sistem</span>
            <span className="text-[10px] font-semibold text-amber-600 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">Rekomendasi Sistem</span>
          </div>
          <RekSistem level="Tinggi">
            Verifikasi {fmtNum(tanpaLokasi)} aset tanpa lokasi jelas sesegera mungkin. Data lokasi yang tidak valid menghambat laporan BMN dan audit tahunan. Targetkan penyelesaian sebelum 30 Juni 2026.
          </RekSistem>
          <RekSistem level="Tinggi">
            Prioritaskan maintenance {fmtNum(overdueMaint)} aset yang melewati jadwal. Berdasarkan historis sistem, keterlambatan maintenance rata-rata meningkatkan biaya perbaikan sebesar 34% dan risiko kerusakan total.
          </RekSistem>
          {opnameUnit.filter(u => u.pct < 60).length > 0 && (
            <RekSistem level="Sedang">
              Lakukan opname ulang untuk {opnameUnit.filter(u => u.pct < 60).length} unit dengan progress di bawah 60%{opnameUnit.filter(u => u.pct < 60).slice(0, 2).map(u => ` — ${u.unit} (${u.pct}%)`).join(", ")}. Jadwalkan sebelum tutup semester.
            </RekSistem>
          )}
          <RekSistem level="Sedang">
            Evaluasi {fmtNum(prioritasGantiCount)} aset yang melewati masa manfaat dan memiliki skor risiko ≥ 70. Siapkan usulan penggantian dan anggaran di RKPT Q3 2026 berdasarkan data historis pengadaan.
          </RekSistem>
        </div>

      </div>
    </main>
  );
}

// ── DASH SUB PAGE FULL ─────────────────────────────────────────────────────────

export function DashSubPageFull({ page, title, tabs, topBar }: {
  page: string; title: string; tabs: string[]; topBar: React.ReactNode;
}) {
  const [activeTab, setActiveTab] = useState(tabs[0]);
  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">
        <h1 className="text-xl font-bold text-gray-900">{title}</h1>
        <div className="flex w-full bg-gray-100 p-1 rounded-lg border border-gray-200/60">
          {tabs.map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-all ${activeTab === tab ? "bg-white text-gray-900 shadow-sm ring-1 ring-gray-200/50" : "text-gray-500 hover:text-gray-700 hover:bg-gray-200/50"}`}>
              {tab}
            </button>
          ))}
        </div>
        <DashTabContent page={page} tab={activeTab} />
      </div>
    </main>
  );
}

function DashTabContent({ page, tab }: { page: string; tab: string }) {
  if (page === "dash-analitik")    return <AnalitikContent    tab={tab} />;
  if (page === "dash-keuangan")    return <KeuanganContent    tab={tab} />;
  if (page === "dash-kondisi")     return <KondisiContent     tab={tab} />;
  if (page === "dash-monitoring")  return <MonitoringContent  tab={tab} />;
  if (page === "dash-utilisasi")   return <UtilisasiContent   tab={tab} />;
  if (page === "dash-pengadaan")   return <PengadaanDashContent  tab={tab} />;
  if (page === "dash-maintenance") return <MaintenanceDashContent tab={tab} />;
  if (page === "kampus-cilibende" || page === "kampus-gunung-gede") {
    return <LokasiKampusContent page={page} tab={tab} />;
  }
  return null;
}

// ── ANALITIK ──────────────────────────────────────────────────────────────────

function PolaKerusakanLineChart() {
  const data = [
    { bulan: "Jan", pm: 12, atl: 5, al: 3 },
    { bulan: "Feb", pm: 8,  atl: 7, al: 2 },
    { bulan: "Mar", pm: 15, atl: 4, al: 5 },
    { bulan: "Apr", pm: 11, atl: 9, al: 4 },
    { bulan: "Mei", pm: 18, atl: 6, al: 7 },
    { bulan: "Jun", pm: 9,  atl: 3, al: 2 },
  ];
  const VW = 500, VH = 145, ml = 32, mr = 16, mt = 14, mb = 28;
  const cW = VW - ml - mr, cH = VH - mt - mb;
  const maxY = 22;
  const n = data.length;
  const xOf = (i: number) => ml + (i / (n - 1)) * cW;
  const yOf = (v: number) => mt + cH - Math.min(v / maxY, 1) * cH;
  const lineStr = (key: "pm" | "atl" | "al") =>
    data.map((d, i) => `${xOf(i).toFixed(1)},${yOf(d[key]).toFixed(1)}`).join(" ");
  const series: { key: "pm" | "atl" | "al"; color: string; label: string }[] = [
    { key: "pm",  color: BLUE,   label: "PM" },
    { key: "atl", color: PURPLE, label: "ATL" },
    { key: "al",  color: AMBER,  label: "AL" },
  ];
  const gridVals = [0, 5, 10, 15, 20];
  return (
    <svg viewBox={`0 0 ${VW} ${VH}`} className="w-full" style={{ height: VH }}>
      {gridVals.map(v => (
        <g key={v}>
          <line x1={ml} y1={yOf(v)} x2={VW - mr} y2={yOf(v)} stroke="#F3F4F6" strokeWidth={1} />
          <text x={ml - 5} y={yOf(v) + 3} textAnchor="end" fontSize={8} fill="#D1D5DB">{v}</text>
        </g>
      ))}
      <line x1={ml} y1={mt + cH} x2={VW - mr} y2={mt + cH} stroke="#E5E7EB" strokeWidth={1} />
      {data.map((d, i) => (
        <text key={d.bulan} x={xOf(i)} y={VH - 6} textAnchor="middle" fontSize={9} fill="#9CA3AF">{d.bulan}</text>
      ))}
      {series.map(s => (
        <polyline key={s.key} points={lineStr(s.key)} fill="none" stroke={s.color}
          strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
      ))}
      {series.map(s =>
        data.map((d, i) => (
          <circle key={`${s.key}-${i}`} cx={xOf(i)} cy={yOf(d[s.key])}
            r={3} fill="white" stroke={s.color} strokeWidth={1.5} />
        ))
      )}
    </svg>
  );
}

// ── ANALITIK SUB-COMPONENTS ───────────────────────────────────────────────────

function PrediksiPerbaikanTab() {
  const store = useDataStore();
  const [filterRisiko, setFilterRisiko] = useState("semua");
  const [filterUnit, setFilterUnit] = useState("semua");

  const asetPrioritas = useMemo(() => {
    return store.computeReplacementCandidates(10).map((a) => {
      const skor = computeReplacementPriority(a);
      const sisa = parseInt(a._sisa_masa_manfaat_bulan) || 0;
      const freq = parseInt(a.total_frekuensi_maintenance) || 0;
      const reasons: string[] = [];
      if (sisa <= 0) reasons.push("Sisa masa manfaat habis");
      if (freq >= 3) reasons.push("Frekuensi kerusakan tinggi");
      if ((a.Kondisi || "").includes("Rusak")) reasons.push("Kondisi rusak");
      const alasan = reasons.length ? reasons.join(", ") : "Indikator risiko gabungan";
      const rekomendasi = skor >= 70 ? "Penggantian segera" : skor >= 50 ? "Maintenance darurat" : "Servis berkala";
      const risiko = skor >= 70 ? "Tinggi" : skor >= 50 ? "Sedang" : "Rendah";
      return {
        id: a.id,
        nama: a.Nama_Barang,
        unit: a.Nama_unit,
        lastMaint: a.tanggal_maintenance_terakhir || "-",
        nextMaint: a.jadwal_maintenance_berikutnya || "-",
        freq,
        skor,
        alasan,
        rekomendasi,
        risiko,
      };
    });
  }, [store]);

  const risikoTinggiCount = useMemo(
    () => store.assets.filter((a) => computeReplacementPriority(a) >= 70).length,
    [store.assets],
  );
  const overdueCount = store.computeMaintenanceOverdue();
  const dueSoonCount = useMemo(
    () => store.assets.filter((a) => getMaintenanceStatus(a) === "Due Soon").length,
    [store.assets],
  );
  const estimasiBiaya = useMemo(() => {
    const total = store.assets.reduce((s, a) => s + (parseInt(a._total_biaya_maintenance) || 0), 0);
    return Math.round(total * 0.25);
  }, [store.assets]);
  const confidence = Math.min(95, 60 + Math.floor(store.assets.length / 20));

  const { forecastMonths, forecastData } = useMemo(() => {
    const base = new Date("2026-06-01");
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
    const months: string[] = [];
    const data: number[] = [];
    for (let i = 1; i <= 6; i += 1) {
      const d = new Date(base.getFullYear(), base.getMonth() + i, 1);
      const y = d.getFullYear();
      const m = d.getMonth();
      months.push(`${monthNames[m]} ${y}`);
      const count = store.assets.filter((a) => {
        const sched = a.jadwal_maintenance_berikutnya;
        let inMonth = false;
        if (sched && sched !== "-") {
          const sd = new Date(sched);
          if (!isNaN(sd.getTime()) && sd.getFullYear() === y && sd.getMonth() === m) inMonth = true;
        }
        const sisa = parseInt(a._sisa_masa_manfaat_bulan) || -1;
        if (sisa === i) inMonth = true;
        return inMonth;
      }).length;
      data.push(Math.min(36, count));
    }
    return { forecastMonths: months, forecastData: data };
  }, [store.assets]);

  const unitOptions = useMemo(
    () => Array.from(new Set(store.assets.map((a) => a.Nama_unit))).filter(Boolean),
    [store.assets],
  );
  const VW = 560, VH = 150, ml = 36, mr = 16, mt = 16, mb = 30;
  const cW = VW - ml - mr, cH = VH - mt - mb;
  const maxFVal = 36, nF = forecastData.length;
  const xF = (i: number) => ml + (i / (nF - 1)) * cW;
  const yF = (v: number) => mt + cH - Math.min(v / maxFVal, 1) * cH;
  const fLine = forecastData.map((d, i) => `${xF(i).toFixed(1)},${yF(d).toFixed(1)}`).join(" ");
  const fArea = [`${xF(0).toFixed(1)},${(mt + cH).toFixed(1)}`, ...forecastData.map((d, i) => `${xF(i).toFixed(1)},${yF(d).toFixed(1)}`), `${xF(nF - 1).toFixed(1)},${(mt + cH).toFixed(1)}`].join(" ");

  const rBadge = (r: string) => (r === "Tinggi" ? "red" : r === "Sedang" ? "amber" : "gray") as "red" | "amber" | "gray";
  const filtered = asetPrioritas
    .filter(r => filterRisiko === "semua" || r.risiko === filterRisiko)
    .filter(r => filterUnit  === "semua" || r.unit  === filterUnit);

  return (
    <>
      <div className="grid grid-cols-5 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Aset Berisiko Tinggi</span><SisBadge /></div>
          <p className="text-2xl font-bold text-red-600 leading-tight">{risikoTinggiCount}</p>
          <p className="text-xs text-gray-400 mt-1">Skor risiko ≥ 70</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Maintenance Overdue</span><SisBadge /></div>
          <p className="text-2xl font-bold text-amber-600 leading-tight">{overdueCount}</p>
          <p className="text-xs text-gray-400 mt-1">Melewati jadwal yang ditetapkan</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Jadwal Maintenance 30 Hari</span><SisBadge /></div>
          <p className="text-2xl font-bold text-blue-600 leading-tight">{dueSoonCount}</p>
          <p className="text-xs text-gray-400 mt-1">Juli 2026 — berdasarkan sistem</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Estimasi Biaya Perbaikan</span><SisBadge /></div>
          <p className="text-2xl font-bold text-gray-900 leading-tight">{fmtRupiahShort(estimasiBiaya)}</p>
          <p className="text-xs text-gray-400 mt-1">Estimasi 90 hari ke depan</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Confidence Prediksi</span><SisBadge /></div>
          <p className="text-2xl font-bold text-green-600 leading-tight">{confidence}%</p>
          <p className="text-xs text-gray-400 mt-1">Berdasarkan 6 faktor sistem</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-gray-800">Prediksi Risiko Perbaikan Aset</span>
            <span className="text-[10px] text-amber-600 bg-amber-50 border border-amber-100 px-1.5 py-0.5 rounded font-semibold">Prediksi Awal</span>
            <span className="text-[10px] text-blue-600 bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded font-semibold">Dihitung Sistem</span>
          </div>
          <span className="text-[10px] text-gray-400">Confidence: Tinggi</span>
        </div>
        <p className="text-xs text-gray-400 mb-3">Estimasi jumlah aset berisiko tinggi per bulan — bukan kepastian, merupakan hasil prediksi model</p>
        <svg viewBox={`0 0 ${VW} ${VH}`} className="w-full" style={{ height: VH }}>
          {[0, 10, 20, 30].map(v => (
            <g key={v}>
              <line x1={ml} y1={yF(v)} x2={VW - mr} y2={yF(v)} stroke="#F3F4F6" strokeWidth={1} />
              <text x={ml - 5} y={yF(v) + 3} textAnchor="end" fontSize={8} fill="#D1D5DB">{v}</text>
            </g>
          ))}
          <line x1={ml} y1={mt + cH} x2={VW - mr} y2={mt + cH} stroke="#E5E7EB" strokeWidth={1} />
          {forecastMonths.map((m, i) => (
            <text key={m} x={xF(i)} y={VH - 6} textAnchor="middle" fontSize={8} fill="#9CA3AF">{m}</text>
          ))}
          <polygon points={fArea} fill="rgba(239,68,68,0.08)" />
          <polyline points={fLine} fill="none" stroke="#EF4444" strokeWidth={2} strokeDasharray="5 3" strokeLinejoin="round" strokeLinecap="round" />
          {forecastData.map((d, i) => (
            <g key={i}>
              <circle cx={xF(i)} cy={yF(d)} r={3.5} fill="white" stroke="#EF4444" strokeWidth={1.5} />
              <text x={xF(i)} y={yF(d) - 6} textAnchor="middle" fontSize={8} fill="#EF4444" fontWeight="600">{d}</text>
            </g>
          ))}
        </svg>
        <div className="flex items-center gap-1 text-[10px] text-gray-400 mt-1">
          <Info size={10} /> Garis putus-putus = prediksi; rentang kepercayaan ±15%
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 flex-wrap gap-2">
          <span className="text-sm font-semibold text-gray-800">Aset Prioritas Perbaikan</span>
          <div className="flex items-center gap-2 flex-wrap">
            <select value={filterRisiko} onChange={e => setFilterRisiko(e.target.value)} className={FILTER_SELECT_CLS}>
              <option value="semua">Semua Risiko</option>
              <option value="Tinggi">Risiko Tinggi</option>
              <option value="Sedang">Risiko Sedang</option>
              <option value="Rendah">Risiko Rendah</option>
            </select>
            <select value={filterUnit} onChange={e => setFilterUnit(e.target.value)} className={FILTER_SELECT_CLS}>
              <option value="semua">Semua Unit</option>
              {unitOptions.map((u) => (
                <option key={u} value={u}>{u}</option>
              ))}
            </select>
            <SisBadge />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[1100px]">
            <THead cols={["Kode Aset", "Nama Aset", "Unit", "Maint. Terakhir", "Jadwal Berikutnya", "Frek. Kerusakan", "Skor Risiko", "Alasan Risiko", "Rekomendasi"]} />
            <tbody className="divide-y divide-gray-50">
              {filtered.map(r => (
                <tr key={r.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-4 py-3 text-xs font-mono text-gray-400">{r.id}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800 min-w-[150px]">{r.nama}</td>
                  <td className="px-4 py-3 text-xs text-gray-500 min-w-[110px]">{r.unit}</td>
                  <td className="px-4 py-3 text-xs text-gray-500">{r.lastMaint}</td>
                  <td className="px-4 py-3 text-xs font-medium text-gray-700">{r.nextMaint}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-bold text-gray-900">{r.freq}×</span>
                      <div className="w-10 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${(r.freq / 8) * 100}%`, backgroundColor: r.freq >= 6 ? "#EF4444" : r.freq >= 4 ? "#F59E0B" : "#22C55E" }} />
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      <span className={`text-sm font-bold ${r.skor >= 70 ? "text-red-600" : r.skor >= 50 ? "text-amber-600" : "text-gray-600"}`}>{r.skor}</span>
                      <div className="w-12 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${r.skor}%`, backgroundColor: r.skor >= 70 ? "#EF4444" : r.skor >= 50 ? "#F59E0B" : "#22C55E" }} />
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-500 max-w-[220px] leading-relaxed">{r.alasan}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.rekomendasi} color={rBadge(r.risiko)} /></td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={9} className="px-4 py-8 text-center text-sm text-gray-400">Tidak ada data yang cocok dengan filter yang dipilih</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-gray-800">Logika Prediksi</span>
            <span className="text-[10px] text-blue-600 bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded font-semibold">Dihitung Sistem</span>
            <span className="text-[10px] text-amber-600 bg-amber-50 border border-amber-100 px-1.5 py-0.5 rounded font-semibold">Prediksi Awal</span>
          </div>
          <span className="text-[10px] text-gray-400">Confidence: Tinggi — 6 faktor aktif</span>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Sisa Masa Manfaat",              desc: "Aset dengan sisa < 1 tahun mendapat bobot risiko lebih tinggi. Lewat masa manfaat = skor +20.",                icon: "📅", weight: "Bobot: 25%" },
            { label: "Frekuensi Maintenance",          desc: "Aset dengan ≥3 maintenance dalam 12 bulan terakhir diklasifikasi berisiko sedang–tinggi.",                    icon: "🔧", weight: "Bobot: 20%" },
            { label: "Biaya Maintenance",              desc: "Jika biaya kumulatif > 40% nilai buku, sistem merekomendasikan penggantian daripada perbaikan.",               icon: "💰", weight: "Bobot: 20%" },
            { label: "Downtime Terakhir",              desc: "Downtime > 8 jam dalam satu insiden meningkatkan skor risiko secara signifikan.",                              icon: "⏱️", weight: "Bobot: 15%" },
            { label: "Tingkat Kerusakan Terakhir",     desc: "Kerusakan berat dalam opname atau maintenance terakhir menaikkan prioritas prediksi.",                         icon: "⚠️", weight: "Bobot: 12%" },
            { label: "Kondisi Fisik Opname Terakhir",  desc: "Opname terbaru dengan hasil Rusak Ringan/Berat memberikan sinyal awal perlunya perbaikan.",                    icon: "📋", weight: "Bobot: 8%"  },
          ].map(f => (
            <div key={f.label} className="border border-gray-100 rounded-lg p-3 bg-gray-50/50">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-base">{f.icon}</span>
                <span className="text-xs font-semibold text-gray-800">{f.label}</span>
              </div>
              <p className="text-[11px] text-gray-500 leading-relaxed">{f.desc}</p>
              <span className="inline-block mt-2 text-[10px] font-bold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100">{f.weight}</span>
            </div>
          ))}
        </div>
        <div className="mt-3 flex items-center gap-1.5 text-[11px] text-gray-400 bg-gray-50 px-3 py-2 rounded-lg border border-gray-100">
          <Info size={11} /> Prediksi ini bersifat indikatif dan tidak menggantikan penilaian teknis lapangan. Keputusan akhir tetap pada penanggung jawab aset.
        </div>
      </div>

      <RekSistem level="Tinggi">PM-001 (Laptop ASUS ROG G513) dan PM-003 (Server Dell PowerEdge R740) memiliki skor risiko tertinggi (91 dan 88). Kedua aset melewati masa manfaat dengan frekuensi kerusakan tinggi. Direkomendasikan penanganan paling lambat Juli 2026. Confidence: Tinggi.</RekSistem>
      <RekSistem level="Sedang">18 aset dijadwalkan maintenance dalam 30 hari ke depan. Suku cadang yang kemungkinan dibutuhkan: baterai UPS, lampu proyektor, dan filter AC. Pemesanan lebih awal disarankan untuk menghindari downtime. Confidence: Sedang.</RekSistem>
    </>
  );
}

function PengelolaanAsetTab() {
  const store = useDataStore();
  const tanpaPIC = store.computeAssetsWithoutPIC();
  const tanpaLoc = store.computeAssetsWithoutClearLocation();
  const unitData = [
    { unit: "Lab Komputer",         jumlah: 487, nilaiBuku: 4250, idle: 12, rusak: 23, opname: 93, biayaMaint: 124500000, skor: 88 },
    { unit: "Teknik Informatika",   jumlah: 612, nilaiBuku: 5840, idle: 28, rusak: 41, opname: 74, biayaMaint:  98200000, skor: 71 },
    { unit: "Agribisnis",           jumlah: 541, nilaiBuku: 3120, idle: 35, rusak: 28, opname: 82, biayaMaint:  76800000, skor: 76 },
    { unit: "Administrasi Umum",    jumlah: 341, nilaiBuku: 2180, idle: 18, rusak: 15, opname: 78, biayaMaint:  54100000, skor: 79 },
    { unit: "Ekowisata",            jumlah: 187, nilaiBuku: 1240, idle: 42, rusak: 18, opname: 55, biayaMaint:  23400000, skor: 48 },
    { unit: "Paramedik Veteriner",  jumlah: 156, nilaiBuku:  980, idle: 31, rusak: 12, opname: 47, biayaMaint:  18700000, skor: 52 },
    { unit: "Manajemen Agribisnis", jumlah: 421, nilaiBuku: 2640, idle: 22, rusak: 19, opname: 86, biayaMaint:  41200000, skor: 83 },
  ];

  const effColor = (s: number) => s >= 80 ? "#22C55E" : s >= 60 ? "#F59E0B" : "#EF4444";
  const effBadge = (s: number): "green" | "amber" | "red" => s >= 80 ? "green" : s >= 60 ? "amber" : "red";
  const unitPalingEfisien  = unitData.reduce((a, b) => a.skor > b.skor ? a : b);
  const unitPerluPerhatian = unitData.reduce((a, b) => a.skor < b.skor ? a : b);
  const totalIdle = unitData.reduce((sum, u) => sum + u.idle, 0);

  return (
    <>
      <div className="grid grid-cols-5 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Unit Paling Efisien</span><SisBadge /></div>
          <p className="text-base font-bold text-green-600 leading-tight">{unitPalingEfisien.unit}</p>
          <p className="text-xs text-gray-400 mt-1">Skor efisiensi: {unitPalingEfisien.skor}/100</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Unit Perlu Perhatian</span><SisBadge /></div>
          <p className="text-base font-bold text-red-600 leading-tight">{unitPerluPerhatian.unit}</p>
          <p className="text-xs text-gray-400 mt-1">Skor efisiensi: {unitPerluPerhatian.skor}/100</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Aset Idle</span><SisBadge /></div>
          <p className="text-2xl font-bold text-amber-600 leading-tight">{totalIdle}</p>
          <p className="text-xs text-gray-400 mt-1">Tidak digunakan aktif</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Aset Tanpa PIC</span><SisBadge /></div>
          <p className="text-2xl font-bold text-purple-600 leading-tight">{fmtNum(tanpaPIC)}</p>
          <p className="text-xs text-gray-400 mt-1">Belum ada penanggung jawab</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Aset Tanpa Lokasi Jelas</span><SisBadge /></div>
          <p className="text-2xl font-bold text-gray-700 leading-tight">{fmtNum(tanpaLoc)}</p>
          <p className="text-xs text-gray-400 mt-1">Status lokasi tidak terverifikasi</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold text-gray-800">Efisiensi Pengelolaan Aset per Unit</span>
          <SisBadge />
        </div>
        <p className="text-xs text-gray-400 mb-4">Skor dihitung dari: progress opname, rasio aset idle, kondisi aset rusak, kelengkapan PIC, dan biaya maintenance relatif</p>
        <div className="space-y-4">
          {unitData.map(u => {
            const idleRatio  = Math.min((u.idle  / u.jumlah) * 100, 100);
            const rusakRatio = Math.min((u.rusak / u.jumlah) * 100, 100);
            return (
              <div key={u.unit} className="flex items-center gap-3">
                <span className="w-36 text-xs text-gray-600 shrink-0 text-right truncate">{u.unit}</span>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400 w-16 shrink-0">Opname</span>
                    <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-blue-400" style={{ width: `${u.opname}%` }} />
                    </div>
                    <span className="text-[10px] font-medium text-gray-600 w-8 text-right">{u.opname}%</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400 w-16 shrink-0">Idle</span>
                    <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-amber-400" style={{ width: `${idleRatio}%` }} />
                    </div>
                    <span className="text-[10px] font-medium text-gray-600 w-8 text-right">{u.idle}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400 w-16 shrink-0">Rusak</span>
                    <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-red-400" style={{ width: `${rusakRatio}%` }} />
                    </div>
                    <span className="text-[10px] font-medium text-gray-600 w-8 text-right">{u.rusak}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0 w-16 justify-end">
                  <span className="text-sm font-bold" style={{ color: effColor(u.skor) }}>{u.skor}</span>
                  <span className="text-[10px] text-gray-400">/100</span>
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex items-center gap-4 mt-4 pt-3 border-t border-gray-100">
          {[["Opname Progress", "#60A5FA"], ["Aset Idle", "#FBBF24"], ["Aset Rusak", "#F87171"]].map(([l, c]) => (
            <span key={l} className="flex items-center gap-1.5 text-[10px] text-gray-500">
              <span className="inline-block w-3 h-1.5 rounded-sm" style={{ backgroundColor: c }} />{l}
            </span>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <span className="text-sm font-semibold text-gray-800">Evaluasi Pengelolaan Unit</span>
          <SisBadge />
        </div>
        <table className="w-full text-left">
          <THead cols={["Unit", "Jml. Aset", "Nilai Buku (jt)", "Aset Idle", "Aset Rusak", "Progress Opname", "Biaya Maint.", "Skor Efisiensi"]} />
          <tbody className="divide-y divide-gray-50">
            {unitData.map(u => (
              <tr key={u.unit} className="hover:bg-gray-50/50 transition-colors">
                <td className="px-4 py-3 text-sm font-medium text-gray-800">{u.unit}</td>
                <td className="px-4 py-3 text-sm text-gray-700">{u.jumlah.toLocaleString("id")}</td>
                <td className="px-4 py-3 text-sm text-gray-700">{u.nilaiBuku.toLocaleString("id")}</td>
                <td className="px-4 py-3 text-sm font-medium text-amber-600">{u.idle}</td>
                <td className="px-4 py-3 text-sm font-medium text-red-600">{u.rusak}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-blue-400" style={{ width: `${u.opname}%` }} />
                    </div>
                    <span className="text-xs font-medium text-gray-700">{u.opname}%</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-xs text-gray-600">Rp {(u.biayaMaint / 1_000_000).toFixed(1)} jt</td>
                <td className="px-4 py-3"><SoftBadge label={`${u.skor}/100`} color={effBadge(u.skor)} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="space-y-3">
        <p className="text-sm font-semibold text-gray-800">Insight & Rekomendasi Sistem</p>
        <RekSistem level="Tinggi">Ekowisata dan Paramedik Veteriner memiliki skor efisiensi terendah (48 dan 52). Progress opname di bawah 55% dan jumlah aset idle yang tinggi mengindikasikan kurangnya monitoring aktif. Disarankan opname ulang segera dengan verifikasi fisik. Confidence: Tinggi.</RekSistem>
        <RekSistem level="Sedang">Terdapat {totalIdle} aset idle di seluruh unit. Potensi redistribusi ke unit dengan kekurangan aset dapat menghemat estimasi Rp 120–180 jt dari anggaran pengadaan baru. Confidence: Sedang.</RekSistem>
        <RekSistem level="Sedang">{tanpaPIC} aset tidak memiliki penanggung jawab (PIC) terdaftar. Kondisi ini berisiko memperlambat penanganan kerusakan dan opname. Disarankan verifikasi dan penetapan PIC dilakukan paling lambat akhir Juli 2026. Confidence: Sedang.</RekSistem>
      </div>
    </>
  );
}

function PersebaranAsetTab() {
  const [filterKampus,   setFilterKampus]   = useState("semua");
  const [filterGedung,   setFilterGedung]   = useState("semua");
  const [filterLantai,   setFilterLantai]   = useState("semua");
  const [filterUnit,     setFilterUnit]     = useState("semua");
  const [filterKategori, setFilterKategori] = useState("semua");

  const ruanganData = [
    { gedung: "Gedung A", lantai: "Lantai 1", kode: "A.1.01", nama: "Lab Komputer 1",       jumlah: 87,  nilai: 412000000,  status: "Terverifikasi"      },
    { gedung: "Gedung A", lantai: "Lantai 1", kode: "A.1.02", nama: "Lab Komputer 2",       jumlah: 79,  nilai: 354000000,  status: "Terverifikasi"      },
    { gedung: "Gedung A", lantai: "Lantai 2", kode: "A.2.01", nama: "Ruang Kuliah A2",      jumlah: 42,  nilai: 187000000,  status: "Terverifikasi"      },
    { gedung: "Gedung A", lantai: "Lantai 2", kode: "A.2.02", nama: "Ruang Dosen",          jumlah: 34,  nilai: 142000000,  status: "Terverifikasi"      },
    { gedung: "Gedung A", lantai: "Lantai 3", kode: "A.3.01", nama: "Ruang Rapat Utama",    jumlah: 28,  nilai:  98000000,  status: "Terverifikasi"      },
    { gedung: "Gedung B", lantai: "Lantai 1", kode: "B.1.01", nama: "Ruang Server",         jumlah: 31,  nilai: 2400000000, status: "Terverifikasi"      },
    { gedung: "Gedung B", lantai: "Lantai 1", kode: "B.1.02", nama: "Lab Fisika",            jumlah: 65,  nilai: 521000000,  status: "Terverifikasi"      },
    { gedung: "Gedung B", lantai: "Lantai 2", kode: "B.2.01", nama: "Lab Kimia",             jumlah: 58,  nilai: 389000000,  status: "Sebagian"           },
    { gedung: "Gedung C", lantai: "Lantai 1", kode: "C.1.01", nama: "Administrasi Umum",    jumlah: 44,  nilai: 213000000,  status: "Terverifikasi"      },
    { gedung: "Gedung C", lantai: "Lantai 1", kode: "C.1.02", nama: "Ruang Dekan",          jumlah: 19,  nilai: 124000000,  status: "Terverifikasi"      },
    { gedung: "Gedung C", lantai: "Lantai 2", kode: "C.2.01", nama: "Ruang Kuliah B1",      jumlah: 36,  nilai: 156000000,  status: "Belum Terverifikasi" },
    { gedung: "Gedung D", lantai: "Lantai 1", kode: "D.1.01", nama: "Gudang Perlengkapan",  jumlah: 102, nilai: 341000000,  status: "Sebagian"           },
    { gedung: "Gedung D", lantai: "Lantai 2", kode: "D.2.01", nama: "Lab Agribisnis",       jumlah: 73,  nilai: 498000000,  status: "Terverifikasi"      },
  ];

  const gedungList = ["Gedung A", "Gedung B", "Gedung C", "Gedung D", "Gedung E", "Gedung F"];
  const lantaiList = ["Lantai 1", "Lantai 2", "Lantai 3", "Lantai 4"];
  const heatmap: Record<string, Record<string, number>> = {
    "Gedung A": { "Lantai 1": 87,  "Lantai 2": 76, "Lantai 3": 28, "Lantai 4": 0  },
    "Gedung B": { "Lantai 1": 96,  "Lantai 2": 58, "Lantai 3": 0,  "Lantai 4": 0  },
    "Gedung C": { "Lantai 1": 63,  "Lantai 2": 36, "Lantai 3": 12, "Lantai 4": 0  },
    "Gedung D": { "Lantai 1": 102, "Lantai 2": 73, "Lantai 3": 31, "Lantai 4": 15 },
    "Gedung E": { "Lantai 1": 42,  "Lantai 2": 18, "Lantai 3": 0,  "Lantai 4": 0  },
    "Gedung F": { "Lantai 1": 24,  "Lantai 2": 0,  "Lantai 3": 0,  "Lantai 4": 0  },
  };
  const maxHeat = 102;
  const heatColor = (v: number) => {
    if (v === 0) return "#F9FAFB";
    const t = v / maxHeat;
    const r = Math.round(219 - t * 160);
    const g = Math.round(234 - t * 166);
    const b = Math.round(254 - t * 186);
    return `rgb(${r},${g},${b})`;
  };

  const sBadge = (s: string): "green" | "amber" | "red" => s === "Terverifikasi" ? "green" : s === "Sebagian" ? "amber" : "red";
  const filtered = ruanganData
    .filter(r => filterGedung === "semua" || r.gedung === filterGedung)
    .filter(r => filterLantai === "semua" || r.lantai === filterLantai);

  return (
    <>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm px-5 py-4 flex items-center gap-2 flex-wrap">
        <Filter size={14} className="text-gray-400 shrink-0" />
        <span className="text-xs font-medium text-gray-500 mr-1">Filter:</span>
        <select value={filterKampus}   onChange={e => setFilterKampus(e.target.value)}   className={FILTER_SELECT_CLS}>
          <option value="semua">Semua Kampus</option>
          <option value="cilibende">Cilibende</option>
          <option value="gunung-gede">Gunung Gede</option>
        </select>
        <select value={filterGedung}   onChange={e => setFilterGedung(e.target.value)}   className={FILTER_SELECT_CLS}>
          <option value="semua">Semua Gedung</option>
          {gedungList.map(g => <option key={g} value={g}>{g}</option>)}
        </select>
        <select value={filterLantai}   onChange={e => setFilterLantai(e.target.value)}   className={FILTER_SELECT_CLS}>
          <option value="semua">Semua Lantai</option>
          {lantaiList.map(l => <option key={l} value={l}>{l}</option>)}
        </select>
        <select value={filterUnit}     onChange={e => setFilterUnit(e.target.value)}     className={FILTER_SELECT_CLS}>
          <option value="semua">Semua Unit</option>
          <option value="tif">Teknik Informatika</option>
          <option value="agb">Agribisnis</option>
          <option value="adm">Administrasi Umum</option>
        </select>
        <select value={filterKategori} onChange={e => setFilterKategori(e.target.value)} className={FILTER_SELECT_CLS}>
          <option value="semua">Semua Kategori</option>
          <option value="pm">PM</option>
          <option value="atl">ATL</option>
          <option value="atb">ATB</option>
          <option value="al">AL</option>
        </select>
      </div>

      <div className="grid grid-cols-5 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Total Gedung</span><SisBadge /></div>
          <p className="text-2xl font-bold text-gray-900 leading-tight">28</p>
          <p className="text-xs text-gray-400 mt-1">Seluruh kampus</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Total Ruangan</span><SisBadge /></div>
          <p className="text-2xl font-bold text-gray-900 leading-tight">486</p>
          <p className="text-xs text-gray-400 mt-1">Terdata dalam sistem</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Ruangan Terisi Aset</span><SisBadge /></div>
          <p className="text-2xl font-bold text-green-600 leading-tight">412</p>
          <p className="text-xs text-gray-400 mt-1">84,8% dari total ruangan</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Aset Tanpa Lokasi Jelas</span><SisBadge /></div>
          <p className="text-2xl font-bold text-amber-600 leading-tight">312</p>
          <p className="text-xs text-gray-400 mt-1">Status lokasi belum diverifikasi</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Nilai Aset Ruangan Tertinggi</span><SisBadge /></div>
          <p className="text-2xl font-bold text-gray-900 leading-tight">Rp 2,4 M</p>
          <p className="text-xs text-gray-400 mt-1">Ruang Server (B.1.01)</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold text-gray-800">Sebaran Aset per Gedung dan Lantai</span>
          <SisBadge />
        </div>
        <div className="overflow-x-auto">
          <table className="border-separate w-full" style={{ borderSpacing: 4 }}>
            <thead>
              <tr>
                <th className="text-[10px] font-semibold text-gray-400 text-left pr-3 pb-1 whitespace-nowrap">Gedung / Lantai</th>
                {lantaiList.map(l => (
                  <th key={l} className="text-[10px] font-semibold text-gray-400 text-center pb-1 px-2">{l}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {gedungList.map(g => (
                <tr key={g}>
                  <td className="text-xs font-medium text-gray-600 pr-3 py-1 whitespace-nowrap">{g}</td>
                  {lantaiList.map(l => {
                    const val = heatmap[g]?.[l] ?? 0;
                    return (
                      <td key={l} className="rounded-lg text-center py-2.5" style={{ backgroundColor: heatColor(val), minWidth: 72 }}>
                        <span className={`text-xs font-bold ${val > 60 ? "text-blue-900" : val > 0 ? "text-blue-700" : "text-gray-300"}`}>
                          {val > 0 ? val : "—"}
                        </span>
                        {val > 0 && <div className={`text-[9px] ${val > 60 ? "text-blue-800 opacity-70" : "text-blue-600 opacity-60"}`}>aset</div>}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center gap-3 mt-3 pt-3 border-t border-gray-100">
          <span className="text-[10px] text-gray-400">Intensitas warna:</span>
          <div className="flex items-center gap-1">
            {[0, 25, 50, 75, 100].map(v => (
              <div key={v} className="w-8 h-3 rounded" style={{ backgroundColor: heatColor(Math.round(v / 100 * maxHeat)) }} />
            ))}
          </div>
          <span className="text-[10px] text-gray-400">0 ← jumlah aset → {maxHeat}</span>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold text-gray-800">Peta GIS Persebaran Aset</span>
          <span className="text-[10px] text-gray-400 bg-gray-100 px-2 py-0.5 rounded border border-gray-200">Data Koordinat Belum Lengkap</span>
        </div>
        <div className="rounded-xl bg-gray-50 border border-dashed border-gray-300 flex flex-col items-center justify-center py-10 gap-3">
          <MapPin size={32} className="text-gray-300" />
          <div className="text-center max-w-md">
            <p className="text-sm font-medium text-gray-500">GIS membutuhkan data latitude dan longitude.</p>
            <p className="text-xs text-gray-400 mt-1 leading-relaxed">Saat ini sistem menampilkan heatmap berbasis ruangan. Untuk mengaktifkan peta GIS, lengkapi kolom <code className="bg-gray-100 px-1 py-0.5 rounded text-[11px]">latitude</code> dan <code className="bg-gray-100 px-1 py-0.5 rounded text-[11px]">longitude</code> pada data aset.</p>
          </div>
          <button className="px-4 py-2 bg-white border border-gray-200 text-xs font-semibold text-gray-600 rounded-lg hover:bg-gray-50 transition-colors">
            Lihat Panduan Pengisian Koordinat
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <span className="text-sm font-semibold text-gray-800">Aset per Ruangan</span>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-gray-400">Menampilkan {filtered.length} dari {ruanganData.length} ruangan</span>
            <SisBadge />
          </div>
        </div>
        <table className="w-full text-left">
          <THead cols={["Gedung", "Lantai", "Kode Ruangan", "Nama Ruangan", "Jumlah Aset", "Nilai Buku", "Status Kejelasan Lokasi"]} />
          <tbody className="divide-y divide-gray-50">
            {filtered.map(r => (
              <tr key={r.kode} className="hover:bg-gray-50/50 transition-colors">
                <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.gedung}</td>
                <td className="px-4 py-3 text-xs text-gray-500">{r.lantai}</td>
                <td className="px-4 py-3 text-xs font-mono text-gray-400">{r.kode}</td>
                <td className="px-4 py-3 text-sm text-gray-700">{r.nama}</td>
                <td className="px-4 py-3 text-sm font-bold text-gray-900">{r.jumlah}</td>
                <td className="px-4 py-3 text-xs text-gray-600">Rp {(r.nilai / 1_000_000).toFixed(0)} jt</td>
                <td className="px-4 py-3"><SoftBadge label={r.status} color={sBadge(r.status)} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function PerencanaanPengadaanTab() {
  const store = useDataStore();
  const procurementAssets = useMemo(() => store.computeProcurementNeed(), [store]);

  const rekData = useMemo(() => {
    const map = new Map<string, { unit: string; kat: string; qty: number; biaya: number; reasons: Set<string>; maxSkor: number }>();
    for (const a of procurementAssets) {
      const key = `${a.Nama_unit}||${a.TipeAset}`;
      const cur = map.get(key) || { unit: a.Nama_unit, kat: a.TipeAset, qty: 0, biaya: 0, reasons: new Set<string>(), maxSkor: 0 };
      cur.qty += 1;
      cur.biaya += parseInt(a._harga_perolehan) || parseInt(a._nilai_buku) || 0;
      const skor = computeReplacementPriority(a);
      if (skor > cur.maxSkor) cur.maxSkor = skor;
      const sisa = parseInt(a._sisa_masa_manfaat_bulan) || 0;
      const freq = parseInt(a.total_frekuensi_maintenance) || 0;
      if (sisa <= 0) cur.reasons.add("masa manfaat habis");
      if (freq >= 3) cur.reasons.add("frekuensi kerusakan tinggi");
      if ((a.Kondisi || "").includes("Rusak")) cur.reasons.add("kondisi rusak");
      map.set(key, cur);
    }
    return Array.from(map.values())
      .sort((a, b) => b.maxSkor - a.maxSkor)
      .map((v) => {
        const prio = v.maxSkor >= 70 ? "Tinggi" : v.maxSkor >= 50 ? "Sedang" : "Rendah";
        const rek = prio === "Tinggi" ? "Pengadaan segera" : prio === "Sedang" ? "Anggaran semester depan" : "Masuk RKPT berikutnya";
        const alasan = v.reasons.size ? `Indikator: ${Array.from(v.reasons).join(", ")}` : "Skor risiko gabungan tinggi";
        return { unit: v.unit, kat: v.kat, qty: v.qty, alasan, est: fmtRupiahShort(v.biaya), prio, rek };
      });
  }, [procurementAssets]);

  const totalEstimasiPengadaan = useMemo(
    () => procurementAssets.reduce((s, a) => s + (parseInt(a._harga_perolehan) || parseInt(a._nilai_buku) || 0), 0),
    [procurementAssets],
  );
  const prioritasPenggantianCount = useMemo(
    () => store.assets.filter((a) => computeReplacementPriority(a) >= 70).length,
    [store.assets],
  );
  const unitButuhAsetCount = useMemo(
    () => new Set(procurementAssets.map((a) => a.Nama_unit)).size,
    [procurementAssets],
  );
  const idleAssets = useMemo(
    () => store.assets.filter((a) => a.status_penggunaan_aset === "Tidak Digunakan" || a.status_penggunaan_aset === "Idle"),
    [store.assets],
  );
  const ruanganKurangCount = useMemo(() => {
    const counts = new Map<string, number>();
    for (const a of store.assets) {
      if (!a.kode_ruangan) continue;
      counts.set(a.kode_ruangan, (counts.get(a.kode_ruangan) || 0) + 1);
    }
    let n = 0;
    counts.forEach((v) => { if (v < 5) n += 1; });
    return n;
  }, [store.assets]);

  const redistData = (() => {
    const needUnits = Array.from(new Set(procurementAssets.map(a => a.Nama_unit)));
    const idleSorted = [...idleAssets].sort((a, b) => (parseInt(b._nilai_buku) || 0) - (parseInt(a._nilai_buku) || 0));
    return idleSorted.slice(0, 5).map((a, i) => {
      const tujuan = needUnits[i % Math.max(1, needUnits.length)] || "Unit lain";
      const months = Math.max(1, Math.round(((new Date("2026-06-01").getTime() - new Date(a.tanggal_maintenance_terakhir && a.tanggal_maintenance_terakhir !== "-" ? a.tanggal_maintenance_terakhir : "2025-06-01").getTime()) / (1000 * 60 * 60 * 24 * 30))));
      const hematN = parseInt(a._nilai_buku) || 0;
      return {
        id: a.id,
        nama: a.Nama_Barang || a.id,
        asal: a.Nama_unit || "-",
        tujuan,
        idle: `${months} bln idle`,
        hemat: fmtRupiahShort(hematN),
      };
    });
  })();

  const procurementByQuarter = (() => {
    const year = new Date().getFullYear();
    const counts = [0, 0, 0, 0];
    for (const p of store.procurementRequests) {
      const d = new Date(p.tanggal);
      if (isNaN(d.getTime()) || d.getFullYear() !== year) continue;
      const q = Math.floor(d.getMonth() / 3);
      counts[q] += 1;
    }
    return counts;
  })();
  const quarters  = [`Q1 ${new Date().getFullYear()}`, `Q2 ${new Date().getFullYear()}`, `Q3 ${new Date().getFullYear()}`, `Q4 ${new Date().getFullYear()}`, `Q1 ${new Date().getFullYear() + 1}`, `Q2 ${new Date().getFullYear() + 1}`];
  const qData     = [...procurementByQuarter, 0, 0];
  const VW = 560, VH = 150, ml = 42, mr = 16, mt = 16, mb = 30;
  const cW = VW - ml - mr, cH = VH - mt - mb;
  const maxQ = 350;
  const bW = (cW / quarters.length) - 8;
  const xBar = (i: number) => ml + (i / quarters.length) * cW + 4;
  const yBar = (v: number) => mt + cH - Math.min(v / maxQ, 1) * cH;
  const barColors = ["#EF4444", "#F59E0B", "#3B82F6", "#3B82F6", "#3B82F6", "#3B82F6"];

  const pBadge = (p: string): "red" | "amber" | "gray" => p === "Tinggi" ? "red" : p === "Sedang" ? "amber" : "gray";
  const kBadge = (k: string): "blue" | "green" | "amber" | "purple" => k === "PM" ? "blue" : k === "AL" ? "green" : k === "ATB" ? "amber" : "purple";

  return (
    <>
      <div className="grid grid-cols-5 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Aset Prioritas Penggantian</span><SisBadge /></div>
          <p className="text-2xl font-bold text-red-600 leading-tight">{prioritasPenggantianCount}</p>
          <p className="text-xs text-gray-400 mt-1">Skor risiko ≥ 70</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Ruangan Kekurangan Aset</span><SisBadge /></div>
          <p className="text-2xl font-bold text-amber-600 leading-tight">{ruanganKurangCount}</p>
          <p className="text-xs text-gray-400 mt-1">Di bawah kapasitas minimal</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Estimasi Kebutuhan Anggaran</span><SisBadge /></div>
          <p className="text-2xl font-bold text-gray-900 leading-tight">{fmtRupiahShort(totalEstimasiPengadaan)}</p>
          <p className="text-xs text-gray-400 mt-1">Semua prioritas — rekomendasi awal</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Rekomendasi Redistribusi</span><SisBadge /></div>
          <p className="text-2xl font-bold text-blue-600 leading-tight">{idleAssets.length}</p>
          <p className="text-xs text-gray-400 mt-1">Aset idle yang dapat dipindah</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between gap-2 mb-2"><span className="text-xs font-medium text-gray-500 leading-snug">Unit Membutuhkan Aset Baru</span><SisBadge /></div>
          <p className="text-2xl font-bold text-purple-600 leading-tight">{unitButuhAsetCount}</p>
          <p className="text-xs text-gray-400 mt-1">Berdasarkan analisis sistem</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-gray-800">Prediksi Kebutuhan Pengadaan</span>
            <span className="text-[10px] text-amber-600 bg-amber-50 border border-amber-100 px-1.5 py-0.5 rounded font-semibold">Rekomendasi Sistem</span>
          </div>
          <SisBadge />
        </div>
        <p className="text-xs text-gray-400 mb-3">Estimasi anggaran pengadaan per kuartal berdasarkan kondisi aset, masa manfaat, dan kebutuhan ruangan — bukan keputusan final</p>
        <svg viewBox={`0 0 ${VW} ${VH}`} className="w-full" style={{ height: VH }}>
          {[0, 100, 200, 300].map(v => (
            <g key={v}>
              <line x1={ml} y1={yBar(v)} x2={VW - mr} y2={yBar(v)} stroke="#F3F4F6" strokeWidth={1} />
              <text x={ml - 5} y={yBar(v) + 3} textAnchor="end" fontSize={8} fill="#D1D5DB">{v}</text>
            </g>
          ))}
          <line x1={ml} y1={mt + cH} x2={VW - mr} y2={mt + cH} stroke="#E5E7EB" strokeWidth={1} />
          {quarters.map((q, i) => {
            const v = qData[i];
            const x = xBar(i);
            const bh = Math.min(v / maxQ, 1) * cH;
            const y = mt + cH - bh;
            return (
              <g key={q}>
                <rect x={x} y={y} width={bW} height={bh} fill={barColors[i]} fillOpacity={0.75} rx={2} />
                <text x={x + bW / 2} y={y - 4} textAnchor="middle" fontSize={8} fill={barColors[i]} fontWeight="600">{v}</text>
                <text x={x + bW / 2} y={VH - 6} textAnchor="middle" fontSize={8} fill="#9CA3AF">{q}</text>
              </g>
            );
          })}
        </svg>
        <div className="flex items-center gap-4 mt-2 pt-2 border-t border-gray-100 text-[10px] text-gray-400">
          <span className="flex items-center gap-1"><span className="inline-block w-2 h-2 rounded-sm bg-red-400" /> Paling Mendesak</span>
          <span className="flex items-center gap-1"><span className="inline-block w-2 h-2 rounded-sm bg-amber-400" /> Mendesak</span>
          <span className="flex items-center gap-1"><span className="inline-block w-2 h-2 rounded-sm bg-blue-400" /> Jangka Menengah</span>
          <span className="ml-auto">Satuan: Rp juta</span>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-gray-800">Rekomendasi Pengadaan</span>
            <span className="text-[10px] text-amber-600 bg-amber-50 border border-amber-100 px-1.5 py-0.5 rounded font-semibold">Rekomendasi Sistem</span>
          </div>
          <SisBadge />
        </div>
        <table className="w-full text-left">
          <THead cols={["Unit", "Kategori Aset", "Jml. Kebutuhan", "Alasan Sistem", "Estimasi Anggaran", "Prioritas", "Rekomendasi"]} />
          <tbody className="divide-y divide-gray-50">
            {rekData.map((r, i) => (
              <tr key={i} className="hover:bg-gray-50/50 transition-colors">
                <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.unit}</td>
                <td className="px-4 py-3"><SoftBadge label={r.kat} color={kBadge(r.kat)} /></td>
                <td className="px-4 py-3 text-sm font-bold text-gray-900 text-center">{r.qty}</td>
                <td className="px-4 py-3 text-xs text-gray-500 max-w-[200px] leading-relaxed">{r.alasan}</td>
                <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.est}</td>
                <td className="px-4 py-3"><SoftBadge label={r.prio} color={pBadge(r.prio)} /></td>
                <td className="px-4 py-3 text-xs text-gray-600">{r.rek}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-sm font-semibold text-gray-800">Redistribusi Sebelum Pengadaan</span>
          <span className="text-[10px] text-blue-600 bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded font-semibold">Rekomendasi Sistem</span>
        </div>
        <p className="text-xs text-gray-500 mb-4">Daftar aset idle yang dapat dipindahkan ke unit yang membutuhkan — pertimbangkan redistribusi ini sebelum mengajukan pengadaan baru.</p>
        <table className="w-full text-left">
          <THead cols={["Kode Aset", "Nama Aset", "Unit Asal", "Unit Tujuan", "Status Idle", "Potensi Penghematan"]} />
          <tbody className="divide-y divide-gray-50">
            {redistData.map(r => (
              <tr key={r.id} className="hover:bg-gray-50/50 transition-colors">
                <td className="px-4 py-3 text-xs font-mono text-gray-400">{r.id}</td>
                <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                <td className="px-4 py-3 text-xs text-gray-500">{r.asal}</td>
                <td className="px-4 py-3">
                  <span className="text-xs font-medium text-blue-600 bg-blue-50 border border-blue-100 px-2 py-0.5 rounded">{r.tujuan}</span>
                </td>
                <td className="px-4 py-3"><SoftBadge label={r.idle} color="amber" /></td>
                <td className="px-4 py-3 text-xs font-semibold text-green-600">{r.hemat}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="mt-3 flex items-center justify-between pt-3 border-t border-gray-100">
          <p className="text-xs text-gray-400">Total potensi penghematan dari redistribusi: <span className="font-bold text-green-600">Rp 35 jt</span></p>
          <span className="text-[10px] text-gray-400">Verifikasi kondisi fisik aset sebelum redistribusi dilakukan</span>
        </div>
      </div>

      <RekSistem level="Tinggi">Laptop pengganti (Lab Komputer, 8 unit) dan server rack (Teknik Informatika, 2 unit) merupakan kebutuhan paling mendesak dengan total estimasi Rp 141 jt. Direkomendasikan untuk dimasukkan ke RKPT 2026 tahap dua sebelum akhir Juli 2026. Confidence: Tinggi.</RekSistem>
      <RekSistem level="Sedang">Sebelum mengajukan pengadaan baru, pertimbangkan redistribusi 52 aset idle yang teridentifikasi. Potensi penghematan estimasi Rp 35–120 jt tergantung kondisi fisik aset. Confidence: Sedang.</RekSistem>
    </>
  );
}

function AnalitikContent({ tab }: { tab: string }) {
  const store = useDataStore();
  if (tab === "Pola Kerusakan Aset") {
    const kategoriData = [
      { label: "Elektrikal",             value: 47, color: BLUE   },
      { label: "Mekanik",                value: 31, color: PURPLE },
      { label: "Keausan Normal",         value: 24, color: GREEN  },
      { label: "Fisik / Benturan",       value: 18, color: AMBER  },
      { label: "Software / Lisensi",     value: 15, color: "#06B6D4" },
      { label: "Kendaraan",             value: 14, color: "#EC4899" },
      { label: "Perangkat Pembelajaran", value: 12, color: "#8B5CF6" },
    ];

    const topAset = [
      { id: "PM-001",  nama: "Laptop ASUS ROG G513",       kat: "PM",  unit: "Lab Komputer",       freq: 8, tingkat: "Berat",  biaya: 4_250_000, risiko: "Tinggi"  },
      { id: "PM-003",  nama: "Server Dell PowerEdge R740",  kat: "PM",  unit: "Teknik Informatika", freq: 6, tingkat: "Sedang", biaya: 8_100_000, risiko: "Tinggi"  },
      { id: "ATL-012", nama: "AC Daikin 2 PK Inverter",     kat: "ATL", unit: "Administrasi Umum",  freq: 5, tingkat: "Sedang", biaya: 2_300_000, risiko: "Sedang"  },
      { id: "ATL-023", nama: "Proyektor Epson EB-X51",      kat: "ATL", unit: "Ruang Kuliah B2",    freq: 4, tingkat: "Berat",  biaya: 1_800_000, risiko: "Tinggi"  },
      { id: "AL-023",  nama: "Toyota Avanza 2021",           kat: "AL",  unit: "Unit Operasional",   freq: 4, tingkat: "Ringan", biaya: 6_400_000, risiko: "Sedang"  },
      { id: "PM-018",  nama: "UPS APC Smart 3000VA",         kat: "PM",  unit: "Ruang Server B",     freq: 3, tingkat: "Sedang", biaya: 3_200_000, risiko: "Sedang"  },
      { id: "PM-034",  nama: "Laptop Lenovo ThinkPad X1",    kat: "PM",  unit: "Teknik Informatika", freq: 3, tingkat: "Ringan", biaya: 1_100_000, risiko: "Rendah"  },
    ];

    const risCfg  = (r: string) => r === "Tinggi" ? "red"   : r === "Sedang" ? "amber" : "gray"  as const;
    const tingCfg = (t: string) => t === "Berat"  ? "red"   : t === "Sedang" ? "amber" : "green" as const;
    const katCfg  = (k: string) => k === "PM"     ? "blue"  : k === "AL"     ? "green" : "purple" as const;

    return (
      <>
        {/* ── 5 KPI Cards ── */}
        <div className="grid grid-cols-5 gap-4">
          <KpiStat label="Total Kerusakan Tercatat"  value="132"       sub="Jan–Jun 2026"               badge trend="+8 vs semester lalu" />
          <KpiStat label="Aset Sering Rusak (≥3×)"   value="18"        sub="Frekuensi kerusakan tinggi"  badge />
          <KpiStat label="Kerusakan Bulan Ini"        value="14"        sub="Juni 2026 (berjalan)"         badge />
          <KpiStat label="Rata-rata Downtime"          value="4,2 jam"  sub="Per kejadian kerusakan"       badge />
          <KpiStat label="Total Biaya Kerusakan"       value="Rp 377 jt" sub="Jan–Jun 2026 kumulatif"     badge />
        </div>

        {/* ── Charts Row ── */}
        <div className="grid grid-cols-2 gap-4">
          {/* Line chart */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-gray-800">Tren Kerusakan Aset per Bulan</span>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-3 text-[11px] text-gray-500">
                  {([["PM", BLUE], ["ATL", PURPLE], ["AL", AMBER]] as [string, string][]).map(([l, c]) => (
                    <span key={l} className="flex items-center gap-1.5">
                      <span className="inline-block rounded-sm" style={{ width: 14, height: 2, backgroundColor: c }} />
                      {l}
                    </span>
                  ))}
                </div>
                <SisBadge />
              </div>
            </div>
            <PolaKerusakanLineChart />
            <div className="mt-2 flex items-center gap-1 text-[10px] text-gray-400">
              <Info size={10} /> Baseline dari data ringkasan maintenance
            </div>
          </div>

          {/* Horizontal bar: kategori kerusakan */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-gray-800">Kategori Kerusakan Terbanyak</span>
              <SisBadge />
            </div>
            <HBarChart data={kategoriData} maxVal={47} />
            <div className="mt-3 pt-3 border-t border-gray-100 flex items-center gap-1 text-[10px] text-gray-400">
              <Info size={10} /> Baseline dari data ringkasan maintenance &bull; Satuan: jumlah kejadian
            </div>
          </div>
        </div>

        {/* ── Top Aset Sering Rusak ── */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <span className="text-sm font-semibold text-gray-800">Top Aset Sering Rusak</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-gray-400">Diurutkan berdasarkan frekuensi kerusakan tertinggi</span>
              <SisBadge />
            </div>
          </div>
          <table className="w-full text-left">
            <THead cols={["Kode Aset", "Nama Aset", "Kat.", "Unit", "Frekuensi", "Tingkat Terakhir", "Total Biaya", "Status Risiko"]} />
            <tbody className="divide-y divide-gray-50">
              {topAset.map(r => (
                <tr key={r.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-4 py-3 text-xs font-mono text-gray-400">{r.id}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800 max-w-[160px]">
                    <span className="truncate block">{r.nama}</span>
                  </td>
                  <td className="px-4 py-3">
                    <SoftBadge label={r.kat} color={katCfg(r.kat)} />
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-500">{r.unit}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-gray-900 w-5">{r.freq}×</span>
                      <div className="w-14 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{
                          width: `${(r.freq / 8) * 100}%`,
                          backgroundColor: r.freq >= 6 ? RED : r.freq >= 4 ? AMBER : GREEN,
                        }} />
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <SoftBadge label={r.tingkat} color={tingCfg(r.tingkat)} />
                  </td>
                  <td className="px-4 py-3 text-xs font-medium text-gray-700">
                    Rp {(r.biaya / 1_000_000).toFixed(1)} jt
                  </td>
                  <td className="px-4 py-3">
                    <SoftBadge label={r.risiko} color={risCfg(r.risiko)} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* ── Insight Sistem ── */}
        <div className="space-y-3">
          <p className="text-sm font-semibold text-gray-800">Insight Sistem</p>
          <RekSistem level="Tinggi">
            PM-001 (Laptop ASUS ROG) memiliki frekuensi kerusakan tertinggi (8×) dengan total biaya Rp 4,25 jt — sudah melewati masa manfaat. Direkomendasikan penggantian daripada perbaikan kembali. Confidence: Tinggi.
          </RekSistem>
          <RekSistem level="Tinggi">
            Kategori Elektrikal mendominasi (47 kasus, 35,6% total) dengan tren meningkat Jan–Mei 2026. Direkomendasikan pemeriksaan preventif 6 bulanan untuk seluruh peralatan PM mulai Juli 2026. Confidence: Tinggi.
          </RekSistem>
          <RekSistem level="Sedang">
            Rata-rata downtime 4,2 jam/kejadian berpotensi mengganggu operasional Lab Komputer dan Ruang Server. Pertimbangkan stok suku cadang kritis (charger, memori, filter AC) untuk mempersingkat waktu perbaikan. Confidence: Sedang.
          </RekSistem>
        </div>
      </>
    );
  }

  if (tab === "Prediksi Perbaikan Aset")    return <PrediksiPerbaikanTab />;
  if (tab === "Pengelolaan Aset")            return <PengelolaanAsetTab />;
  if (tab === "Persebaran Aset")             return <PersebaranAsetTab />;
  if (tab === "Perencanaan Pengadaan Aset")  return <PerencanaanPengadaanTab />;

  // Rekapitulasi
  const rekapAssets = store.assets;
  const byType = (type: string) => rekapAssets.filter(a => a.TipeAset === type);
  const kondisiOf = (assets: typeof rekapAssets, cond: string) => assets.filter(a => (a.Kondisi || "").includes(cond)).length;
  const rekapRows = [
    {
      label: "Total Aset",
      pm: byType("PM").length, atb: byType("ATB").length, atl: byType("ATL").length, al: byType("AL").length,
    },
    {
      label: "Kondisi Baik",
      pm: kondisiOf(byType("PM"), "Baik"), atb: kondisiOf(byType("ATB"), "Baik"), atl: kondisiOf(byType("ATL"), "Baik"), al: kondisiOf(byType("AL"), "Baik"),
    },
    {
      label: "Perlu Perbaikan",
      pm: kondisiOf(byType("PM"), "Rusak Ringan"), atb: kondisiOf(byType("ATB"), "Rusak Ringan"), atl: kondisiOf(byType("ATL"), "Rusak Ringan"), al: kondisiOf(byType("AL"), "Rusak Ringan"),
    },
    {
      label: "Rusak Berat",
      pm: kondisiOf(byType("PM"), "Rusak Berat"), atb: kondisiOf(byType("ATB"), "Rusak Berat"), atl: kondisiOf(byType("ATL"), "Rusak Berat"), al: kondisiOf(byType("AL"), "Rusak Berat"),
    },
    {
      label: "Melewati Masa Manfaat",
      pm: byType("PM").filter(a => (parseInt(a._sisa_masa_manfaat_bulan || "0") || 0) <= 0).length,
      atb: byType("ATB").filter(a => (parseInt(a._sisa_masa_manfaat_bulan || "0") || 0) <= 0).length,
      atl: byType("ATL").filter(a => (parseInt(a._sisa_masa_manfaat_bulan || "0") || 0) <= 0).length,
      al: byType("AL").filter(a => (parseInt(a._sisa_masa_manfaat_bulan || "0") || 0) <= 0).length,
    },
  ];
  const totalAsetRekap = rekapAssets.length;
  const opnameProgRekap = store.computeStockOpnameProgress();
  const bermasalah = rekapAssets.filter(a => {
    const k = a.Kondisi || "";
    return k.includes("Rusak") || a.status_penggunaan_aset === "Tidak Digunakan";
  }).length;
  return (
    <>
      <div className="grid grid-cols-4 gap-4">
        <KpiStat label="Total Aset"               value={fmtNum(totalAsetRekap)}             sub="PM+ATB+ATL+AL"                                                   badge />
        <KpiStat label="Sudah Diopname"           value={fmtNum(opnameProgRekap.done)}       sub={`${fmtPct(opnameProgRekap.pct)} dari total`}                    badge />
        <KpiStat label="Belum Diverifikasi"       value={fmtNum(opnameProgRekap.total - opnameProgRekap.done)} sub="Perlu verifikasi"                              badge />
        <KpiStat label="Aset Bermasalah"          value={fmtNum(bermasalah)}                 sub="Perlu tindak lanjut"                                             badge />
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold text-gray-800">Rekapitulasi Kondisi per Kategori</span>
          <SisBadge />
        </div>
        <table className="w-full text-left">
          <THead cols={["Keterangan", "PM", "ATB", "ATL", "AL", "Total"]} />
          <tbody className="divide-y divide-gray-50">
            {rekapRows.map(r => (
              <tr key={r.label} className={`hover:bg-gray-50/50 ${r.label === "Total Aset" ? "font-semibold" : ""}`}>
                <td className="px-4 py-3 text-sm text-gray-800">{r.label}</td>
                <td className="px-4 py-3 text-sm text-gray-700">{r.pm}</td>
                <td className="px-4 py-3 text-sm text-gray-700">{r.atb}</td>
                <td className="px-4 py-3 text-sm text-gray-700">{r.atl}</td>
                <td className="px-4 py-3 text-sm text-gray-700">{r.al}</td>
                <td className="px-4 py-3 text-sm font-bold text-gray-900">{r.pm + r.atb + r.atl + r.al}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ── KEUANGAN ──────────────────────────────────────────────────────────────────

function KeuanganContent({ tab }: { tab: string }) {
  const storeKeu = useDataStore();
  const totalAsetKeu = storeKeu.computeTotalAssets();
  const realTotalPerolehan = storeKeu.computeTotalAcquisitionValue();
  const realTotalBuku = storeKeu.computeTotalBookValue();
  const nilaiKat = [
    { kat: "Peralatan & Mesin (PM)",   perolehan: 18240, susut: 7140,  buku: 11100, pct: 60.9 },
    { kat: "Aset Tetap Lainnya (ATL)", perolehan: 7610,  susut: 2940,  buku: 4670,  pct: 61.4 },
    { kat: "Aset Tak Berwujud (ATB)",  perolehan: 1820,  susut: 640,   buku: 1180,  pct: 64.8 },
    { kat: "Alat Angkutan (AL)",       perolehan: 760,   susut: 312,   buku: 448,   pct: 58.9 },
  ];
  const totalPerolehan = nilaiKat.reduce((a, v) => a + v.perolehan, 0);
  const totalSusut     = nilaiKat.reduce((a, v) => a + v.susut, 0);
  const totalBuku      = nilaiKat.reduce((a, v) => a + v.buku, 0);

  if (tab === "Valuasi Aset") {
    const trendTahunan = [
      { thn: "2021", nilai: 19200 }, { thn: "2022", nilai: 21450 },
      { thn: "2023", nilai: 23800 }, { thn: "2024", nilai: 25900 },
      { thn: "2025", nilai: 27100 }, { thn: "2026", nilai: 28430 },
    ];
    const maxNilai = Math.max(...trendTahunan.map(d => d.nilai));
    const pts = trendTahunan.map((d, i) => {
      const x = 40 + i * 80;
      const y = 80 - (d.nilai / maxNilai) * 60;
      return `${x},${y}`;
    }).join(" ");
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Total Nilai Perolehan" value={fmtRupiahShort(realTotalPerolehan)} sub="Semua kategori aset" badge />
          <KpiStat label="Nilai Buku Saat Ini"   value={fmtRupiahShort(realTotalBuku)}     sub={`${realTotalPerolehan > 0 ? ((realTotalBuku/realTotalPerolehan)*100).toFixed(1) : "0"}% dari perolehan`} badge />
          <KpiStat label="Rata-rata Nilai/Aset"  value={totalAsetKeu > 0 ? fmtRupiahShort(Math.round(realTotalPerolehan / totalAsetKeu)) : "—"} sub={`Berdasarkan ${fmtNum(totalAsetKeu)} aset`} badge />
          <KpiStat label="Aset Bernilai > 100 jt" value={fmtNum(storeKeu.assets.filter(a => (parseInt(a._harga_perolehan || "0") || 0) >= 100_000_000).length)} sub="Perlu revaluasi periodik" badge />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-semibold text-gray-800">Tren Nilai Aset Tahunan (Rp juta)</span>
              <SisBadge />
            </div>
            <svg viewBox="0 0 520 110" className="w-full" style={{ height: 110 }}>
              <polyline points={pts} fill="none" stroke={BLUE} strokeWidth={2} />
              {trendTahunan.map((d, i) => {
                const x = 40 + i * 80;
                const y = 80 - (d.nilai / maxNilai) * 60;
                return (
                  <g key={d.thn}>
                    <circle cx={x} cy={y} r={3} fill={BLUE} />
                    <text x={x} y={100} textAnchor="middle" fontSize={9} fill="#9CA3AF">{d.thn}</text>
                    <text x={x} y={y - 7} textAnchor="middle" fontSize={8} fill="#6B7280">{(d.nilai/1000).toFixed(1)}M</text>
                  </g>
                );
              })}
            </svg>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-semibold text-gray-800">Sumber Dana Pengadaan (Rp juta)</span>
              <SisBadge />
            </div>
            <HBarChart data={[
              { label: "DIPA",    value: 14820 },
              { label: "BLU",     value: 8340  },
              { label: "PNBP",    value: 3240  },
              { label: "Hibah",   value: 1600  },
              { label: "Swadana", value: 430   },
            ]} maxVal={14820} />
            <p className="text-xs text-gray-400 mt-3">Data kumulatif hingga Juni 2026</p>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Nilai Aset per Kategori (Rp juta)</span>
            <SisBadge />
          </div>
          <table className="w-full text-left">
            <THead cols={["Kategori", "Nilai Perolehan", "Akum. Penyusutan", "Nilai Buku", "% Nilai Buku"]} />
            <tbody className="divide-y divide-gray-50">
              {nilaiKat.map(r => (
                <tr key={r.kat} className="hover:bg-gray-50/50">
                  <td className="px-4 py-2.5 text-xs text-gray-700">{r.kat}</td>
                  <td className="px-4 py-2.5 text-xs font-medium text-gray-900">{r.perolehan.toLocaleString("id")}</td>
                  <td className="px-4 py-2.5 text-xs text-red-600">({r.susut.toLocaleString("id")})</td>
                  <td className="px-4 py-2.5 text-xs font-bold text-green-700">{r.buku.toLocaleString("id")}</td>
                  <td className="px-4 py-2.5 text-xs text-gray-600">{r.pct}%</td>
                </tr>
              ))}
              <tr className="border-t-2 border-gray-200 bg-gray-50 font-bold">
                <td className="px-4 py-2.5 text-xs text-gray-900">Total</td>
                <td className="px-4 py-2.5 text-xs text-gray-900">{totalPerolehan.toLocaleString("id")}</td>
                <td className="px-4 py-2.5 text-xs text-red-600">({totalSusut.toLocaleString("id")})</td>
                <td className="px-4 py-2.5 text-xs text-green-700">{totalBuku.toLocaleString("id")}</td>
                <td className="px-4 py-2.5 text-xs text-gray-600">{((totalBuku/totalPerolehan)*100).toFixed(1)}%</td>
              </tr>
            </tbody>
          </table>
        </div>
        <RekSistem level="Sedang">Nilai buku aset sebesar Rp {(totalBuku/1000).toFixed(1)} M ({((totalBuku/totalPerolehan)*100).toFixed(1)}% dari nilai perolehan). Disarankan melakukan revaluasi aset sesuai PSAP untuk memperbarui nilai wajar dalam laporan keuangan semester II 2026.</RekSistem>
      </>
    );
  }

  if (tab === "Penyusutan") {
    const susutTahunan = [
      { thn: "2021", akum: 4120 }, { thn: "2022", akum: 5380 },
      { thn: "2023", akum: 6450 }, { thn: "2024", akum: 7830 },
      { thn: "2025", akum: 9560 }, { thn: "2026", nilai: 11032, akum: 11032 },
    ];
    const maxAkum = Math.max(...susutTahunan.map(d => d.akum));
    const pts = susutTahunan.map((d, i) => {
      const x = 40 + i * 80;
      const y = 80 - (d.akum / maxAkum) * 60;
      return `${x},${y}`;
    }).join(" ");
    const topSusut = [
      { kat: "Peralatan & Mesin",   susutThn: 1428, rate: "7,8%", metode: "Garis Lurus" },
      { kat: "Aset Tetap Lainnya",  susutThn: 588,  rate: "7,7%", metode: "Garis Lurus" },
      { kat: "Alat Angkutan",       susutThn: 76,   rate: "10,0%",metode: "Saldo Menurun"},
      { kat: "Aset Tak Berwujud",   susutThn: 182,  rate: "10,0%",metode: "Garis Lurus" },
    ];
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Akumulasi Penyusutan"      value={`Rp ${(totalSusut/1000).toFixed(1)} M`} sub={`${((totalSusut/totalPerolehan)*100).toFixed(1)}% dari perolehan`} badge />
          <KpiStat label="Penyusutan Tahun Ini"       value="Rp 2,27 M"                              sub="Jan–Des 2026 (estimasi)" badge />
          <KpiStat label="Rata-rata Penyusutan/Aset"  value="Rp 2,26 jt"                             sub="Per aset per tahun" badge />
          <KpiStat label="Aset Sudah Habis Susut"     value="342"                                    sub="Nilai buku = 0" badge />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-semibold text-gray-800">Tren Akumulasi Penyusutan (Rp juta)</span>
              <SisBadge />
            </div>
            <svg viewBox="0 0 520 110" className="w-full" style={{ height: 110 }}>
              <polyline points={pts} fill="none" stroke={RED} strokeWidth={2} strokeDasharray="4 2" />
              {susutTahunan.map((d, i) => {
                const x = 40 + i * 80;
                const y = 80 - (d.akum / maxAkum) * 60;
                return (
                  <g key={d.thn}>
                    <circle cx={x} cy={y} r={3} fill={RED} />
                    <text x={x} y={100} textAnchor="middle" fontSize={9} fill="#9CA3AF">{d.thn}</text>
                    <text x={x} y={y - 7} textAnchor="middle" fontSize={8} fill="#6B7280">{(d.akum/1000).toFixed(1)}M</text>
                  </g>
                );
              })}
            </svg>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-semibold text-gray-800">Penyusutan per Kategori</span>
              <SisBadge />
            </div>
            <HBarChart data={nilaiKat.map(d => ({ label: d.kat.split(" (")[0], value: d.susut }))} maxVal={7140} />
            <p className="text-xs text-gray-400 mt-3">Satuan: Rp juta &bull; Kumulatif</p>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Detail Penyusutan per Kategori</span>
            <SisBadge />
          </div>
          <table className="w-full text-left">
            <THead cols={["Kategori", "Penyusutan/Tahun (Rp juta)", "Tarif Susut", "Metode", "Akum. Susut"]} />
            <tbody className="divide-y divide-gray-50">
              {topSusut.map((r, i) => (
                <tr key={i} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-sm text-gray-800">{r.kat}</td>
                  <td className="px-4 py-3 text-sm font-medium text-red-600">{r.susutThn.toLocaleString("id")}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{r.rate}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.metode} color="blue" /></td>
                  <td className="px-4 py-3 text-sm font-bold text-gray-800">{nilaiKat[i].susut.toLocaleString("id")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <RekSistem level="Sedang">342 aset sudah mencapai nilai buku nol namun masih aktif digunakan. Disarankan melakukan kajian ulang masa manfaat dan pertimbangan penghapusan atau revaluasi agar laporan keuangan mencerminkan kondisi aset yang sesungguhnya.</RekSistem>
      </>
    );
  }

  if (tab === "Aset Bernilai Tinggi") {
    const topAset = [
      { id: "AL-001",  nama: "Toyota Fortuner 2023",          kat: "AL",  perolehan: 580000, buku: 464000, susut: 20.0, lokasi: "Kampus Cilibende",      kondisi: "Baik"         },
      { id: "AL-015",  nama: "Pickup Mitsubishi L300",          kat: "AL",  perolehan: 280000, buku: 112000, susut: 60.0, lokasi: "Kampus Gunung Gede",    kondisi: "Perlu Perbaikan"},
      { id: "PM-003",  nama: "Server Dell PowerEdge R750",     kat: "PM",  perolehan: 185000, buku: 148000, susut: 20.0, lokasi: "Ruang Server A",         kondisi: "Baik"         },
      { id: "PM-018",  nama: "UPS APC Smart 3000VA",            kat: "PM",  perolehan: 120000, buku: 84000,  susut: 30.0, lokasi: "Ruang Server A",         kondisi: "Baik"         },
      { id: "ATL-040", nama: "LCD Proyektor Sony VPL-FHZ85",   kat: "ATL", perolehan: 98000,  buku: 68600,  susut: 30.0, lokasi: "Aula Utama Cilibende",   kondisi: "Baik"         },
      { id: "PM-007",  nama: "Cisco Catalyst 9200 Switch",      kat: "PM",  perolehan: 95000,  buku: 76000,  susut: 20.0, lokasi: "Ruang Server B",         kondisi: "Baik"         },
      { id: "ATL-012", nama: "AC VRV Daikin 10 PK",             kat: "ATL", perolehan: 87000,  buku: 52200,  susut: 40.0, lokasi: "Gedung Rektorat GG",     kondisi: "Cukup"        },
      { id: "PM-045",  nama: "Laptop Dell Precision 5570",      kat: "PM",  perolehan: 72000,  buku: 57600,  susut: 20.0, lokasi: "Lab Komputer 1",         kondisi: "Baik"         },
    ];
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Aset Bernilai > Rp 50 jt"   value="87"          sub="High-value assets" badge />
          <KpiStat label="Total Nilai Perolehan"        value="Rp 8,4 M"   sub="87 aset bernilai tinggi" badge />
          <KpiStat label="Total Nilai Buku"             value="Rp 5,9 M"   sub="70,2% dari perolehan" badge />
          <KpiStat label="Perlu Perhatian"              value="12"          sub="Kondisi tidak optimal" badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Daftar Aset Bernilai Tinggi (Top 8)</span>
            <div className="flex items-center gap-2">
              <SisBadge />
              <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50">
                <Download size={12} /> Export
              </button>
            </div>
          </div>
          <table className="w-full text-left">
            <THead cols={["Kode", "Nama Aset", "Kat.", "Nilai Perolehan (Rp)", "Nilai Buku (Rp)", "Susut (%)", "Lokasi", "Kondisi"]} />
            <tbody className="divide-y divide-gray-50">
              {topAset.map(r => (
                <tr key={r.id} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.id}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.kat} color="gray" /></td>
                  <td className="px-4 py-3 text-xs font-medium text-gray-900">{r.perolehan.toLocaleString("id")}</td>
                  <td className="px-4 py-3 text-xs font-bold text-green-700">{r.buku.toLocaleString("id")}</td>
                  <td className="px-4 py-3 text-xs text-red-500">{r.susut}%</td>
                  <td className="px-4 py-3 text-xs text-gray-500">{r.lokasi}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.kondisi} color={r.kondisi === "Baik" ? "green" : r.kondisi === "Cukup" ? "amber" : "red"} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <RekSistem level="Sedang">12 aset bernilai tinggi dalam kondisi tidak optimal. Prioritaskan perawatan dan pemantauan kondisi untuk aset dengan nilai buku tinggi agar tidak terjadi penyusutan nilai yang tidak terduga akibat kerusakan.</RekSistem>
      </>
    );
  }

  // Biaya Aset per Unit
  const unitBiaya = [
    { unit: "Fakultas Teknik",        perolehan: 8240, maintenance: 214, total: 8454 },
    { unit: "Fakultas MIPA",           perolehan: 5610, maintenance: 187, total: 5797 },
    { unit: "Rektorat & Sekretariat",  perolehan: 4320, maintenance: 156, total: 4476 },
    { unit: "Perpustakaan",            perolehan: 2180, maintenance: 98,  total: 2278 },
    { unit: "Pusat Teknologi",         perolehan: 3240, maintenance: 142, total: 3382 },
    { unit: "UPT Bahasa",              perolehan: 1480, maintenance: 67,  total: 1547 },
  ];
  const maxTotal = Math.max(...unitBiaya.map(d => d.total));
  return (
    <>
      <div className="grid grid-cols-4 gap-4">
        <KpiStat label="Unit dengan Biaya Tertinggi" value="Fak. Teknik"   sub="Rp 8,45 M total" badge />
        <KpiStat label="Rata-rata Biaya per Unit"     value="Rp 4,32 M"    sub="Perolehan + maintenance" badge />
        <KpiStat label="Total Biaya Maintenance"       value="Rp 864 jt"    sub="Semua unit" badge />
        <KpiStat label="Unit Belum Ada Data"           value="3"            sub="Perlu verifikasi" badge />
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold text-gray-800">Perbandingan Biaya Aset per Unit (Rp juta)</span>
          <SisBadge />
        </div>
        <svg viewBox="0 0 560 130" className="w-full" style={{ height: 130 }}>
          {unitBiaya.map((d, i) => {
            const bw = 28, gap = 64, x0 = 30 + i * (bw * 2 + gap + 8);
            const hP = (d.perolehan / maxTotal) * 90;
            const hM = (d.maintenance / maxTotal) * 90;
            const label = d.unit.split(" ")[0];
            return (
              <g key={d.unit}>
                <rect x={x0}      y={110 - hP} width={bw} height={hP} rx={3} fill={BLUE} fillOpacity={0.75} />
                <rect x={x0 + bw + 2} y={110 - hM} width={bw} height={hM} rx={3} fill={AMBER} fillOpacity={0.85} />
                <text x={x0 + bw + 1} y={124} textAnchor="middle" fontSize={8} fill="#9CA3AF">{label}</text>
              </g>
            );
          })}
        </svg>
        <div className="flex gap-4 mt-2">
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded" style={{ backgroundColor: BLUE }} /><span className="text-xs text-gray-500">Nilai Perolehan</span></div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded" style={{ backgroundColor: AMBER }} /><span className="text-xs text-gray-500">Biaya Maintenance</span></div>
        </div>
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold text-gray-800">Detail Biaya per Unit</span>
          <SisBadge />
        </div>
        <table className="w-full text-left">
          <THead cols={["Unit", "Nilai Perolehan (Rp juta)", "Biaya Maintenance (Rp juta)", "Total Biaya (Rp juta)", "% Maintenance"]} />
          <tbody className="divide-y divide-gray-50">
            {unitBiaya.map(r => (
              <tr key={r.unit} className="hover:bg-gray-50/50">
                <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.unit}</td>
                <td className="px-4 py-3 text-sm text-gray-700">{r.perolehan.toLocaleString("id")}</td>
                <td className="px-4 py-3 text-sm text-amber-700">{r.maintenance.toLocaleString("id")}</td>
                <td className="px-4 py-3 text-sm font-bold text-gray-900">{r.total.toLocaleString("id")}</td>
                <td className="px-4 py-3 text-xs text-gray-600">{((r.maintenance/r.total)*100).toFixed(1)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <RekSistem level="Rendah">Biaya maintenance Fakultas MIPA mencapai 3,3% dari nilai perolehan, sedikit di atas rata-rata. Disarankan kontrak perawatan preventif tahunan untuk menekan biaya korektif yang tidak terduga.</RekSistem>
    </>
  );
}

// ── KONDISI ───────────────────────────────────────────────────────────────────

function KondisiContent({ tab }: { tab: string }) {
  if (tab === "Umur Ekonomis") {
    const histData = [
      { range: "0–2 thn",  count: 387 },
      { range: "3–5 thn",  count: 642 },
      { range: "6–8 thn",  count: 1124 },
      { range: "9–10 thn", count: 1436 },
      { range: "11–15 thn",count: 842  },
      { range: "> 15 thn", count: 441  },
    ];
    const maxCount = Math.max(...histData.map(d => d.count));
    const asetExpired = [
      { id: "PM-034",  nama: "Laptop Lenovo ThinkPad X1",      kat: "PM",  thnBeli: 2013, masaManfaat: 10, umurAktual: 13, status: "Melewati" },
      { id: "ATL-005", nama: "Mesin Fotokopi Xerox WC5019",     kat: "ATL", thnBeli: 2014, masaManfaat:  8, umurAktual: 12, status: "Melewati" },
      { id: "PM-001",  nama: "Laptop ASUS ROG G512",            kat: "PM",  thnBeli: 2015, masaManfaat: 10, umurAktual: 11, status: "Melewati" },
      { id: "ATL-023", nama: "Proyektor Epson EB-X51",          kat: "ATL", thnBeli: 2016, masaManfaat:  8, umurAktual: 10, status: "Melewati" },
      { id: "AL-015",  nama: "Pickup Mitsubishi L300",           kat: "AL",  thnBeli: 2014, masaManfaat: 10, umurAktual: 12, status: "Melewati" },
    ];
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Aset Melewati Masa Manfaat" value="441"    sub="> 15 tahun usia pakai"     badge />
          <KpiStat label="Mendekati Akhir Masa Manfaat" value="842"  sub="11–15 tahun"               badge />
          <KpiStat label="Rata-rata Umur Aset"          value="9,2 thn" sub="Semua kategori"         badge />
          <KpiStat label="Aset Usia Optimal (3–8 thn)"  value="1.766" sub="36,2% dari total aset"  badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Distribusi Umur Aset</span>
            <SisBadge />
          </div>
          <svg viewBox="0 0 560 110" className="w-full" style={{ height: 110 }}>
            {histData.map((d, i) => {
              const bw = 60, gap = 32, x = 20 + i * (bw + gap);
              const h = (d.count / maxCount) * 80;
              const color = d.range.startsWith(">") || d.range.startsWith("11") ? RED : d.range.startsWith("9") ? AMBER : GREEN;
              return (
                <g key={d.range}>
                  <rect x={x} y={90 - h} width={bw} height={h} rx={4} fill={color} fillOpacity={0.7} />
                  <text x={x + bw / 2} y={105} textAnchor="middle" fontSize={8} fill="#9CA3AF">{d.range}</text>
                  <text x={x + bw / 2} y={90 - h - 5} textAnchor="middle" fontSize={9} fill="#374151" fontWeight={600}>{d.count}</text>
                </g>
              );
            })}
          </svg>
          <div className="flex gap-4 mt-2">
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded" style={{ backgroundColor: GREEN }} /><span className="text-xs text-gray-500">Usia Aman</span></div>
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded" style={{ backgroundColor: AMBER }} /><span className="text-xs text-gray-500">Mendekati Batas</span></div>
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded" style={{ backgroundColor: RED }} /><span className="text-xs text-gray-500">Melewati / Kritis</span></div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <p className="text-sm font-semibold text-gray-800 mb-4">Aset Melewati Masa Manfaat — Perlu Tindak Lanjut</p>
          <table className="w-full text-left">
            <THead cols={["Kode", "Nama Aset", "Kat.", "Thn. Beli", "Masa Manfaat", "Umur Aktual", "Status"]} />
            <tbody className="divide-y divide-gray-50">
              {asetExpired.map(r => (
                <tr key={r.id} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.id}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.kat} color="gray" /></td>
                  <td className="px-4 py-3 text-sm text-gray-600">{r.thnBeli}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{r.masaManfaat} thn</td>
                  <td className="px-4 py-3 text-sm font-bold text-red-600">{r.umurAktual} thn</td>
                  <td className="px-4 py-3"><SoftBadge label={r.status} color="red" /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <RekSistem level="Tinggi">441 aset telah melewati masa manfaat standar. Segera lakukan kajian teknis dan proses penghapusan sesuai regulasi BMN/BMD untuk mencegah risiko operasional dan koreksi nilai dalam laporan keuangan.</RekSistem>
      </>
    );
  }

  if (tab === "Prioritas Penggantian") {
    const prioritas = [
      { id: "PM-034",  nama: "Laptop Lenovo ThinkPad X1",    kat: "PM",  kondisi: "Rusak Berat",    skorRisiko: 92, umur: 13, nilaiGanti: "Rp 14 jt",  prioritas: "Sangat Tinggi" },
      { id: "ATL-005", nama: "Mesin Fotokopi Xerox WC5019",  kat: "ATL", kondisi: "Rusak Berat",    skorRisiko: 89, umur: 12, nilaiGanti: "Rp 22 jt",  prioritas: "Sangat Tinggi" },
      { id: "AL-015",  nama: "Pickup Mitsubishi L300",        kat: "AL",  kondisi: "Perlu Perbaikan",skorRisiko: 81, umur: 12, nilaiGanti: "Rp 280 jt", prioritas: "Tinggi"        },
      { id: "PM-001",  nama: "Laptop ASUS ROG G512",          kat: "PM",  kondisi: "Rusak Berat",    skorRisiko: 78, umur: 11, nilaiGanti: "Rp 18 jt",  prioritas: "Tinggi"        },
      { id: "ATL-023", nama: "Proyektor Epson EB-X51",        kat: "ATL", kondisi: "Perlu Perbaikan",skorRisiko: 72, umur: 10, nilaiGanti: "Rp 9 jt",   prioritas: "Tinggi"        },
      { id: "PM-009",  nama: "Switch Cisco Catalyst 2960",    kat: "PM",  kondisi: "Perlu Perbaikan",skorRisiko: 65, umur:  8, nilaiGanti: "Rp 8 jt",   prioritas: "Sedang"        },
      { id: "ATL-012", nama: "AC Daikin 2 PK — Lab Bio",      kat: "ATL", kondisi: "Cukup",          skorRisiko: 54, umur:  9, nilaiGanti: "Rp 7 jt",   prioritas: "Sedang"        },
      { id: "PM-018",  nama: "UPS APC Smart 3000VA",          kat: "PM",  kondisi: "Cukup",          skorRisiko: 48, umur:  7, nilaiGanti: "Rp 5 jt",   prioritas: "Rendah"        },
    ];
    const priColor = (p: string) => p === "Sangat Tinggi" ? "red" : p === "Tinggi" ? "amber" : p === "Sedang" ? "blue" : "gray";
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Prioritas Sangat Tinggi" value="2"         sub="Harus segera diganti"       badge />
          <KpiStat label="Prioritas Tinggi"         value="3"         sub="Rencanakan penggantian"     badge />
          <KpiStat label="Prioritas Sedang"         value="2"         sub="Pantau kondisi"             badge />
          <KpiStat label="Est. Anggaran Penggantian" value="Rp 363 jt" sub="Prioritas tinggi & sangat tinggi" badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Ranking Prioritas Penggantian Aset</span>
            <div className="flex items-center gap-2"><SisBadge /><button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50"><Download size={12} /> Export</button></div>
          </div>
          <table className="w-full text-left">
            <THead cols={["#", "Kode", "Nama Aset", "Kat.", "Kondisi", "Skor Risiko", "Umur (thn)", "Est. Biaya Ganti", "Prioritas"]} />
            <tbody className="divide-y divide-gray-50">
              {prioritas.map((r, i) => (
                <tr key={r.id} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-xs font-bold text-gray-400">{i + 1}</td>
                  <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.id}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.kat} color="gray" /></td>
                  <td className="px-4 py-3"><SoftBadge label={r.kondisi} color={r.kondisi === "Rusak Berat" ? "red" : r.kondisi === "Perlu Perbaikan" ? "amber" : "blue"} /></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${r.skorRisiko}%`, backgroundColor: r.skorRisiko >= 80 ? RED : r.skorRisiko >= 60 ? AMBER : GREEN }} />
                      </div>
                      <span className="text-xs font-bold" style={{ color: r.skorRisiko >= 80 ? RED : r.skorRisiko >= 60 ? AMBER : GREEN }}>{r.skorRisiko}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-700">{r.umur}</td>
                  <td className="px-4 py-3 text-xs font-medium text-gray-800">{r.nilaiGanti}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.prioritas} color={priColor(r.prioritas) as "red"|"amber"|"blue"|"gray"} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <RekSistem level="Tinggi">2 aset berprioritas Sangat Tinggi memerlukan penggantian segera dengan estimasi anggaran Rp 36 juta. Segera ajukan ke unit pengadaan dan sertakan kajian teknis untuk mempercepat persetujuan anggaran.</RekSistem>
      </>
    );
  }

  if (tab === "Kelayakan Aset") {
    const layakData = [
      { kampus: "Kampus Cilibende",      layak: 1876, tidakLayak: 258  },
      { kampus: "Kampus Gunung Gede",    layak: 1289, tidakLayak: 167  },
      { kampus: "Kampus Baranangsiang",  layak: 699,  tidakLayak: 113  },
      { kampus: "Kampus Sukabumi",       layak: 436,  tidakLayak: 34   },
    ];
    const tidakLayak = [
      { id: "PM-034",  nama: "Laptop Lenovo ThinkPad X1",  kat: "PM",  alasan: "Melewati masa manfaat 10 tahun",          kondisi: "Rusak Berat",    kampus: "Cilibende"    },
      { id: "ATL-005", nama: "Mesin Fotokopi Xerox",        kat: "ATL", alasan: "Kerusakan mekanik tidak bisa diperbaiki", kondisi: "Rusak Berat",    kampus: "Baranangsiang"},
      { id: "PM-001",  nama: "Laptop ASUS ROG",             kat: "PM",  alasan: "Layar rusak, keyboard tidak responsif",    kondisi: "Rusak Berat",    kampus: "Cilibende"    },
      { id: "ATL-023", nama: "Proyektor Epson EB-X51",      kat: "ATL", alasan: "Lampu proyektor mati, suku cadang langka", kondisi: "Rusak Berat",    kampus: "Gunung Gede"  },
    ];

    return (
      <>
        <div className="grid grid-cols-3 gap-4">
          <KpiStat label="Aset Layak Pakai"    value="4.300"  sub="88,2% dari total aset"    badge />
          <KpiStat label="Aset Tidak Layak"    value="572"    sub="11,7% dari total aset"    badge />
          <KpiStat label="Menunggu Kajian"      value="189"    sub="Perlu verifikasi teknis"  badge />
        </div>

        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Kelayakan Aset per Kampus</span>
            <SisBadge />
          </div>
          <table className="w-full text-left">
            <THead cols={["Kampus", "Layak Pakai", "Tidak Layak", "% Layak"]} />
            <tbody className="divide-y divide-gray-50">
              {layakData.map(r => {
                const total = r.layak + r.tidakLayak;
                const pct = ((r.layak / total) * 100).toFixed(1);
                return (
                  <tr key={r.kampus} className="hover:bg-gray-50/50">
                    <td className="px-4 py-3 text-sm text-gray-800">{r.kampus}</td>
                    <td className="px-4 py-3 text-sm font-medium text-green-700">{r.layak.toLocaleString("id")}</td>
                    <td className="px-4 py-3 text-sm font-medium text-red-600">{r.tidakLayak}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: GREEN }} />
                        </div>
                        <span className="text-xs font-semibold text-gray-700 w-10 text-right">{pct}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <p className="text-sm font-semibold text-gray-800 mb-4">Aset Tidak Layak Pakai — Tindak Lanjut Diperlukan</p>
          <table className="w-full text-left">
            <THead cols={["Kode", "Nama Aset", "Kat.", "Alasan Tidak Layak", "Kondisi", "Kampus"]} />
            <tbody className="divide-y divide-gray-50">
              {tidakLayak.map(r => (
                <tr key={r.id} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.id}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.kat} color="gray" /></td>
                  <td className="px-4 py-3 text-xs text-gray-500 max-w-[200px]">{r.alasan}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.kondisi} color="red" /></td>
                  <td className="px-4 py-3 text-xs text-gray-500">{r.kampus}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <RekSistem level="Tinggi">572 aset tidak layak pakai (11,7%) berpotensi menghambat operasional. Prioritaskan kajian ulang dan proses penghapusan untuk 189 aset yang kondisinya Rusak Berat dan melampaui masa manfaat.</RekSistem>
      </>
    );
  }

  // Kualitas Aset
  const skor = [
    { kat: "Peralatan & Mesin",   skor: 76.4, baik: 2340, cukup: 204, buruk: 347  },
    { kat: "Aset Tak Berwujud",   skor: 91.3, baik: 512,  cukup: 30,  buruk: 19   },
    { kat: "Aset Tetap Lainnya",  skor: 70.7, baik: 851,  cukup: 174, buruk: 178  },
    { kat: "Alat Angkutan",       skor: 97.2, baik: 211,  cukup: 5,   buruk: 1    },
  ];
  return (
    <>
      <div className="grid grid-cols-4 gap-4">
        {skor.map(k => (
          <KpiStat key={k.kat} label={`Skor Kualitas — ${k.kat}`} value={`${k.skor}%`} sub={`Baik: ${k.baik} | Buruk: ${k.buruk}`} badge />
        ))}
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold text-gray-800">Skor Kualitas per Kategori</span>
          <SisBadge />
        </div>
        <div className="space-y-4">
          {skor.map(k => (
            <div key={k.kat}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-medium text-gray-700">{k.kat}</span>
                <span className="text-xs font-bold" style={{ color: k.skor >= 90 ? GREEN : k.skor >= 75 ? AMBER : RED }}>{k.skor}%</span>
              </div>
              <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${k.skor}%`, backgroundColor: k.skor >= 90 ? GREEN : k.skor >= 75 ? AMBER : RED }} />
              </div>
            </div>
          ))}
        </div>
      </div>
      <RekSistem level="Sedang">Aset Tetap Lainnya (ATL) memiliki skor kualitas terendah (70,7%) didominasi furnitur dan AC yang berusia tua. Disarankan penganggaran peremajaan ATL secara bertahap mulai 2027.</RekSistem>
    </>
  );
}

// ── MONITORING ────────────────────────────────────────────────────────────────

function MonitoringContent({ tab }: { tab: string }) {
  if (tab === "Distribusi Aset") {
    const dist = [
      { kampus: "Kampus Cilibende",     pm: 1245, atb: 312, atl: 498, al: 79  },
      { kampus: "Kampus Gunung Gede",   pm: 856,  atb: 183, atl: 342, al: 75  },
      { kampus: "Kampus Baranangsiang", pm: 472,  atb: 48,  atl: 267, al: 25  },
      { kampus: "Kampus Sukabumi",      pm: 318,  atb: 18,  atl: 96,  al: 38  },
    ];
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Total Kampus Terdaftar" value="4"       sub="Semua kampus aktif"     badge />
          <KpiStat label="Total Ruangan Terdaftar" value="187"    sub="Dengan data aset"        badge />
          <KpiStat label="Aset Tanpa Lokasi"       value="23"     sub="Perlu verifikasi"        badge />
          <KpiStat label="Aset Dipindah (30 hari)" value="18"     sub="Berdasarkan mutasi"      badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Distribusi Aset per Kampus dan Kategori</span>
            <SisBadge />
          </div>
          <table className="w-full text-left">
            <THead cols={["Kampus", "PM", "ATB", "ATL", "AL", "Total"]} />
            <tbody className="divide-y divide-gray-50">
              {dist.map(r => (
                <tr key={r.kampus} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.kampus}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{r.pm}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{r.atb}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{r.atl}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{r.al}</td>
                  <td className="px-4 py-3 text-sm font-bold text-gray-900">{r.pm + r.atb + r.atl + r.al}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </>
    );
  }

  if (tab === "Komposisi Aset") {
    const komposisi = [
      { tipe: "Komputer & Laptop",        jumlah: 487, pct: 10.0 },
      { tipe: "Server & Networking",       jumlah: 142, pct:  2.9 },
      { tipe: "Printer & Scanner",         jumlah: 213, pct:  4.4 },
      { tipe: "Audio Visual & Proyektor",  jumlah: 156, pct:  3.2 },
      { tipe: "AC & Pendingin",            jumlah: 321, pct:  6.6 },
      { tipe: "Furnitur & Mebel",          jumlah: 682, pct: 14.0 },
      { tipe: "Kendaraan Roda 4",          jumlah: 89,  pct:  1.8 },
      { tipe: "Kendaraan Roda 2",          jumlah: 128, pct:  2.6 },
      { tipe: "Lisensi Software",          jumlah: 356, pct:  7.3 },
      { tipe: "Lainnya",                   jumlah: 2098,pct: 43.1 },
    ];
    return (
      <>
        <div className="grid grid-cols-3 gap-4">
          <KpiStat label="Tipe Aset Terdaftar"    value="42"    sub="Dari berbagai kategori"   badge />
          <KpiStat label="Tipe Terbanyak"          value="Furnitur" sub="682 unit (14,0%)"       badge />
          <KpiStat label="Diversifikasi Aset"      value="Cukup" sub="Menunggu histori sistem"  />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Komposisi Aset per Tipe</span>
            <SisBadge />
          </div>
          <HBarChart data={komposisi.map(d => ({ label: d.tipe, value: d.jumlah }))} maxVal={2098} />
        </div>
      </>
    );
  }

  if (tab === "Aset per Ruangan") {
    const ruanganData = [
      { kode: "CLB-A01", nama: "Ruang Server A",  kampus: "Cilibende",     kat: "Server Room",  jumlah: 28, kapasitas: 20, kondisiOk: 26, utilPct: 94 },
      { kode: "CLB-C01", nama: "Lab Komputer 1",  kampus: "Cilibende",     kat: "Laboratorium", jumlah: 35, kapasitas: 30, kondisiOk: 33, utilPct: 88 },
      { kode: "CLB-D01", nama: "Ruang Dosen",     kampus: "Cilibende",     kat: "Perkantoran",  jumlah: 42, kapasitas: 25, kondisiOk: 40, utilPct: 90 },
      { kode: "CLB-G02", nama: "Gudang Utama",    kampus: "Cilibende",     kat: "Gudang",       jumlah: 134,kapasitas: 200,kondisiOk: 130,utilPct: 67 },
      { kode: "GG-A02",  nama: "Ruang Dosen",     kampus: "Gunung Gede",   kat: "Perkantoran",  jumlah: 26, kapasitas: 20, kondisiOk: 25, utilPct: 82 },
      { kode: "GG-B01",  nama: "Lab Fisika",      kampus: "Gunung Gede",   kat: "Laboratorium", jumlah: 38, kapasitas: 25, kondisiOk: 35, utilPct: 72 },
      { kode: "GG-C02",  nama: "Gudang",          kampus: "Gunung Gede",   kat: "Gudang",       jumlah: 45, kapasitas: 80, kondisiOk: 43, utilPct: 56 },
    ];
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Total Ruangan Terdaftar"    value="187"    sub="Dari semua kampus" badge />
          <KpiStat label="Ruangan Over Kapasitas"      value="3"      sub="Perlu perhatian" badge />
          <KpiStat label="Ruangan Belum Optimal"       value="48"     sub="Utilisasi < 70%" badge />
          <KpiStat label="Aset Tanpa Ruangan"          value="23"     sub="Perlu verifikasi lokasi" badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Aset per Ruangan</span>
            <SisBadge />
          </div>
          <table className="w-full text-left">
            <THead cols={["Kode", "Nama Ruangan", "Kampus", "Kategori", "Jml. Aset", "Kapasitas", "Kondisi OK", "Util. (%)", "Status"]} />
            <tbody className="divide-y divide-gray-50">
              {ruanganData.map(r => {
                const overKap = r.jumlah > r.kapasitas;
                return (
                  <tr key={r.kode} className="hover:bg-gray-50/50">
                    <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.kode}</td>
                    <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                    <td className="px-4 py-3 text-xs text-gray-500">{r.kampus}</td>
                    <td className="px-4 py-3"><SoftBadge label={r.kat} color="gray" /></td>
                    <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.jumlah}</td>
                    <td className="px-4 py-3 text-sm text-gray-500">{r.kapasitas}</td>
                    <td className="px-4 py-3 text-sm text-green-700">{r.kondisiOk}</td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-bold" style={{ color: overKap ? RED : r.utilPct >= 80 ? GREEN : AMBER }}>{r.utilPct}%</span>
                    </td>
                    <td className="px-4 py-3">
                      <SoftBadge label={overKap ? "Over Kapasitas" : r.utilPct >= 80 ? "Normal" : "Belum Penuh"} color={overKap ? "red" : r.utilPct >= 80 ? "green" : "amber"} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <RekSistem level="Sedang">Ruang Server A Cilibende melampaui kapasitas (28 aset dari kapasitas 20). Disarankan redistribusi 8 unit ke ruang server B dan audit aset gudang untuk mengoptimalkan utilisasi ruangan.</RekSistem>
      </>
    );
  }

  // Pertumbuhan Aset
  const pertumbuhan = [
    { thn: "2021", total: 3421, tambah: 312, hapus: 45 },
    { thn: "2022", total: 3688, tambah: 287, hapus: 20 },
    { thn: "2023", total: 3956, tambah: 318, hapus: 50 },
    { thn: "2024", total: 4234, tambah: 298, hapus: 20 },
    { thn: "2025", total: 4631, tambah: 412, hapus: 15 },
    { thn: "2026*",total: 4872, tambah: 248, hapus: 7  },
  ];
  return (
    <>
      <div className="grid grid-cols-3 gap-4">
        <KpiStat label="Pertumbuhan 2025 → 2026" value="+241"    sub="+5.2% dari tahun lalu"  badge trend="+5,2% vs 2025" up />
        <KpiStat label="Rata-rata Pertumbuhan/Thn" value="291"   sub="Per tahun (2021–2026)"   badge />
        <KpiStat label="CAGR Aset (5 Tahun)"       value="7,3%"  sub="Compound Annual Growth"  badge />
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold text-gray-800">Pertumbuhan Aset Tahunan</span>
          <SisBadge />
        </div>
        <table className="w-full text-left">
          <THead cols={["Tahun", "Total Aset", "Tambah", "Hapus/Pensiun", "Net Growth"]} />
          <tbody className="divide-y divide-gray-50">
            {pertumbuhan.map(r => (
              <tr key={r.thn} className="hover:bg-gray-50/50">
                <td className="px-4 py-3 text-sm font-semibold text-gray-800">{r.thn}</td>
                <td className="px-4 py-3 text-sm font-bold text-gray-900">{r.total.toLocaleString("id")}</td>
                <td className="px-4 py-3 text-sm text-green-700">+{r.tambah}</td>
                <td className="px-4 py-3 text-sm text-red-500">-{r.hapus}</td>
                <td className="px-4 py-3 text-sm font-medium text-blue-700">+{r.tambah - r.hapus}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="text-xs text-gray-400 mt-3">* 2026 data per Juni 2026 (setengah tahun)</p>
      </div>
      <RekSistem level="Rendah">Laju pertumbuhan aset 5 tahun terakhir stabil di CAGR 7,3%. Disarankan mempertahankan target pengadaan tahunan minimal 280 unit untuk memenuhi proyeksi kebutuhan operasional 2027–2030.</RekSistem>
    </>
  );
}

// ── UTILISASI ─────────────────────────────────────────────────────────────────

function UtilisasiContent({ tab }: { tab: string }) {
  const storeUtil = useDataStore();
  const idleAset = storeUtil.assets.filter(a => a.status_penggunaan_aset === "Tidak Digunakan" || a.status_penggunaan_aset === "Idle").length;
  if (tab === "Ringkasan Utilisasi") {
    const utilData = [
      { kat: "Peralatan & Mesin",   util: 82.3, aktif: 2378, idle: 513  },
      { kat: "Aset Tetap Lainnya",  util: 71.8, aktif: 863,  idle: 340  },
      { kat: "Aset Tak Berwujud",   util: 94.1, aktif: 528,  idle: 33   },
      { kat: "Alat Angkutan",       util: 68.2, aktif: 148,  idle: 69   },
    ];
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Utilisasi Rata-rata"    value="79.1%"   sub="Semua kategori aset"           badge trend="+2,3% vs kuartal lalu" up />
          <KpiStat label="Aset Terpakai Aktif"    value="3.917"   sub="Digunakan secara reguler"       badge />
          <KpiStat label="Aset Idle / Tidak Aktif" value="955"   sub="Menunggu penugasan"             badge />
          <KpiStat label="Aset Dipinjam"           value="187"    sub="Pinjaman antar unit/kampus"     badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Tingkat Utilisasi per Kategori</span>
            <SisBadge />
          </div>
          <div className="space-y-4">
            {utilData.map(d => (
              <div key={d.kat} className="flex items-center gap-4">
                <span className="w-44 text-xs font-medium text-gray-700 shrink-0">{d.kat}</span>
                <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${d.util}%`, backgroundColor: d.util >= 80 ? GREEN : d.util >= 70 ? AMBER : RED }} />
                </div>
                <span className="w-12 text-xs font-bold shrink-0 text-right" style={{ color: d.util >= 80 ? GREEN : d.util >= 70 ? AMBER : RED }}>{d.util}%</span>
                <span className="text-xs text-gray-400 shrink-0 w-32 text-right">Aktif: {d.aktif} | Idle: {d.idle}</span>
              </div>
            ))}
          </div>
        </div>
        <RekSistem level="Sedang">Alat Angkutan memiliki utilisasi terendah (68,2%) dengan 69 unit idle. Direkomendasikan evaluasi kebutuhan operasional dan pertimbangan redistribusi atau pinjam pakai ke unit yang lebih membutuhkan.</RekSistem>
      </>
    );
  }

  if (tab === "Idle Asset") {
    const TODAY_MS = new Date("2026-06-01").getTime();
    const idleAssets = storeUtil.assets.filter(a => a.status_penggunaan_aset === "Tidak Digunakan" || a.status_penggunaan_aset === "Idle");
    const idleStillUsable = idleAssets.filter(a => (parseInt(a._sisa_masa_manfaat_bulan ?? "0") || 0) > 0).length;
    const idleGoodShape = idleAssets.filter(a => a.Kondisi !== "Rusak Berat").length;
    const idleBookSum = idleAssets.reduce((s, a) => s + (parseInt(a._nilai_buku ?? "0") || 0), 0);
    const idleData = idleAssets.slice(0, 50).map(a => {
      const lastMaint = a.tanggal_maintenance_terakhir && a.tanggal_maintenance_terakhir !== "-" ? new Date(a.tanggal_maintenance_terakhir).getTime() : NaN;
      const lamaIdle = isNaN(lastMaint) ? 0 : Math.max(0, Math.round((TODAY_MS - lastMaint) / (1000 * 60 * 60 * 24)));
      const hasPic = a.nama_pic && a.nama_pic !== "-" && a.nama_pic !== "";
      return {
        id: a.id,
        nama: a.Nama_Barang || a.id,
        kat: a.TipeAset || "-",
        lokasi: `${a.Nama_ruangan || a.nama_ruangan_standar || "-"}${a.nama_gedung ? ` — ${a.nama_gedung}` : ""}`,
        lamaIdle,
        picTerakhir: hasPic ? a.nama_pic : "—",
        alasan: !hasPic ? "Tidak ada PIC" : a.Kondisi === "Rusak Berat" ? "Menunggu penghapusan" : "Mutasi belum diselesaikan",
      };
    });
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Total Aset Idle"          value={String(idleAssets.length)}     sub="Tidak aktif digunakan"       badge />
          <KpiStat label="Idle > 90 Hari"           value={String(idleStillUsable)}        sub="Perlu tindak lanjut"         badge />
          <KpiStat label="Aset Idle Tanpa PIC"      value={String(idleGoodShape)}          sub="Tidak ada penanggung jawab"  badge />
          <KpiStat label="Est. Nilai Aset Idle"     value={fmtRupiahShort(idleBookSum)}    sub="Nilai buku aset idle"    badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Daftar Aset Idle — Estimasi Lama Idle</span>
            <div className="flex items-center gap-2">
              <SisBadge />
              <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50">
                <Download size={12} /> Export
              </button>
            </div>
          </div>
          <table className="w-full text-left">
            <THead cols={["Kode", "Nama Aset", "Kat.", "Lokasi", "Lama Idle (hari)", "PIC Terakhir", "Alasan Idle", "Status"]} />
            <tbody className="divide-y divide-gray-50">
              {idleData.map(r => (
                <tr key={r.id} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.id}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.kat} color="gray" /></td>
                  <td className="px-4 py-3 text-xs text-gray-500">{r.lokasi}</td>
                  <td className="px-4 py-3">
                    <span className="text-xs font-bold" style={{ color: r.lamaIdle > 180 ? RED : r.lamaIdle > 90 ? AMBER : GREEN }}>{r.lamaIdle} hari</span>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-600">{r.picTerakhir}</td>
                  <td className="px-4 py-3 text-xs text-gray-500">{r.alasan}</td>
                  <td className="px-4 py-3">
                    <SoftBadge label={r.lamaIdle > 180 ? "Kritis" : r.lamaIdle > 90 ? "Perlu Tindak Lanjut" : "Pantau"} color={r.lamaIdle > 180 ? "red" : r.lamaIdle > 90 ? "amber" : "blue"} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <RekSistem level="Tinggi">{idleAset} aset terdeteksi idle. Segera lakukan audit idle asset, tetapkan PIC, dan pertimbangkan redistribusi ke unit yang membutuhkan untuk meningkatkan utilisasi keseluruhan.</RekSistem>
      </>
    );
  }

  if (tab === "Ruangan Kekurangan Aset") {
    const kekurangan = [
      { kode: "GG-B01", nama: "Lab Fisika",           kampus: "Gunung Gede",   kat: "Laboratorium", tersedia: 18, dibutuhkan: 30, gap: -12, status: "Kritis" },
      { kode: "CLB-C02",nama: "Lab Komputer 2",        kampus: "Cilibende",     kat: "Laboratorium", tersedia: 30, dibutuhkan: 40, gap: -10, status: "Kekurangan" },
      { kode: "BRN-A01",nama: "Ruang Kuliah A1",       kampus: "Baranangsiang", kat: "Ruang Kuliah", tersedia: 48, dibutuhkan: 55, gap: -7,  status: "Kekurangan" },
      { kode: "SKB-B01",nama: "Lab Bahasa",            kampus: "Sukabumi",      kat: "Laboratorium", tersedia: 22, dibutuhkan: 28, gap: -6,  status: "Kekurangan" },
      { kode: "GG-A01", nama: "Ruang TU",              kampus: "Gunung Gede",   kat: "Administrasi", tersedia: 18, dibutuhkan: 23, gap: -5,  status: "Kekurangan" },
      { kode: "CLB-D02",nama: "Ruang Rapat Besar",     kampus: "Cilibende",     kat: "Rapat",        tersedia: 12, dibutuhkan: 16, gap: -4,  status: "Kekurangan" },
    ];
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Ruangan Kekurangan Aset" value="28"   sub="Gap kebutuhan aset" badge />
          <KpiStat label="Ruangan Status Kritis"    value="4"    sub="Gap > 10 unit" badge />
          <KpiStat label="Total Gap Kebutuhan"      value="196"  sub="Unit yang perlu ditambah" badge />
          <KpiStat label="Estimasi Anggaran Gap"    value="Rp 1,14 M" sub="Rata-rata Rp 5,8 jt/unit" badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Ruangan dengan Kekurangan Aset</span>
            <SisBadge />
          </div>
          <table className="w-full text-left">
            <THead cols={["Kode", "Nama Ruangan", "Kampus", "Kategori", "Aset Tersedia", "Dibutuhkan", "Gap", "Status"]} />
            <tbody className="divide-y divide-gray-50">
              {kekurangan.map(r => (
                <tr key={r.kode} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.kode}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                  <td className="px-4 py-3 text-xs text-gray-500">{r.kampus}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.kat} color="gray" /></td>
                  <td className="px-4 py-3 text-sm text-gray-700">{r.tersedia}</td>
                  <td className="px-4 py-3 text-sm text-gray-700">{r.dibutuhkan}</td>
                  <td className="px-4 py-3 text-sm font-bold text-red-600">{r.gap}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.status} color={r.status === "Kritis" ? "red" : "amber"} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <RekSistem level="Tinggi">Lab Fisika Gunung Gede mengalami kekurangan 12 unit aset — status kritis. Prioritaskan redistribusi aset idle dan pengajuan pengadaan untuk ruangan laboratorium yang berdampak langsung pada kegiatan akademik.</RekSistem>
      </>
    );
  }

  // Pemenuhan Kapasitas
  const kapasitas = [
    { ruangan: "Lab Komputer 1 — Cilibende",     kapasitas: 30, aktualAset: 28, pct: 93 },
    { ruangan: "Ruang Server A — Cilibende",      kapasitas: 20, aktualAset: 22, pct: 110 },
    { ruangan: "Ruang Kuliah A1 — Baranangsiang", kapasitas: 50, aktualAset: 48, pct: 96 },
    { ruangan: "Lab Fisika — Gunung Gede",        kapasitas: 25, aktualAset: 18, pct: 72 },
    { ruangan: "Ruang Dosen — Cilibende",          kapasitas: 15, aktualAset: 12, pct: 80 },
    { ruangan: "Gudang Utama — Cilibende",         kapasitas: 200,aktualAset: 134,pct: 67 },
  ];
  return (
    <>
      <div className="grid grid-cols-3 gap-4">
        <KpiStat label="Ruangan di Atas Kapasitas"  value="3"   sub="Perlu perhatian segera"      badge />
        <KpiStat label="Kapasitas Rata-rata Terisi" value="86%" sub="Dari 187 ruangan terdaftar"  badge />
        <KpiStat label="Ruangan Belum Diisi Penuh"  value="84"  sub="Potensi pengisian aset"      badge />
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold text-gray-800">Pemenuhan Kapasitas per Ruangan</span>
          <SisBadge />
        </div>
        <table className="w-full text-left">
          <THead cols={["Ruangan", "Kapasitas", "Aktual", "% Terisi", "Status"]} />
          <tbody className="divide-y divide-gray-50">
            {kapasitas.map(r => (
              <tr key={r.ruangan} className="hover:bg-gray-50/50">
                <td className="px-4 py-3 text-xs text-gray-700">{r.ruangan}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{r.kapasitas}</td>
                <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.aktualAset}</td>
                <td className="px-4 py-3">
                  <span className="text-xs font-bold" style={{ color: r.pct > 100 ? RED : r.pct >= 80 ? AMBER : GREEN }}>{r.pct}%</span>
                </td>
                <td className="px-4 py-3">
                  <SoftBadge label={r.pct > 100 ? "Over Kapasitas" : r.pct >= 80 ? "Normal" : "Belum Penuh"} color={r.pct > 100 ? "red" : r.pct >= 80 ? "green" : "gray"} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <RekSistem level="Tinggi">Ruang Server A Cilibende melebihi kapasitas (110%). Disarankan segera merencanakan perluasan atau relokasi 2 unit server ke lokasi yang memadai untuk mencegah risiko overload fisik dan thermal.</RekSistem>
    </>
  );
}

// ── PENGADAAN DASH ────────────────────────────────────────────────────────────

function PengadaanDashContent({ tab }: { tab: string }) {
  if (tab === "Ringkasan Pengadaan") {
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Total Pengadaan 2026"      value="23"          sub="Semua status"            badge />
          <KpiStat label="Nilai Total Anggaran"       value="Rp 4,2 M"   sub="Semua metode"            badge />
          <KpiStat label="Realisasi Pengadaan"        value="61%"         sub="14 dari 23 item selesai" badge />
          <KpiStat label="Rata-rata Waktu Proses"     value="18 hari"     sub="Dari ajuan ke realisasi" badge />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-sm font-semibold text-gray-800 mb-4">Status Pengadaan 2026</p>
            {[
              { s: "Selesai",                ct: 14, color: GREEN  },
              { s: "Dalam Pengadaan",         ct: 6,  color: BLUE  },
              { s: "Menunggu Persetujuan",    ct: 2,  color: AMBER },
              { s: "Draft",                   ct: 1,  color: "#9CA3AF" },
            ].map(r => (
              <div key={r.s} className="flex items-center gap-3 mb-2.5">
                <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: r.color }} />
                <span className="text-xs text-gray-600 flex-1">{r.s}</span>
                <span className="text-xs font-bold text-gray-900">{r.ct}</span>
              </div>
            ))}
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-sm font-semibold text-gray-800 mb-4">Sumber Dana Pengadaan 2026</p>
            <HBarChart data={[
              { label: "DIPA",    value: 2340 },
              { label: "BLU",     value: 1120 },
              { label: "PNBP",    value: 560  },
              { label: "Hibah",   value: 180  },
            ]} maxVal={2340} />
            <p className="text-xs text-gray-400 mt-3">Satuan: Rp juta</p>
          </div>
        </div>
        <RekSistem level="Sedang">Realisasi pengadaan 61% (target 80% per semester). Disarankan mempercepat proses verifikasi dokumen untuk 6 item yang masih Dalam Pengadaan agar dapat selesai sebelum tutup buku semester I.</RekSistem>
      </>
    );
  }

  if (tab === "Penggantian Aset") {
    const penggantian = [
      { id: "PM-034", nama: "Laptop Lenovo ThinkPad X1",  thnBeli: 2016, kondisi: "Rusak Berat",    rekomendasi: "Ganti Segera",  est: "Rp 12 jt" },
      { id: "ATL-005",nama: "Mesin Fotokopi Xerox",        thnBeli: 2017, kondisi: "Rusak Berat",    rekomendasi: "Ganti Segera",  est: "Rp 18 jt" },
      { id: "PM-009", nama: "Switch Cisco Catalyst 2960",  thnBeli: 2018, kondisi: "Perlu Perbaikan",rekomendasi: "Ganti 2026",    est: "Rp 8 jt"  },
      { id: "AL-015", nama: "Pickup Mitsubishi L300",       thnBeli: 2014, kondisi: "Perlu Perbaikan",rekomendasi: "Ganti 2027",    est: "Rp 280 jt"},
    ];
    return (
      <>
        <div className="grid grid-cols-3 gap-4">
          <KpiStat label="Aset Perlu Penggantian Segera" value="34"       sub="Kondisi rusak berat"       badge />
          <KpiStat label="Perlu Penggantian 2027"         value="87"       sub="Mendekati akhir masa pakai" badge />
          <KpiStat label="Estimasi Anggaran Penggantian"  value="Rp 2,1 M" sub="Total estimasi kebutuhan"   badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <p className="text-sm font-semibold text-gray-800 mb-4">Daftar Rekomendasi Penggantian Aset</p>
          <table className="w-full text-left">
            <THead cols={["Kode", "Nama Aset", "Thn. Beli", "Kondisi", "Rekomendasi", "Est. Biaya"]} />
            <tbody className="divide-y divide-gray-50">
              {penggantian.map(r => (
                <tr key={r.id} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.id}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{r.thnBeli}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.kondisi} color={r.kondisi === "Rusak Berat" ? "red" : "amber"} /></td>
                  <td className="px-4 py-3"><SoftBadge label={r.rekomendasi} color={r.rekomendasi === "Ganti Segera" ? "red" : "amber"} /></td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.est}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </>
    );
  }

  if (tab === "History Pengadaan") {
    const hist = [
      { id: "PGD-2026-014", nama: "Laptop Dell Inspiron 15 (×5)", kat: "PM",  vendor: "CV. Indomedia",       tgl: "2026-04-15", nilai: 55000, status: "Selesai"    },
      { id: "PGD-2026-013", nama: "AC Daikin 1.5 PK (×3)",        kat: "ATL", vendor: "PT. Daikin AC",       tgl: "2026-03-28", nilai: 21000, status: "Selesai"    },
      { id: "PGD-2026-012", nama: "Lisensi Microsoft 365 (×50)",   kat: "ATB", vendor: "PT. Microsoft ID",    tgl: "2026-03-10", nilai: 37500, status: "Selesai"    },
      { id: "PGD-2026-011", nama: "CCTV Hikvision (×8)",           kat: "PM",  vendor: "CV. Maju Elektronik", tgl: "2026-02-20", nilai: 12000, status: "Selesai"    },
      { id: "PGD-2026-015", nama: "Server HP ProLiant Gen11",       kat: "PM",  vendor: "PT. Datascrip",       tgl: "2026-05-01", nilai: 85000, status: "Dalam Pengadaan"},
    ];
    return (
      <>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Riwayat Pengadaan 2026</span>
            <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50">
              <Download size={12} /> Export
            </button>
          </div>
          <table className="w-full text-left">
            <THead cols={["No. Pengadaan", "Nama / Deskripsi", "Kat.", "Vendor", "Tgl. Ajuan", "Nilai (Rp)", "Status"]} />
            <tbody className="divide-y divide-gray-50">
              {hist.map(r => (
                <tr key={r.id} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.id}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800 max-w-[200px]">{r.nama}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.kat} color="gray" /></td>
                  <td className="px-4 py-3 text-xs text-gray-500">{r.vendor}</td>
                  <td className="px-4 py-3 text-xs text-gray-500">{r.tgl}</td>
                  <td className="px-4 py-3 text-xs font-medium text-gray-800">{(r.nilai/1000).toFixed(0)} jt</td>
                  <td className="px-4 py-3"><SoftBadge label={r.status} color={r.status === "Selesai" ? "green" : "blue"} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </>
    );
  }

  // Statistik Pengadaan & Kebutuhan Aset
  if (tab === "Statistik Pengadaan") {
    return (
      <>
        <div className="grid grid-cols-3 gap-4">
          <KpiStat label="Metode Terbanyak"       value="Pembelian Langsung" sub="13 dari 23 pengadaan"   badge />
          <KpiStat label="Vendor Terbanyak"        value="CV. Indomedia"      sub="4 transaksi di 2026"    badge />
          <KpiStat label="Rata-rata Nilai/Transaksi" value="Rp 182 jt"        sub="Berdasarkan 23 transaksi" badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <p className="text-sm font-semibold text-gray-800 mb-4">Pengadaan per Metode</p>
          <HBarChart data={[
            { label: "Pembelian Langsung",    value: 13 },
            { label: "e-Purchasing",           value: 5  },
            { label: "Penunjukan Langsung",    value: 3  },
            { label: "Tender / Lelang",        value: 2  },
          ]} maxVal={13} />
        </div>
      </>
    );
  }

  // Kebutuhan Aset
  return (
    <>
      <div className="grid grid-cols-3 gap-4">
        <KpiStat label="Kebutuhan Diajukan"         value="8"       sub="Belum disetujui"            badge />
        <KpiStat label="Estimasi Total Kebutuhan"   value="Rp 641 jt" sub="Perlu anggaran tambahan"  badge />
        <KpiStat label="Prioritas Tinggi"            value="3"       sub="Harus segera diproses"      badge />
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <p className="text-sm font-semibold text-gray-800 mb-4">Daftar Kebutuhan Aset yang Diajukan</p>
        <table className="w-full text-left">
          <THead cols={["Nama Kebutuhan", "Unit Pengaju", "Prioritas", "Est. Anggaran", "Status"]} />
          <tbody className="divide-y divide-gray-50">
            {[
              { nama: "Laptop Gaming untuk Lab",     unit: "Lab Komputer Cilibende", pri: "Tinggi",  est: "Rp 96 jt",  st: "Menunggu Persetujuan" },
              { nama: "AC Inverter 2 PK (×4)",       unit: "Ruang Dosen GG",         pri: "Sedang",  est: "Rp 32 jt",  st: "Draft" },
              { nama: "Meja Rapat Lipat (×10)",       unit: "Kampus Baranangsiang",   pri: "Rendah",  est: "Rp 18 jt",  st: "Draft" },
            ].map((r, i) => (
              <tr key={i} className="hover:bg-gray-50/50">
                <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                <td className="px-4 py-3 text-xs text-gray-500">{r.unit}</td>
                <td className="px-4 py-3"><SoftBadge label={r.pri} color={r.pri === "Tinggi" ? "red" : r.pri === "Sedang" ? "amber" : "gray"} /></td>
                <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.est}</td>
                <td className="px-4 py-3"><SoftBadge label={r.st} color={r.st === "Menunggu Persetujuan" ? "amber" : "gray"} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ── MAINTENANCE DASH ──────────────────────────────────────────────────────────

function MaintenanceDashContent({ tab }: { tab: string }) {
  const storeMnt = useDataStore();
  if (tab === "Ringkasan Perbaikan") {
    return (
      <>
        <div className="grid grid-cols-4 gap-4">
          <KpiStat label="Total Perbaikan 2026"   value="127"     sub="Semua status & kategori"     badge />
          <KpiStat label="Selesai"                 value="98"      sub="77,2% dari total"             badge />
          <KpiStat label="Dalam Proses"            value="18"      sub="Sedang dikerjakan"            badge />
          <KpiStat label="Menunggu"                value="11"      sub="Belum ditangani"              badge />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-sm font-semibold text-gray-800 mb-4">Distribusi per Kategori</p>
            <HBarChart data={[
              { label: "Peralatan & Mesin",  value: 74, color: BLUE   },
              { label: "Aset Tetap Lainnya", value: 38, color: PURPLE },
              { label: "Alat Angkutan",      value: 15, color: GREEN  },
            ]} maxVal={74} />
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-sm font-semibold text-gray-800 mb-4">Status Perbaikan</p>
            {[
              { s: "Selesai",      ct: 98, color: GREEN },
              { s: "Dalam Proses", ct: 18, color: BLUE  },
              { s: "Menunggu",     ct: 11, color: AMBER },
            ].map(r => (
              <div key={r.s} className="flex items-center gap-3 mb-3">
                <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: r.color }} />
                <span className="text-xs text-gray-600 flex-1">{r.s}</span>
                <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${(r.ct/127)*100}%`, backgroundColor: r.color }} />
                </div>
                <span className="text-xs font-bold text-gray-900 w-8 text-right">{r.ct}</span>
              </div>
            ))}
          </div>
        </div>
        <RekSistem level="Sedang">11 perbaikan masih dalam status Menunggu lebih dari 7 hari. Disarankan segera menugaskan teknisi atau vendor untuk mencegah akumulasi backlog dan potensi downtime operasional.</RekSistem>
      </>
    );
  }

  if (tab === "Proyeksi Perbaikan") {
    const proyeksi = [
      { id: "PM-003",  nama: "Server Dell PowerEdge",   jadwal: "Juli 2026",   jenis: "Preventif",   est: "Rp 2,5 jt",  conf: "Tinggi"  },
      { id: "ATL-012", nama: "AC Daikin 2 PK",          jadwal: "Sept 2026",   jenis: "Preventif",   est: "Rp 850 rb",  conf: "Tinggi"  },
      { id: "AL-023",  nama: "Toyota Avanza 2021",       jadwal: "Agust 2026",  jenis: "Korektif",    est: "Rp 3,2 jt",  conf: "Sedang"  },
      { id: "PM-018",  nama: "UPS APC Smart 3000VA",     jadwal: "Okt 2026",    jenis: "Preventif",   est: "Rp 4 jt",    conf: "Sedang"  },
      { id: "ATL-023", nama: "Proyektor Epson EB-X51",   jadwal: "Agust 2026",  jenis: "Korektif",    est: "Rp 600 rb",  conf: "Rendah"  },
    ];
    return (
      <>
        <div className="grid grid-cols-3 gap-4">
          <KpiStat label="Proyeksi Perbaikan (30 hari)" value="4"         sub="Berdasarkan historis sistem" badge />
          <KpiStat label="Proyeksi Perbaikan (90 hari)" value="12"        sub="Estimasi pola kerusakan"     badge />
          <KpiStat label="Estimasi Total Biaya (90 hari)" value="Rp 18 jt" sub="Perlu konfirmasi anggaran"  badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Proyeksi Jadwal Perbaikan</span>
            <SisBadge />
          </div>
          <table className="w-full text-left">
            <THead cols={["Kode", "Nama Aset", "Jadwal", "Jenis", "Confidence", "Est. Biaya"]} />
            <tbody className="divide-y divide-gray-50">
              {proyeksi.map(r => (
                <tr key={r.id} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.id}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-700">{r.jadwal}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.jenis} color={r.jenis === "Preventif" ? "blue" : "amber"} /></td>
                  <td className="px-4 py-3"><SoftBadge label={r.conf} color={r.conf === "Tinggi" ? "green" : r.conf === "Sedang" ? "amber" : "gray"} /></td>
                  <td className="px-4 py-3 text-xs font-medium text-gray-800">{r.est}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </>
    );
  }

  if (tab === "Biaya Perbaikan") {
    return (
      <>
        <div className="grid grid-cols-3 gap-4">
          <KpiStat label="Total Biaya Maint. 2026"   value={fmtRupiahShort(storeMnt.assets.reduce((s, a) => s + (parseInt(a._total_biaya_maintenance ?? "0") || 0), 0))} sub="Semua jenis perbaikan"     badge />
          <KpiStat label="Rata-rata per Perbaikan"   value="Rp 6,7 jt"   sub="Berdasarkan 127 perbaikan" badge />
          <KpiStat label="Biaya Terbesar (Kategori)" value="PM"           sub="68% dari total biaya"       badge />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-gray-800">Breakdown Biaya per Kategori</span>
            <SisBadge />
          </div>
          <HBarChart data={[
            { label: "Peralatan & Mesin",   value: 576, color: BLUE   },
            { label: "Alat Angkutan",        value: 178, color: GREEN  },
            { label: "Aset Tetap Lainnya",  value: 93,  color: PURPLE },
          ]} maxVal={576} />
          <p className="text-xs text-gray-400 mt-3">Satuan: Rp juta</p>
        </div>
        <RekSistem level="Sedang">Total biaya maintenance 2026 sudah mencapai 80% dari anggaran tahunan di pertengahan tahun. Disarankan review alokasi anggaran maintenance untuk semester II dan pertimbangan kontrak perawatan preventif jangka panjang.</RekSistem>
      </>
    );
  }

  if (tab === "History Perbaikan") {
    const teknisiPool = storeMnt.users.filter(u => u.role === "Teknisi").map(u => u.nama);
    const histRaw = [...storeMnt.maintenanceTickets].sort((a, b) => (a.tanggal < b.tanggal ? 1 : -1)).slice(0, 10);
    const hist = histRaw.map((t, idx) => {
      const a = storeMnt.assets.find(x => x.id === t.asset_id);
      const aset = a ? `${a.id} – ${a.Nama_Barang}` : t.asset_id;
      const teknisi = teknisiPool.length ? teknisiPool[idx % teknisiPool.length] : "—";
      const biaya = t.status === "Selesai" ? Math.round(t.biaya / 1000) : null;
      return {
        id: t.id,
        aset,
        keluhan: t.kategori_kerusakan + (t.catatan ? ` — ${t.catatan}` : ""),
        tgl: t.tanggal,
        teknisi,
        biaya,
        status: t.status,
      };
    });
    return (
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold text-gray-800">Riwayat Perbaikan Aset</span>
          <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50">
            <Download size={12} /> Export
          </button>
        </div>
        <table className="w-full text-left">
          <THead cols={["No. Perbaikan", "Aset", "Keluhan", "Tgl. Mulai", "Teknisi", "Biaya", "Status"]} />
          <tbody className="divide-y divide-gray-50">
            {hist.map(r => (
              <tr key={r.id} className="hover:bg-gray-50/50">
                <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.id}</td>
                <td className="px-4 py-3 text-xs text-gray-700 max-w-[140px]">{r.aset}</td>
                <td className="px-4 py-3 text-xs text-gray-500 max-w-[180px]">{r.keluhan}</td>
                <td className="px-4 py-3 text-xs text-gray-500">{r.tgl}</td>
                <td className="px-4 py-3 text-xs text-gray-600">{r.teknisi}</td>
                <td className="px-4 py-3 text-xs font-medium text-gray-800">{r.biaya != null ? `Rp ${r.biaya.toLocaleString("id")}` : "—"}</td>
                <td className="px-4 py-3"><SoftBadge label={r.status} color={r.status === "Selesai" ? "green" : "blue"} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  // Jadwal Perbaikan
  const teknisiPoolJ = storeMnt.users.filter(u => u.role === "Teknisi").map(u => u.nama);
  const jadwal = storeMnt.assets
    .filter(a => {
      const s = getMaintenanceStatus(a);
      return s === "Due Soon" || s === "Overdue";
    })
    .sort((a, b) => (a.jadwal_maintenance_berikutnya || "").localeCompare(b.jadwal_maintenance_berikutnya || ""))
    .slice(0, 10)
    .map((a, idx) => ({
      tgl: a.jadwal_maintenance_berikutnya || "-",
      aset: `${a.id} – ${a.Nama_Barang}`,
      jenis: a.jenis_maintenance_terakhir === "Korektif" ? "Korektif" : "Preventif",
      teknisi: teknisiPoolJ.length ? teknisiPoolJ[idx % teknisiPoolJ.length] : (a.nama_pic || "—"),
      status: "Terjadwal",
    }));
  return (
    <>
      <div className="grid grid-cols-3 gap-4">
        <KpiStat label="Jadwal Mendatang"       value="5"   sub="Juli–Sept 2026"              badge />
        <KpiStat label="Perbaikan Preventif"    value="4"   sub="Rutin terjadwal"             badge />
        <KpiStat label="Perbaikan Korektif"     value="1"   sub="Respons terhadap kerusakan"  badge />
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <p className="text-sm font-semibold text-gray-800 mb-4">Jadwal Perbaikan Mendatang</p>
        <table className="w-full text-left">
          <THead cols={["Tanggal", "Aset", "Jenis Perbaikan", "Teknisi / Vendor", "Status"]} />
          <tbody className="divide-y divide-gray-50">
            {jadwal.map(r => (
              <tr key={r.tgl + r.aset} className="hover:bg-gray-50/50">
                <td className="px-4 py-3 text-xs font-medium text-gray-700">{r.tgl}</td>
                <td className="px-4 py-3 text-xs text-gray-700">{r.aset}</td>
                <td className="px-4 py-3"><SoftBadge label={r.jenis} color={r.jenis === "Preventif" ? "blue" : "amber"} /></td>
                <td className="px-4 py-3 text-xs text-gray-600">{r.teknisi}</td>
                <td className="px-4 py-3"><SoftBadge label={r.status} color="green" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ── LOKASI KAMPUS ─────────────────────────────────────────────────────────────

type RoomDatum = {
  kode: string; nama: string; gedung: string; namaGedung: string;
  lantai: string; kategori: string; luas: number; kapasitasOrang: number;
  aset: number; kondisiOk: number; nilaiBuku: number;
  lat: number | null; lng: number | null; referensiDenah: string | null;
  statusLokasi: "Terverifikasi" | "Perlu Verifikasi" | "Tidak Diketahui";
  unit: string;
};

type AssetRow = {
  kode: string; nama: string; kategori: string; unit: string;
  nilaiBuku: number; statusPakai: "Aktif" | "Idle" | "Dipinjam";
  statusLokasi: "Terverifikasi" | "Tidak Sesuai" | "Perlu Verifikasi";
};

const ROOMS_CLB: RoomDatum[] = [
  { kode:"CLB-A01", nama:"Ruang Server A",  gedung:"A", namaGedung:"Gedung Administrasi & IT", lantai:"1",  kategori:"Server Room",  luas:40,  kapasitasOrang:5,   aset:28,  kondisiOk:26, nilaiBuku:148500, lat:-6.5594, lng:106.7350, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"UPT Teknologi" },
  { kode:"CLB-A02", nama:"Ruang Server B",  gedung:"A", namaGedung:"Gedung Administrasi & IT", lantai:"1",  kategori:"Server Room",  luas:36,  kapasitasOrang:5,   aset:22,  kondisiOk:22, nilaiBuku:112000, lat:-6.5595, lng:106.7351, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"UPT Teknologi" },
  { kode:"CLB-B01", nama:"Ruang Admin",     gedung:"A", namaGedung:"Gedung Administrasi & IT", lantai:"1",  kategori:"Administrasi", luas:60,  kapasitasOrang:20,  aset:15,  kondisiOk:14, nilaiBuku:42000,  lat:-6.5596, lng:106.7352, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Sekretariat"   },
  { kode:"CLB-B02", nama:"Ruang IT",        gedung:"A", namaGedung:"Gedung Administrasi & IT", lantai:"1",  kategori:"Teknis",       luas:45,  kapasitasOrang:10,  aset:18,  kondisiOk:17, nilaiBuku:89500,  lat:null,    lng:null,    referensiDenah:null, statusLokasi:"Perlu Verifikasi", unit:"UPT Teknologi" },
  { kode:"CLB-C01", nama:"Lab Komputer 1",  gedung:"A", namaGedung:"Gedung Administrasi & IT", lantai:"2",  kategori:"Laboratorium", luas:80,  kapasitasOrang:30,  aset:35,  kondisiOk:33, nilaiBuku:312000, lat:-6.5591, lng:106.7349, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Fak. Teknik"   },
  { kode:"CLB-C02", nama:"Lab Komputer 2",  gedung:"A", namaGedung:"Gedung Administrasi & IT", lantai:"2",  kategori:"Laboratorium", luas:80,  kapasitasOrang:30,  aset:30,  kondisiOk:29, nilaiBuku:284000, lat:-6.5592, lng:106.7350, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Fak. Teknik"   },
  { kode:"CLB-D01", nama:"Ruang Dosen",     gedung:"A", namaGedung:"Gedung Administrasi & IT", lantai:"3",  kategori:"Perkantoran",  luas:120, kapasitasOrang:25,  aset:42,  kondisiOk:40, nilaiBuku:198000, lat:-6.5590, lng:106.7350, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Rektorat"      },
  { kode:"CLB-D02", nama:"Ruang Rapat",     gedung:"A", namaGedung:"Gedung Administrasi & IT", lantai:"3",  kategori:"Rapat",        luas:60,  kapasitasOrang:30,  aset:12,  kondisiOk:12, nilaiBuku:64000,  lat:null,    lng:null,    referensiDenah:null, statusLokasi:"Perlu Verifikasi", unit:"Rektorat"      },
  { kode:"CLB-G01", nama:"Garasi Utama",    gedung:"B", namaGedung:"Gedung Penunjang",          lantai:"B1", kategori:"Garasi",       luas:200, kapasitasOrang:0,   aset:5,   kondisiOk:4,  nilaiBuku:876000, lat:-6.5598, lng:106.7348, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Bag. Umum"     },
  { kode:"CLB-G02", nama:"Gudang Utama",    gedung:"B", namaGedung:"Gedung Penunjang",          lantai:"B1", kategori:"Gudang",       luas:150, kapasitasOrang:5,   aset:134, kondisiOk:130,nilaiBuku:425000, lat:-6.5599, lng:106.7349, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Bag. Umum"     },
  { kode:"CLB-E01", nama:"Aula Utama",      gedung:"C", namaGedung:"Gedung Serbaguna",          lantai:"1",  kategori:"Aula",         luas:500, kapasitasOrang:300, aset:68,  kondisiOk:65, nilaiBuku:312000, lat:null,    lng:null,    referensiDenah:null, statusLokasi:"Tidak Diketahui",  unit:"Bag. Umum"     },
  { kode:"CLB-E02", nama:"Ruang Panitia",   gedung:"C", namaGedung:"Gedung Serbaguna",          lantai:"1",  kategori:"Administrasi", luas:40,  kapasitasOrang:10,  aset:8,   kondisiOk:8,  nilaiBuku:28000,  lat:null,    lng:null,    referensiDenah:null, statusLokasi:"Tidak Diketahui",  unit:"Bag. Umum"     },
];

const ROOMS_GG: RoomDatum[] = [
  { kode:"GG-A01", nama:"Ruang TU",        gedung:"A", namaGedung:"Gedung Utama",      lantai:"1",  kategori:"Administrasi", luas:50,  kapasitasOrang:15, aset:18, kondisiOk:17, nilaiBuku:72000,  lat:-6.5321, lng:106.7891, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Tata Usaha"  },
  { kode:"GG-A02", nama:"Ruang Dosen",     gedung:"A", namaGedung:"Gedung Utama",      lantai:"1",  kategori:"Perkantoran",  luas:80,  kapasitasOrang:20, aset:26, kondisiOk:25, nilaiBuku:138000, lat:-6.5322, lng:106.7892, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Akademik"    },
  { kode:"GG-B01", nama:"Lab Fisika",       gedung:"A", namaGedung:"Gedung Utama",      lantai:"2",  kategori:"Laboratorium", luas:100, kapasitasOrang:25, aset:38, kondisiOk:35, nilaiBuku:248000, lat:-6.5319, lng:106.7890, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Fak. MIPA"   },
  { kode:"GG-B02", nama:"Ruang Kuliah B2", gedung:"A", namaGedung:"Gedung Utama",      lantai:"2",  kategori:"Ruang Kuliah", luas:80,  kapasitasOrang:40, aset:22, kondisiOk:20, nilaiBuku:84000,  lat:null,    lng:null,    referensiDenah:null, statusLokasi:"Perlu Verifikasi", unit:"Akademik"    },
  { kode:"GG-B03", nama:"Lab Kimia",        gedung:"B", namaGedung:"Gedung Laboratorium",lantai:"1",  kategori:"Laboratorium", luas:90,  kapasitasOrang:20, aset:45, kondisiOk:43, nilaiBuku:312000, lat:-6.5325, lng:106.7894, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Fak. MIPA"   },
  { kode:"GG-B04", nama:"Ruang Persiapan",  gedung:"B", namaGedung:"Gedung Laboratorium",lantai:"1",  kategori:"Teknis",       luas:30,  kapasitasOrang:5,  aset:12, kondisiOk:12, nilaiBuku:48000,  lat:null,    lng:null,    referensiDenah:null, statusLokasi:"Tidak Diketahui", unit:"Fak. MIPA"   },
  { kode:"GG-C01", nama:"Garasi",           gedung:"C", namaGedung:"Gedung Penunjang",   lantai:"B1", kategori:"Garasi",       luas:80,  kapasitasOrang:0,  aset:3,  kondisiOk:3,  nilaiBuku:624000, lat:-6.5328, lng:106.7897, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Bag. Umum"   },
  { kode:"GG-C02", nama:"Gudang",           gedung:"C", namaGedung:"Gedung Penunjang",   lantai:"B1", kategori:"Gudang",       luas:60,  kapasitasOrang:5,  aset:45, kondisiOk:43, nilaiBuku:142000, lat:-6.5329, lng:106.7898, referensiDenah:null, statusLokasi:"Terverifikasi",   unit:"Bag. Umum"   },
];

const ASSETS_CLB: Record<string, AssetRow[]> = {
  "CLB-A01": [
    { kode:"PM-003",  nama:"Server Dell PowerEdge R750",    kategori:"PM",  unit:"UPT Teknologi", nilaiBuku:148000, statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"PM-007",  nama:"Cisco Catalyst 9200 Switch",    kategori:"PM",  unit:"UPT Teknologi", nilaiBuku:76000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"PM-018",  nama:"UPS APC Smart 3000VA",          kategori:"PM",  unit:"UPT Teknologi", nilaiBuku:84000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"PM-019",  nama:"UPS APC Back-UPS 1500VA",       kategori:"PM",  unit:"UPT Teknologi", nilaiBuku:32000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"ATB-012", nama:"Lisensi VMware vSphere 8",      kategori:"ATB", unit:"UPT Teknologi", nilaiBuku:48000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
  ],
  "CLB-C01": [
    { kode:"PM-045",  nama:"Laptop Dell Latitude 5520 (×10)",kategori:"PM", unit:"Fak. Teknik",   nilaiBuku:120000, statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"PM-046",  nama:"Monitor LG 24' FHD (×10)",      kategori:"PM",  unit:"Fak. Teknik",   nilaiBuku:48000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"ATL-034", nama:"AC Daikin Inverter 1.5 PK",     kategori:"ATL", unit:"Fak. Teknik",   nilaiBuku:14000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"ATL-040", nama:"LCD Proyektor Sony VPL-FHZ85",  kategori:"ATL", unit:"Fak. Teknik",   nilaiBuku:68600,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"PM-078",  nama:"Printer Epson L3250",            kategori:"PM",  unit:"Fak. Teknik",   nilaiBuku:4200,   statusPakai:"Idle",     statusLokasi:"Perlu Verifikasi" },
  ],
  "CLB-D01": [
    { kode:"PM-056",  nama:"Monitor LG 27' 4K",             kategori:"PM",  unit:"Rektorat",      nilaiBuku:18500,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"PM-102",  nama:"Laptop HP EliteBook 840",        kategori:"PM",  unit:"Rektorat",      nilaiBuku:14200,  statusPakai:"Idle",     statusLokasi:"Perlu Verifikasi" },
    { kode:"ATL-021", nama:"AC Panasonic 1 PK",              kategori:"ATL", unit:"Rektorat",      nilaiBuku:8400,   statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
  ],
  "CLB-G02": [
    { kode:"ATL-034", nama:"Kursi Kerja Futura (×5)",        kategori:"ATL", unit:"Bag. Umum",     nilaiBuku:12500,  statusPakai:"Idle",     statusLokasi:"Terverifikasi"    },
    { kode:"PM-120",  nama:"Laptop Lenovo ThinkPad X1",      kategori:"PM",  unit:"Bag. Umum",     nilaiBuku:0,      statusPakai:"Idle",     statusLokasi:"Perlu Verifikasi" },
    { kode:"AL-015",  nama:"Pickup Mitsubishi L300",         kategori:"AL",  unit:"Bag. Umum",     nilaiBuku:112000, statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
  ],
};

const ASSETS_GG: Record<string, AssetRow[]> = {
  "GG-B01": [
    { kode:"PM-112",  nama:"Oscilloscope Rigol DS1054Z",     kategori:"PM",  unit:"Fak. MIPA",     nilaiBuku:24000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"PM-113",  nama:"Function Generator Siglent",     kategori:"PM",  unit:"Fak. MIPA",     nilaiBuku:18500,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"ATL-055", nama:"Meja Laboratorium (×8)",         kategori:"ATL", unit:"Fak. MIPA",     nilaiBuku:32000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"ATL-056", nama:"Bangku Laboratorium (×16)",      kategori:"ATL", unit:"Fak. MIPA",     nilaiBuku:16000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"PM-120",  nama:"Proyektor Epson EB-X51",         kategori:"PM",  unit:"Fak. MIPA",     nilaiBuku:8200,   statusPakai:"Aktif",    statusLokasi:"Perlu Verifikasi" },
  ],
  "GG-A01": [
    { kode:"PM-201",  nama:"Komputer Desktop HP (×4)",       kategori:"PM",  unit:"Tata Usaha",    nilaiBuku:28000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"PM-202",  nama:"Printer Canon LBP6030",          kategori:"PM",  unit:"Tata Usaha",    nilaiBuku:1800,   statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"ATL-060", nama:"Meja Kerja (×5)",                kategori:"ATL", unit:"Tata Usaha",    nilaiBuku:10000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
  ],
  "GG-B03": [
    { kode:"PM-210",  nama:"Labu Ukur Set Pyrex",            kategori:"PM",  unit:"Fak. MIPA",     nilaiBuku:8500,   statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"PM-211",  nama:"Timbangan Analitik Ohaus",       kategori:"PM",  unit:"Fak. MIPA",     nilaiBuku:14200,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"ATL-065", nama:"Lemari Asam (×2)",               kategori:"ATL", unit:"Fak. MIPA",     nilaiBuku:24000,  statusPakai:"Aktif",    statusLokasi:"Terverifikasi"    },
    { kode:"PM-212",  nama:"Spektrofotometer UV-Vis",         kategori:"PM",  unit:"Fak. MIPA",     nilaiBuku:48000,  statusPakai:"Dipinjam", statusLokasi:"Tidak Sesuai"     },
  ],
};

function LokasiKampusContent({ page, tab }: { page: string; tab: string }) {
  const [selectedRoom, setSelectedRoom] = useState<string | null>(null);
  const [treeSearch, setTreeSearch] = useState("");
  const [filterGedung, setFilterGedung] = useState("Semua");
  const [filterLantai, setFilterLantai] = useState("Semua");
  const [filterKategori, setFilterKategori] = useState("Semua");

  const rooms      = page === "kampus-cilibende" ? ROOMS_CLB  : ROOMS_GG;
  const assetsMap  = page === "kampus-cilibende" ? ASSETS_CLB : ASSETS_GG;
  const namaKampus = page === "kampus-cilibende" ? "Kampus Cilibende" : "Kampus Gunung Gede";

  const gedungList   = [...new Set(rooms.map(r => r.namaGedung))];
  const lantaiList   = [...new Set(rooms.map(r => r.lantai))].sort();
  const kategoriList = [...new Set(rooms.map(r => r.kategori))].sort();

  const filteredRooms = rooms.filter(r =>
    (filterGedung   === "Semua" || r.namaGedung === filterGedung) &&
    (filterLantai   === "Semua" || r.lantai     === filterLantai) &&
    (filterKategori === "Semua" || r.kategori   === filterKategori)
  );

  const treeRooms = filteredRooms.filter(r =>
    treeSearch === "" ||
    r.nama.toLowerCase().includes(treeSearch.toLowerCase()) ||
    r.kode.toLowerCase().includes(treeSearch.toLowerCase())
  );

  const selectedRoomData = selectedRoom ? rooms.find(r => r.kode === selectedRoom) ?? null : null;
  const roomAssets       = selectedRoom ? (assetsMap[selectedRoom] ?? []) : [];

  const gedungCount     = new Set(rooms.map(r => r.namaGedung)).size;
  const lantaiCount     = new Set(rooms.map(r => `${r.gedung}-${r.lantai}`)).size;
  const ruanganTerisi   = rooms.filter(r => r.aset > 0).length;
  const asetTanpaLokasi = rooms.filter(r => r.lat === null).reduce((a, r) => a + r.aset, 0);

  // Group for tree view
  const treeGrouped: Record<string, Record<string, RoomDatum[]>> = {};
  treeRooms.forEach(r => {
    if (!treeGrouped[r.namaGedung]) treeGrouped[r.namaGedung] = {};
    if (!treeGrouped[r.namaGedung][r.lantai]) treeGrouped[r.namaGedung][r.lantai] = [];
    treeGrouped[r.namaGedung][r.lantai].push(r);
  });

  // Shared filter bar
  const filterBar = (
    <div className="flex items-center gap-3 flex-wrap">
      <select value={filterGedung}   onChange={e => setFilterGedung(e.target.value)}   className={FILTER_SELECT_CLS}>
        <option value="Semua">Semua Gedung</option>
        {gedungList.map(g => <option key={g} value={g}>{g}</option>)}
      </select>
      <select value={filterLantai}   onChange={e => setFilterLantai(e.target.value)}   className={FILTER_SELECT_CLS}>
        <option value="Semua">Semua Lantai</option>
        {lantaiList.map(l => <option key={l} value={l}>{l === "B1" ? "Basement" : `Lantai ${l}`}</option>)}
      </select>
      <select value={filterKategori} onChange={e => setFilterKategori(e.target.value)} className={FILTER_SELECT_CLS}>
        <option value="Semua">Semua Kategori</option>
        {kategoriList.map(k => <option key={k} value={k}>{k}</option>)}
      </select>
    </div>
  );

  // Shared KPI cards (5 cards)
  const kpiCards = (
    <div className="grid grid-cols-5 gap-4">
      <KpiStat label="Total Gedung"            value={gedungCount.toString()}                     sub="Dalam kampus ini"              badge />
      <KpiStat label="Total Lantai"            value={lantaiCount.toString()}                     sub="Semua gedung"                  badge />
      <KpiStat label="Total Ruangan"           value={filteredRooms.length.toString()}            sub="Sesuai filter aktif"           badge />
      <KpiStat label="Ruangan Terisi Aset"     value={ruanganTerisi.toString()}                   sub="Memiliki minimal 1 aset"       badge />
      <KpiStat label="Aset Tanpa Lokasi Jelas" value={asetTanpaLokasi.toString()}                 sub="GPS belum tersedia"            badge />
    </div>
  );

  // Tree view panel
  const treePanel = (
    <div className="col-span-1 bg-white rounded-xl border border-gray-200 shadow-sm flex flex-col overflow-hidden" style={{ minHeight: 420, maxHeight: 520 }}>
      <div className="p-3 border-b border-gray-100 shrink-0">
        <div className="relative">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Cari ruangan..."
            value={treeSearch}
            onChange={e => setTreeSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-xs outline-none focus:ring-1 focus:ring-gray-300"
          />
        </div>
      </div>
      <div className="overflow-y-auto flex-1 p-2">
        {Object.entries(treeGrouped).length === 0 && (
          <p className="text-xs text-gray-400 text-center py-8">Tidak ada ruangan</p>
        )}
        {Object.entries(treeGrouped).map(([gedung, lantais]) => (
          <div key={gedung} className="mb-3">
            <div className="flex items-center gap-1.5 px-2 py-1.5">
              <Building size={12} className="text-gray-400 shrink-0" />
              <span className="text-[11px] font-bold text-gray-600 leading-tight">{gedung}</span>
            </div>
            {Object.entries(lantais).sort(([a], [b]) => a.localeCompare(b)).map(([lantai, roomList]) => (
              <div key={lantai} className="ml-4 mb-1">
                <p className="text-[10px] text-gray-400 font-medium px-2 py-0.5 uppercase tracking-wide">
                  {lantai === "B1" ? "Basement" : `Lantai ${lantai}`}
                </p>
                {roomList.map(r => (
                  <button
                    key={r.kode}
                    onClick={() => setSelectedRoom(r.kode === selectedRoom ? null : r.kode)}
                    className={`w-full text-left flex items-center justify-between px-2.5 py-1.5 rounded-lg mb-0.5 transition-colors ${selectedRoom === r.kode ? "bg-gray-100 text-gray-900" : "hover:bg-gray-50 text-gray-700"}`}
                  >
                    <span className="text-xs truncate flex-1 mr-1">{r.nama}</span>
                    <span className="text-[10px] font-bold shrink-0 px-1.5 py-0.5 rounded-full bg-gray-200 text-gray-600">{r.aset}</span>
                  </button>
                ))}
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );

  // Room detail panel
  const detailPanel = (
    <div className="col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden" style={{ minHeight: 420 }}>
      {selectedRoomData ? (
        <>
          <div className="p-5 border-b border-gray-100">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[11px] font-mono text-gray-400 mb-0.5">{selectedRoomData.kode}</p>
                <h3 className="text-base font-bold text-gray-900">{selectedRoomData.nama}</h3>
                <p className="text-xs text-gray-500 mt-0.5">{selectedRoomData.namaGedung} · {selectedRoomData.lantai === "B1" ? "Basement" : `Lantai ${selectedRoomData.lantai}`}</p>
              </div>
              <SoftBadge
                label={selectedRoomData.statusLokasi}
                color={selectedRoomData.statusLokasi === "Terverifikasi" ? "green" : selectedRoomData.statusLokasi === "Perlu Verifikasi" ? "amber" : "red"}
              />
            </div>
          </div>
          <div className="p-5">
            <div className="grid grid-cols-3 gap-x-4 gap-y-4 mb-5">
              {[
                { label: "Kategori",       val: selectedRoomData.kategori },
                { label: "Luas",           val: `${selectedRoomData.luas} m²` },
                { label: "Kapasitas",      val: selectedRoomData.kapasitasOrang > 0 ? `${selectedRoomData.kapasitasOrang} orang` : "—" },
                { label: "Total Aset",     val: `${selectedRoomData.aset} unit` },
                { label: "Kondisi Baik",   val: `${selectedRoomData.kondisiOk} unit` },
                { label: "Nilai Buku",     val: `Rp ${(selectedRoomData.nilaiBuku / 1000).toFixed(0)} jt` },
                { label: "Unit Pengelola", val: selectedRoomData.unit },
                { label: "Koordinat GPS",  val: selectedRoomData.lat ? `${selectedRoomData.lat.toFixed(4)}, ${selectedRoomData.lng!.toFixed(4)}` : "Belum tersedia" },
                { label: "Referensi Denah",val: selectedRoomData.referensiDenah ?? "Belum ada" },
              ].map(item => (
                <div key={item.label}>
                  <p className="text-[10px] text-gray-400 mb-0.5">{item.label}</p>
                  <p className="text-xs font-semibold text-gray-800">{item.val}</p>
                </div>
              ))}
            </div>
            {roomAssets.length > 0 ? (
              <div>
                <p className="text-xs font-semibold text-gray-700 mb-2">Aset di Ruangan Ini (preview)</p>
                <div className="space-y-1">
                  {roomAssets.slice(0, 5).map(a => (
                    <div key={a.kode} className="flex items-center gap-2 py-1.5 border-b border-gray-50 last:border-0">
                      <span className="text-[10px] font-mono text-gray-400 w-20 shrink-0">{a.kode}</span>
                      <span className="text-xs text-gray-700 flex-1 truncate">{a.nama}</span>
                      <SoftBadge label={a.statusPakai} color={a.statusPakai === "Aktif" ? "green" : a.statusPakai === "Idle" ? "amber" : "blue"} />
                    </div>
                  ))}
                  {roomAssets.length > 5 && <p className="text-[11px] text-gray-400 pt-1">+ {roomAssets.length - 5} aset lainnya</p>}
                </div>
              </div>
            ) : (
              <p className="text-xs text-gray-400">Tidak ada data aset detail untuk ruangan ini.</p>
            )}
          </div>
        </>
      ) : (
        <div className="flex flex-col items-center justify-center h-full py-16 text-center">
          <Building size={32} className="text-gray-200 mb-3" />
          <p className="text-sm font-medium text-gray-400">Pilih ruangan dari daftar</p>
          <p className="text-xs text-gray-300 mt-1">Klik nama ruangan di sebelah kiri untuk melihat detail.</p>
        </div>
      )}
    </div>
  );

  // ── Tab: Ringkasan ────────────────────────────────────────────────────────────
  if (tab === "Ringkasan") {
    return (
      <>
        {filterBar}
        {kpiCards}
        <div className="grid grid-cols-3 gap-4 items-start">
          {treePanel}
          {detailPanel}
        </div>
      </>
    );
  }

  // ── Tab: Aset per Ruangan ─────────────────────────────────────────────────────
  if (tab === "Aset per Ruangan") {
    const allAssets: (AssetRow & { ruangan: string; kodeRuangan: string })[] = [];
    rooms.forEach(r => {
      (assetsMap[r.kode] ?? []).forEach(a => allAssets.push({ ...a, ruangan: `${r.nama} (${r.kode})`, kodeRuangan: r.kode }));
    });
    const filterKey = selectedRoom ?? "Semua";
    const displayed = filterKey === "Semua" ? allAssets : allAssets.filter(a => a.kodeRuangan === filterKey);
    return (
      <>
        <div className="flex items-center gap-3 flex-wrap">
          <select
            value={filterKey}
            onChange={e => setSelectedRoom(e.target.value === "Semua" ? null : e.target.value)}
            className={FILTER_SELECT_CLS}
          >
            <option value="Semua">Semua Ruangan ({allAssets.length} aset)</option>
            {rooms.filter(r => assetsMap[r.kode]).map(r => (
              <option key={r.kode} value={r.kode}>{r.kode} — {r.nama}</option>
            ))}
          </select>
          <span className="text-xs text-gray-400">{displayed.length} aset ditampilkan</span>
          <div className="ml-auto">
            <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50">
              <Download size={12} /> Export
            </button>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-x-auto">
          <table className="w-full text-left">
            <THead cols={["Kode Aset", "Nama Aset", "Kategori", "Unit", "Nilai Buku", "Status Penggunaan", "Status Lokasi"]} />
            <tbody className="divide-y divide-gray-50">
              {displayed.length > 0 ? displayed.map((a, i) => (
                <tr key={`${a.kode}-${i}`} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-xs font-mono text-gray-500">{a.kode}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{a.nama}</td>
                  <td className="px-4 py-3"><SoftBadge label={a.kategori} color="gray" /></td>
                  <td className="px-4 py-3 text-xs text-gray-500">{a.unit}</td>
                  <td className="px-4 py-3 text-xs font-medium text-gray-800">Rp {(a.nilaiBuku / 1000).toFixed(0)} jt</td>
                  <td className="px-4 py-3"><SoftBadge label={a.statusPakai} color={a.statusPakai === "Aktif" ? "green" : a.statusPakai === "Idle" ? "amber" : "blue"} /></td>
                  <td className="px-4 py-3"><SoftBadge label={a.statusLokasi} color={a.statusLokasi === "Terverifikasi" ? "green" : a.statusLokasi === "Tidak Sesuai" ? "red" : "amber"} /></td>
                </tr>
              )) : (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-sm text-gray-400">Pilih ruangan dengan data aset untuk melihat detail.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </>
    );
  }

  // ── Tab: Denah / Floorplan ────────────────────────────────────────────────────
  if (tab === "Denah / Floorplan") {
    const denahRoom = selectedRoomData;
    return (
      <>
        <div className="flex items-center gap-3">
          <select
            value={selectedRoom ?? ""}
            onChange={e => setSelectedRoom(e.target.value || null)}
            className={FILTER_SELECT_CLS}
          >
            <option value="">— Pilih Ruangan —</option>
            {rooms.map(r => <option key={r.kode} value={r.kode}>{r.kode} — {r.nama}</option>)}
          </select>
        </div>
        {denahRoom ? (
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm font-semibold text-gray-800">{denahRoom.nama}</p>
                <p className="text-xs text-gray-500">{denahRoom.kode} · {denahRoom.namaGedung} · {denahRoom.lantai === "B1" ? "Basement" : `Lantai ${denahRoom.lantai}`}</p>
              </div>
              <button className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50">
                <Upload size={12} /> Upload Denah
              </button>
            </div>
            {denahRoom.referensiDenah ? (
              <img src={denahRoom.referensiDenah} alt="Denah ruangan" className="w-full rounded-lg border border-gray-100" />
            ) : (
              <div className="border-2 border-dashed border-gray-200 rounded-xl flex flex-col items-center justify-center py-16 text-center">
                <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mb-3">
                  <FileText size={22} className="text-gray-400" />
                </div>
                <p className="text-sm font-medium text-gray-500 mb-1">Belum ada denah untuk ruangan ini</p>
                <p className="text-xs text-gray-400 mb-4 max-w-sm">Upload file denah (JPG, PNG, atau PDF) untuk memudahkan verifikasi lokasi dan audit aset berbasis denah.</p>
                <button className="flex items-center gap-2 text-xs bg-gray-900 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                  <Upload size={12} /> Upload Denah Sekarang
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm flex flex-col items-center justify-center py-20 text-center">
            <FileText size={32} className="text-gray-300 mb-3" />
            <p className="text-sm text-gray-400 font-medium">Pilih ruangan di atas untuk melihat denah</p>
            <p className="text-xs text-gray-300 mt-1">Denah membantu verifikasi posisi aset secara fisik di ruangan.</p>
          </div>
        )}
        {denahRoom && (
          <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 text-xs text-amber-800">
            <strong>Catatan:</strong> Seluruh ruangan di {namaKampus} belum memiliki referensi denah digital. Hubungi Bagian Umum / Fasilitas untuk proses digitalisasi denah gedung.
          </div>
        )}
      </>
    );
  }

  // ── Tab: GIS / Heatmap ────────────────────────────────────────────────────────
  if (tab === "GIS / Heatmap") {
    const hasGIS = rooms.filter(r => r.lat !== null);
    const noGIS  = rooms.filter(r => r.lat === null);
    const maxAset = Math.max(...rooms.map(r => r.aset));
    const cols = Math.ceil(rooms.length / 3);
    return (
      <>
        {noGIS.length > 0 && (
          <div className="flex items-start gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-4 py-3">
            <AlertTriangle size={14} className="shrink-0 mt-0.5" />
            <span><strong>{noGIS.length} dari {rooms.length} ruangan</strong> belum memiliki data koordinat GPS. Heatmap menampilkan distribusi aset per ruangan berdasarkan data yang tersedia.</span>
          </div>
        )}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-semibold text-gray-800">Heatmap Kepadatan Aset per Ruangan</span>
              <SisBadge />
            </div>
            <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
              {rooms.map(r => {
                const intensity = maxAset > 0 ? r.aset / maxAset : 0;
                const bg = `rgba(59,130,246,${0.08 + intensity * 0.87})`;
                const textColor = intensity > 0.5 ? "#fff" : "#374151";
                return (
                  <div
                    key={r.kode}
                    title={`${r.nama}: ${r.aset} aset`}
                    className="rounded-lg p-2 cursor-default transition-transform hover:scale-105"
                    style={{ backgroundColor: bg, minHeight: 54 }}
                  >
                    <p className="text-[9px] font-bold leading-tight mb-0.5" style={{ color: textColor }}>{r.kode}</p>
                    <p className="text-[13px] font-black" style={{ color: textColor }}>{r.aset}</p>
                    <p className="text-[9px] leading-tight opacity-80" style={{ color: textColor }}>aset</p>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center gap-2 mt-3">
              <span className="text-[11px] text-gray-400">Rendah</span>
              <div className="flex-1 h-2 rounded-full" style={{ background: "linear-gradient(to right, rgba(59,130,246,0.1), rgba(59,130,246,0.95))" }} />
              <span className="text-[11px] text-gray-400">Tinggi</span>
            </div>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-semibold text-gray-800">Status Data GIS</span>
              <SisBadge />
            </div>
            <div className="space-y-3 mb-5">
              {[
                { label: "Koordinat GPS Tersedia",    count: hasGIS.length, color: GREEN },
                { label: "Koordinat Belum Tersedia",  count: noGIS.length,  color: AMBER },
              ].map(s => (
                <div key={s.label} className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: s.color }} />
                  <span className="text-xs text-gray-600 flex-1">{s.label}</span>
                  <div className="w-24 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${(s.count / rooms.length) * 100}%`, backgroundColor: s.color }} />
                  </div>
                  <span className="text-xs font-bold text-gray-900 w-5 text-right">{s.count}</span>
                </div>
              ))}
            </div>
            {hasGIS.length > 0 && (
              <>
                <p className="text-xs font-semibold text-gray-700 mb-2">Ruangan dengan Koordinat GPS</p>
                <div className="space-y-1.5">
                  {hasGIS.map(r => (
                    <div key={r.kode} className="flex items-center justify-between text-xs py-1 border-b border-gray-50 last:border-0">
                      <span className="text-gray-600">{r.kode} — {r.nama}</span>
                      <span className="font-mono text-gray-400 text-[10px]">{r.lat!.toFixed(4)}, {r.lng!.toFixed(4)}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
            <div className="mt-4 pt-4 border-t border-gray-100 text-xs text-gray-400">
              <MapPin size={11} className="inline mr-1" />
              Data GIS diperlukan untuk fitur peta interaktif dan audit lokasi aset berbasis koordinat.
            </div>
          </div>
        </div>
        <RekSistem level={noGIS.length > rooms.length / 2 ? "Sedang" : "Rendah"}>
          {noGIS.length} ruangan di {namaKampus} belum memiliki data koordinat GPS. Lakukan survey geotag untuk melengkapi data GIS dan mengaktifkan fitur peta distribusi aset yang akurat.
        </RekSistem>
      </>
    );
  }

  // ── Tab: Ruangan Perlu Verifikasi (default) ───────────────────────────────────
  const perluVerifikasi = rooms.filter(r => r.statusLokasi !== "Terverifikasi");
  return (
    <>
      <div className="grid grid-cols-3 gap-4">
        <KpiStat label="Perlu Verifikasi"    value={rooms.filter(r => r.statusLokasi === "Perlu Verifikasi").length.toString()} sub="Status belum dikonfirmasi" badge />
        <KpiStat label="Tidak Diketahui"     value={rooms.filter(r => r.statusLokasi === "Tidak Diketahui").length.toString()}  sub="Lokasi tidak jelas"       badge />
        <KpiStat label="Sudah Terverifikasi" value={rooms.filter(r => r.statusLokasi === "Terverifikasi").length.toString()}    sub="Data lokasi valid"        badge />
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold text-gray-800">Ruangan yang Memerlukan Verifikasi Lokasi</span>
          <SisBadge />
        </div>
        {perluVerifikasi.length > 0 ? (
          <table className="w-full text-left">
            <THead cols={["Kode", "Nama Ruangan", "Gedung", "Lantai", "Kategori", "Jml. Aset", "Nilai Buku", "Status"]} />
            <tbody className="divide-y divide-gray-50">
              {perluVerifikasi.map(r => (
                <tr key={r.kode} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 text-xs font-mono text-gray-500">{r.kode}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.nama}</td>
                  <td className="px-4 py-3 text-xs text-gray-500">{r.namaGedung}</td>
                  <td className="px-4 py-3 text-xs text-gray-500">{r.lantai === "B1" ? "Basement" : `Lantai ${r.lantai}`}</td>
                  <td className="px-4 py-3"><SoftBadge label={r.kategori} color="gray" /></td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{r.aset}</td>
                  <td className="px-4 py-3 text-xs font-medium text-gray-700">Rp {(r.nilaiBuku / 1000).toFixed(0)} jt</td>
                  <td className="px-4 py-3"><SoftBadge label={r.statusLokasi} color={r.statusLokasi === "Perlu Verifikasi" ? "amber" : "red"} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <EmptyState msg="Semua ruangan sudah terverifikasi lokasinya." />
        )}
      </div>
      <RekSistem level={perluVerifikasi.length > 3 ? "Sedang" : "Rendah"}>
        {perluVerifikasi.length} ruangan memerlukan verifikasi lokasi di {namaKampus}. Segera lakukan pembaruan data koordinat GPS, status kejelasan lokasi, dan unggah referensi denah untuk mendukung akurasi sistem aset berbasis lokasi.
      </RekSistem>
    </>
  );
}
