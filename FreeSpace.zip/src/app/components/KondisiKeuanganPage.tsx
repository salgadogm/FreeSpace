import React, { useState } from "react";
import { Plus, MoreHorizontal } from "lucide-react";
import {
  LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, CartesianGrid, BarChart, Bar
} from "recharts";

const fmtRp = (n: number) => "Rp" + n.toLocaleString("id-ID");

// ── Tab: Aset ──────────────────────────────────────────────────────────────────
const ASET_DATA = [
  { name: "Bank Utama",      jenis: "Rekening",    nilai: 4850000,  updated: "3 Jul 2026" },
  { name: "E-Wallet",        jenis: "Kas Digital", nilai: 850000,   updated: "3 Jul 2026" },
  { name: "Dana Darurat",    jenis: "Tabungan",    nilai: 1500000,  updated: "1 Jul 2026" },
  { name: "Portofolio Saham",jenis: "Investasi",   nilai: 3400000,  updated: "3 Jul 2026" },
  { name: "Laptop",          jenis: "Barang",      nilai: 1600000,  updated: "Jun 2026"   },
  { name: "Perangkat Lain",  jenis: "Barang",      nilai: 600000,   updated: "Jun 2026"   },
];

const ASET_DONUT = [
  { name: "Kas & Rekening", value: 7200000, color: "#3B82F6" },
  { name: "Investasi",      value: 3400000, color: "#8B5CF6" },
  { name: "Aset Lainnya",   value: 2200000, color: "#E5E7EB" },
];

function TabAset() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Total Aset",     value: "Rp12.800.000", color: "text-gray-900" },
          { label: "Kas & Rekening", value: "Rp7.200.000",  color: "text-blue-600" },
          { label: "Investasi",      value: "Rp3.400.000",  color: "text-purple-600" },
          { label: "Aset Lainnya",   value: "Rp2.200.000",  color: "text-gray-700" },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-xs font-medium text-gray-500 mb-2">{c.label}</p>
            <p className={`text-2xl font-bold ${c.color}`}>{c.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">Komposisi Aset</h3>
          <div style={{ height: 140 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={ASET_DONUT} cx="50%" cy="50%" innerRadius={40} outerRadius={60} dataKey="value" stroke="none">
                  {ASET_DONUT.map((d, i) => <Cell key={i} fill={d.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 space-y-1.5">
            {ASET_DONUT.map(d => (
              <div key={d.name} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: d.color }} />
                <span className="text-xs text-gray-600 flex-1">{d.name}</span>
                <span className="text-xs font-semibold">{fmtRp(d.value)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-gray-800">Daftar Aset</h3>
            <button className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-900 text-white rounded-lg text-xs font-semibold">
              <Plus size={12} /> Tambah Aset
            </button>
          </div>
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="px-4 py-2.5 text-left font-medium text-gray-500">Nama Aset</th>
                <th className="px-4 py-2.5 text-left font-medium text-gray-500">Jenis</th>
                <th className="px-4 py-2.5 text-right font-medium text-gray-500">Nilai</th>
                <th className="px-4 py-2.5 text-left font-medium text-gray-500">Diperbarui</th>
                <th className="w-8"></th>
              </tr>
            </thead>
            <tbody>
              {ASET_DATA.map(r => (
                <tr key={r.name} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="px-4 py-2.5 font-medium text-gray-800">{r.name}</td>
                  <td className="px-4 py-2.5 text-gray-500">{r.jenis}</td>
                  <td className="px-4 py-2.5 text-right font-semibold text-gray-800">{fmtRp(r.nilai)}</td>
                  <td className="px-4 py-2.5 text-gray-400">{r.updated}</td>
                  <td className="px-3 py-2.5"><button className="p-0.5 hover:bg-gray-200 rounded"><MoreHorizontal size={13} className="text-gray-400" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Tab: Utang & Piutang ───────────────────────────────────────────────────────
const UTANG_DATA = [
  { nama: "Pinjaman Buku", pemberi: "Teman A",   sisa: 200000,  cicilan: 100000, jatuh: "12 Jul 2026", status: "Akan Jatuh Tempo" },
  { nama: "Biaya Kursus",  pemberi: "Online Edu", sisa: 2000000, cicilan: 450000, jatuh: "1 Agu 2026",  status: "Lancar" },
];

const PIUTANG_DATA = [
  { nama: "Pinjaman Teman", pihak: "Teman B", nominal: 150000, jatuh: "10 Jul 2026", status: "Akan Jatuh Tempo" },
  { nama: "Beli Bareng",    pihak: "Teman C", nominal: 600000, jatuh: "15 Jul 2026", status: "Lancar" },
];

function StatusBadge({ s }: { s: string }) {
  const cfg: Record<string, string> = {
    "Lancar":            "bg-green-50 text-green-700 border-green-200",
    "Akan Jatuh Tempo":  "bg-amber-50 text-amber-700 border-amber-200",
    "Terlambat":         "bg-red-50 text-red-600 border-red-200",
    "Lunas":             "bg-gray-50 text-gray-600 border-gray-200",
  };
  return <span className={`text-[10px] font-semibold border px-1.5 py-0.5 rounded ${cfg[s] ?? ""}`}>{s}</span>;
}

function TabUtangPiutang() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Total Utang",        value: "Rp2.200.000",  color: "text-red-600" },
          { label: "Cicilan Bulanan",    value: "Rp550.000",    color: "text-amber-600" },
          { label: "Total Piutang",      value: "Rp750.000",    color: "text-blue-600" },
          { label: "Jatuh Tempo Terdekat",value:"12 Jul 2026",  color: "text-gray-900" },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-xs font-medium text-gray-500 mb-2">{c.label}</p>
            <p className={`text-xl font-bold ${c.color}`}>{c.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b border-gray-100"><h3 className="text-sm font-semibold text-gray-800">Utang & Cicilan</h3></div>
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              {["Nama","Pemberi Pinjaman","Sisa Utang","Cicilan","Jatuh Tempo","Status"].map(h => (
                <th key={h} className="px-4 py-2.5 text-left font-medium text-gray-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {UTANG_DATA.map(r => (
              <tr key={r.nama} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-2.5 font-medium text-gray-800">{r.nama}</td>
                <td className="px-4 py-2.5 text-gray-500">{r.pemberi}</td>
                <td className="px-4 py-2.5 text-red-600 font-medium">{fmtRp(r.sisa)}</td>
                <td className="px-4 py-2.5 text-gray-700">{fmtRp(r.cicilan)}</td>
                <td className="px-4 py-2.5 text-gray-500">{r.jatuh}</td>
                <td className="px-4 py-2.5"><StatusBadge s={r.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b border-gray-100"><h3 className="text-sm font-semibold text-gray-800">Piutang</h3></div>
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              {["Nama","Pihak Terkait","Nominal","Jatuh Tempo","Status"].map(h => (
                <th key={h} className="px-4 py-2.5 text-left font-medium text-gray-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {PIUTANG_DATA.map(r => (
              <tr key={r.nama} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-2.5 font-medium text-gray-800">{r.nama}</td>
                <td className="px-4 py-2.5 text-gray-500">{r.pihak}</td>
                <td className="px-4 py-2.5 text-blue-600 font-medium">{fmtRp(r.nominal)}</td>
                <td className="px-4 py-2.5 text-gray-500">{r.jatuh}</td>
                <td className="px-4 py-2.5"><StatusBadge s={r.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Tab: Kekayaan Bersih ───────────────────────────────────────────────────────
const NW_HISTORY = [
  { bln: "Feb", aset: 10200000, liabilitas: 2800000, nw: 7400000 },
  { bln: "Mar", aset: 10600000, liabilitas: 2700000, nw: 7900000 },
  { bln: "Apr", aset: 11200000, liabilitas: 2600000, nw: 8600000 },
  { bln: "Mei", aset: 11700000, liabilitas: 2500000, nw: 9200000 },
  { bln: "Jun", aset: 12000000, liabilitas: 2250000, nw: 9750000 },
  { bln: "Jul", aset: 12800000, liabilitas: 2200000, nw: 10600000 },
];

function TabKekayaanBersih() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Total Aset",       value: "Rp12.800.000", color: "text-green-600" },
          { label: "Total Kewajiban",  value: "Rp2.200.000",  color: "text-red-500" },
          { label: "Kekayaan Bersih",  value: "Rp10.600.000", color: "text-gray-900" },
          { label: "Perubahan Bulan Ini",value:"+Rp850.000",  color: "text-green-600" },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <p className="text-xs font-medium text-gray-500 mb-2">{c.label}</p>
            <p className={`text-2xl font-bold ${c.color}`}>{c.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <h3 className="text-sm font-semibold text-gray-800 mb-4">Tren Kekayaan Bersih (6 Bulan)</h3>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={NW_HISTORY}>
            <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" />
            <XAxis dataKey="bln" tick={{ fontSize: 11, fill: "#6B7280" }} />
            <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickFormatter={v => `${(v/1000000).toFixed(0)}jt`} />
            <Tooltip formatter={(v: number) => fmtRp(v)} />
            <Legend />
            <Line type="monotone" dataKey="aset"       name="Total Aset"       stroke="#22C55E" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="liabilitas" name="Kewajiban"        stroke="#EF4444" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="nw"         name="Kekayaan Bersih"  stroke="#3B82F6" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b border-gray-100"><h3 className="text-sm font-semibold text-gray-800">Riwayat Kekayaan Bersih</h3></div>
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              {["Periode","Total Aset","Total Kewajiban","Kekayaan Bersih","Perubahan"].map(h => (
                <th key={h} className="px-4 py-2.5 text-right first:text-left font-medium text-gray-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {NW_HISTORY.slice().reverse().map((r, i, arr) => {
              const prev = arr[i + 1];
              const delta = prev ? r.nw - prev.nw : 0;
              return (
                <tr key={r.bln} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="px-4 py-2.5 font-medium text-gray-800">{r.bln} 2026</td>
                  <td className="px-4 py-2.5 text-right text-gray-700">{fmtRp(r.aset)}</td>
                  <td className="px-4 py-2.5 text-right text-gray-700">{fmtRp(r.liabilitas)}</td>
                  <td className="px-4 py-2.5 text-right font-semibold text-gray-900">{fmtRp(r.nw)}</td>
                  <td className={`px-4 py-2.5 text-right font-medium ${delta >= 0 ? "text-green-600" : "text-red-500"}`}>
                    {delta !== 0 ? `${delta >= 0 ? "+" : ""}${fmtRp(delta)}` : "—"}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Tab: Target & Kesehatan ────────────────────────────────────────────────────
const GOALS = [
  { name: "Dana Darurat",           target: 12000000, terkumpul: 5400000,  pct: 45 },
  { name: "Laptop Baru",            target: 15000000, terkumpul: 3000000,  pct: 20 },
  { name: "Sertifikasi Profesional",target:  4000000, terkumpul: 1600000,  pct: 40 },
];

const METRICS = [
  { label: "Savings Rate",      value: "46%",    bar: 46,  good: true },
  { label: "Debt Ratio",        value: "17,2%",  bar: 17,  good: true },
  { label: "Emergency Fund",    value: "2,7 bln",bar: 45,  good: false },
  { label: "Cash Flow",         value: "Positif",bar: 100, good: true },
  { label: "Budget Discipline", value: "82%",    bar: 82,  good: true },
];

function TabTargetKesehatan() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        {/* Score Card */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 flex flex-col items-center justify-center gap-3">
          <div className="relative w-40 h-40">
            <svg viewBox="0 0 140 140" className="w-full h-full -rotate-90">
              <circle cx="70" cy="70" r="55" fill="none" stroke="#F3F4F6" strokeWidth="12" />
              <circle cx="70" cy="70" r="55" fill="none" stroke="#22C55E" strokeWidth="12"
                strokeDasharray={`${2 * Math.PI * 55 * 0.78} ${2 * Math.PI * 55}`}
                strokeLinecap="round" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold text-gray-900">78</span>
              <span className="text-xs text-gray-400">dari 100</span>
            </div>
          </div>
          <div className="text-center">
            <p className="text-base font-bold text-gray-900">Financial Health Score</p>
            <span className="inline-block mt-1 px-3 py-1 bg-green-100 text-green-700 text-sm font-semibold rounded-full">Baik</span>
          </div>
        </div>

        {/* Metrics */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-800 mb-4">Metrik Keuangan</h3>
          <div className="space-y-4">
            {METRICS.map(m => (
              <div key={m.label}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-600">{m.label}</span>
                  <span className={`text-xs font-bold ${m.good ? "text-green-600" : "text-amber-600"}`}>{m.value}</span>
                </div>
                <div className="h-1.5 rounded-full bg-gray-100 overflow-hidden">
                  <div className={`h-full rounded-full ${m.good ? "bg-green-500" : "bg-amber-400"}`} style={{ width: `${Math.min(m.bar, 100)}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Financial Goals */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-gray-800">Target Keuangan</h3>
          <button className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-900 text-white rounded-lg text-xs font-semibold">
            <Plus size={12} /> Tambah Target
          </button>
        </div>
        <div className="space-y-4">
          {GOALS.map(g => (
            <div key={g.name} className="border border-gray-100 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-800">{g.name}</span>
                <span className="text-xs font-bold text-gray-700">{g.pct}%</span>
              </div>
              <div className="h-2 rounded-full bg-gray-100 overflow-hidden mb-2">
                <div className="h-full rounded-full bg-blue-500" style={{ width: `${g.pct}%` }} />
              </div>
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span>Terkumpul: <strong>{fmtRp(g.terkumpul)}</strong></span>
                <span>Target: <strong>{fmtRp(g.target)}</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export function KondisiKeuanganPage({ topBar }: { topBar: React.ReactNode }) {
  const [activeTab, setActiveTab] = useState("aset");

  const TABS = [
    { id: "aset",     label: "Aset" },
    { id: "utang",    label: "Utang & Piutang" },
    { id: "kekayaan", label: "Kekayaan Bersih" },
    { id: "target",   label: "Target & Kesehatan" },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-6">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Kondisi Keuangan</h1>
          <p className="text-sm text-gray-500 mt-1">Pantau aset, kewajiban, kekayaan bersih, dan kesehatan finansial.</p>
        </div>

        <div className="flex items-center gap-0 border-b border-gray-200">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                activeTab === t.id ? "border-gray-900 text-gray-900" : "border-transparent text-gray-500 hover:text-gray-700"
              }`}>{t.label}</button>
          ))}
        </div>

        {activeTab === "aset"     && <TabAset />}
        {activeTab === "utang"    && <TabUtangPiutang />}
        {activeTab === "kekayaan" && <TabKekayaanBersih />}
        {activeTab === "target"   && <TabTargetKesehatan />}
      </div>
    </main>
  );
}
