import React, { useState, useEffect } from "react";
import {
  Play, Pause, ChevronLeft, ChevronRight, X, RefreshCw,
  CheckCircle2, Clock, BookOpen, Headphones, PenSquare,
  Volume2, Info, TrendingUp, Target, Bookmark,
  RotateCcw, AlertCircle,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, LineChart, Line, ReferenceLine,
} from "recharts";

type TOEFLTab = "latihan" | "simulasi" | "progress";
type PracticeSection = "listening" | "structure" | "reading";

// ── Data ──────────────────────────────────────────────────────────────────────
const SCORE_TREND = [
  { sesi: "S1",  score: 423 }, { sesi: "S2",  score: 447 }, { sesi: "S3",  score: 453 },
  { sesi: "S4",  score: 460 }, { sesi: "S5",  score: 470 }, { sesi: "S6",  score: 480 },
  { sesi: "S7",  score: 475 }, { sesi: "S8",  score: 493 },
];

const SECTION_ACCURACY = [
  { name: "Listening", akurasi: 71 }, { name: "Structure", akurasi: 77 }, { name: "Reading", akurasi: 72 },
];

const HISTORY_DATA = [
  { tgl: "3 Jul 2026",  tipe: "Tes Mini",   listen: 48, struct: 31, read: 36, score: 493, dur: "45 mnt" },
  { tgl: "2 Jul 2026",  tipe: "Latihan",    listen: 45, struct: 29, read: 34, score: 480, dur: "30 mnt" },
  { tgl: "1 Jul 2026",  tipe: "Latihan",    listen: 43, struct: 28, read: 33, score: 470, dur: "25 mnt" },
  { tgl: "30 Jun 2026", tipe: "Simulasi",   listen: 40, struct: 26, read: 30, score: 453, dur: "115 mnt" },
];

// ── Mock Questions ────────────────────────────────────────────────────────────
const STRUCTURE_QUESTIONS = [
  {
    id: 1,
    type: "structure",
    question: "_______ the financial report accurately, the accountant rechecked all the data.",
    options: ["A. To prepare", "B. Preparing", "C. Prepared", "D. Be preparing"],
    correct: 0,
    explanation: "Infinitive phrase 'To prepare' functions as an adverbial modifier indicating purpose.",
    concept: "Infinitive of Purpose",
  },
  {
    id: 2,
    type: "structure",
    question: "The balance sheet _______ by the audit committee before it is submitted.",
    options: ["A. must review", "B. must be reviewed", "C. must reviewing", "D. must reviewed"],
    correct: 1,
    explanation: "'must be reviewed' uses passive voice correctly. The subject (balance sheet) receives the action.",
    concept: "Passive Voice with Modal",
  },
  {
    id: 3,
    type: "error",
    question: "The company <u>has been</u> conducting <u>their</u> annual audit <u>since</u> three months, <u>but</u> the results are not yet ready.",
    options: ["A. has been", "B. their", "C. since", "D. but"],
    correct: 2,
    explanation: "'for' should be used instead of 'since' because the duration (three months) is a period, not a point in time.",
    concept: "For vs. Since",
  },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function SummaryCard({ label, value, desc, color, icon: Icon }: {
  label: string; value: string | number; desc: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
          style={{ backgroundColor: color + "18", color }}>
          <Icon size={16} />
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 leading-tight">{value}</p>
      <p className="text-[11px] text-gray-400 leading-snug">{desc}</p>
    </div>
  );
}

// ── Setup Modal ───────────────────────────────────────────────────────────────
function SetupModal({ section, onClose, onStart }: {
  section: string; onClose: () => void; onStart: () => void;
}) {
  const [jumlah, setJumlah] = useState("10");
  const [diff, setDiff]     = useState("Menengah");
  const [mode, setMode]     = useState("Mode Latihan");
  const [showDiscussion, setShowDiscussion] = useState(true);
  const [acak, setAcak]     = useState(true);

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[440px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Atur Latihan — {section}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Topik</label>
            <select className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
              {section === "Structure" ? ["Subject–Verb Agreement","Tenses","Clauses","Parallel Structure","Semua Topik"].map(t => <option key={t}>{t}</option>) : ["Semua Topik"].map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Tingkat Kesulitan</label>
              <select value={diff} onChange={e => setDiff(e.target.value)}
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                {["Dasar","Menengah","Lanjutan","Campuran"].map(d => <option key={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Jumlah Soal</label>
              <select value={jumlah} onChange={e => setJumlah(e.target.value)}
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none bg-white">
                {["5","10","20","Custom"].map(j => <option key={j}>{j}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Mode</label>
            <div className="flex gap-2">
              {["Mode Latihan","Mode Waktu Terbatas"].map(m => (
                <button key={m} onClick={() => setMode(m)}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors ${mode === m ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"}`}>{m}</button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            {[[showDiscussion, setShowDiscussion, "Tampilkan pembahasan setelah setiap soal"], [acak, setAcak, "Acak soal"]].map(([val, setter, label], i) => (
              <label key={i} className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={val as boolean} onChange={e => (setter as (v: boolean) => void)(e.target.checked)} />
                <span className="text-xs text-gray-700">{label as string}</span>
              </label>
            ))}
          </div>
        </div>
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Batal</button>
          <button onClick={onStart} className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors flex items-center gap-2">
            <Play size={13} /> Mulai Latihan
          </button>
        </div>
      </div>
    </>
  );
}

// ── Practice Interface ────────────────────────────────────────────────────────
function PracticeInterface({ onBack }: { onBack: () => void }) {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<Record<number, number>>({});
  const [showFeedback, setShowFeedback] = useState(false);
  const [marked, setMarked]     = useState<Set<number>>(new Set());
  const [timeLeft, setTimeLeft] = useState(8 * 60 + 32);

  const q = STRUCTURE_QUESTIONS[currentQ];
  const answered = selected[currentQ] !== undefined;
  const isCorrect = answered && selected[currentQ] === q.correct;

  useEffect(() => {
    const timer = setInterval(() => setTimeLeft(t => Math.max(0, t - 1)), 1000);
    return () => clearInterval(timer);
  }, []);

  const fmt = (s: number) => `${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;

  const handleAnswer = (i: number) => {
    if (showFeedback) return;
    setSelected({ ...selected, [currentQ]: i });
    setShowFeedback(true);
  };

  const nextQ = () => {
    setShowFeedback(false);
    if (currentQ < STRUCTURE_QUESTIONS.length - 1) setCurrentQ(currentQ + 1);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Internal test bar */}
      <div className="bg-white border-b border-gray-200 px-5 py-3 flex items-center gap-4 shrink-0">
        <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-gray-800 transition-colors">
          <ChevronLeft size={14} /> Keluar
        </button>
        <div className="flex-1 text-center">
          <span className="text-sm font-semibold text-gray-800">Structure and Written Expression</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-gray-500">Soal {currentQ + 1} dari {STRUCTURE_QUESTIONS.length}</span>
          <span className="flex items-center gap-1 text-xs font-mono font-semibold text-gray-700">
            <Clock size={12} className="text-amber-500" /> {fmt(timeLeft)}
          </span>
        </div>
      </div>

      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Main question area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
            <div className="flex items-start justify-between gap-3 mb-4">
              <div className="flex-1">
                <span className="text-[10px] font-semibold bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">
                  {q.type === "error" ? "Identifikasi Kesalahan" : "Pelengkap Struktur"}
                </span>
                <p className="text-sm leading-relaxed text-gray-800 mt-3" dangerouslySetInnerHTML={{ __html: q.question }} />
              </div>
            </div>

            {/* Answer options */}
            <div className="space-y-2.5 mt-5">
              {q.options.map((opt, i) => {
                let cls = "border-gray-200 hover:border-gray-300 hover:bg-gray-50";
                if (showFeedback) {
                  if (i === q.correct) cls = "border-green-400 bg-green-50";
                  else if (i === selected[currentQ] && i !== q.correct) cls = "border-red-300 bg-red-50";
                  else cls = "border-gray-100 opacity-60";
                } else if (selected[currentQ] === i) cls = "border-gray-900 bg-gray-50";

                return (
                  <button key={i} onClick={() => handleAnswer(i)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 text-left transition-all ${cls}`}>
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                      showFeedback && i === q.correct ? "bg-green-500 text-white" :
                      showFeedback && i === selected[currentQ] && i !== q.correct ? "bg-red-400 text-white" :
                      "bg-gray-100 text-gray-600"
                    }`}>{["A","B","C","D"][i]}</span>
                    <span className="text-sm text-gray-800">{opt.slice(3)}</span>
                    {showFeedback && i === q.correct && <CheckCircle2 size={14} className="text-green-500 ml-auto shrink-0" />}
                  </button>
                );
              })}
            </div>

            {/* Feedback */}
            {showFeedback && (
              <div className={`mt-4 p-4 rounded-xl border ${isCorrect ? "bg-green-50 border-green-200" : "bg-amber-50 border-amber-200"}`}>
                <p className={`text-xs font-bold mb-1 ${isCorrect ? "text-green-700" : "text-amber-700"}`}>
                  {isCorrect ? "✓ Jawaban Benar" : "✗ Belum Tepat"}
                </p>
                <p className="text-xs text-gray-700 mb-1">{q.explanation}</p>
                <p className="text-[10px] text-gray-500">Konsep: <span className="font-semibold">{q.concept}</span></p>
                <div className="flex gap-2 mt-3">
                  <button className="text-xs text-gray-600 border border-gray-200 px-2.5 py-1 rounded-lg hover:bg-white transition-colors">Pelajari Konsep</button>
                  <button className="text-xs text-gray-600 border border-gray-200 px-2.5 py-1 rounded-lg hover:bg-white transition-colors">Simpan Catatan</button>
                  <button onClick={nextQ} className="text-xs text-white bg-gray-900 px-3 py-1 rounded-lg hover:bg-black transition-colors ml-auto">
                    Lanjut →
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Controls */}
          {!showFeedback && (
            <div className="flex items-center justify-between">
              <button onClick={() => setCurrentQ(Math.max(0, currentQ - 1))} className="flex items-center gap-1.5 text-xs text-gray-600 border border-gray-200 px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors">
                <ChevronLeft size={13} /> Sebelumnya
              </button>
              <button onClick={() => setMarked(prev => { const n = new Set(prev); n.has(currentQ) ? n.delete(currentQ) : n.add(currentQ); return n; })}
                className={`flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg border transition-colors ${marked.has(currentQ) ? "bg-amber-50 text-amber-600 border-amber-200" : "text-gray-600 border-gray-200 hover:bg-gray-50"}`}>
                <Bookmark size={13} /> {marked.has(currentQ) ? "Ditandai" : "Tandai Ragu"}
              </button>
              <button onClick={() => setCurrentQ(Math.min(STRUCTURE_QUESTIONS.length - 1, currentQ + 1))} className="flex items-center gap-1.5 text-xs text-white bg-gray-900 px-3 py-2 rounded-lg hover:bg-black transition-colors">
                Selanjutnya <ChevronRight size={13} />
              </button>
            </div>
          )}
        </div>

        {/* Question navigator */}
        <div className="w-44 shrink-0 bg-white border-l border-gray-100 p-4">
          <p className="text-[10px] font-semibold text-gray-400 uppercase mb-3">Navigator</p>
          <div className="grid grid-cols-4 gap-1.5 mb-4">
            {STRUCTURE_QUESTIONS.map((_, i) => (
              <button key={i} onClick={() => { setCurrentQ(i); setShowFeedback(!!selected[i]); }}
                className={`w-8 h-8 rounded-lg text-xs font-bold transition-colors ${
                  i === currentQ ? "bg-gray-900 text-white" :
                  marked.has(i) ? "bg-amber-100 text-amber-700" :
                  selected[i] !== undefined ? "bg-green-100 text-green-700" :
                  "bg-gray-100 text-gray-500 hover:bg-gray-200"
                }`}>{i + 1}</button>
            ))}
          </div>
          <div className="space-y-1.5 text-[10px] text-gray-500">
            {[["bg-gray-900","Soal Aktif"],["bg-green-100","Dijawab"],["bg-amber-100","Ditandai"],["bg-gray-100","Belum Dijawab"]].map(([bg, label]) => (
              <div key={label} className="flex items-center gap-1.5">
                <span className={`w-3 h-3 rounded ${bg}`} /> {label}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── TAB LATIHAN ───────────────────────────────────────────────────────────────
function LatihanTab({ onStartPractice }: { onStartPractice: () => void }) {
  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 flex items-start gap-2 text-xs text-blue-700">
        <Info size={14} className="shrink-0 mt-0.5" />
        Materi latihan menggunakan format TOEFL ITP-style untuk pembelajaran dan bukan soal resmi ETS.
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[
          {
            id: "Listening", icon: Headphones, color: "#3B82F6",
            title: "Listening Comprehension",
            paket: "12 paket latihan", soal: "68 soal tersedia",
            akurasi: 71, prog: 45,
            levels: ["Basic Conversations","Longer Conversations","Talks and Lectures"],
          },
          {
            id: "Structure", icon: PenSquare, color: "#8B5CF6",
            title: "Structure and Written Expression",
            paket: "10 paket latihan", soal: "40 soal tersedia",
            akurasi: 77, prog: 62,
            levels: ["Subject–Verb Agreement","Tenses","Clauses","Parallel Structure","Word Forms"],
          },
          {
            id: "Reading", icon: BookOpen, color: "#22C55E",
            title: "Reading Comprehension",
            paket: "10 paket latihan", soal: "50 soal tersedia",
            akurasi: 72, prog: 50,
            levels: ["Main Idea","Detail","Inference","Vocabulary","Reference"],
          },
        ].map(skill => (
          <div key={skill.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:border-gray-300 hover:shadow-sm transition-all">
            <div className="h-2" style={{ backgroundColor: skill.color }} />
            <div className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: skill.color + "15" }}>
                  <skill.icon size={18} style={{ color: skill.color }} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-900">{skill.id}</p>
                  <p className="text-[10px] text-gray-400">{skill.title}</p>
                </div>
              </div>
              <div className="space-y-1.5 mb-4">
                <p className="text-xs text-gray-500">{skill.paket} • {skill.soal}</p>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500">Akurasi terakhir</span>
                  <span className="font-semibold text-gray-800">{skill.akurasi}%</span>
                </div>
                <div className="bg-gray-100 rounded-full h-1.5 overflow-hidden">
                  <div className="h-1.5 rounded-full" style={{ width: `${skill.prog}%`, backgroundColor: skill.color }} />
                </div>
              </div>
              <div className="space-y-1 mb-4">
                {skill.levels.slice(0,3).map(l => (
                  <div key={l} className="flex items-center gap-1.5 text-xs text-gray-600">
                    <div className="w-1.5 h-1.5 rounded-full bg-gray-300 shrink-0" /> {l}
                  </div>
                ))}
              </div>
              <button onClick={onStartPractice}
                className="w-full flex items-center justify-center gap-1.5 py-2.5 text-xs font-semibold text-white rounded-xl transition-colors"
                style={{ backgroundColor: skill.color }}>
                <Play size={12} /> Mulai Latihan
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── TAB SIMULASI ──────────────────────────────────────────────────────────────
function SimulasiTab({ onStart }: { onStart: () => void }) {
  const [simType, setSimType] = useState("Tes Mini");

  return (
    <div className="grid grid-cols-2 gap-6">
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-gray-800">Pilih Jenis Simulasi</h3>
        {[
          { label: "Tes Penuh",   desc: "Listening + Structure + Reading (± 2 jam)", soal: "115 soal" },
          { label: "Tes Mini",    desc: "Versi ringkas dari ketiga seksi (± 45 mnt)", soal: "45 soal" },
          { label: "Tes Kustom",  desc: "Pilih seksi dan jumlah soal sendiri" },
        ].map(s => (
          <button key={s.label} onClick={() => setSimType(s.label)}
            className={`w-full flex items-start gap-3 px-4 py-3.5 rounded-xl border-2 text-left transition-all ${simType === s.label ? "border-gray-900 bg-gray-50" : "border-gray-200 hover:border-gray-300"}`}>
            <div className={`w-4 h-4 rounded-full border-2 mt-0.5 shrink-0 ${simType === s.label ? "bg-gray-900 border-gray-900" : "border-gray-300"}`} />
            <div>
              <p className="text-sm font-semibold text-gray-900">{s.label}</p>
              <p className="text-xs text-gray-500">{s.desc} {s.soal && `• ${s.soal}`}</p>
            </div>
          </button>
        ))}
      </div>

      <div className="space-y-4">
        <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 space-y-2">
          <p className="text-xs font-semibold text-amber-800 flex items-center gap-1.5"><AlertCircle size={13} /> Persiapan Sebelum Simulasi</p>
          {["Gunakan headphone untuk Listening","Pastikan koneksi internet stabil","Siapkan waktu tanpa gangguan","Audio tidak dapat diulang pada mode simulasi"].map(c => (
            <label key={c} className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" defaultChecked className="rounded" />
              <span className="text-xs text-amber-700">{c}</span>
            </label>
          ))}
        </div>
        <div className="bg-white border border-gray-200 rounded-xl p-4 space-y-2">
          <p className="text-xs font-semibold text-gray-700 mb-2">Detail Simulasi</p>
          {simType === "Tes Mini" && (
            <>
              {[["Listening","20 soal","± 20 mnt"],["Structure","15 soal","± 15 mnt"],["Reading","10 soal","± 15 mnt"]].map(([s,q,t]) => (
                <div key={s} className="flex justify-between text-xs py-1 border-b border-gray-50 last:border-0">
                  <span className="text-gray-600">{s}</span>
                  <span className="text-gray-400">{q} • {t}</span>
                </div>
              ))}
            </>
          )}
          {simType === "Tes Penuh" && (
            <>
              {[["Listening","50 soal","± 40 mnt"],["Structure","40 soal","± 25 mnt"],["Reading","50 soal","± 55 mnt"]].map(([s,q,t]) => (
                <div key={s} className="flex justify-between text-xs py-1 border-b border-gray-50 last:border-0">
                  <span className="text-gray-600">{s}</span>
                  <span className="text-gray-400">{q} • {t}</span>
                </div>
              ))}
            </>
          )}
        </div>
        <button onClick={onStart}
          className="w-full flex items-center justify-center gap-2 py-3 text-sm font-semibold text-white bg-gray-900 rounded-xl hover:bg-black transition-colors">
          <Play size={15} /> Mulai Simulasi
        </button>
        <p className="text-[10px] text-gray-400 text-center">Estimasi skor bukan skor TOEFL resmi dari ETS.</p>
      </div>
    </div>
  );
}

// ── TAB PROGRESS ─────────────────────────────────────────────────────────────
function ProgressTab() {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Best Score",   value: "510",  desc: "Hasil terbaik",       color: "#22C55E" },
          { label: "Latest Score", value: "493",  desc: "3 Jul 2026",          color: "#3B82F6" },
          { label: "Target",       value: "550",  desc: "30 Sep 2026",         color: "#F59E0B" },
          { label: "Total Sesi",   value: "24",   desc: "Bulan ini",           color: "#6B7280" },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
            <p className="text-xs text-gray-500 mb-1">{s.label}</p>
            <p className="text-2xl font-bold" style={{ color: s.color }}>{s.value}</p>
            <p className="text-[10px] text-gray-400 mt-0.5">{s.desc}</p>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-2 gap-5">
        <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
          <p className="text-sm font-semibold text-gray-800 mb-4">Tren Estimated Score</p>
          <div className="h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart id="line-toefl-trend" data={SCORE_TREND}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
                <XAxis dataKey="sesi" tick={{ fontSize: 10, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <YAxis domain={[400, 600]} tick={{ fontSize: 10, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8, border: "1px solid #E5E7EB" }} />
                <ReferenceLine y={550} stroke="#F59E0B" strokeDasharray="4 4" label={{ value: "Target", position: "right", fontSize: 9, fill: "#F59E0B" }} />
                <Line type="monotone" dataKey="score" stroke="#111827" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
          <p className="text-sm font-semibold text-gray-800 mb-4">Akurasi per Seksi</p>
          <div className="h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart id="bar-toefl-accuracy" data={SECTION_ACCURACY} barSize={40}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <Tooltip formatter={(v: number) => [`${v}%`, "Akurasi"]} contentStyle={{ fontSize: 11, borderRadius: 8 }} />
                <Bar dataKey="akurasi" fill="#111827" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Study Plan */}
      <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-sm font-semibold text-gray-800">Rencana Belajar</p>
            <p className="text-xs text-gray-500">Target 550 — 30 September 2026</p>
          </div>
          <button className="text-xs text-gray-600 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50 transition-colors">Edit Rencana</button>
        </div>
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "Listening",  sesi: "3 sesi/minggu", color: "#3B82F6" },
            { label: "Structure",  sesi: "3 sesi/minggu", color: "#8B5CF6" },
            { label: "Reading",    sesi: "2 sesi/minggu", color: "#22C55E" },
            { label: "Tes Mini",   sesi: "1 sesi/minggu", color: "#F59E0B" },
          ].map(p => (
            <div key={p.label} className="rounded-xl border border-gray-200 p-3 text-center">
              <div className="w-8 h-8 rounded-full mx-auto mb-2 flex items-center justify-center" style={{ backgroundColor: p.color + "20" }}>
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: p.color }} />
              </div>
              <p className="text-xs font-semibold text-gray-800">{p.label}</p>
              <p className="text-[10px] text-gray-400 mt-0.5">{p.sesi}</p>
            </div>
          ))}
        </div>
      </div>

      {/* History table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b border-gray-100 bg-gray-50/50">
          <p className="text-sm font-semibold text-gray-800">Riwayat Latihan</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-100">
                {["Tanggal","Tipe","Listening","Structure","Reading","Est. Score","Durasi","Aksi"].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {HISTORY_DATA.map((r, i) => (
                <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4 text-xs text-gray-600">{r.tgl}</td>
                  <td className="py-3 px-4"><span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${r.tipe === "Simulasi" ? "bg-purple-50 text-purple-600" : "bg-gray-100 text-gray-600"}`}>{r.tipe}</span></td>
                  <td className="py-3 px-4 text-xs font-medium text-gray-700">{r.listen}</td>
                  <td className="py-3 px-4 text-xs font-medium text-gray-700">{r.struct}</td>
                  <td className="py-3 px-4 text-xs font-medium text-gray-700">{r.read}</td>
                  <td className="py-3 px-4 text-sm font-bold text-gray-900">{r.score}</td>
                  <td className="py-3 px-4 text-xs text-gray-400">{r.dur}</td>
                  <td className="py-3 px-4">
                    <button className="text-xs text-gray-500 border border-gray-200 px-2 py-1 rounded hover:bg-gray-50 transition-colors">Review</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function TOEFLTrainingPage({ topBar }: { topBar?: React.ReactNode }) {
  const [tab, setTab]           = useState<TOEFLTab>("latihan");
  const [showSetup, setShowSetup] = useState(false);
  const [practicing, setPracticing] = useState(false);
  const [simulating, setSimulating] = useState(false);

  if (practicing) {
    return (
      <main className="flex-1 overflow-hidden bg-gray-50 min-w-0 flex flex-col">
        <PracticeInterface onBack={() => setPracticing(false)} />
      </main>
    );
  }

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">TOEFL Training</h1>
            <p className="text-xs text-gray-500 mt-0.5">Latih kemampuan Listening, Structure, dan Reading melalui latihan dan simulasi tes.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button onClick={() => { setTab("simulasi"); }}
              className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
              Mulai Simulasi
            </button>
            <button onClick={() => setShowSetup(true)}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors shadow-sm">
              <Play size={13} /> Mulai Latihan
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <SummaryCard label="Estimated Score" value={493}        desc="Target 550"                    color="#111827" icon={Target} />
          <SummaryCard label="Latihan Selesai" value={24}         desc="Bulan ini"                     color="#3B82F6" icon={CheckCircle2} />
          <SummaryCard label="Streak Belajar"  value="5 Hari"    desc="Pertahankan konsistensi"        color="#22C55E" icon={TrendingUp} />
          <SummaryCard label="Akurasi Rata-Rata" value="72%"     desc="Naik 4% dari minggu lalu"      color="#8B5CF6" icon={BarChart2} />
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {([["latihan","Latihan"],["simulasi","Simulasi Tes"],["progress","Hasil & Progress"]] as const).map(([id, label]) => (
            <button key={id} onClick={() => setTab(id as TOEFLTab)}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${tab === id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              {label}
            </button>
          ))}
        </div>

        {tab === "latihan"  && <LatihanTab   onStartPractice={() => setShowSetup(true)} />}
        {tab === "simulasi" && <SimulasiTab  onStart={() => setPracticing(true)} />}
        {tab === "progress" && <ProgressTab />}
      </div>

      {showSetup && (
        <SetupModal
          section="Structure"
          onClose={() => setShowSetup(false)}
          onStart={() => { setShowSetup(false); setPracticing(true); }}
        />
      )}
    </main>
  );
}

const BarChart2 = ({ size, className }: { size?: number; className?: string }) => (
  <svg width={size || 16} height={size || 16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="18" y1="20" x2="18" y2="10" /><line x1="12" y1="20" x2="12" y2="4" /><line x1="6" y1="20" x2="6" y2="14" />
    <line x1="2" y1="20" x2="22" y2="20" />
  </svg>
);
