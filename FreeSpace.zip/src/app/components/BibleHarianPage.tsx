import React, { useState } from "react";
import {
  BookOpen, ChevronLeft, ChevronRight, Bookmark, MoreHorizontal,
  X, Plus, Minus, AlignJustify, Download, Trash2, Edit3, Lock,
  CheckCircle2, List, Clock, Check,
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────
type BibleTab = "baca" | "catatan" | "riwayat";
type NoteStatus = "Draft" | "Selesai";
type HighlightColor = "kuning" | "hijau" | "biru" | "ungu";

interface ReflectionNote {
  id: number;
  referensi: string;
  tanggal: string;
  judul: string;
  intisari: string;
  nilai: string[];
  status: NoteStatus;
}

// ── Data Simulasi ─────────────────────────────────────────────────────────────
const NOTES: ReflectionNote[] = [
  {
    id: 1, referensi: "Mazmur 23", tanggal: "3 Jul 2026",
    judul: "Kepercayaan dan ketenangan", status: "Draft",
    intisari: "Allah adalah gembala yang memelihara dan memimpin kita melalui segala situasi.",
    nilai: ["Kepercayaan", "Ketenangan", "Pengharapan"],
  },
  {
    id: 2, referensi: "Mazmur 22", tanggal: "2 Jul 2026",
    judul: "Tetap berharap dalam kesulitan", status: "Selesai",
    intisari: "Bahkan di tengah kesulitan terbesar, pengharapan kepada Allah tidak pernah sia-sia.",
    nilai: ["Ketekunan", "Iman", "Pengharapan"],
  },
  {
    id: 3, referensi: "Amsal 3", tanggal: "1 Jul 2026",
    judul: "Percaya dalam setiap keputusan", status: "Selesai",
    intisari: "Bersandar pada Allah dalam setiap keputusan menghasilkan jalan yang lurus.",
    nilai: ["Kebijaksanaan", "Kepercayaan", "Tuntunan"],
  },
];

const READING_HISTORY = [
  { tanggal: "3 Jul 2026", bacaan: "Mazmur 23", durasi: "15 menit", catatan: "1 draft", status: "Dibaca" },
  { tanggal: "2 Jul 2026", bacaan: "Mazmur 22", durasi: "18 menit", catatan: "1 catatan", status: "Selesai" },
  { tanggal: "1 Jul 2026", bacaan: "Amsal 3",   durasi: "20 menit", catatan: "1 catatan", status: "Selesai" },
  { tanggal: "30 Jun 2026",bacaan: "Mazmur 21", durasi: "12 menit", catatan: "Tidak ada", status: "Selesai" },
];

const HIGHLIGHT_CFG: Record<HighlightColor, { bg: string; label: string }> = {
  kuning: { bg: "#FEF9C3", label: "Kuning" },
  hijau:  { bg: "#D1FAE5", label: "Hijau" },
  biru:   { bg: "#DBEAFE", label: "Biru" },
  ungu:   { bg: "#EDE9FE", label: "Ungu" },
};

// Placeholder verses for Mazmur 23
const PSALM_23_VERSES = [
  { num: 1, text: "TUHAN adalah gembalaku, takkan kekurangan aku." },
  { num: 2, text: "Ia membaringkan aku di padang yang berumput hijau; Ia membimbing aku ke air yang tenang;" },
  { num: 3, text: "Ia menyegarkan jiwaku; Ia menuntun aku di jalan yang benar oleh karena nama-Nya." },
  { num: 4, text: "Sekalipun aku berjalan dalam lembah kekelaman, aku tidak takut bahaya, sebab Engkau besertaku; gadamu dan tongkatmu, itulah yang menghibur aku." },
  { num: 5, text: "Engkau menyediakan hidangan bagiku di hadapan lawanku; Engkau mengurapi kepalaku dengan minyak; pialaku penuh melimpah." },
  { num: 6, text: "Kebajikan dan kemurahan belaka akan mengikuti aku seumur hidupku; dan aku akan diam dalam rumah TUHAN sepanjang masa." },
];

// ── Summary Card ──────────────────────────────────────────────────────────────
function SCard({ label, value, desc, color, icon: Icon }: {
  label: string; value: string; desc: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
          style={{ backgroundColor: color + "18", color }}>
          <Icon size={16} />
        </div>
      </div>
      <p className="text-lg font-bold text-gray-900 leading-tight">{value}</p>
      <p className="text-[11px] text-gray-400 leading-snug">{desc}</p>
    </div>
  );
}

// ── Reading Plan Modal ────────────────────────────────────────────────────────
function ReadingPlanModal({ onClose }: { onClose: () => void }) {
  const planDays = [
    { hari: 12, bacaan: "Mazmur 23", ket: "Hari Ini", today: true },
    { hari: 13, bacaan: "Mazmur 24", ket: "Besok", today: false },
    { hari: 14, bacaan: "Amsal 4",   ket: "5 Jul 2026", today: false },
  ];

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[520px] bg-white rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-bold text-gray-900">Rencana Bacaan</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>
        <div className="p-5 space-y-4">
          {/* Current plan */}
          <div className="bg-gray-50 rounded-xl p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-bold text-gray-900">30 Hari Mazmur dan Amsal</p>
                <p className="text-xs text-gray-500 mt-0.5">12 dari 30 hari • Progress 40%</p>
              </div>
              <span className="text-[10px] font-semibold bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">Berjalan</span>
            </div>
            <div className="mt-3 bg-gray-200 rounded-full h-2 overflow-hidden">
              <div className="bg-gray-900 h-2 rounded-full" style={{ width: "40%" }} />
            </div>
          </div>

          {/* Plan days */}
          <div className="space-y-2">
            {planDays.map(d => (
              <div key={d.hari}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl border transition-colors ${d.today ? "bg-gray-900 border-gray-900" : "bg-white border-gray-200"}`}>
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${d.today ? "bg-white/20 text-white" : "bg-gray-100 text-gray-600"}`}>
                  {d.hari}
                </div>
                <div className="flex-1">
                  <p className={`text-sm font-semibold ${d.today ? "text-white" : "text-gray-800"}`}>{d.bacaan}</p>
                  <p className={`text-xs ${d.today ? "text-gray-300" : "text-gray-400"}`}>{d.ket}</p>
                </div>
                {d.today && <span className="text-[10px] font-semibold bg-white/20 text-white px-2 py-0.5 rounded-full">Hari Ini</span>}
              </div>
            ))}
          </div>

          <div className="flex gap-2 flex-wrap">
            {["Lanjutkan Rencana","Ubah Jadwal","Tandai Hari Selesai"].map(a => (
              <button key={a} className="px-3 py-1.5 text-xs font-semibold text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">{a}</button>
            ))}
            <button className="px-3 py-1.5 text-xs font-semibold text-red-600 border border-red-100 rounded-lg hover:bg-red-50 transition-colors">Hentikan Rencana</button>
          </div>

          <div className="pt-3 border-t border-gray-100">
            <button className="w-full flex items-center justify-center gap-2 py-2.5 text-xs font-semibold text-gray-900 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
              <Plus size={13} /> Buat Rencana Baru
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

// ── Verse Row ─────────────────────────────────────────────────────────────────
function VerseRow({ verse, onAddNote }: {
  verse: { num: number; text: string };
  onAddNote: (ref: string) => void;
}) {
  const [highlight, setHighlight] = useState<HighlightColor | null>(null);
  const [showMenu, setShowMenu] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);

  return (
    <div
      className="group flex gap-3 py-2 px-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer relative"
      style={highlight ? { backgroundColor: HIGHLIGHT_CFG[highlight].bg } : {}}
      onClick={() => setShowMenu(!showMenu)}>
      <span className="text-xs font-bold text-gray-300 w-5 shrink-0 pt-0.5 select-none">{verse.num}</span>
      <p className="text-sm text-gray-700 leading-relaxed flex-1">{verse.text}</p>
      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
        <button onClick={e => { e.stopPropagation(); setBookmarked(!bookmarked); }}
          className={`p-1 rounded transition-colors ${bookmarked ? "text-amber-500" : "text-gray-300 hover:text-gray-500"}`}>
          <Bookmark size={13} fill={bookmarked ? "currentColor" : "none"} />
        </button>
      </div>

      {showMenu && (
        <>
          <div className="fixed inset-0 z-10" onClick={e => { e.stopPropagation(); setShowMenu(false); }} />
          <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-xl shadow-lg z-20 p-2 flex flex-col gap-1 min-w-[150px]">
            <p className="text-[10px] font-semibold text-gray-400 px-2 mb-1">Highlight</p>
            <div className="flex gap-1.5 px-2 mb-1">
              {(Object.keys(HIGHLIGHT_CFG) as HighlightColor[]).map(c => (
                <button key={c} onClick={e => { e.stopPropagation(); setHighlight(highlight === c ? null : c); setShowMenu(false); }}
                  title={HIGHLIGHT_CFG[c].label}
                  className={`w-5 h-5 rounded-full border-2 transition-all ${highlight === c ? "border-gray-700 scale-110" : "border-transparent"}`}
                  style={{ backgroundColor: HIGHLIGHT_CFG[c].bg }} />
              ))}
            </div>
            {[
              ["Tambah Catatan", () => { onAddNote(`Mazmur 23:${verse.num}`); setShowMenu(false); }],
              ["Salin Referensi", () => setShowMenu(false)],
            ].map(([label, action]) => (
              <button key={label as string} onClick={e => { e.stopPropagation(); (action as () => void)(); }}
                className="text-left px-2 py-1.5 text-xs text-gray-700 hover:bg-gray-50 rounded-lg transition-colors">{label}</button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ── Baca Alkitab Tab ──────────────────────────────────────────────────────────
function BacaAlkitabTab({ onOpenPlan }: { onOpenPlan: () => void }) {
  const [kitab, setKitab] = useState("Mazmur");
  const [pasal, setPasal] = useState("23");
  const [fontSize, setFontSize] = useState(14);
  const [noteRef, setNoteRef] = useState("Mazmur 23:1–3");
  const [intisari, setIntisari] = useState("");
  const [nilai, setNilai] = useState(["Kepercayaan", "Pengharapan", "Ketenangan"]);
  const [nilaiInput, setNilaiInput] = useState("");
  const [maknaPribadi, setMaknaPribadi] = useState("");
  const [refleksi, setRefleksi] = useState("");
  const [penerapan, setPenerapan] = useState("");
  const [doa, setDoa] = useState("");

  const addNilai = () => {
    if (nilaiInput.trim() && !nilai.includes(nilaiInput.trim())) {
      setNilai([...nilai, nilaiInput.trim()]);
      setNilaiInput("");
    }
  };

  return (
    <div className="grid grid-cols-[1fr_360px] gap-6">
      {/* Left — Reader */}
      <div className="space-y-3">
        {/* Reader toolbar */}
        <div className="bg-white border border-gray-200 rounded-xl p-3 flex items-center gap-2 flex-wrap">
          <select value={kitab} onChange={e => setKitab(e.target.value)}
            className="text-sm font-semibold text-gray-800 border border-gray-200 rounded-lg px-3 py-1.5 outline-none bg-white">
            {["Kejadian","Keluaran","Mazmur","Amsal","Yohanes","Roma"].map(k => <option key={k}>{k}</option>)}
          </select>
          <select value={pasal} onChange={e => setPasal(e.target.value)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none bg-white w-20">
            {Array.from({ length: 50 }, (_, i) => String(i + 1)).map(p => <option key={p}>{p}</option>)}
          </select>
          <div className="flex gap-1 ml-auto">
            <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors"><ChevronLeft size={15} /></button>
            <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors"><ChevronRight size={15} /></button>
          </div>
          <div className="flex items-center gap-1 border-l border-gray-100 pl-2 ml-1">
            <button onClick={() => setFontSize(Math.max(11, fontSize - 1))}
              className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors"><Minus size={13} /></button>
            <span className="text-xs text-gray-500 w-8 text-center font-mono">{fontSize}px</span>
            <button onClick={() => setFontSize(Math.min(22, fontSize + 1))}
              className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors"><Plus size={13} /></button>
          </div>
          <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors"><AlignJustify size={13} /></button>
          <button className="p-1.5 rounded-lg hover:bg-gray-100 text-amber-500 transition-colors"><Bookmark size={13} /></button>
        </div>

        {/* Reader content */}
        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="text-center mb-6">
            <h2 className="text-lg font-bold text-gray-900">{kitab} {pasal}</h2>
            <p className="text-xs text-gray-400 mt-0.5">Klik ayat untuk highlight, bookmark, atau tambah catatan</p>
          </div>
          <div className="space-y-1 max-w-prose mx-auto" style={{ fontSize }}>
            {PSALM_23_VERSES.map(v => (
              <VerseRow key={v.num} verse={v} onAddNote={setNoteRef} />
            ))}
          </div>
          <p className="text-[10px] text-gray-300 text-center mt-6">
            Teks ditampilkan sebagai referensi. Untuk teks lengkap, gunakan aplikasi Alkitab berlisensi.
          </p>
        </div>
      </div>

      {/* Right — Notes */}
      <div className="space-y-4 sticky top-4 self-start">
        <div className="bg-white border border-gray-200 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-semibold text-gray-700">Catatan Bacaan</p>
            <button onClick={onOpenPlan}
              className="text-xs text-gray-500 hover:text-gray-700 border border-gray-200 px-2 py-1 rounded-lg hover:bg-gray-50 transition-colors">
              Rencana Bacaan
            </button>
          </div>

          <div className="space-y-3">
            {/* Ayat berkesan */}
            <div>
              <label className="block text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Ayat yang Berkesan</label>
              <div className="flex items-center gap-2 bg-blue-50 text-blue-700 rounded-lg px-3 py-2">
                <Bookmark size={12} />
                <span className="text-xs font-medium">{noteRef}</span>
              </div>
            </div>

            {/* Intisari */}
            <div>
              <label className="block text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Intisari Bacaan</label>
              <textarea value={intisari} onChange={e => setIntisari(e.target.value)}
                rows={2} placeholder="Apa inti dari bacaan hari ini?"
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none" />
            </div>

            {/* Nilai */}
            <div>
              <label className="block text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Nilai yang Dipelajari</label>
              <div className="flex flex-wrap gap-1 mb-1.5">
                {nilai.map(n => (
                  <span key={n} className="flex items-center gap-1 text-[10px] bg-purple-50 text-purple-700 px-2 py-0.5 rounded-full">
                    {n}
                    <button onClick={() => setNilai(nilai.filter(x => x !== n))} className="text-purple-400 hover:text-red-500"><X size={9} /></button>
                  </span>
                ))}
              </div>
              <div className="flex gap-1">
                <input value={nilaiInput} onChange={e => setNilaiInput(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && addNilai()}
                  placeholder="Tambah nilai..." className="flex-1 text-xs px-2 py-1.5 border border-gray-200 rounded-lg outline-none" />
                <button onClick={addNilai} className="px-2 py-1.5 bg-gray-100 text-gray-600 rounded-lg text-xs hover:bg-gray-200 transition-colors">+</button>
              </div>
            </div>

            {/* Makna pribadi */}
            <div>
              <label className="block text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Makna Pribadi</label>
              <textarea value={maknaPribadi} onChange={e => setMaknaPribadi(e.target.value)}
                rows={2} placeholder="Apa makna bacaan ini bagi kehidupan Anda saat ini?"
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none" />
            </div>

            {/* Refleksi */}
            <div>
              <label className="block text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Refleksi</label>
              <textarea value={refleksi} onChange={e => setRefleksi(e.target.value)}
                rows={2} placeholder="Tuliskan refleksi pribadi Anda..."
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none" />
            </div>

            {/* Penerapan */}
            <div>
              <label className="block text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Penerapan</label>
              <textarea value={penerapan} onChange={e => setPenerapan(e.target.value)}
                rows={2} placeholder="Apa tindakan nyata yang ingin Anda lakukan?"
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none" />
            </div>

            {/* Doa pribadi */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-[10px] font-semibold text-gray-500 uppercase tracking-wider">Doa Pribadi</label>
                <span className="flex items-center gap-1 text-[9px] text-gray-400">
                  <Lock size={9} /> Pribadi — hanya Anda
                </span>
              </div>
              <textarea value={doa} onChange={e => setDoa(e.target.value)}
                rows={2} placeholder="Tuliskan doa pribadi Anda..."
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none bg-amber-50/30" />
            </div>
          </div>

          <div className="flex gap-2 mt-4 pt-3 border-t border-gray-100">
            <button className="flex-1 text-xs font-semibold text-gray-600 border border-gray-200 py-2 rounded-lg hover:bg-gray-50 transition-colors">Simpan Draft</button>
            <button className="flex-1 text-xs font-semibold text-gray-600 border border-gray-200 py-2 rounded-lg hover:bg-gray-50 transition-colors">Tandai Selesai</button>
            <button className="flex-1 text-xs font-semibold text-white bg-gray-900 py-2 rounded-lg hover:bg-black transition-colors">Simpan Refleksi</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Catatan & Refleksi Tab ────────────────────────────────────────────────────
function CatatanTab() {
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("Semua");

  const filtered = NOTES.filter(n => {
    const matchQ = n.referensi.toLowerCase().includes(search.toLowerCase()) || n.judul.toLowerCase().includes(search.toLowerCase());
    const matchS = filterStatus === "Semua" || n.status === filterStatus;
    return matchQ && matchS;
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[180px]">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs">🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari catatan..."
            className="w-full pl-8 pr-3 py-2 text-sm border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 bg-white" />
        </div>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
          <option value="Semua">Semua Status</option>
          <option>Draft</option><option>Selesai</option>
        </select>
      </div>

      <div className="space-y-3">
        {filtered.map(n => (
          <div key={n.id} className="bg-white border border-gray-200 rounded-xl p-4 hover:border-gray-300 transition-all group">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full">{n.referensi}</span>
                  <span className="text-xs text-gray-400">{n.tanggal}</span>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                    n.status === "Draft" ? "bg-amber-50 text-amber-600" : "bg-green-50 text-green-600"
                  }`}>{n.status}</span>
                </div>
                <p className="text-sm font-semibold text-gray-900 mb-1">{n.judul}</p>
                <p className="text-xs text-gray-500 line-clamp-2">{n.intisari}</p>
                <div className="flex flex-wrap gap-1 mt-2">
                  {n.nilai.map(v => (
                    <span key={v} className="text-[10px] bg-purple-50 text-purple-600 px-2 py-0.5 rounded-full">{v}</span>
                  ))}
                </div>
              </div>
              <div className="relative" >
                <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity">
                  <MoreHorizontal size={14} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Riwayat Bacaan Tab ────────────────────────────────────────────────────────
function RiwayatBacaanTab() {
  const daysRead = [1, 2, 3, 22, 23, 24, 25, 26, 27, 28, 29, 30];

  return (
    <div className="space-y-4">
      {/* Stats row */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Streak Membaca", value: "12 hari", color: "#22C55E" },
          { label: "Progress Rencana", value: "40%", color: "#3B82F6" },
          { label: "Total Pasal", value: "24", color: "#8B5CF6" },
          { label: "Total Catatan", value: "11", color: "#F59E0B" },
        ].map(s => (
          <div key={s.label} className="bg-white border border-gray-200 rounded-xl p-3 text-center">
            <p className="text-xl font-bold" style={{ color: s.color }}>{s.value}</p>
            <p className="text-[10px] text-gray-400 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Heatmap */}
      <div className="bg-white border border-gray-200 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-semibold text-gray-700">Kalender Bacaan — Juli 2026</p>
          <div className="flex items-center gap-2 text-[10px] text-gray-400">
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-gray-100 inline-block" /> Belum</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-green-400 inline-block" /> Selesai</span>
          </div>
        </div>
        <div className="grid grid-cols-7 gap-1">
          {["Min","Sen","Sel","Rab","Kam","Jum","Sab"].map(d => (
            <div key={d} className="text-center text-[9px] text-gray-400 font-medium pb-1">{d}</div>
          ))}
          {[1,2,3].map(i => <div key={"pad"+i} />)}
          {Array.from({ length: 31 }, (_, i) => i + 1).map(d => {
            const hasRead = daysRead.includes(d);
            const isToday = d === 3;
            return (
              <div key={d}
                className={`aspect-square rounded-sm flex items-center justify-center text-[10px] font-medium cursor-pointer transition-all ${
                  isToday ? "bg-gray-900 text-white" :
                  hasRead ? "bg-green-100 text-green-700 hover:bg-green-200" :
                  "bg-gray-50 text-gray-400 hover:bg-gray-100"
                }`}>
                {d}
              </div>
            );
          })}
        </div>
      </div>

      {/* History table */}
      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/70">
                {["Tanggal","Bacaan","Durasi","Catatan","Status"].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {READING_HISTORY.map((r, i) => (
                <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4 text-xs text-gray-600">{r.tanggal}</td>
                  <td className="py-3 px-4">
                    <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full">{r.bacaan}</span>
                  </td>
                  <td className="py-3 px-4 text-xs text-gray-500">{r.durasi}</td>
                  <td className="py-3 px-4 text-xs text-gray-500">{r.catatan}</td>
                  <td className="py-3 px-4">
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                      r.status === "Selesai" ? "bg-green-50 text-green-600" : "bg-blue-50 text-blue-600"
                    }`}>{r.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function BibleHarianPage({ topBar }: { topBar?: React.ReactNode }) {
  const [tab, setTab] = useState<BibleTab>("baca");
  const [showPlan, setShowPlan] = useState(false);

  const summaryCards = [
    { label: "Bacaan Hari Ini", value: "Mazmur 23", desc: "6 ayat dalam bacaan hari ini", color: "#111827", icon: BookOpen },
    { label: "Streak Membaca", value: "12 Hari", desc: "Konsisten sejak 22 Juni 2026", color: "#22C55E", icon: CheckCircle2 },
    { label: "Progress Rencana", value: "40%", desc: "12 dari 30 hari", color: "#3B82F6", icon: List },
    { label: "Catatan Refleksi", value: "11", desc: "1 draft belum selesai", color: "#F59E0B", icon: Edit3 },
  ];

  const tabs: { id: BibleTab; label: string; icon: React.ElementType }[] = [
    { id: "baca", label: "Baca Alkitab", icon: BookOpen },
    { id: "catatan", label: "Catatan & Refleksi", icon: Edit3 },
    { id: "riwayat", label: "Riwayat Bacaan", icon: Clock },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Bible Harian</h1>
            <p className="text-xs text-gray-500 mt-0.5">Baca Alkitab dan catat intisari, nilai, serta refleksi pribadi.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button onClick={() => setShowPlan(true)}
              className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
              <List size={13} /> Rencana Bacaan
            </button>
            <button onClick={() => setTab("baca")}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors shadow-sm">
              <BookOpen size={13} /> Mulai Membaca
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          {summaryCards.map(c => (
            <div key={c.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">{c.label}</span>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: c.color + "18", color: c.color }}>
                  <c.icon size={16} />
                </div>
              </div>
              <p className="text-lg font-bold text-gray-900 leading-tight">{c.value}</p>
              <p className="text-[11px] text-gray-400 leading-snug">{c.desc}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${tab === t.id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              <t.icon size={13} /> {t.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {tab === "baca"    && <BacaAlkitabTab onOpenPlan={() => setShowPlan(true)} />}
        {tab === "catatan" && <CatatanTab />}
        {tab === "riwayat" && <RiwayatBacaanTab />}
      </div>

      {showPlan && <ReadingPlanModal onClose={() => setShowPlan(false)} />}
    </main>
  );
}
