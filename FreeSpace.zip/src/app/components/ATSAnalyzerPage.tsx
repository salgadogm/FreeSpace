import React, { useState } from "react";
import {
  Search, Upload, FileText, ChevronRight, X, RefreshCw,
  AlertCircle, CheckCircle2, AlertTriangle, Info,
  MoreHorizontal, Download, Eye, BarChart2, Sparkles,
} from "lucide-react";

type ATSTab = "analisis-baru" | "hasil" | "riwayat";

// ── Data ─────────────────────────────────────────────────────────────────────
const SCORE_BREAKDOWN = [
  { label: "Keyword Match",        score: 78, status: "Perlu Perbaikan" },
  { label: "Struktur CV",          score: 92, status: "Sangat Baik"    },
  { label: "Pengalaman Relevan",   score: 80, status: "Baik"           },
  { label: "Keahlian",             score: 84, status: "Baik"           },
  { label: "Pendidikan",           score: 90, status: "Sangat Baik"    },
  { label: "Keterbacaan",          score: 88, status: "Sangat Baik"    },
  { label: "Format ATS",           score: 95, status: "Sangat Baik"    },
  { label: "Kelengkapan",          score: 92, status: "Sangat Baik"    },
];

const KEYWORDS_FOUND     = ["Journal Entries","Microsoft Excel","Financial Reporting","General Ledger","Reconciliation","Accounting"];
const KEYWORDS_MISSING   = ["Accounts Payable","Accounts Receivable","Month-End Closing","ERP","Tax Reporting"];
const KEYWORDS_OVERUSED  = ["Accounting","Teamwork"];

const SECTION_ANALYSIS = [
  { section: "Ringkasan Profesional", score: 80, status: "Baik",           finding: "Belum menyebutkan target posisi dan kemampuan Excel.", rec: "Tambahkan target Junior Accountant dan satu kompetensi teknis utama.", action: "Edit Ringkasan" },
  { section: "Pengalaman",            score: 75, status: "Perlu Perbaikan", finding: "Bullet belum menggunakan kata kerja aktif secara konsisten.", rec: "Mulai setiap bullet dengan kata kerja aktif dan tambahkan angka hasil.", action: "Edit Pengalaman" },
  { section: "Keahlian",              score: 84, status: "Baik",           finding: "Skills akuntansi sudah baik, namun ERP belum tercantum.", rec: "Tambahkan pengalaman ERP jika relevan.", action: "Edit Keahlian" },
  { section: "Pendidikan",            score: 90, status: "Sangat Baik",   finding: "Informasi pendidikan sudah lengkap.", rec: "Sudah baik, tidak ada perbaikan utama.", action: "Lihat" },
  { section: "Sertifikasi",           score: 70, status: "Perlu Perbaikan", finding: "Belum ada sertifikasi yang tercantum.", rec: "Tambahkan sertifikasi akuntansi atau Excel jika tersedia.", action: "Edit Sertifikasi" },
  { section: "Format ATS",            score: 95, status: "Sangat Baik",   finding: "Format sangat bersih dan kompatibel dengan ATS.", rec: "Pertahankan format satu kolom tanpa elemen grafis.", action: "Lihat" },
];

const RECOMMENDATIONS = [
  { prio: "Tinggi",  item: "Tambahkan pengalaman terkait rekonsiliasi.",         dampak: "+5 poin", section: "Pengalaman",         status: "Belum Diterapkan" },
  { prio: "Tinggi",  item: "Perjelas hasil pada pengalaman organisasi.",          dampak: "+4 poin", section: "Pengalaman",         status: "Belum Diterapkan" },
  { prio: "Sedang",  item: "Tambahkan skill Accounts Payable jika relevan.",      dampak: "+3 poin", section: "Keahlian",           status: "Belum Diterapkan" },
  { prio: "Sedang",  item: "Ringkas ringkasan profesional.",                      dampak: "+2 poin", section: "Ringkasan",          status: "Belum Diterapkan" },
  { prio: "Rendah",  item: "Konsistenkan format tanggal.",                        dampak: "+1 poin", section: "Format",             status: "Belum Diterapkan" },
  { prio: "Rendah",  item: "Kurangi pengulangan keyword Accounting.",              dampak: "+1 poin", section: "Keyword",            status: "Belum Diterapkan" },
];

const ATS_HISTORY = [
  { tgl: "3 Jul 2026",  cv: "CV Akuntansi 2026",        posisi: "Junior Accountant",    co: "PT Contoh Indonesia", score: 82, match: "78%", status: "Selesai" },
  { tgl: "1 Jul 2026",  cv: "CV Finance English",        posisi: "Finance Intern",       co: "Global Finance Ltd",  score: 76, match: "71%", status: "Selesai" },
  { tgl: "28 Jun 2026", cv: "CV General Fresh Graduate", posisi: "Management Trainee",   co: "Company Example",     score: 71, match: "65%", status: "Selesai" },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function SummaryCard({ label, value, desc, color, icon: Icon }: {
  label: string; value: string | number; desc: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
          style={{ backgroundColor: color + "18", color }}>
          <Icon size={16} />
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 leading-tight">{value}</p>
      <p className="text-[11px] text-gray-400 leading-snug">{desc}</p>
    </div>
  );
}

function getStatusCfg(s: string) {
  switch (s) {
    case "Sangat Baik":    return { color: "#22C55E", bg: "#DCFCE7" };
    case "Baik":           return { color: "#3B82F6", bg: "#DBEAFE" };
    case "Perlu Perbaikan":return { color: "#F59E0B", bg: "#FEF3C7" };
    case "Kritis":         return { color: "#EF4444", bg: "#FEE2E2" };
    default:               return { color: "#6B7280", bg: "#F3F4F6" };
  }
}

function PrioBadge({ p }: { p: string }) {
  const cfg = { Tinggi: "bg-red-50 text-red-600", Sedang: "bg-amber-50 text-amber-600", Rendah: "bg-gray-100 text-gray-500" }[p] ?? "bg-gray-100 text-gray-500";
  return <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${cfg}`}>{p}</span>;
}

function ScoreCircle({ score }: { score: number }) {
  const color = score >= 85 ? "#22C55E" : score >= 70 ? "#F59E0B" : "#EF4444";
  const r = 42, circ = 2 * Math.PI * r, offset = circ * (1 - score / 100);
  return (
    <div className="relative w-28 h-28">
      <svg width="112" height="112" className="transform -rotate-90">
        <circle cx="56" cy="56" r={r} fill="none" stroke="#F3F4F6" strokeWidth="10" />
        <circle cx="56" cy="56" r={r} fill="none" stroke={color} strokeWidth="10"
          strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={offset} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-bold text-gray-900">{score}</span>
        <span className="text-[10px] text-gray-400">/ 100</span>
      </div>
    </div>
  );
}

// ── Processing State ─────────────────────────────────────────────────────────
function ProcessingState({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState(0);
  const steps = ["Membaca struktur CV","Mengidentifikasi keyword pekerjaan","Membandingkan pengalaman dan skill","Mengevaluasi format ATS","Menyusun rekomendasi"];

  React.useEffect(() => {
    const interval = setInterval(() => {
      setStep(prev => {
        if (prev >= steps.length - 1) { clearInterval(interval); setTimeout(onDone, 500); return prev; }
        return prev + 1;
      });
    }, 600);
    return () => clearInterval(interval);
  }, []);

  const progress = Math.round(((step + 1) / steps.length) * 100);

  return (
    <div className="flex flex-col items-center py-16 space-y-6">
      <div className="relative w-20 h-20">
        <svg width="80" height="80" className="transform -rotate-90">
          <circle cx="40" cy="40" r="32" fill="none" stroke="#F3F4F6" strokeWidth="6" />
          <circle cx="40" cy="40" r="32" fill="none" stroke="#111827" strokeWidth="6"
            strokeLinecap="round" strokeDasharray={2 * Math.PI * 32}
            strokeDashoffset={2 * Math.PI * 32 * (1 - progress / 100)}
            style={{ transition: "stroke-dashoffset 0.5s ease" }} />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-sm font-bold text-gray-900">{progress}%</span>
        </div>
      </div>
      <div className="space-y-2 w-full max-w-sm">
        {steps.map((s, i) => (
          <div key={s} className={`flex items-center gap-2 text-xs ${i <= step ? "text-gray-800" : "text-gray-300"}`}>
            {i < step ? <CheckCircle2 size={13} className="text-green-500 shrink-0" />
              : i === step ? <RefreshCw size={13} className="text-gray-900 animate-spin shrink-0" />
              : <div className="w-3 h-3 rounded-full border border-gray-200 shrink-0" />
            }
            {s}
          </div>
        ))}
      </div>
      <p className="text-xs text-gray-400">Analisis biasanya membutuhkan beberapa detik.</p>
    </div>
  );
}

// ── Analisis Baru Tab ─────────────────────────────────────────────────────────
function AnalisisBaruTab({ onAnalyze }: { onAnalyze: () => void }) {
  const [jd, setJd] = useState("");

  return (
    <div className="grid grid-cols-2 gap-6">
      {/* CV Selection */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-gray-800">Pilih CV</h3>
        <div className="space-y-2">
          {[
            { label: "Pilih dari CV Builder", sub: "CV Akuntansi 2026 — 92% lengkap", active: true },
            { label: "Upload CV PDF", sub: "Maks. 5 MB" },
            { label: "Upload CV DOCX", sub: "Maks. 5 MB" },
          ].map(opt => (
            <button key={opt.label}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 text-left transition-all ${opt.active ? "border-gray-900 bg-gray-50" : "border-gray-200 hover:border-gray-300"}`}>
              <div className={`w-4 h-4 rounded-full border-2 shrink-0 ${opt.active ? "bg-gray-900 border-gray-900" : "border-gray-300"}`} />
              <div>
                <p className="text-sm font-medium text-gray-800">{opt.label}</p>
                {opt.sub && <p className="text-xs text-gray-500">{opt.sub}</p>}
              </div>
            </button>
          ))}
        </div>
        <div className="bg-gray-50 rounded-xl border border-gray-200 p-4 space-y-1.5">
          <p className="text-xs font-semibold text-gray-700">CV Akuntansi 2026</p>
          {[["Bahasa","Bahasa Indonesia"],["Kelengkapan","92%"],["Diperbarui","2 Jul 2026"]].map(([k,v]) => (
            <div key={k} className="flex justify-between text-xs">
              <span className="text-gray-500">{k}</span>
              <span className="font-medium text-gray-800">{v}</span>
            </div>
          ))}
        </div>
      </div>

      {/* JD Input */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-gray-800">Job Description</h3>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Target Posisi</label>
            <input defaultValue="Junior Accountant" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1.5">Perusahaan</label>
            <input defaultValue="PT Contoh Indonesia" className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1.5">Deskripsi Pekerjaan <span className="text-red-500">*</span></label>
          <textarea value={jd} onChange={e => setJd(e.target.value)} rows={8}
            placeholder="Tempelkan deskripsi pekerjaan di sini..."
            className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 resize-none" />
          <p className="text-[10px] text-gray-400 mt-1">{jd.split(/\s+/).filter(Boolean).length} kata</p>
        </div>
        <button onClick={onAnalyze}
          className="w-full flex items-center justify-center gap-2 py-3 text-sm font-semibold text-white bg-gray-900 rounded-xl hover:bg-black transition-colors">
          <Search size={15} /> Analisis CV
        </button>
      </div>
    </div>
  );
}

// ── Hasil Tab ────────────────────────────────────────────────────────────────
function HasilTab() {
  const [recStatus, setRecStatus] = useState<Record<number, string>>({});

  return (
    <div className="space-y-5">
      {/* Header hasil */}
      <div className="bg-white border border-gray-200 rounded-xl p-5 flex items-center gap-6">
        <ScoreCircle score={82} />
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-1">
            <h3 className="text-lg font-bold text-gray-900">CV Akuntansi 2026</h3>
            <span className="text-[10px] font-bold bg-green-50 text-green-700 px-2 py-0.5 rounded-full">Baik</span>
          </div>
          <p className="text-sm text-gray-500">Junior Accountant — PT Contoh Indonesia</p>
          <p className="text-xs text-gray-400 mt-1">Dianalisis 3 Jul 2026</p>
        </div>
        <div className="flex gap-2 shrink-0">
          <button className="px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-1.5"><Download size={12} /> Export PDF</button>
          <button className="px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-1.5"><RefreshCw size={12} /> Analisis Ulang</button>
          <button className="px-3 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors flex items-center gap-1.5">Buka CV Builder</button>
        </div>
      </div>

      {/* Score Breakdown */}
      <div className="bg-white border border-gray-200 rounded-xl p-5">
        <h3 className="text-sm font-semibold text-gray-800 mb-4">Rincian Skor</h3>
        <div className="grid grid-cols-2 gap-3">
          {SCORE_BREAKDOWN.map(s => {
            const cfg = getStatusCfg(s.status);
            return (
              <div key={s.label} className="flex items-center gap-3">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-gray-600">{s.label}</span>
                    <span className="text-xs font-semibold text-gray-900">{s.score}%</span>
                  </div>
                  <div className="bg-gray-100 rounded-full h-1.5 overflow-hidden">
                    <div className="h-1.5 rounded-full transition-all" style={{ width: `${s.score}%`, backgroundColor: cfg.color }} />
                  </div>
                </div>
                <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded-full shrink-0" style={{ color: cfg.color, backgroundColor: cfg.bg }}>{s.status}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Keyword Analysis */}
      <div className="bg-white border border-gray-200 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-gray-800">Analisis Keyword</h3>
          <span className="text-xs text-gray-400">78% match — 39 dari 50 keyword</span>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <p className="text-xs font-semibold text-green-700 mb-2 flex items-center gap-1"><CheckCircle2 size={12} /> Ditemukan ({KEYWORDS_FOUND.length})</p>
            <div className="flex flex-wrap gap-1.5">
              {KEYWORDS_FOUND.map(k => <span key={k} className="text-[10px] bg-green-50 text-green-700 px-2 py-0.5 rounded-full">{k}</span>)}
            </div>
          </div>
          <div>
            <p className="text-xs font-semibold text-amber-700 mb-2 flex items-center gap-1"><AlertTriangle size={12} /> Belum Ditemukan ({KEYWORDS_MISSING.length})</p>
            <div className="flex flex-wrap gap-1.5">
              {KEYWORDS_MISSING.map(k => <span key={k} className="text-[10px] bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full">{k}</span>)}
            </div>
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-500 mb-2 flex items-center gap-1"><Info size={12} /> Berlebihan ({KEYWORDS_OVERUSED.length})</p>
            <div className="flex flex-wrap gap-1.5">
              {KEYWORDS_OVERUSED.map(k => <span key={k} className="text-[10px] bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">{k}</span>)}
            </div>
          </div>
        </div>
        <div className="mt-3 p-3 bg-amber-50 border border-amber-100 rounded-lg text-xs text-amber-700 flex items-start gap-1.5">
          <AlertCircle size={12} className="shrink-0 mt-0.5" />
          Tambahkan keyword hanya jika benar-benar mencerminkan kemampuan atau pengalaman Anda.
        </div>
      </div>

      {/* Section Analysis */}
      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
        <div className="px-5 py-3.5 border-b border-gray-100 bg-gray-50/50">
          <h3 className="text-sm font-semibold text-gray-800">Analisis per Bagian</h3>
        </div>
        <div className="divide-y divide-gray-50">
          {SECTION_ANALYSIS.map(s => {
            const cfg = getStatusCfg(s.status);
            return (
              <div key={s.section} className="px-5 py-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-semibold text-gray-900">{s.section}</span>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full" style={{ color: cfg.color, backgroundColor: cfg.bg }}>{s.status}</span>
                    </div>
                    <p className="text-xs text-gray-500 mb-1"><strong>Temuan:</strong> {s.finding}</p>
                    <p className="text-xs text-gray-500"><strong>Rekomendasi:</strong> {s.rec}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-sm font-bold" style={{ color: cfg.color }}>{s.score}</span>
                    <button className="text-xs text-gray-600 border border-gray-200 px-2.5 py-1 rounded-lg hover:bg-gray-50 transition-colors whitespace-nowrap">{s.action}</button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recommendations */}
      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
        <div className="px-5 py-3.5 border-b border-gray-100 bg-gray-50/50">
          <h3 className="text-sm font-semibold text-gray-800">Rekomendasi Perbaikan</h3>
        </div>
        <div className="divide-y divide-gray-50">
          {RECOMMENDATIONS.map((r, i) => (
            <div key={i} className="px-5 py-3.5 flex items-center gap-3">
              <PrioBadge p={r.prio} />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-gray-800 truncate">{r.item}</p>
                <p className="text-[10px] text-gray-400">{r.section} • Dampak: <span className="text-green-600 font-semibold">{r.dampak}</span></p>
              </div>
              <div className="flex gap-1 shrink-0">
                <button onClick={() => setRecStatus({ ...recStatus, [i]: "selesai" })}
                  className={`text-xs px-2.5 py-1 rounded-lg border transition-colors ${recStatus[i] === "selesai" ? "bg-green-50 text-green-700 border-green-100" : "text-gray-600 border-gray-200 hover:bg-gray-50"}`}>
                  {recStatus[i] === "selesai" ? "✓ Selesai" : "Terapkan"}
                </button>
                <button className="text-xs text-gray-400 px-2 py-1 hover:bg-gray-100 rounded-lg transition-colors">Abaikan</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Riwayat Tab ───────────────────────────────────────────────────────────────
function RiwayatTab() {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      <table className="w-full">
        <thead>
          <tr className="border-b border-gray-100 bg-gray-50/70">
            {["Tanggal","CV","Target Posisi","Perusahaan","ATS Score","Keyword Match","Status","Aksi"].map(h => (
              <th key={h} className="text-left py-3 px-4 text-[11px] font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {ATS_HISTORY.map((a, i) => (
            <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
              <td className="py-3 px-4 text-xs text-gray-600 whitespace-nowrap">{a.tgl}</td>
              <td className="py-3 px-4 text-xs font-medium text-gray-800">{a.cv}</td>
              <td className="py-3 px-4 text-xs text-gray-600">{a.posisi}</td>
              <td className="py-3 px-4 text-xs text-gray-500">{a.co}</td>
              <td className="py-3 px-4">
                <span className={`text-sm font-bold ${a.score >= 80 ? "text-green-600" : a.score >= 70 ? "text-amber-600" : "text-red-500"}`}>{a.score}</span>
              </td>
              <td className="py-3 px-4 text-xs text-gray-600">{a.match}</td>
              <td className="py-3 px-4">
                <span className="text-[10px] font-semibold bg-green-50 text-green-600 px-2 py-0.5 rounded-full">{a.status}</span>
              </td>
              <td className="py-3 px-4">
                <div className="flex gap-1">
                  <button className="text-xs text-gray-500 border border-gray-200 px-2 py-1 rounded hover:bg-gray-50 transition-colors">Buka Hasil</button>
                  <button className="text-xs text-gray-500 border border-gray-200 px-2 py-1 rounded hover:bg-gray-50 transition-colors">Export</button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function ATSAnalyzerPage({ topBar }: { topBar?: React.ReactNode }) {
  const [tab, setTab]         = useState<ATSTab>("analisis-baru");
  const [processing, setProcessing] = useState(false);

  const handleAnalyze = () => setProcessing(true);
  const handleDone    = () => { setProcessing(false); setTab("hasil"); };

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">ATS Analyzer</h1>
            <p className="text-xs text-gray-500 mt-0.5">Analisis kesesuaian CV terhadap deskripsi pekerjaan dan dapatkan rekomendasi perbaikan.</p>
          </div>
          <button onClick={() => setTab("riwayat")}
            className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm shrink-0">
            Lihat Riwayat
          </button>
        </div>

        {/* Disclaimer */}
        <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 flex items-start gap-2 text-xs text-blue-700">
          <Info size={14} className="shrink-0 mt-0.5" />
          ATS Score merupakan estimasi berdasarkan struktur, keyword, dan kesesuaian konten. Hasil tidak menjamin kelulusan proses rekrutmen.
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <SummaryCard label="ATS Score Terakhir" value={82}  desc="Kategori Baik"           color="#22C55E" icon={BarChart2} />
          <SummaryCard label="Keyword Match"       value="78%" desc="39 dari 50 keyword"      color="#3B82F6" icon={Search} />
          <SummaryCard label="Masalah Kritis"      value={2}   desc="Perlu diperbaiki"         color="#EF4444" icon={AlertCircle} />
          <SummaryCard label="Riwayat Analisis"    value={6}   desc="3 posisi berbeda"         color="#6B7280" icon={FileText} />
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {([["analisis-baru","Analisis Baru"],["hasil","Hasil Terakhir"],["riwayat","Riwayat Analisis"]] as const).map(([id, label]) => (
            <button key={id} onClick={() => setTab(id as ATSTab)}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${tab === id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              {label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {tab === "analisis-baru" && !processing && <AnalisisBaruTab onAnalyze={handleAnalyze} />}
        {tab === "analisis-baru" && processing     && <ProcessingState onDone={handleDone} />}
        {tab === "hasil"         && <HasilTab />}
        {tab === "riwayat"       && <RiwayatTab />}
      </div>
    </main>
  );
}
