import React, { useState, useEffect } from "react";
import {
  Edit3, ChevronLeft, ChevronRight, Calendar, List,
  Smile, Meh, Frown, X, Tag, Paperclip, CheckSquare, Square,
  Download, Trash2, MoreHorizontal, Clock, BookOpen, RefreshCw,
  Bookmark, CheckCircle2,
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────
type Mood = "Sangat Baik" | "Baik" | "Biasa" | "Kurang Baik" | "Buruk";
type JurnalStatus = "Draft" | "Tersimpan" | "Diperbarui";

interface JurnalEntry {
  id: number;
  tanggal: string;
  hari: string;
  mood: Mood;
  judul: string;
  cerita: string;
  syukur: string[];
  pelajaran: string;
  refleksi: string;
  rencanaBesok: string[];
  tags: string[];
  status: JurnalStatus;
}

// ── Data Simulasi ─────────────────────────────────────────────────────────────
const RIWAYAT: JurnalEntry[] = [
  {
    id: 1, tanggal: "2 Jul 2026", hari: "Kamis", mood: "Baik",
    judul: "Hari yang cukup produktif",
    cerita: "Hari ini cukup produktif. Berhasil menyelesaikan review materi dan latihan soal.",
    syukur: ["Bisa belajar dengan fokus", "Cuaca yang menyenangkan", "Teman yang supportif"],
    pelajaran: "Konsistensi kecil setiap hari menghasilkan kemajuan besar.",
    refleksi: "Masih perlu meningkatkan manajemen waktu di sore hari.",
    rencanaBesok: ["Review bab 5 Akuntansi", "Olahraga pagi"],
    tags: ["Kuliah", "Produktif"],
    status: "Tersimpan",
  },
  {
    id: 2, tanggal: "1 Jul 2026", hari: "Rabu", mood: "Biasa",
    judul: "Awal bulan dan evaluasi keuangan",
    cerita: "Evaluasi pengeluaran bulan Juni. Perlu lebih hemat di bulan Juli.",
    syukur: ["Kesehatan yang baik", "Bisa evaluasi keuangan"],
    pelajaran: "Anggaran perlu dievaluasi setiap awal bulan.",
    refleksi: "Pengeluaran makanan perlu dikurangi 20%.",
    rencanaBesok: ["Buat budget Juli", "Mulai streak jurnal"],
    tags: ["Keuangan", "Refleksi"],
    status: "Tersimpan",
  },
  {
    id: 3, tanggal: "30 Jun 2026", hari: "Selasa", mood: "Baik",
    judul: "Persiapan target bulan baru",
    cerita: "Menyusun target-target untuk bulan Juli. Semangat untuk memulai bulan baru.",
    syukur: ["Motivasi tinggi", "Rencana yang jelas"],
    pelajaran: "Memiliki target yang jelas membuat hari lebih terarah.",
    refleksi: "Bulan Juni berjalan cukup baik secara keseluruhan.",
    rencanaBesok: ["Mulai bulan baru dengan semangat"],
    tags: ["Planning"],
    status: "Tersimpan",
  },
];

const MOOD_CFG: Record<Mood, { icon: React.ElementType; color: string; bg: string; emoji: string }> = {
  "Sangat Baik": { icon: Smile,  color: "#22C55E", bg: "#DCFCE7", emoji: "😄" },
  "Baik":        { icon: Smile,  color: "#3B82F6", bg: "#DBEAFE", emoji: "🙂" },
  "Biasa":       { icon: Meh,   color: "#F59E0B", bg: "#FEF3C7", emoji: "😐" },
  "Kurang Baik": { icon: Frown, color: "#EF4444", bg: "#FEE2E2", emoji: "😕" },
  "Buruk":       { icon: Frown, color: "#7C3AED", bg: "#EDE9FE", emoji: "😞" },
};

const PROMPT_LIST = [
  "Apa pencapaian kecil yang paling berarti hari ini?",
  "Apa satu hal yang dapat dilakukan lebih baik besok?",
  "Apa yang membuat Anda merasa bersyukur?",
  "Apa pelajaran terbesar yang Anda pelajari hari ini?",
  "Bagaimana perasaan Anda secara keseluruhan?",
];

// ── Mood Selector ─────────────────────────────────────────────────────────────
function MoodSelector({ value, onChange }: { value: Mood | null; onChange: (m: Mood) => void }) {
  return (
    <div className="flex gap-2 flex-wrap">
      {(Object.keys(MOOD_CFG) as Mood[]).map(m => {
        const cfg = MOOD_CFG[m];
        const active = value === m;
        return (
          <button key={m} onClick={() => onChange(m)}
            title={m}
            className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl border-2 transition-all ${
              active ? "border-gray-900 shadow-sm" : "border-transparent bg-gray-50 hover:border-gray-200"
            }`}>
            <span className="text-xl">{cfg.emoji}</span>
            <span className="text-[10px] font-medium text-gray-600">{m}</span>
          </button>
        );
      })}
    </div>
  );
}

// ── Autosave Indicator ────────────────────────────────────────────────────────
function AutosaveIndicator({ saved }: { saved: boolean }) {
  return (
    <span className="flex items-center gap-1 text-[10px] text-gray-400">
      {saved ? <><CheckCircle2 size={11} className="text-green-500" /> Tersimpan otomatis</> : <><RefreshCw size={11} className="animate-spin" /> Menyimpan...</>}
    </span>
  );
}

// ── Jurnal Entry Card ─────────────────────────────────────────────────────────
function JurnalEntryCard({ entry, onClick }: { entry: JurnalEntry; onClick: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const moodCfg = MOOD_CFG[entry.mood];

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-4 hover:border-gray-300 transition-all cursor-pointer group"
      onClick={onClick}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs text-gray-400">{entry.tanggal}</span>
            <span className="text-sm">{moodCfg.emoji}</span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
              style={{ color: moodCfg.color, backgroundColor: moodCfg.bg }}>{entry.mood}</span>
            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
              entry.status === "Draft" ? "bg-amber-50 text-amber-600" : "bg-green-50 text-green-600"
            }`}>{entry.status}</span>
          </div>
          <p className="text-sm font-semibold text-gray-900 mb-1 truncate">{entry.judul}</p>
          <p className="text-xs text-gray-500 line-clamp-2">{entry.cerita}</p>
          <div className="flex flex-wrap gap-1 mt-2">
            {entry.tags.map(t => (
              <span key={t} className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{t}</span>
            ))}
          </div>
        </div>
        <div className="relative" onClick={e => e.stopPropagation()}>
          <button onClick={() => setMenuOpen(!menuOpen)}
            className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity">
            <MoreHorizontal size={14} />
          </button>
          {menuOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
              <div className="absolute right-0 top-full mt-1 w-40 bg-white border border-gray-200 rounded-xl shadow-lg z-20 py-1">
                {([["Buka", BookOpen], ["Edit", Edit3], ["Export PDF", Download], ["Hapus", Trash2]] as [string, React.ElementType][]).map(([label, Icon]) => (
                  <button key={label}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs transition-colors ${label === "Hapus" ? "text-red-600 hover:bg-red-50" : "text-gray-700 hover:bg-gray-50"}`}
                    onClick={() => setMenuOpen(false)}>
                    <Icon size={12} /> {label}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Detail View ───────────────────────────────────────────────────────────────
function JurnalDetail({ entry, onClose }: { entry: JurnalEntry; onClose: () => void }) {
  const moodCfg = MOOD_CFG[entry.mood];
  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed top-0 right-0 h-screen w-[480px] bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-300">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div>
            <p className="text-xs text-gray-400">{entry.tanggal}, {entry.hari}</p>
            <h2 className="text-sm font-bold text-gray-900">{entry.judul}</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"><X size={16} /></button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          <div className="flex items-center gap-2">
            <span className="text-xl">{moodCfg.emoji}</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full"
              style={{ color: moodCfg.color, backgroundColor: moodCfg.bg }}>{entry.mood}</span>
            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${entry.status === "Draft" ? "bg-amber-50 text-amber-600" : "bg-green-50 text-green-600"}`}>{entry.status}</span>
          </div>

          {[
            { label: "Cerita Hari Ini", value: entry.cerita },
            { label: "Pelajaran Hari Ini", value: entry.pelajaran },
            { label: "Refleksi Diri", value: entry.refleksi },
          ].map(s => (
            <div key={s.label}>
              <p className="text-xs font-semibold text-gray-700 mb-1">{s.label}</p>
              <p className="text-sm text-gray-600 leading-relaxed">{s.value}</p>
            </div>
          ))}

          <div>
            <p className="text-xs font-semibold text-gray-700 mb-2">Hal yang Disyukuri</p>
            <ul className="space-y-1">
              {entry.syukur.map((s, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                  <span className="text-green-500 mt-0.5">✓</span> {s}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-xs font-semibold text-gray-700 mb-2">Rencana Besok</p>
            <ul className="space-y-1">
              {entry.rencanaBesok.map((r, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                  <span className="text-gray-400">→</span> {r}
                </li>
              ))}
            </ul>
          </div>

          <div className="flex flex-wrap gap-1">
            {entry.tags.map(t => (
              <span key={t} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{t}</span>
            ))}
          </div>
        </div>
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2">
          <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Edit3 size={12} /> Edit
          </button>
          <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Download size={12} /> Export PDF
          </button>
          <button className="flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-red-500 border border-red-100 rounded-lg hover:bg-red-50 transition-colors">
            <Trash2 size={12} />
          </button>
        </div>
      </div>
    </>
  );
}

// ── Tulis Jurnal Tab ──────────────────────────────────────────────────────────
function TulisJurnalTab() {
  const [mood, setMood] = useState<Mood | null>(null);
  const [cerita, setCerita] = useState("");
  const [syukur, setSyukur] = useState(["", "", ""]);
  const [pelajaran, setPelajaran] = useState("");
  const [refleksi, setRefleksi] = useState("");
  const [rencana, setRencana] = useState(["", ""]);
  const [tags, setTags] = useState(["Kuliah", "Produktif"]);
  const [tagInput, setTagInput] = useState("");
  const [autosaved, setAutosaved] = useState(true);
  const [selectedPrompt, setSelectedPrompt] = useState("");

  useEffect(() => {
    setAutosaved(false);
    const t = setTimeout(() => setAutosaved(true), 1500);
    return () => clearTimeout(t);
  }, [cerita, pelajaran, refleksi]);

  const addTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  return (
    <div className="grid grid-cols-[1fr_320px] gap-6">
      {/* Left — Editor */}
      <div className="space-y-4">
        {/* Date nav */}
        <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-4 py-2.5">
          <button className="p-1 rounded hover:bg-gray-100 text-gray-400"><ChevronLeft size={15} /></button>
          <span className="flex-1 text-center text-sm font-semibold text-gray-800">Jumat, 3 Juli 2026</span>
          <button className="p-1 rounded hover:bg-gray-100 text-gray-400 mr-1"><ChevronRight size={15} /></button>
          <button className="px-3 py-1 text-xs font-semibold bg-gray-900 text-white rounded-lg">Hari Ini</button>
        </div>

        {/* Mood */}
        <div className="bg-white border border-gray-200 rounded-xl p-4">
          <p className="text-xs font-semibold text-gray-700 mb-3">Mood Hari Ini</p>
          <MoodSelector value={mood} onChange={setMood} />
        </div>

        {/* Aktivitas selesai */}
        <div className="bg-white border border-gray-200 rounded-xl p-4">
          <p className="text-xs font-semibold text-gray-700 mb-2">Aktivitas Hari Ini</p>
          <div className="space-y-1.5 mb-3">
            {["Sarapan dan persiapan kuliah", "Merapikan catatan kuliah"].map((a, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-gray-600">
                <CheckSquare size={13} className="text-green-500 shrink-0" />
                <span className="line-through text-gray-400">{a}</span>
              </div>
            ))}
          </div>
          <input placeholder="Aktivitas penting lainnya..."
            className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
        </div>

        {/* Cerita hari ini */}
        <div className="bg-white border border-gray-200 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold text-gray-700">Cerita Hari Ini</p>
            <AutosaveIndicator saved={autosaved} />
          </div>
          {/* Simple rich-text toolbar */}
          <div className="flex items-center gap-1 mb-2 pb-2 border-b border-gray-100 flex-wrap">
            {["B", "I", "•—", "1.", "❝", "🔗"].map(t => (
              <button key={t} className="px-2 py-1 text-xs font-bold text-gray-500 hover:bg-gray-100 rounded transition-colors min-w-[28px]">
                {t}
              </button>
            ))}
          </div>
          <textarea value={cerita} onChange={e => setCerita(e.target.value)}
            rows={5} placeholder="Apa yang terjadi hari ini?"
            className="w-full text-sm text-gray-700 outline-none resize-none placeholder:text-gray-300 leading-relaxed" />
          {selectedPrompt && (
            <p className="text-xs text-blue-600 bg-blue-50 rounded-lg p-2 mt-2 italic">{selectedPrompt}</p>
          )}
        </div>

        {/* Hal yang disyukuri */}
        <div className="bg-white border border-gray-200 rounded-xl p-4">
          <p className="text-xs font-semibold text-gray-700 mb-3">Hal yang Disyukuri</p>
          <div className="space-y-2">
            {[
              "Saya bersyukur untuk...",
              "Hal baik yang saya alami...",
              "Orang atau kejadian yang saya hargai...",
            ].map((ph, i) => (
              <input key={i} value={syukur[i]} onChange={e => setSyukur(prev => { const n = [...prev]; n[i] = e.target.value; return n; })}
                placeholder={ph}
                className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
            ))}
          </div>
        </div>

        {/* Pelajaran & Refleksi */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white border border-gray-200 rounded-xl p-4">
            <p className="text-xs font-semibold text-gray-700 mb-2">Pelajaran Hari Ini</p>
            <textarea value={pelajaran} onChange={e => setPelajaran(e.target.value)}
              rows={3} placeholder="Apa hal penting yang Anda pelajari hari ini?"
              className="w-full text-sm outline-none resize-none text-gray-700 placeholder:text-gray-300 leading-relaxed" />
          </div>
          <div className="bg-white border border-gray-200 rounded-xl p-4">
            <p className="text-xs font-semibold text-gray-700 mb-2">Refleksi Diri</p>
            <textarea value={refleksi} onChange={e => setRefleksi(e.target.value)}
              rows={3} placeholder="Apa yang sudah berjalan baik dan apa yang perlu diperbaiki?"
              className="w-full text-sm outline-none resize-none text-gray-700 placeholder:text-gray-300 leading-relaxed" />
          </div>
        </div>

        {/* Rencana besok */}
        <div className="bg-white border border-gray-200 rounded-xl p-4">
          <p className="text-xs font-semibold text-gray-700 mb-2">Rencana Besok</p>
          <div className="space-y-2">
            {rencana.map((r, i) => (
              <div key={i} className="flex items-center gap-2">
                <Square size={13} className="text-gray-300 shrink-0" />
                <input value={r} onChange={e => setRencana(prev => { const n = [...prev]; n[i] = e.target.value; return n; })}
                  placeholder="Apa yang ingin Anda prioritaskan besok?"
                  className="flex-1 text-sm outline-none border-b border-gray-100 py-1 focus:border-gray-300 transition-colors text-gray-700 placeholder:text-gray-300" />
              </div>
            ))}
            <button onClick={() => setRencana([...rencana, ""])}
              className="text-xs text-gray-400 hover:text-gray-600 transition-colors">+ Tambah rencana</button>
          </div>
        </div>

        {/* Tags */}
        <div className="bg-white border border-gray-200 rounded-xl p-4">
          <p className="text-xs font-semibold text-gray-700 mb-2">Tag</p>
          <div className="flex flex-wrap gap-1.5 mb-2">
            {tags.map(t => (
              <span key={t} className="flex items-center gap-1 text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">
                {t}
                <button onClick={() => setTags(tags.filter(x => x !== t))} className="text-gray-400 hover:text-red-500 ml-0.5"><X size={10} /></button>
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <input value={tagInput} onChange={e => setTagInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && addTag()}
              placeholder="Tambah tag..."
              className="flex-1 text-sm px-3 py-1.5 border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300" />
            <button onClick={addTag} className="px-3 py-1.5 text-xs bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors">Tambah</button>
          </div>
        </div>

        {/* Lampiran */}
        <div className="bg-white border border-dashed border-gray-300 rounded-xl p-4 text-center hover:border-gray-400 transition-colors cursor-pointer">
          <Paperclip size={18} className="text-gray-300 mx-auto mb-1.5" />
          <p className="text-xs text-gray-400">Seret file ke sini atau <span className="text-gray-600 underline">pilih file</span></p>
          <p className="text-[10px] text-gray-300 mt-0.5">Gambar atau PDF</p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3 justify-end pb-4">
          <AutosaveIndicator saved={autosaved} />
          <button className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            Simpan Draft
          </button>
          <button className="px-4 py-2 text-sm font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors">
            Simpan Jurnal
          </button>
        </div>
      </div>

      {/* Right — Summary & Prompts */}
      <div className="space-y-4">
        <div className="bg-white border border-gray-200 rounded-xl p-4 sticky top-4">
          <p className="text-xs font-semibold text-gray-700 mb-3">Ringkasan Hari Ini</p>
          <div className="space-y-2.5">
            {[
              { label: "Aktivitas selesai", value: "2 dari 5", color: "#22C55E" },
              { label: "Langkah hari ini", value: "7.420 langkah", color: "#3B82F6" },
              { label: "Pengeluaran", value: "Rp57.000", color: "#F59E0B" },
              { label: "Target membaca", value: "20 halaman", color: "#8B5CF6" },
              { label: "Status jurnal", value: "Belum disimpan", color: "#EF4444" },
            ].map(s => (
              <div key={s.label} className="flex items-center justify-between">
                <span className="text-xs text-gray-500">{s.label}</span>
                <span className="text-xs font-semibold" style={{ color: s.color }}>{s.value}</span>
              </div>
            ))}
          </div>

          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-xs font-semibold text-gray-700 mb-2">Prompt Refleksi</p>
            <div className="space-y-2">
              {PROMPT_LIST.slice(0, 3).map(p => (
                <div key={p} className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-xs text-gray-600 mb-1.5 leading-relaxed">{p}</p>
                  <button onClick={() => setSelectedPrompt(p)}
                    className="text-[10px] text-gray-500 hover:text-gray-700 font-medium underline transition-colors">
                    Gunakan Prompt Ini
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-xs font-semibold text-gray-700 mb-2">Streak Jurnal</p>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold text-gray-900">6</span>
              <div>
                <p className="text-xs font-medium text-gray-700">hari berturut-turut</p>
                <p className="text-[10px] text-gray-400">Pertahankan konsistensi!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Riwayat Tab ───────────────────────────────────────────────────────────────
function RiwayatJurnalTab({ onDetail }: { onDetail: (e: JurnalEntry) => void }) {
  const [search, setSearch] = useState("");
  const [filterMood, setFilterMood] = useState("Semua Mood");

  // Simple July 2026 heatmap
  const daysWithJournal = [30, 29, 28, 27, 26, 2, 1];

  const filtered = RIWAYAT.filter(e => {
    const matchQ = e.judul.toLowerCase().includes(search.toLowerCase()) || e.cerita.toLowerCase().includes(search.toLowerCase());
    const matchM = filterMood === "Semua Mood" || e.mood === filterMood;
    return matchQ && matchM;
  });

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[180px]">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs">🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari jurnal..."
            className="w-full pl-8 pr-3 py-2 text-sm border border-gray-200 rounded-lg outline-none focus:ring-1 focus:ring-gray-300 bg-white" />
        </div>
        <select value={filterMood} onChange={e => setFilterMood(e.target.value)}
          className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white outline-none">
          <option>Semua Mood</option>
          {Object.keys(MOOD_CFG).map(m => <option key={m}>{m}</option>)}
        </select>
      </div>

      {/* Calendar heatmap */}
      <div className="bg-white border border-gray-200 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-semibold text-gray-700">Juli 2026</p>
          <div className="flex items-center gap-2 text-[10px] text-gray-400">
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-gray-100 inline-block" /> Tidak ada</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-blue-400 inline-block" /> Ada jurnal</span>
          </div>
        </div>
        <div className="grid grid-cols-7 gap-1">
          {["Min","Sen","Sel","Rab","Kam","Jum","Sab"].map(d => (
            <div key={d} className="text-center text-[9px] text-gray-400 font-medium pb-1">{d}</div>
          ))}
          {/* offset for July 1 = Wednesday */}
          {[1,2,3].map(i => <div key={"pad"+i} />)}
          {Array.from({ length: 31 }, (_, i) => i + 1).map(d => {
            const hasJ = daysWithJournal.includes(d);
            const isToday = d === 3;
            return (
              <div key={d}
                className={`aspect-square rounded-sm flex items-center justify-center text-[10px] font-medium cursor-pointer transition-all ${
                  isToday ? "bg-gray-900 text-white" :
                  hasJ ? "bg-blue-100 text-blue-700 hover:bg-blue-200" :
                  "bg-gray-50 text-gray-400 hover:bg-gray-100"
                }`}>
                {d}
              </div>
            );
          })}
        </div>
      </div>

      {/* Entry list */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-xl p-10 text-center">
            <BookOpen size={28} className="text-gray-200 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Belum ada jurnal yang sesuai filter.</p>
          </div>
        ) : (
          filtered.map(e => <JurnalEntryCard key={e.id} entry={e} onClick={() => onDetail(e)} />)
        )}
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export function JurnalHarianPage({ topBar }: { topBar?: React.ReactNode }) {
  const [tab, setTab] = useState<"tulis" | "riwayat">("tulis");
  const [detailEntry, setDetailEntry] = useState<JurnalEntry | null>(null);

  const summaryCards = [
    { label: "Status Hari Ini", value: "Belum Diisi", desc: "Mulai menulis jurnal hari ini", color: "#F59E0B", icon: Edit3 },
    { label: "Streak Jurnal", value: "6 Hari", desc: "Pertahankan konsistensi Anda", color: "#22C55E", icon: Bookmark },
    { label: "Jurnal Bulan Ini", value: "12", desc: "Dari 31 hari pada Juli", color: "#3B82F6", icon: Calendar },
    { label: "Mood Terbanyak", value: "Produktif", desc: "Berdasarkan jurnal bulan ini", color: "#8B5CF6", icon: Smile },
  ];

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50 min-w-0">
      {topBar}
      <div className="px-8 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Jurnal Harian</h1>
            <p className="text-xs text-gray-500 mt-0.5">Catat aktivitas, refleksi, dan pelajaran dari hari Anda.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button onClick={() => setTab("riwayat")}
              className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border border-gray-200 bg-white rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
              <List size={13} /> Lihat Riwayat
            </button>
            <button onClick={() => setTab("tulis")}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gray-900 rounded-lg hover:bg-black transition-colors shadow-sm">
              <Edit3 size={13} /> Tulis Jurnal Hari Ini
            </button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          {summaryCards.map(c => (
            <div key={c.label} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">{c.label}</span>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: c.color + "18", color: c.color }}>
                  <c.icon size={16} />
                </div>
              </div>
              <p className="text-lg font-bold text-gray-900 leading-tight">{c.value}</p>
              <p className="text-[11px] text-gray-400 leading-snug">{c.desc}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200 w-fit">
          {([["tulis","Tulis Jurnal",Edit3], ["riwayat","Riwayat Jurnal",List]] as const).map(([id, label, Icon]) => (
            <button key={id} onClick={() => setTab(id as "tulis" | "riwayat")}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${tab === id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}>
              <Icon size={13} /> {label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {tab === "tulis" && <TulisJurnalTab />}
        {tab === "riwayat" && <RiwayatJurnalTab onDetail={setDetailEntry} />}
      </div>

      {detailEntry && <JurnalDetail entry={detailEntry} onClose={() => setDetailEntry(null)} />}
    </main>
  );
}
