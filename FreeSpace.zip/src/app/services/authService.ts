import apiClient from "./apiClient";

export interface LoginPayload {
  email: string;
  password: string;
  turnstileToken?: string; // Cloudflare Turnstile verification token
}

export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  user: {
    id: string;
    nama: string;
    email: string;
    role: string;
    unit?: string;
  };
}

export const authService = {
  async login(payload: LoginPayload): Promise<AuthTokens> {
    const { data } = await apiClient.post<AuthTokens>("/auth/login", payload);
    localStorage.setItem("access_token", data.access_token);
    localStorage.setItem("refresh_token", data.refresh_token);
    return data;
  },

  async logout(): Promise<void> {
    try {
      await apiClient.post("/auth/logout");
    } finally {
      localStorage.removeItem("access_token");
      localStorage.removeItem("refresh_token");
    }
  },

  async refreshToken(): Promise<string> {
    const refresh = localStorage.getItem("refresh_token");
    const { data } = await apiClient.post<{ access_token: string }>("/auth/refresh", {
      refresh_token: refresh,
    });
    localStorage.setItem("access_token", data.access_token);
    return data.access_token;
  },

  async getProfile() {
    const { data } = await apiClient.get("/auth/profile");
    return data;
  },

  isAuthenticated(): boolean {
    return !!localStorage.getItem("access_token");
  },

  getAccessToken(): string | null {
    return localStorage.getItem("access_token");
  },
};

export default authService;
