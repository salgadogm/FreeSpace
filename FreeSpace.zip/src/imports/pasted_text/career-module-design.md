ROLE AND EXECUTION MODE

Anda adalah Senior Product Designer, UX Architect, Career-Tech Product Designer, ATS Product Specialist, CV Editor Experience Designer, TOEFL Learning Designer, Interview Simulation Designer, dan Figma Design-System Specialist.

Edit langsung desain FreeSpace yang SUDAH ADA pada file Figma ini.

Kondisi desain saat ini:

1. Branding telah menjadi “FreeSpace – Personal Workspace”.
2. Sidebar, topbar, profile card, search, Tanya AI, notifikasi, dan share sudah tersedia.
3. Parent menu Karier sudah tersedia dan dapat diperluas.
4. Submenu Karier sudah terdiri dari:
   - CV Builder
   - ATS Analyzer
   - TOEFL Training
   - Interview Simulator
5. Halaman CV Builder masih berupa placeholder “Segera Hadir”.
6. Halaman ATS Analyzer, TOEFL Training, dan Interview Simulator belum memiliki konten lengkap.
7. Visual language, card, table, form, tabs, modal, drawer, dan komponen dasar FreeSpace telah tersedia dari modul sebelumnya.

Tugas Anda sekarang adalah:

1. Menghapus seluruh placeholder “Segera Hadir” pada modul Karier.
2. Mendesain dan mengeksekusi halaman CV Builder.
3. Mendesain dan mengeksekusi halaman ATS Analyzer.
4. Mendesain dan mengeksekusi halaman TOEFL Training.
5. Mendesain dan mengeksekusi halaman Interview Simulator.
6. Membuat reusable components, variants, states, overlays, dan prototype interactions.
7. Menggunakan visual pattern existing FreeSpace.
8. Mempertahankan information architecture yang telah disetujui.
9. Tidak menambah submenu baru pada sidebar.
10. Tidak membuat Dashboard Karier baru.

Jangan hanya menghasilkan penjelasan, konsep, atau low-fidelity wireframe.

Eksekusi desain final high-fidelity menggunakan:

- Existing frames.
- Components.
- Component variants.
- Auto Layout.
- Variables.
- Constraints.
- Prototype links.
- Modals.
- Drawers.
- Responsive states.

==================================================
1. PRINSIP UTAMA MODUL KARIER
==================================================

Modul Karier membantu pengguna mempersiapkan diri untuk melamar pekerjaan di bidang:

- Akuntansi.
- Keuangan.
- Audit.
- Perpajakan.
- Perbankan.
- Financial Planning and Analysis.
- Fresh Graduate General Role.

Struktur sidebar tetap:

Karier
- CV Builder
- ATS Analyzer
- TOEFL Training
- Interview Simulator

Tidak boleh menambahkan hierarchy level ketiga pada sidebar.

Jangan membuat submenu sidebar seperti:

- Daftar CV.
- Editor CV.
- Template CV.
- Preview.
- Export.
- Analisis CV.
- Riwayat Analisis.
- Listening.
- Structure.
- Reading.
- Simulasi Tes.
- Hasil Tes.
- HR Interview.
- Technical Interview.
- Behavioral Interview.
- Hasil Interview.

Seluruh fungsi tersebut harus ditempatkan sebagai:

- Tabs.
- Segmented controls.
- Internal navigation.
- Page sections.
- Modal.
- Drawer.
- Setup screen.
- Stepper.
- Toolbar.
- Filters.

Jangan membuat:

- Dashboard Karier.
- Dashboard CV.
- Dashboard TOEFL.
- Dashboard Interview.
- Menu Job Portal.
- Menu Lowongan Kerja.
- Menu Lamaran.
- Menu Portfolio.
- Menu Cover Letter baru.
- Menu AI Karier di sidebar.
- Navigation level ketiga.

Dashboard global tetap menjadi satu-satunya Dashboard di seluruh aplikasi.

==================================================
2. PERTAHANKAN DESAIN EXISTING
==================================================

Pertahankan sepenuhnya:

- Ukuran dan posisi sidebar.
- Ukuran dan posisi topbar.
- Logo FreeSpace.
- Subtitle Personal Workspace.
- Profile card pengguna.
- Search field.
- Shortcut indicator pada search.
- Tombol Tanya AI.
- Notification icon dan badge.
- Share button.
- Page background.
- Page padding.
- Existing grid.
- Typography.
- Font family.
- Heading hierarchy.
- Body text style.
- Warna utama.
- Warna status.
- Icon style.
- Border.
- Border radius.
- Shadow.
- Card style.
- Table style.
- Form style.
- Breadcrumb style.
- Sidebar active state.
- Sidebar hover state.
- Spacing system.
- Existing design tokens.

Jangan:

- Membuat visual language baru.
- Mengganti font.
- Membuat gradient baru.
- Memperlebar sidebar.
- Memindahkan profile card.
- Mengubah topbar.
- Mengubah tombol Tanya AI.
- Membuat navigation rail baru.
- Membuat bottom navigation pada desktop.
- Menggunakan ilustrasi dekoratif berlebihan.
- Membuat halaman menyerupai marketplace pekerjaan.
- Membuat desain seperti HR enterprise system.
- Menggunakan terlalu banyak warna.
- Mengubah tampilan utama menjadi dark theme.
- Menggunakan card berbeda dari design system existing.
- Memenuhi halaman dengan terlalu banyak panel kecil.

==================================================
3. DATA SIMULASI YANG HARUS KONSISTEN
==================================================

Gunakan data simulasi berikut di seluruh modul Karier.

Nama pengguna:
Salgado Ginting

Status:
Mahasiswa Akuntansi

Target posisi:
Junior Accountant

Target bidang:
Akuntansi dan Keuangan

CV tersimpan:
3 CV

CV aktif:
CV Akuntansi 2026

Kelengkapan CV aktif:
92%

ATS score terakhir:
82/100

Job description aktif:
Junior Accountant — PT Contoh Indonesia

Keyword match:
78%

Masalah kritis CV:
2

Rekomendasi perbaikan:
6

TOEFL estimated score terakhir:
493

Listening:
48 dari 68

Structure:
31 dari 40

Reading:
36 dari 50

Target TOEFL:
550

Latihan TOEFL selesai:
24 sesi

Streak TOEFL:
5 hari

Simulasi interview selesai:
8 sesi

Skor interview terakhir:
78/100

Kekuatan interview:
Struktur jawaban dan pemahaman dasar akuntansi

Area perbaikan:
Kejelasan contoh pengalaman dan penggunaan bahasa Inggris

Tanggal aktif:
3 Juli 2026

Gunakan data tersebut secara konsisten pada halaman, card, riwayat, dan Dashboard global.

==================================================
4. GLOBAL PAGE TEMPLATE
==================================================

Gunakan page template yang konsisten pada seluruh modul Karier.

Struktur:

Topbar
Breadcrumb
Page header
- Judul halaman
- Subtitle
- Primary action
- Secondary action jika diperlukan
Content area
- Summary cards jika relevan
- Tabs atau segmented control
- Filter toolbar
- Main content
- Table, editor, test interface, atau simulator
Optional modal atau drawer

Gunakan maksimal:

- Satu primary action utama per halaman.
- Satu atau dua secondary actions.
- Empat summary cards dalam satu baris.
- Empat sampai lima filter utama.
- Tiga sampai empat section besar pada initial viewport.
- Lima sampai sepuluh rows tabel pada initial viewport.

Jangan memenuhi halaman dengan terlalu banyak card kecil.

==================================================
5. SIDEBAR DAN ACTIVE STATE
==================================================

Untuk seluruh frame Karier:

- Parent Karier harus expanded.
- Keuangan collapsed.
- Produktivitas collapsed.
- Library collapsed.
- Pengaturan collapsed.

Buat active state berikut:

1. Karier expanded dan CV Builder aktif.
2. Karier expanded dan ATS Analyzer aktif.
3. Karier expanded dan TOEFL Training aktif.
4. Karier expanded dan Interview Simulator aktif.

Pertahankan:

- Parent icon.
- Child dot indicator.
- Indentation.
- Chevron.
- Active child background.
- Parent active state.
- Item height.
- Spacing.
- Font weight.
- Border radius.

Hanya satu child aktif pada satu waktu.

==================================================
6. HALAMAN CV BUILDER
==================================================

FRAME NAME:

FreeSpace/Desktop/Karier/CVBuilder-List

Hapus seluruh placeholder:

- Segera Hadir.
- Fitur CV Builder sedang dalam pengembangan.
- Loading dots.
- Development empty state.

BREADCRUMB:

Karier > CV Builder

JUDUL:

CV Builder

SUBTITLE:

Buat, kelola, dan export CV profesional yang ramah ATS.

PRIMARY ACTION:

Buat CV Baru

Icon:
Document Plus

SECONDARY ACTION:

Import CV

Icon:
Arrow Up Tray

--------------------------------------------------
6.1 SUMMARY CARDS CV BUILDER
--------------------------------------------------

Buat empat summary cards.

CARD 1

Label:
Total CV

Value:
3

Description:
Versi CV tersimpan

Status:
Primary

CARD 2

Label:
CV Aktif

Value:
CV Akuntansi 2026

Description:
Diperbarui 2 Jul 2026

Status:
Secondary

CARD 3

Label:
Kelengkapan

Value:
92%

Description:
2 bagian perlu dilengkapi

Status:
Positive

CARD 4

Label:
ATS Score Terakhir

Value:
82

Description:
Cocok untuk Junior Accountant

Status:
Positive atau primary

Gunakan card style existing.

--------------------------------------------------
6.2 INTERNAL TABS CV BUILDER
--------------------------------------------------

Buat tabs:

- CV Saya
- Template
- Riwayat Versi

Default active:
CV Saya

Jangan menjadikan tabs ini sebagai submenu sidebar.

--------------------------------------------------
6.3 TAB CV SAYA
--------------------------------------------------

Toolbar:

- Search CV.
- Filter bahasa.
- Filter status.
- Sort.
- Grid/List view.

Search placeholder:

Cari nama CV...

Bahasa:

- Semua Bahasa.
- Bahasa Indonesia.
- English.

Status:

- Semua Status.
- Draft.
- Aktif.
- Diarsipkan.

Sort:

- Terakhir Diperbarui.
- Terbaru Dibuat.
- Nama A–Z.
- ATS Score Tertinggi.

Buat CV card component.

Setiap card menampilkan:

- Thumbnail CV.
- Nama CV.
- Target posisi.
- Bahasa.
- Template.
- Kelengkapan.
- ATS score terakhir.
- Tanggal diperbarui.
- Status.
- More action.

Data:

1.
CV Akuntansi 2026
Target: Junior Accountant
Bahasa: Bahasa Indonesia
Template: ATS Minimal
Kelengkapan: 92%
ATS Score: 82
Status: Aktif

2.
CV Finance English
Target: Finance Intern
Bahasa: English
Template: Professional
Kelengkapan: 85%
ATS Score: 76
Status: Draft

3.
CV General Fresh Graduate
Target: Management Trainee
Bahasa: Bahasa Indonesia
Template: Clean
Kelengkapan: 78%
ATS Score: 71
Status: Draft

Actions:

- Edit CV.
- Preview.
- Analisis ATS.
- Duplikat.
- Rename.
- Export PDF.
- Export Word.
- Jadikan CV Aktif.
- Arsipkan.
- Hapus.

Hapus menggunakan confirmation modal.

--------------------------------------------------
6.4 TAB TEMPLATE
--------------------------------------------------

Tampilkan template CV yang ATS-friendly.

Template:

1. ATS Minimal
2. Clean Professional
3. Modern Accounting
4. Classic Corporate
5. Simple Graduate

Setiap template menampilkan:

- Preview.
- Nama.
- Deskripsi singkat.
- ATS-friendly badge.
- Single-column atau two-column indicator.
- Bahasa yang didukung.
- Button Gunakan Template.

Jangan membuat template dengan:

- Grafik skill berlebihan.
- Progress bar skill.
- Banyak icon dekoratif.
- Foto wajib.
- Layout terlalu kompleks.
- Dua kolom sempit yang sulit dibaca ATS.

Tambahkan filter:

- ATS Friendly.
- Satu Kolom.
- Dua Kolom.
- Bahasa Indonesia.
- English.

--------------------------------------------------
6.5 TAB RIWAYAT VERSI
--------------------------------------------------

Tampilkan version history.

Kolom:

- Versi.
- Nama CV.
- Perubahan.
- Tanggal.
- Sumber.
- Action.

Data:

v1.4
CV Akuntansi 2026
Memperbaiki pengalaman organisasi
2 Jul 2026, 20.15
Manual

v1.3
CV Akuntansi 2026
Mengoptimalkan keyword Junior Accountant
2 Jul 2026, 18.42
ATS Recommendation

v1.2
CV Akuntansi 2026
Menambahkan sertifikasi
1 Jul 2026, 21.10
Manual

Actions:

- Preview.
- Bandingkan.
- Pulihkan Versi.
- Duplikat.

Pemulihan versi harus meminta konfirmasi.

==================================================
7. MODAL BUAT CV BARU
==================================================

Buat modal atau stepper.

Judul:

Buat CV Baru

Step 1:
Informasi Awal

Fields:

- Nama CV.
- Target posisi.
- Bahasa.
- Template.
- Gunakan data profil tersimpan.

Step 2:
Pilih Sumber

Options:

- Mulai dari Kosong.
- Duplikat CV Lama.
- Import CV.
- Gunakan Data Profil.

Step 3:
Konfirmasi

Buttons:

- Batal.
- Kembali.
- Lanjutkan.
- Buat CV.

==================================================
8. CV EDITOR
==================================================

FRAME NAME:

FreeSpace/Desktop/Karier/CVBuilder-Editor

Gunakan layout tiga kolom pada desktop.

KOLOM KIRI:
Section navigator.

KOLOM TENGAH:
Form editor.

KOLOM KANAN:
Live preview CV.

Jangan mengubah sidebar utama aplikasi.

--------------------------------------------------
8.1 EDITOR TOPBAR INTERNAL
--------------------------------------------------

Buat toolbar internal:

- Back ke CV Saya.
- Nama CV.
- Status autosave.
- Undo.
- Redo.
- Preview mode.
- Pilih template.
- Analisis ATS.
- Export.

Autosave indicator:

Tersimpan otomatis

States:

- Menyimpan...
- Tersimpan.
- Gagal menyimpan.
- Perubahan belum tersimpan.

--------------------------------------------------
8.2 SECTION NAVIGATOR
--------------------------------------------------

Sections:

- Informasi Pribadi.
- Ringkasan Profesional.
- Pendidikan.
- Pengalaman.
- Organisasi.
- Proyek.
- Keahlian.
- Sertifikasi.
- Bahasa.
- Penghargaan.
- Referensi.
- Section Tambahan.

Setiap section menampilkan:

- Completion indicator.
- Drag handle.
- Visibility toggle.
- Error indicator jika ada data wajib belum lengkap.

Pengguna dapat:

- Mengubah urutan.
- Menyembunyikan section.
- Menambahkan section.
- Menghapus section tambahan.

Section inti tertentu tidak dihapus permanen, hanya disembunyikan.

--------------------------------------------------
8.3 INFORMASI PRIBADI
--------------------------------------------------

Fields:

- Nama lengkap.
- Headline profesional.
- Email.
- Nomor telepon.
- Kota dan negara.
- LinkedIn.
- Portfolio atau website.
- Foto opsional.
- Status ketersediaan kerja opsional.

Tambahkan privacy note:

Masukkan hanya informasi pribadi yang relevan dengan lamaran kerja.

Foto tidak wajib.

--------------------------------------------------
8.4 RINGKASAN PROFESIONAL
--------------------------------------------------

Rich textarea.

Placeholder:

Tuliskan ringkasan singkat mengenai latar belakang, kompetensi, dan target karier Anda.

Character guidance:

40–80 kata

Tambahkan indikator:

- Terlalu pendek.
- Ideal.
- Terlalu panjang.

AI contextual action:

Bantu Perbaiki

Pilihan:

- Buat Lebih Ringkas.
- Buat Lebih Profesional.
- Sesuaikan dengan Posisi.
- Perbaiki Tata Bahasa.

AI tidak boleh mengganti teks tanpa konfirmasi pengguna.

--------------------------------------------------
8.5 PENDIDIKAN
--------------------------------------------------

Repeatable form.

Fields:

- Institusi.
- Program studi.
- Jenjang.
- Lokasi.
- Tanggal mulai.
- Tanggal selesai.
- Masih belajar toggle.
- IPK opsional.
- Deskripsi atau pencapaian.
- Mata kuliah relevan opsional.

Actions:

- Tambah Pendidikan.
- Edit.
- Duplikat.
- Hapus.
- Ubah Urutan.

--------------------------------------------------
8.6 PENGALAMAN
--------------------------------------------------

Repeatable form.

Fields:

- Nama perusahaan.
- Posisi.
- Tipe pekerjaan.
- Lokasi.
- Tanggal mulai.
- Tanggal selesai.
- Masih bekerja toggle.
- Deskripsi.
- Pencapaian.
- Tools.
- Skills terkait.

Gunakan bullet editor.

Tambahkan guidance:

Gunakan kata kerja aktif dan hasil yang terukur.

Contoh visual, bukan isi wajib:

- Mengelola...
- Menganalisis...
- Menyusun...
- Mengurangi...
- Meningkatkan...

Tambahkan AI action:

Optimalkan Bullet

Jangan membuat data pengalaman palsu.

--------------------------------------------------
8.7 ORGANISASI DAN PROYEK
--------------------------------------------------

ORGANISASI

Fields:

- Nama organisasi.
- Peran.
- Periode.
- Deskripsi.
- Pencapaian.

PROYEK

Fields:

- Nama proyek.
- Peran.
- Periode.
- Deskripsi.
- Tools.
- Link.
- Hasil.

--------------------------------------------------
8.8 KEAHLIAN
--------------------------------------------------

Groups:

- Hard Skills.
- Software.
- Accounting Skills.
- Soft Skills.
- Other Skills.

Contoh:

Accounting Skills:

- Financial Reporting.
- General Ledger.
- Journal Entries.
- Financial Analysis.
- Budgeting.
- Tax Basics.
- Audit Basics.

Software:

- Microsoft Excel.
- Microsoft Word.
- Google Sheets.
- Accounting Software.

Jangan gunakan rating bintang atau progress bar untuk tingkat skill.

Gunakan level teks opsional:

- Dasar.
- Menengah.
- Mahir.

--------------------------------------------------
8.9 SERTIFIKASI, BAHASA, DAN PENGHARGAAN
--------------------------------------------------

SERTIFIKASI

Fields:

- Nama sertifikasi.
- Penerbit.
- Tanggal terbit.
- Tanggal kedaluwarsa.
- Credential ID.
- Credential URL.

BAHASA

Fields:

- Bahasa.
- Tingkat kemampuan.

Options:

- Dasar.
- Menengah.
- Profesional.
- Fasih.
- Native.

PENGHARGAAN

Fields:

- Nama penghargaan.
- Pemberi.
- Tanggal.
- Deskripsi.

--------------------------------------------------
8.10 LIVE PREVIEW
--------------------------------------------------

Preview harus:

- Menggunakan ukuran halaman A4.
- Memiliki zoom.
- Fit width.
- Page navigation jika lebih dari satu halaman.
- Menunjukkan page break.
- Update secara real-time.
- Mempertahankan margin printable.
- Menampilkan warning jika melebihi dua halaman.

Controls:

- Zoom out.
- Zoom percentage.
- Zoom in.
- Fit width.
- Full preview.
- Toggle page boundary.

Warning:

CV Anda telah melebihi dua halaman.

Action:

Lihat Bagian yang Dapat Diringkas.

==================================================
9. EXPORT CV
==================================================

Buat export modal.

Judul:

Export CV

Formats:

- PDF.
- Word DOCX.

Options:

- Nama file.
- Page size A4.
- Include hyperlinks.
- Embed fonts jika didukung.
- ATS-safe mode.
- Print quality.

Default filename:

Salgado_Ginting_CV_Junior_Accountant_2026

Buttons:

- Batal.
- Export.

States:

- Preparing.
- Generating.
- Success.
- Failed.

Success:

CV berhasil diekspor.

==================================================
10. HALAMAN ATS ANALYZER
==================================================

FRAME NAME:

FreeSpace/Desktop/Karier/ATSAnalyzer-Setup

BREADCRUMB:

Karier > ATS Analyzer

JUDUL:

ATS Analyzer

SUBTITLE:

Analisis kesesuaian CV terhadap deskripsi pekerjaan dan dapatkan rekomendasi perbaikan.

PRIMARY ACTION:

Mulai Analisis

Icon:
Magnifying Glass

SECONDARY ACTION:

Lihat Riwayat

Tambahkan information banner:

ATS Score merupakan estimasi berdasarkan struktur, keyword, dan kesesuaian konten. Hasil tidak menjamin kelulusan proses rekrutmen.

--------------------------------------------------
10.1 SUMMARY CARDS ATS
--------------------------------------------------

Buat empat cards.

CARD 1

Label:
ATS Score Terakhir

Value:
82

Description:
Kategori Baik

CARD 2

Label:
Keyword Match

Value:
78%

Description:
39 dari 50 keyword relevan

CARD 3

Label:
Masalah Kritis

Value:
2

Description:
Perlu diperbaiki sebelum melamar

CARD 4

Label:
Riwayat Analisis

Value:
6

Description:
3 posisi berbeda

--------------------------------------------------
10.2 INTERNAL TABS ATS
--------------------------------------------------

Tabs:

- Analisis Baru
- Hasil Terakhir
- Riwayat Analisis

Default active:
Analisis Baru

--------------------------------------------------
10.3 SETUP ANALISIS
--------------------------------------------------

Gunakan layout dua kolom.

KOLOM KIRI:
Pilih CV.

Options:

- Pilih CV dari CV Builder.
- Upload CV PDF.
- Upload CV DOCX.

Default selected:

CV Akuntansi 2026

Tampilkan preview ringkas:

- Nama CV.
- Bahasa.
- Kelengkapan.
- Terakhir diperbarui.

KOLOM KANAN:
Job Description.

Fields:

- Target posisi.
- Nama perusahaan opsional.
- Lokasi opsional.
- Paste job description.
- Upload job description opsional.
- Bahasa pekerjaan.

Default:

Target posisi:
Junior Accountant

Company:
PT Contoh Indonesia

Textarea placeholder:

Tempelkan deskripsi pekerjaan di sini...

Validation:

- CV wajib dipilih.
- Job description wajib tersedia.
- Minimal panjang job description.
- File harus valid.

Button:

Analisis CV

==================================================
11. ATS PROCESSING STATE
==================================================

Buat processing state.

Steps:

1. Membaca struktur CV.
2. Mengidentifikasi keyword pekerjaan.
3. Membandingkan pengalaman dan skill.
4. Mengevaluasi format ATS.
5. Menyusun rekomendasi.

Progress indicator:

0–100%

Copy:

Analisis biasanya membutuhkan beberapa detik.

Jangan menampilkan klaim pasti mengenai durasi.

==================================================
12. HASIL ATS ANALYZER
==================================================

FRAME NAME:

FreeSpace/Desktop/Karier/ATSAnalyzer-Result

Header:

CV Akuntansi 2026

Target:
Junior Accountant

Company:
PT Contoh Indonesia

Overall ATS score:
82/100

Category:
Baik

--------------------------------------------------
12.1 SCORE BREAKDOWN
--------------------------------------------------

Buat cards atau bars:

- Keyword Match: 78%.
- Struktur CV: 92%.
- Pengalaman Relevan: 80%.
- Keahlian: 84%.
- Pendidikan: 90%.
- Keterbacaan: 88%.
- Format ATS: 95%.
- Kelengkapan: 92%.

Gunakan status:

- Sangat Baik.
- Baik.
- Perlu Perbaikan.
- Kritis.

--------------------------------------------------
12.2 KEYWORD ANALYSIS
--------------------------------------------------

Buat tiga groups.

Keyword Ditemukan:

- Journal Entries.
- Microsoft Excel.
- Financial Reporting.
- General Ledger.
- Reconciliation.
- Accounting.

Keyword Belum Ditemukan:

- Accounts Payable.
- Accounts Receivable.
- Month-End Closing.
- ERP.
- Tax Reporting.

Keyword Berlebihan:

- Accounting.
- Teamwork.

Tampilkan source context dari job description.

Jangan menyarankan memasukkan keyword yang tidak sesuai pengalaman pengguna.

Tambahkan warning:

Tambahkan keyword hanya jika benar-benar mencerminkan kemampuan atau pengalaman Anda.

--------------------------------------------------
12.3 SECTION ANALYSIS
--------------------------------------------------

Sections:

- Ringkasan Profesional.
- Pendidikan.
- Pengalaman.
- Skills.
- Sertifikasi.
- Formatting.
- Contact Information.

Setiap section menampilkan:

- Score.
- Status.
- Temuan.
- Recommendation.
- Action Terapkan di CV Builder.

Contoh:

Ringkasan Profesional

Temuan:
Belum menyebutkan target posisi dan kemampuan Excel.

Rekomendasi:
Tambahkan target Junior Accountant dan satu kompetensi teknis utama.

Action:
Edit Ringkasan

--------------------------------------------------
12.4 RECOMMENDATION PRIORITY
--------------------------------------------------

Groups:

Prioritas Tinggi:

1. Tambahkan pengalaman terkait rekonsiliasi.
2. Perjelas hasil pada pengalaman organisasi.

Prioritas Sedang:

3. Tambahkan skill Accounts Payable jika relevan.
4. Ringkas ringkasan profesional.

Prioritas Rendah:

5. Konsistenkan format tanggal.
6. Kurangi pengulangan keyword Accounting.

Setiap rekomendasi menampilkan:

- Dampak estimasi.
- Section.
- Status.
- Action.

Actions:

- Terapkan.
- Buka Editor.
- Tandai Selesai.
- Abaikan.

--------------------------------------------------
12.5 BEFORE AND AFTER COMPARISON
--------------------------------------------------

Buat comparison view.

Kiri:
Versi Sekarang

Kanan:
Saran Perbaikan

Pengguna dapat:

- Menggunakan Saran.
- Edit Dulu.
- Abaikan.

Konten AI harus memiliki label:

Saran AI

Jangan mengganti CV secara otomatis tanpa konfirmasi.

--------------------------------------------------
12.6 ATS REPORT EXPORT
--------------------------------------------------

Actions:

- Export PDF.
- Simpan Hasil.
- Analisis Ulang.
- Buka CV Builder.
- Bandingkan Versi.

==================================================
13. RIWAYAT ANALISIS ATS
==================================================

Table:

- Tanggal.
- CV.
- Target Posisi.
- Perusahaan.
- ATS Score.
- Keyword Match.
- Status.
- Action.

Data:

3 Jul 2026
CV Akuntansi 2026
Junior Accountant
PT Contoh Indonesia
82
78%
Selesai

1 Jul 2026
CV Finance English
Finance Intern
Global Finance Ltd
76
71%
Selesai

28 Jun 2026
CV General Fresh Graduate
Management Trainee
Company Example
71
65%
Selesai

Actions:

- Buka Hasil.
- Analisis Ulang.
- Bandingkan.
- Export.
- Hapus.

==================================================
14. HALAMAN TOEFL TRAINING
==================================================

FRAME NAME:

FreeSpace/Desktop/Karier/TOEFL-Overview

BREADCRUMB:

Karier > TOEFL Training

JUDUL:

TOEFL Training

SUBTITLE:

Latih kemampuan Listening, Structure, dan Reading melalui latihan dan simulasi tes.

PRIMARY ACTION:

Mulai Latihan

Icon:
Play

SECONDARY ACTION:

Mulai Simulasi

Tambahkan information banner:

Materi latihan menggunakan format TOEFL ITP-style untuk pembelajaran dan bukan soal resmi ETS.

Jangan menggunakan atau menyalin soal resmi berhak cipta.

Gunakan soal latihan original dengan struktur serupa.

--------------------------------------------------
14.1 SUMMARY CARDS TOEFL
--------------------------------------------------

CARD 1

Label:
Estimated Score

Value:
493

Description:
Target 550

CARD 2

Label:
Latihan Selesai

Value:
24

Description:
Bulan ini

CARD 3

Label:
Streak Belajar

Value:
5 Hari

Description:
Pertahankan konsistensi

CARD 4

Label:
Akurasi Rata-Rata

Value:
72%

Description:
Naik 4% dari minggu lalu

--------------------------------------------------
14.2 INTERNAL TABS TOEFL
--------------------------------------------------

Tabs:

- Latihan
- Simulasi Tes
- Hasil & Progress

Default active:
Latihan

Jangan menjadikannya submenu sidebar.

==================================================
15. TAB LATIHAN TOEFL
==================================================

Buat section tiga skill.

--------------------------------------------------
15.1 LISTENING
--------------------------------------------------

Card menampilkan:

- Listening Comprehension.
- 12 paket latihan.
- 68 soal tersedia.
- Akurasi terakhir 71%.
- Progress.

Actions:

- Mulai Latihan.
- Lanjutkan.
- Lihat Pembahasan.

Levels:

- Basic Conversations.
- Longer Conversations.
- Talks and Lectures.

Audio menggunakan placeholder original atau royalty-free.

Jangan menggunakan audio TOEFL resmi.

--------------------------------------------------
15.2 STRUCTURE
--------------------------------------------------

Card:

- Structure and Written Expression.
- 10 paket latihan.
- 40 soal tersedia.
- Akurasi terakhir 77%.

Topics:

- Subject–Verb Agreement.
- Tenses.
- Clauses.
- Parallel Structure.
- Word Forms.
- Error Identification.

--------------------------------------------------
15.3 READING
--------------------------------------------------

Card:

- Reading Comprehension.
- 10 paket latihan.
- 50 soal tersedia.
- Akurasi terakhir 72%.

Topics:

- Main Idea.
- Detail.
- Inference.
- Vocabulary.
- Reference.
- Organization.

Gunakan passage original, public domain, atau dibuat khusus untuk latihan.

==================================================
16. SETUP LATIHAN TOEFL
==================================================

Buat modal.

Judul:

Atur Latihan

Fields:

- Section.
- Topik.
- Tingkat kesulitan.
- Jumlah soal.
- Waktu.
- Tampilkan pembahasan setelah setiap soal.
- Acak soal.

Difficulty:

- Dasar.
- Menengah.
- Lanjutan.
- Campuran.

Jumlah soal:

- 5.
- 10.
- 20.
- Custom.

Mode:

- Practice Mode.
- Timed Mode.

Buttons:

- Batal.
- Mulai Latihan.

==================================================
17. TOEFL QUESTION INTERFACE
==================================================

FRAME NAME:

FreeSpace/Desktop/Karier/TOEFL-Practice

Gunakan layout utama:

Top internal test bar
Question content
Answer options
Question navigator
Control footer

--------------------------------------------------
17.1 INTERNAL TEST BAR
--------------------------------------------------

Tampilkan:

- Section.
- Progress.
- Timer jika aktif.
- Nomor soal.
- Pause.
- Keluar.

Contoh:

Structure
Soal 4 dari 10
08:32 tersisa

--------------------------------------------------
17.2 QUESTION AREA
--------------------------------------------------

LISTENING

Tampilkan:

- Audio player.
- Play state.
- Volume.
- Progress.
- Replay limit jika mode simulasi.

Dalam Practice Mode audio boleh diputar ulang.

Dalam Simulation Mode mengikuti batasan tes yang ditetapkan.

STRUCTURE

Tampilkan sentence dan pilihan jawaban.

READING

Gunakan split layout:

- Passage.
- Question.
- Options.

Pada iPad portrait gunakan stacked layout.

--------------------------------------------------
17.3 ANSWER CONTROLS
--------------------------------------------------

Answer options:

A
B
C
D

Actions:

- Sebelumnya.
- Tandai Ragu.
- Selanjutnya.
- Submit Section.

Question navigator:

- Belum Dijawab.
- Sudah Dijawab.
- Ditandai.
- Aktif.

Jangan hanya membedakan status berdasarkan warna.

==================================================
18. PRACTICE FEEDBACK
==================================================

Dalam Practice Mode setelah menjawab, tampilkan:

- Jawaban Benar atau Belum Tepat.
- Correct answer.
- Penjelasan.
- Konsep terkait.
- Tips.
- Tambahkan ke Review List.

Untuk jawaban salah, jangan hanya menampilkan warna merah.

Gunakan teks penjelasan yang jelas.

Actions:

- Lanjut.
- Pelajari Konsep.
- Simpan Catatan.

==================================================
19. SIMULASI TOEFL
==================================================

FRAME NAME:

FreeSpace/Desktop/Karier/TOEFL-SimulationSetup

Setup:

- Full Test.
- Mini Test.
- Custom Test.

Full Test sections:

- Listening.
- Structure and Written Expression.
- Reading.

Tampilkan:

- Jumlah soal.
- Estimasi waktu.
- Aturan simulasi.
- Audio requirement.
- Autosave.
- Fullscreen recommendation.

Checklist:

- Gunakan headphone.
- Pastikan koneksi stabil.
- Siapkan waktu tanpa gangguan.
- Audio tidak dapat diulang pada mode tertentu.

Button:

Mulai Simulasi

Confirmation:

Tes akan dimulai setelah Anda menekan Mulai.

--------------------------------------------------
19.1 SIMULATION BREAK SCREEN
--------------------------------------------------

Antar-section tampilkan:

Section selesai.

Summary:

- Dijawab.
- Belum dijawab.
- Ditandai.

Actions:

- Tinjau.
- Lanjut ke Section Berikutnya.

--------------------------------------------------
19.2 TOEFL RESULT
--------------------------------------------------

FRAME NAME:

FreeSpace/Desktop/Karier/TOEFL-Result

Tampilkan:

Estimated Score:
493

Label:

Estimasi skor latihan, bukan skor TOEFL resmi.

Section score:

- Listening: 48.
- Structure: 31.
- Reading: 36.

Summary:

- Correct.
- Incorrect.
- Unanswered.
- Accuracy.
- Time used.

Charts:

- Section performance.
- Topic accuracy.
- Score trend.
- Time per question.

Recommendations:

- Fokus pada inference questions.
- Tingkatkan subject–verb agreement.
- Latih longer conversations.
- Perbanyak vocabulary akademik.

Actions:

- Review Jawaban.
- Buat Rencana Belajar.
- Ulangi Tes.
- Export Hasil.

==================================================
20. HASIL & PROGRESS TOEFL
==================================================

Summary cards:

- Best Score: 510.
- Latest Score: 493.
- Target: 550.
- Sessions: 24.

Charts:

- Estimated score trend.
- Accuracy per section.
- Study activity.
- Weak topics.

Study plan:

Target:
550

Target date:
30 September 2026

Weekly plan:

- Listening 3 sesi.
- Structure 3 sesi.
- Reading 2 sesi.
- Mini Test 1 sesi.

History table:

- Tanggal.
- Tipe.
- Listening.
- Structure.
- Reading.
- Estimated Score.
- Durasi.
- Action.

==================================================
21. HALAMAN INTERVIEW SIMULATOR
==================================================

FRAME NAME:

FreeSpace/Desktop/Karier/Interview-Overview

BREADCRUMB:

Karier > Interview Simulator

JUDUL:

Interview Simulator

SUBTITLE:

Latih jawaban interview secara terstruktur dan dapatkan feedback untuk meningkatkan performa Anda.

PRIMARY ACTION:

Mulai Simulasi

Icon:
Microphone atau Chat Bubble

SECONDARY ACTION:

Latihan Pertanyaan

Tambahkan information banner:

Feedback merupakan evaluasi latihan dan tidak menjamin hasil proses rekrutmen.

--------------------------------------------------
21.1 SUMMARY CARDS INTERVIEW
--------------------------------------------------

CARD 1

Label:
Simulasi Selesai

Value:
8

Description:
3 sesi bulan ini

CARD 2

Label:
Skor Terakhir

Value:
78

Description:
Kategori Baik

CARD 3

Label:
Rata-Rata Durasi

Value:
18 Menit

Description:
Per sesi

CARD 4

Label:
Area Perbaikan

Value:
2

Description:
Contoh pengalaman dan English fluency

--------------------------------------------------
21.2 INTERNAL TABS INTERVIEW
--------------------------------------------------

Tabs:

- Latihan Pertanyaan
- Simulasi Interview
- Hasil & Feedback

Default active:
Latihan Pertanyaan

==================================================
22. TAB LATIHAN PERTANYAAN
==================================================

Filter:

- Bidang.
- Tipe Interview.
- Tingkat kesulitan.
- Bahasa.
- Status.

Bidang:

- Akuntansi.
- Keuangan.
- Audit.
- Perpajakan.
- Perbankan.
- Fresh Graduate.

Tipe:

- HR Interview.
- Behavioral.
- Technical.
- Situational.
- Case Interview.

Bahasa:

- Bahasa Indonesia.
- English.

Question cards contoh:

1.
Ceritakan tentang diri Anda.

Type:
HR Interview

Difficulty:
Dasar

2.
Mengapa Anda tertarik bekerja sebagai Junior Accountant?

Type:
Motivation

3.
Jelaskan proses penyusunan jurnal penyesuaian.

Type:
Technical Accounting

4.
Ceritakan pengalaman ketika Anda bekerja dalam tim.

Type:
Behavioral

5.
Bagaimana Anda menangani perbedaan antara saldo buku besar dan rekening bank?

Type:
Technical Accounting

6.
Tell me about a time you had to meet a difficult deadline.

Type:
Behavioral English

Actions:

- Mulai Jawab.
- Simpan untuk Nanti.
- Lihat Tips.
- Tandai Sudah Dikuasai.

==================================================
23. INTERVIEW SETUP
==================================================

Buat setup stepper.

Step 1:
Pilih Posisi

Fields:

- Target posisi.
- Bidang.
- Level pengalaman.
- Nama perusahaan opsional.
- Job description opsional.

Default:

Target:
Junior Accountant

Bidang:
Akuntansi

Level:
Fresh Graduate

Step 2:
Pilih Jenis Interview

Options:

- HR.
- Behavioral.
- Technical.
- Campuran.

Step 3:
Pilih Mode

- Text Answer.
- Audio Answer.
- Video Answer jika browser mendukung.
- Guided Practice.

Untuk implementasi awal, Text dan Audio aktif.

Video dapat diberi label:

Opsional

Step 4:
Atur Sesi

- Jumlah pertanyaan.
- Bahasa.
- Waktu per jawaban.
- Feedback setelah tiap soal.
- Interviewer style.

Styles:

- Ramah.
- Profesional.
- Menantang.

Step 5:
Permission

Jika menggunakan audio atau video:

- Minta izin microphone.
- Minta izin camera.
- Jelaskan data yang direkam.
- Berikan pilihan tanpa rekaman.

Buttons:

- Kembali.
- Lanjut.
- Mulai Simulasi.

==================================================
24. INTERVIEW SESSION
==================================================

FRAME NAME:

FreeSpace/Desktop/Karier/Interview-Session

Gunakan layout:

Interviewer panel
Question
Response area
Session progress
Control footer

--------------------------------------------------
24.1 INTERVIEWER PANEL
--------------------------------------------------

Tampilkan avatar ilustratif netral atau icon.

Jangan gunakan foto orang nyata tanpa izin.

Informasi:

Interviewer:
Recruiter FreeSpace

Position:
Junior Accountant

Mode:
Campuran

Progress:
Pertanyaan 3 dari 8

Timer:
01:42

--------------------------------------------------
24.2 QUESTION PANEL
--------------------------------------------------

Tampilkan:

- Pertanyaan.
- Tipe.
- Kompetensi yang dinilai tidak ditampilkan penuh sebelum menjawab.
- Repeat question.
- Clarify question jika mode mendukung.

Contoh:

“Ceritakan pengalaman ketika Anda harus menyelesaikan pekerjaan dengan tenggat waktu yang terbatas.”

--------------------------------------------------
24.3 RESPONSE AREA
--------------------------------------------------

TEXT MODE

- Textarea.
- Word count.
- Time indicator.
- Submit answer.

AUDIO MODE

- Record button.
- Pause.
- Resume.
- Stop.
- Playback.
- Re-record.
- Audio duration.

VIDEO MODE

- Camera preview.
- Record.
- Pause.
- Stop.
- Playback.

Berikan privacy indicator:

Rekaman hanya digunakan untuk evaluasi latihan pribadi.

--------------------------------------------------
24.4 STRUCTURED ANSWER GUIDE
--------------------------------------------------

Dalam Guided Practice, tampilkan bantuan STAR:

- Situation.
- Task.
- Action.
- Result.

Jangan menampilkan contoh jawaban lengkap sebelum pengguna mencoba.

Setelah jawaban pertama, baru sediakan:

- Struktur jawaban.
- Prompt tambahan.
- Tips.

==================================================
25. FEEDBACK PER JAWABAN
==================================================

Evaluasi:

- Relevansi.
- Struktur.
- Kejelasan.
- Spesifisitas.
- Dampak.
- Confidence.
- Bahasa.
- Durasi.

Skor:
0–100

Feedback sections:

Yang Sudah Baik

Contoh:
Jawaban memiliki urutan kejadian yang jelas.

Perlu Diperbaiki

Contoh:
Hasil akhir belum dijelaskan secara terukur.

Saran Perbaikan

Contoh:
Tambahkan hasil atau pembelajaran yang diperoleh.

Suggested structure:

Situation
Task
Action
Result

Jangan membuat pengalaman palsu untuk pengguna.

AI hanya boleh membantu menyusun ulang informasi yang diberikan pengguna.

Actions:

- Coba Lagi.
- Gunakan Kerangka.
- Simpan Feedback.
- Lanjut.

==================================================
26. HASIL INTERVIEW
==================================================

FRAME NAME:

FreeSpace/Desktop/Karier/Interview-Result

Overall score:
78/100

Category:
Baik

Summary:

- Pertanyaan dijawab: 8.
- Durasi: 18 menit.
- Bahasa: Bahasa Indonesia.
- Posisi: Junior Accountant.

Competency scores:

- Komunikasi: 82.
- Struktur Jawaban: 84.
- Technical Accounting: 80.
- Problem Solving: 74.
- Confidence: 72.
- Relevansi: 79.

Strengths:

- Struktur jawaban cukup jelas.
- Pemahaman dasar akuntansi baik.
- Durasi jawaban sesuai.

Areas for improvement:

- Tambahkan contoh hasil yang terukur.
- Kurangi filler words.
- Perkuat jawaban dalam Bahasa Inggris.

Charts:

- Competency radar atau bars.
- Question-by-question score.
- Progress trend.
- Answer duration.

Gunakan bar chart jika radar chart tidak konsisten dengan design system.

--------------------------------------------------
26.1 QUESTION REVIEW
--------------------------------------------------

List:

- Pertanyaan.
- Jawaban.
- Score.
- Feedback.
- Audio atau video playback jika tersedia.
- Retry action.

--------------------------------------------------
26.2 ACTION PLAN
--------------------------------------------------

Buat personalized action plan:

1. Latihan behavioral question dua kali.
2. Latihan technical accounting tiga kali.
3. Latihan jawaban Bahasa Inggris.
4. Gunakan struktur STAR.
5. Tambahkan hasil terukur dalam jawaban.

Actions:

- Buat Jadwal Latihan.
- Ulangi Simulasi.
- Export Feedback.
- Simpan ke Progress.

==================================================
27. RIWAYAT INTERVIEW
==================================================

Table:

- Tanggal.
- Target Posisi.
- Bidang.
- Jenis.
- Bahasa.
- Skor.
- Durasi.
- Action.

Data:

3 Jul 2026
Junior Accountant
Akuntansi
Campuran
Bahasa Indonesia
78
18 menit

1 Jul 2026
Finance Intern
Keuangan
HR
English
72
14 menit

28 Jun 2026
Audit Intern
Audit
Technical
Bahasa Indonesia
75
20 menit

Actions:

- Lihat Hasil.
- Ulangi.
- Bandingkan.
- Export.
- Hapus.

==================================================
28. AI ASSISTANCE
==================================================

Tombol Tanya AI tetap berada pada topbar.

Jangan membuat AI sebagai submenu Karier.

AI dapat digunakan secara kontekstual untuk:

CV Builder:

- Merapikan ringkasan profesional.
- Mengoptimalkan bullet.
- Memeriksa tata bahasa.
- Menyarankan keyword.
- Menyesuaikan CV dengan posisi.
- Membantu meringkas konten.

ATS Analyzer:

- Mengevaluasi struktur.
- Membandingkan keyword.
- Memberikan rekomendasi.
- Membuat comparison.
- Menjelaskan alasan score.

TOEFL Training:

- Membuat soal latihan original.
- Menjelaskan jawaban.
- Membuat study plan.
- Membantu memahami grammar.
- Menjelaskan vocabulary.

Interview Simulator:

- Menghasilkan pertanyaan sesuai bidang.
- Mengevaluasi struktur jawaban.
- Memberikan feedback.
- Memberikan pertanyaan lanjutan.
- Membantu merapikan jawaban.

Aturan wajib:

- AI hanya aktif setelah dipicu pengguna.
- Jangan membuat pengalaman kerja palsu.
- Jangan membuat sertifikasi palsu.
- Jangan membuat nilai atau pencapaian palsu.
- Jangan otomatis mengganti CV.
- Jangan mengklaim hasil pasti dalam rekrutmen.
- Jangan mengklaim ATS score sebagai score resmi perusahaan.
- Jangan mengklaim estimated TOEFL score sebagai score resmi ETS.
- Jangan mengklaim feedback interview menjamin kelulusan.
- Hasil AI harus diberi label:
  “Saran AI”
- Pengguna harus memilih:
  - Gunakan.
  - Edit.
  - Salin.
  - Abaikan.

==================================================
29. PRIVACY DAN DATA
==================================================

CV, job description, rekaman audio, rekaman video, dan hasil analisis adalah data pribadi.

Tampilkan privacy indicator bila relevan:

Pribadi — hanya dapat diakses oleh Anda

Sebelum merekam audio atau video:

- Minta permission.
- Jelaskan tujuan rekaman.
- Berikan pilihan tanpa rekaman.
- Berikan opsi hapus rekaman setelah analisis.

Jangan membagikan data kepada pihak luar secara default.

Delete confirmation untuk:

- CV.
- ATS analysis.
- TOEFL attempt.
- Interview recording.
- Interview result.

==================================================
30. KETERKAITAN DENGAN MODUL LAIN
==================================================

Dashboard:

- Menampilkan progress TOEFL.
- Menampilkan interview score terakhir.
- Menampilkan ATS score terakhir.
- Menampilkan CV completeness.

Produktivitas:

- Jadwal TOEFL dapat dibuat sebagai aktivitas.
- Jadwal interview dapat dibuat sebagai aktivitas.
- Deadline perbaikan CV dapat menjadi aktivitas.

History:

- Membuat CV.
- Mengubah CV.
- Export CV.
- Analisis ATS.
- Menyelesaikan TOEFL.
- Menyelesaikan interview.
- Menghapus rekaman.

Notifikasi:

- Pengingat latihan TOEFL.
- Pengingat simulasi interview.
- Hasil ATS selesai.
- Target belajar mingguan.
- CV belum lengkap.

==================================================
31. EMPTY STATES
==================================================

CV BUILDER

Title:
Belum ada CV

Description:
Buat CV pertama untuk mulai mempersiapkan lamaran kerja Anda.

Action:
Buat CV Baru

ATS ANALYZER

Title:
Belum ada analisis ATS

Description:
Pilih CV dan masukkan deskripsi pekerjaan untuk memulai analisis.

Action:
Mulai Analisis

TOEFL TRAINING

Title:
Belum ada riwayat latihan

Description:
Mulai latihan pertama untuk mengukur kemampuan Anda.

Action:
Mulai Latihan

INTERVIEW SIMULATOR

Title:
Belum ada simulasi interview

Description:
Mulai sesi interview untuk berlatih menjawab secara lebih terstruktur.

Action:
Mulai Simulasi

Jangan menggunakan:

- Segera Hadir.
- Sedang Dikembangkan.
- Coming Soon.

==================================================
32. LOADING, ERROR, DAN SUCCESS STATES
==================================================

Loading:

- Skeleton CV cards.
- CV autosave.
- ATS processing.
- TOEFL question loading.
- Audio buffering.
- Interview analysis processing.
- Export generation.

Errors:

- CV gagal dimuat.
- Gagal menyimpan CV.
- File CV tidak valid.
- ATS analysis gagal.
- Job description terlalu pendek.
- Audio TOEFL gagal dimuat.
- Jawaban gagal disimpan.
- Microphone permission ditolak.
- Rekaman gagal.
- Feedback gagal dibuat.
- Export gagal.

Success toasts:

- CV berhasil dibuat.
- CV berhasil disimpan.
- CV berhasil diekspor.
- Analisis ATS selesai.
- Rekomendasi berhasil diterapkan.
- Latihan TOEFL selesai.
- Simulasi TOEFL selesai.
- Jawaban interview berhasil disimpan.
- Simulasi interview selesai.
- Jadwal latihan berhasil dibuat.

==================================================
33. REUSABLE COMPONENTS
==================================================

Buat atau rapikan components berikut.

NAVIGATION

- Sidebar/NavItem/Parent.
- Sidebar/NavItem/Child.
- Sidebar/Accordion.
- Breadcrumb.

PAGE

- Page/Header.
- Page/ActionBar.
- Page/FilterBar.

CV BUILDER

- CV/Card.
- CV/Thumbnail.
- CV/Completion.
- CV/SectionNavigator.
- CV/SectionItem.
- CV/EditorToolbar.
- CV/LivePreview.
- CV/A4Page.
- CV/AutosaveIndicator.
- CV/VersionRow.
- CV/TemplateCard.

ATS

- ATS/ScoreCard.
- ATS/ScoreBar.
- ATS/KeywordTag.
- ATS/RecommendationCard.
- ATS/SectionScore.
- ATS/Comparison.
- ATS/ProcessingStep.
- ATS/HistoryRow.

TOEFL

- TOEFL/SkillCard.
- TOEFL/TestHeader.
- TOEFL/Question.
- TOEFL/AnswerOption.
- TOEFL/QuestionNavigator.
- TOEFL/AudioPlayer.
- TOEFL/FeedbackCard.
- TOEFL/ScoreCard.
- TOEFL/ResultChart.
- TOEFL/HistoryRow.

INTERVIEW

- Interview/QuestionCard.
- Interview/SetupStep.
- Interview/InterviewerPanel.
- Interview/Recorder.
- Interview/STARGuide.
- Interview/FeedbackCard.
- Interview/CompetencyBar.
- Interview/ResultCard.
- Interview/HistoryRow.

GLOBAL

- Card/Summary.
- Tabs/Primary.
- Tabs/Segmented.
- Input/Text.
- Input/Date.
- Input/DateRange.
- Input/Number.
- Select.
- SearchInput.
- Textarea.
- RichTextEditor.
- FileUpload.
- AudioPlayer.
- Toggle.
- Checkbox.
- Radio.
- Stepper.
- Modal/Form.
- Modal/Confirm.
- Drawer/Detail.
- Table/Header.
- Table/Row.
- Badge/Positive.
- Badge/Warning.
- Badge/Danger.
- Badge/Neutral.
- Toast/Success.
- Toast/Error.
- Alert/Info.
- Alert/Warning.

Gunakan component variants.

Jangan menduplikasi style secara manual.

==================================================
34. REQUIRED COMPONENT STATES
==================================================

Buat state jika relevan:

- Default.
- Hover.
- Focus.
- Active.
- Selected.
- Disabled.
- Loading.
- Empty.
- Error.
- Success.
- Draft.
- Autosaving.
- Saved.
- Uploading.
- Processing.
- Completed.
- Paused.
- Answered.
- Unanswered.
- Marked.
- Correct.
- Incorrect.
- Recording.
- Permission Denied.
- Analysis Ready.

CV status:

- Draft.
- Aktif.
- Diarsipkan.

ATS status:

- Menunggu.
- Diproses.
- Selesai.
- Gagal.

TOEFL status:

- Belum Dimulai.
- Sedang Berjalan.
- Dijeda.
- Selesai.

Interview status:

- Belum Dimulai.
- Merekam.
- Diproses.
- Selesai.
- Dibatalkan.

==================================================
35. PROTOTYPE INTERACTIONS
==================================================

SIDEBAR

- CV Builder menuju CV Builder.
- ATS Analyzer menuju ATS Analyzer.
- TOEFL Training menuju TOEFL Training.
- Interview Simulator menuju Interview Simulator.

CV BUILDER

- Buat CV membuka modal.
- Click CV membuka editor.
- Template dapat dipilih.
- Section dapat diurutkan.
- Preview berubah real-time.
- Analisis ATS membuka ATS Analyzer.
- Export membuka modal.
- Version comparison membuka comparison view.

ATS

- Pilih CV.
- Paste job description.
- Mulai Analisis membuka processing state.
- Processing menuju result.
- Recommendation membuka CV editor.
- Apply suggestion meminta confirmation.
- History row membuka result lama.

TOEFL

- Mulai Latihan membuka setup.
- Setup membuka practice.
- Answer option dapat dipilih.
- Next berpindah soal.
- Marked question mengubah navigator.
- Submit membuka result.
- Audio player berjalan.
- Simulation setup membuka full test.
- Review membuka jawaban.

INTERVIEW

- Mulai Simulasi membuka setup.
- Permission modal muncul untuk audio atau video.
- Record mulai dan berhenti.
- Submit answer membuka processing.
- Feedback muncul setelah analisis.
- Retry mengulang pertanyaan.
- Finish membuka result.
- Schedule action terhubung ke Aktivitas.

Gunakan Smart Animate:

150–250 ms

Jangan menggunakan animasi dekoratif berlebihan.

==================================================
36. RESPONSIVE DESIGN
==================================================

Buat responsive layout untuk:

1. Desktop atau laptop existing frame.
2. iPad landscape.
3. iPad portrait.

DESKTOP

- Sidebar fixed.
- Topbar fixed.
- Summary cards empat kolom.
- CV editor tiga kolom.
- TOEFL Reading split layout.
- Interview layout dua kolom jika diperlukan.
- Tables full-width.

IPAD LANDSCAPE

- CV editor dapat menjadi dua kolom:
  section navigation collapsible, editor, preview drawer.
- Summary cards dua kolom.
- Filter dapat wrap.
- ATS result tetap dua kolom jika ruang cukup.
- TOEFL reading passage dan question dapat split.
- Interview recorder tetap visible.

IPAD PORTRAIT

- Sidebar menjadi off-canvas drawer.
- Summary cards dua kolom.
- CV editor menjadi satu kolom.
- Section navigator menjadi drawer.
- Live preview menjadi separate preview mode.
- ATS comparison menjadi stacked.
- TOEFL Reading menjadi passage lalu question.
- Question navigator menjadi bottom sheet.
- Interview setup menjadi vertical.
- Recorder menjadi full-width.
- Modal besar menjadi full-screen sheet.
- Table dapat horizontal scroll atau berubah menjadi cards.

Jangan membuat bottom navigation baru.

==================================================
37. ACCESSIBILITY
==================================================

Pastikan:

- Area klik minimal 40–44 px.
- Semua form memiliki label.
- Placeholder tidak menggantikan label.
- Focus state terlihat.
- Icon-only button memiliki tooltip.
- Status menggunakan teks dan warna.
- CV preview dapat di-zoom.
- Drag-and-drop memiliki alternatif button.
- ATS score memiliki penjelasan teks.
- TOEFL audio memiliki volume control.
- Jawaban tidak hanya ditandai warna.
- Timer dapat dibaca dengan jelas.
- Interview recorder memiliki status teks.
- Permission state jelas.
- Error ditampilkan dekat field.
- Contrast memadai.
- Keyboard navigation diperhitungkan.
- Preview A4 tidak terlalu kecil.
- Chart memiliki legend atau data label.

==================================================
38. FIGMA FILE ORGANIZATION
==================================================

Gunakan section atau page:

01 — Foundations
02 — Components
03 — Dashboard
04 — Keuangan
05 — Produktivitas
06 — Library
07 — Karier
08 — System
09 — Responsive
10 — Prototype

Frame names:

FreeSpace/Desktop/Karier/CV-List
FreeSpace/Desktop/Karier/CV-Templates
FreeSpace/Desktop/Karier/CV-Versions
FreeSpace/Desktop/Karier/CV-Editor
FreeSpace/Desktop/Karier/CV-Preview

FreeSpace/Desktop/Karier/ATS-Setup
FreeSpace/Desktop/Karier/ATS-Processing
FreeSpace/Desktop/Karier/ATS-Result
FreeSpace/Desktop/Karier/ATS-History
FreeSpace/Desktop/Karier/ATS-Comparison

FreeSpace/Desktop/Karier/TOEFL-Overview
FreeSpace/Desktop/Karier/TOEFL-Practice
FreeSpace/Desktop/Karier/TOEFL-SimulationSetup
FreeSpace/Desktop/Karier/TOEFL-Simulation
FreeSpace/Desktop/Karier/TOEFL-Result
FreeSpace/Desktop/Karier/TOEFL-Progress

FreeSpace/Desktop/Karier/Interview-Overview
FreeSpace/Desktop/Karier/Interview-Questions
FreeSpace/Desktop/Karier/Interview-Setup
FreeSpace/Desktop/Karier/Interview-Session
FreeSpace/Desktop/Karier/Interview-Feedback
FreeSpace/Desktop/Karier/Interview-Result
FreeSpace/Desktop/Karier/Interview-History

Overlay names:

FreeSpace/Overlay/CV/Create
FreeSpace/Overlay/CV/Import
FreeSpace/Overlay/CV/Template
FreeSpace/Overlay/CV/Export
FreeSpace/Overlay/CV/Delete
FreeSpace/Overlay/CV/RestoreVersion

FreeSpace/Overlay/ATS/Upload
FreeSpace/Overlay/ATS/ApplySuggestion
FreeSpace/Overlay/ATS/Delete

FreeSpace/Overlay/TOEFL/PracticeSetup
FreeSpace/Overlay/TOEFL/ExitTest
FreeSpace/Overlay/TOEFL/SubmitTest

FreeSpace/Overlay/Interview/Permission
FreeSpace/Overlay/Interview/DeleteRecording
FreeSpace/Overlay/Interview/ExitSession

Jangan menggunakan nama:

- Frame 1.
- Group 23.
- Copy.
- Rectangle.
- New Component.

Gunakan descriptive layer naming.

==================================================
39. EXECUTION PRIORITY
==================================================

Kerjakan dalam urutan berikut:

PHASE 1 — CV BUILDER

1. CV Saya.
2. Template.
3. Riwayat Versi.
4. Modal Buat CV.
5. CV Editor.
6. Live Preview.
7. Export.

PHASE 2 — ATS ANALYZER

8. Analisis Baru.
9. Processing state.
10. Hasil Analisis.
11. Keyword Analysis.
12. Recommendation.
13. Comparison.
14. Riwayat.

PHASE 3 — TOEFL TRAINING

15. TOEFL Overview.
16. Setup Latihan.
17. Question Interface.
18. Feedback.
19. Simulation Setup.
20. Simulation.
21. Result.
22. Progress.

PHASE 4 — INTERVIEW SIMULATOR

23. Question Library.
24. Interview Setup.
25. Permission flow.
26. Interview Session.
27. Feedback.
28. Result.
29. History.

Gunakan komponen existing dan reusable components secara konsisten.

Jangan berhenti setelah membuat halaman CV Builder saja.

==================================================
40. ACCEPTANCE CHECKLIST
==================================================

GLOBAL

[ ] Topbar tidak berubah.
[ ] Sidebar tidak berubah.
[ ] Profile card tetap sama.
[ ] Karier tetap memiliki empat submenu.
[ ] Tidak ada hierarchy sidebar level 3.
[ ] Tidak ada Dashboard Karier.
[ ] Tidak ada placeholder Segera Hadir.
[ ] Typography konsisten.
[ ] Warna konsisten.
[ ] Card, form, table, modal, dan drawer konsisten.

CV BUILDER

[ ] Daftar CV tersedia.
[ ] Template tersedia.
[ ] Riwayat versi tersedia.
[ ] Buat CV tersedia.
[ ] Import CV tersedia.
[ ] Editor section tersedia.
[ ] Drag reorder tersedia.
[ ] Live preview tersedia.
[ ] Autosave tersedia.
[ ] PDF export tersedia.
[ ] Word export tersedia.
[ ] Template ATS-friendly tersedia.
[ ] Tidak ada pengalaman palsu yang dibuat otomatis.

ATS ANALYZER

[ ] Pilih CV tersedia.
[ ] Upload CV tersedia.
[ ] Input job description tersedia.
[ ] Processing state tersedia.
[ ] ATS score tersedia.
[ ] Keyword match tersedia.
[ ] Section analysis tersedia.
[ ] Recommendation priority tersedia.
[ ] Before and after tersedia.
[ ] Riwayat tersedia.
[ ] Disclaimer tersedia.
[ ] ATS score tidak diklaim sebagai score resmi perusahaan.

TOEFL TRAINING

[ ] Listening tersedia.
[ ] Structure tersedia.
[ ] Reading tersedia.
[ ] Practice mode tersedia.
[ ] Timed mode tersedia.
[ ] Simulation tersedia.
[ ] Question navigator tersedia.
[ ] Audio player tersedia.
[ ] Feedback tersedia.
[ ] Estimated score tersedia.
[ ] Progress tersedia.
[ ] Study plan tersedia.
[ ] Disclaimer bukan soal resmi tersedia.
[ ] Tidak ada soal resmi berhak cipta.

INTERVIEW SIMULATOR

[ ] Question library tersedia.
[ ] Bidang Akuntansi tersedia.
[ ] Bidang Keuangan tersedia.
[ ] Behavioral tersedia.
[ ] Technical tersedia.
[ ] HR interview tersedia.
[ ] Text mode tersedia.
[ ] Audio mode tersedia.
[ ] Permission tersedia.
[ ] STAR guide tersedia.
[ ] Feedback per jawaban tersedia.
[ ] Overall result tersedia.
[ ] Action plan tersedia.
[ ] Riwayat tersedia.
[ ] Rekaman bersifat privat.
[ ] Tidak ada klaim menjamin kelulusan interview.

AI

[ ] AI hanya aktif atas permintaan pengguna.
[ ] Konten AI diberi label.
[ ] Pengguna mengonfirmasi sebelum menerapkan.
[ ] AI tidak membuat pengalaman palsu.
[ ] AI tidak membuat sertifikasi palsu.
[ ] AI tidak mengubah CV tanpa konfirmasi.
[ ] AI tidak menjamin hasil rekrutmen.

RESPONSIVE

[ ] Desktop tersedia.
[ ] iPad landscape tersedia.
[ ] iPad portrait tersedia.
[ ] CV editor responsif.
[ ] Preview responsif.
[ ] ATS result responsif.
[ ] TOEFL interface responsif.
[ ] Interview recorder responsif.
[ ] Modal menjadi sheet pada layar kecil.

==================================================
41. FINAL EXECUTION INSTRUCTION
==================================================

Mulai dengan mengedit frame CV Builder placeholder yang sedang aktif.

Hapus card “Segera Hadir” dan ganti seluruh area konten dengan halaman CV Builder final.

Setelah CV Builder selesai:

1. Buat ATS Analyzer.
2. Buat TOEFL Training.
3. Buat Interview Simulator.
4. Buat seluruh modal, overlay, drawer, states, dan prototype interactions.
5. Pastikan seluruh modul menggunakan component dan visual pattern yang sama dengan FreeSpace existing.

Jangan membuat konsep alternatif.

Jangan membuat moodboard.

Jangan membuat landing page.

Jangan membuat low-fidelity wireframe.

Jangan mengubah sidebar.

Jangan mengubah topbar.

Jangan menambahkan menu baru.

Jangan menjadikan internal tabs sebagai submenu sidebar.

Gunakan bahasa Indonesia yang natural.

Gunakan bahasa Inggris hanya pada materi TOEFL, contoh interview English, dan istilah profesional yang memang diperlukan.

Gunakan data simulasi yang konsisten.

Hasil akhir harus terlihat sebagai kelanjutan langsung dari desain FreeSpace yang sekarang, bukan aplikasi yang berbeda.