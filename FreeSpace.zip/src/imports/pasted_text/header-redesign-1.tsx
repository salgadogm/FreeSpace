Redesign the current website top header / top navigation bar so it visually matches the HD orange SaaS dashboard reference as closely as possible.

IMPORTANT GOAL:
Transform the current blue-accent header into a premium white-and-orange top bar that matches the reference image in style, proportions, icon treatment, border weight, spacing, and component design. The result must look like the same design system as the HD orange reference.

CONTENT RULE:
Keep the current page title text "Ringkasan" instead of replacing it with "Dashboard", but restyle everything else to match the orange HD reference. Do not keep the old blue button style.

LAYOUT:
Create a full-width top navigation bar with a height of approximately 72–76 px.
Background must be pure white.
Add a very subtle 1 px bottom border in light gray (#ECECEC or similar).
Use a clean horizontal auto-layout with vertically centered alignment.
Use balanced padding: approximately 24–32 px horizontal padding and 14–18 px vertical alignment.
The top bar should feel airy, precise, modern, and consistent.

LEFT SECTION:
On the left side, keep a single page label: "Ringkasan".
Make the text dark, crisp, and semibold.
Use a clean modern UI font such as Inter or SF Pro Display.
Font size approximately 15–18 px, weight 600.
Text color: dark gray / near-black (#1F1F1F to #202020).
Do not use blue text.
Do not use a heavy oversized heading style.
Keep it simple and aligned vertically in the center.

CENTER SECTION:
Place a search bar in the center area, visually matching the HD reference.
The search field should be a rounded rectangle with:
- width approximately 320–420 px
- height approximately 38–40 px
- corner radius 10–12 px
- white fill
- 1 px subtle border in light gray (#DDDDDD to #E6E6E6)
- no heavy shadow
Inside the search bar:
- a small outline search icon on the left
- placeholder text: "Search..."
- placeholder color medium gray (#8B8B8B to #9A9A9A)
- use Inter/SF Pro, 14–16 px regular weight
On the right inside the search field, add a small keyboard shortcut badge with text "⌘K".
The shortcut badge should be:
- a tiny rounded rectangle / pill
- light gray or off-white fill (#F5F5F5)
- subtle light border (#E8E8E8)
- small gray text
- centered vertically inside the search field
The search bar should look elegant, precise, and almost identical to the reference.

RIGHT SECTION:
Create a right-aligned action group with this exact order:
1. Run AI Prompt
2. Bell button
3. Share button

PRIMARY ACTION BUTTON — "Run AI Prompt":
This must visually match the HD orange reference.
Style:
- rounded rectangle
- height 38–40 px
- corner radius 10–12 px
- white fill
- 1–1.5 px border in orange/coral (#FF7A59 or similar)
- horizontal padding approximately 16–18 px
- no blue tones
Inside the button:
- a small orange sparkle / AI magic icon on the left
- the text "Run AI Prompt"
- text color orange/coral matching the border
- font: Inter or SF Pro, 14–15 px, weight 500–600
- icon and text vertically centered
The button must feel premium, light, clean, and not bulky.

ICON BUTTONS — Bell and Share:
Both should use the exact same design system.
Style:
- square rounded buttons
- size approximately 38–40 px by 38–40 px
- white fill
- 1 px light gray border (#E7E7E7 to #ECECEC)
- corner radius 10–12 px
- centered dark icon
- no blue fill
- no blue icon
- no heavy shadows
Icon color should be dark gray / near-black (#222222).
Icon stroke should be clean, thin, and modern.
Use a bell outline icon for notifications.
Use a minimalist share icon with 3 connected nodes or the same clean outline style as the reference.

SPACING:
Use 10–14 px gap between the right-side buttons.
Keep the search bar separated from the action group with comfortable spacing.
Make sure all elements are visually centered on the same horizontal axis.
Spacing must feel identical to a premium SaaS dashboard header.

VISUAL STYLE:
The overall design language must match the HD orange reference:
- minimal
- modern SaaS
- white background
- subtle gray borders
- dark icons
- orange accent only for the Run AI Prompt button
- clean rounded corners
- precise spacing
- high-resolution look
- polished UI
- no bright blue call-to-action styling

STRICT MATCH REQUIREMENTS:
Match the reference as closely as possible in:
- icon style
- component shape
- button proportions
- border color
- corner radius
- text weight
- action ordering
- spacing rhythm
- UI sharpness
- premium dashboard feel

DO NOT:
- do not use blue buttons
- do not use a filled blue Share button
- do not use inconsistent icon styles
- do not add extra shadows
- do not add extra labels
- do not add extra containers
- do not change the page title text from "Ringkasan"
- do not make the layout cartoonish or generic
- do not use gradients
- do not make the header dark

FINAL RESULT:
A clean, high-resolution, premium website top bar that preserves the current title "Ringkasan" but looks visually almost identical to the orange HD reference in component styling, orange accent, search bar design, action buttons, and overall SaaS dashboard polish.