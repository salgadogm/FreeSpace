MASTER CODE MIGRATION AND REFACTOR PROMPT
FREESPACE: REACT/NODE/DOCKER TO LARAVEL 13 + LIVEWIRE 4

==================================================
ROLE
==================================================

Anda adalah:

- Principal Software Architect.
- Senior Laravel Engineer.
- Senior Livewire Engineer.
- Senior PHP Engineer.
- Senior Frontend Engineer.
- Database Architect.
- Accounting Systems Engineer.
- Security Engineer.
- Refactoring Specialist.
- Design-System Preservation Specialist.
- Shared-Hosting Deployment Specialist.

Anda bekerja langsung pada source code aplikasi FreeSpace yang saat ini terbuka di workspace Figma AI.

Aplikasi FreeSpace secara visual, fitur, menu, halaman, interaksi, ukuran, spacing, typography, warna, chart, table, modal, drawer, responsive behavior, dan seluruh desainnya SUDAH SELESAI.

Tugas Anda BUKAN mendesain ulang aplikasi.

Tugas Anda adalah melakukan MIGRASI DAN REFACTOR TOTAL terhadap source code lama dari stack React, TypeScript, Node.js, Docker, dan Nginx menjadi Laravel, PHP, Blade, Livewire, Alpine.js, dan MariaDB.

Lakukan perubahan langsung pada source code.

Jangan hanya menghasilkan:

- Penjelasan.
- Rekomendasi.
- Contoh parsial.
- Pseudocode.
- Wireframe.
- Dokumentasi tanpa implementasi.
- File kosong.
- Placeholder.
- Komentar TODO sebagai pengganti implementasi.

Hasil akhir harus berupa aplikasi Laravel yang lengkap, dapat dijalankan, dapat dibangun, dan mempertahankan feature parity serta visual parity dengan aplikasi FreeSpace yang sekarang.

==================================================
1. SUMBER KEBENARAN UTAMA
==================================================

Gunakan aplikasi React yang saat ini tersedia sebagai:

1. Visual source of truth.
2. Layout source of truth.
3. Interaction source of truth.
4. Feature source of truth.
5. Responsive source of truth.
6. Copywriting source of truth.
7. Navigation source of truth.

Jangan mengubah tampilan hanya karena stack berubah.

Target akhir harus terlihat seperti aplikasi yang sama, bukan aplikasi Laravel baru dengan desain berbeda.

Seluruh hasil render harus mempertahankan:

- Posisi elemen.
- Ukuran elemen.
- Tinggi topbar.
- Lebar sidebar.
- Page padding.
- Grid layout.
- Card dimensions.
- Table dimensions.
- Modal dimensions.
- Drawer dimensions.
- Border radius.
- Border color.
- Shadow.
- Typography.
- Font size.
- Font weight.
- Line height.
- Letter spacing.
- Icon dimensions.
- Icon stroke.
- Gap.
- Margin.
- Responsive breakpoints.
- Active state.
- Hover state.
- Focus state.
- Loading state.
- Empty state.
- Error state.
- Success state.

Target toleransi visual:

- Tidak ada perubahan layout yang terlihat secara kasat mata.
- Perbedaan posisi maksimal 1–2 px apabila disebabkan perbedaan rendering browser.
- Tidak ada card, button, chart, table, text, atau navigation yang berpindah tanpa alasan.
- Tidak ada halaman yang kehilangan konten.
- Tidak ada fitur yang berubah menjadi placeholder.

==================================================
2. CURRENT LEGACY STACK YANG HARUS DIMIGRASIKAN
==================================================

Source code saat ini menggunakan sebagian atau seluruh teknologi berikut:

- React.
- React DOM.
- TypeScript.
- TSX.
- React hooks.
- React state.
- React component routing atau manual page switching.
- Node.js runtime.
- pnpm workspace.
- Vite React.
- lucide-react.
- Docker.
- docker-compose.
- Nginx.
- Frontend Dockerfile.
- Struktur `src/app`.
- Entry point `App.tsx`.
- React component files.
- Legacy backend folder.
- Asset-management legacy components.

Pada source saat ini terlihat file dan folder seperti:

- `src/app/App.tsx`
- `src/app/components`
- `src/app/hooks`
- `src/app/services`
- `src/imports`
- `src/styles`
- `backend`
- `nginx`
- `docker-compose.yml`
- `Dockerfile.frontend`
- `pnpm-workspace.yaml`
- React page imports
- `lucide-react`

Source juga masih dapat mengandung sisa aplikasi lama Manajemen Aset seperti:

- PerbaikanPage.
- PengadaanPage.
- StockOpnamePage.
- DokumenPage.
- PenggunaPage.
- AsetDataTable.
- EksekutifPage.
- Aset SV IPB.
- Data aset.
- Maintenance.
- Pengadaan.
- Stock opname.
- Kampus.
- Unit.
- Asset-management routes.
- Asset-management service.
- Asset-management types.

Audit seluruh repository dan hapus seluruh legacy code yang:

1. Tidak digunakan oleh FreeSpace.
2. Berasal dari aplikasi Manajemen Aset.
3. Tidak lagi relevan dengan requirement FreeSpace.
4. Hanya menjadi dead import.
5. Menyebabkan React atau Node runtime tetap dibutuhkan.

Jangan meninggalkan dead code hanya untuk menghindari refactor.

==================================================
3. TARGET TECH STACK FINAL
==================================================

Gunakan stack final berikut secara konsisten.

BACKEND

- PHP 8.3.
- Laravel 13.
- Composer 2.
- Modular Monolith.
- Laravel Blade.
- Livewire 4.
- Laravel Fortify.
- Laravel Scheduler.
- Laravel Database Queue.
- Laravel Notifications.
- Laravel Scout Database Engine.
- Laravel HTTP Client.

FRONTEND

- Alpine.js 3.
- Tailwind CSS 4.1.
- Vite.
- Heroicons.
- ApexCharts.
- FullCalendar.
- Mozilla PDF.js.
- Tiptap.
- SortableJS.

DATABASE

- MariaDB.
- Laravel Eloquent.
- Laravel Migration.
- Laravel Database Transaction.
- MariaDB Full-Text Search.
- phpMyAdmin-compatible schema.

ACCOUNTING

- Custom Double-Entry Accounting Engine.
- brick/money.
- brick/math.
- Custom Immutable Accounting Audit Trail.
- spatie/laravel-activitylog.

AI

- Google Gemini API.
- xAI Grok API.
- Gemini Vision API.
- Custom AI Provider Service.
- Database Queue.
- JSON Schema Validation.
- Intervention Image 3.

DOCUMENTS

- Spatie Laravel Media Library.
- barryvdh/laravel-dompdf.
- phpoffice/phpword.
- phpoffice/phpspreadsheet.
- maatwebsite/excel.
- PHP ZipArchive.

SECURITY

- Laravel Fortify.
- Two-Factor Authentication.
- Argon2id.
- CSRF Protection.
- Rate Limiting.
- Laravel Policies.
- Signed URLs.
- Encrypted Casts.
- Private Storage.
- Secure Cookies.

TESTING AND QUALITY

- Pest PHP.
- PHPUnit.
- Laravel Pint.
- PHPStan.
- Larastan.
- Rector.
- Composer Audit.
- NPM Audit.

==================================================
4. TEKNOLOGI YANG DILARANG PADA HASIL AKHIR
==================================================

Jangan gunakan teknologi berikut pada runtime aplikasi akhir:

- React.
- React DOM.
- React Router.
- Next.js.
- Remix.
- Vue.
- Nuxt.
- Angular.
- Svelte.
- Inertia.js.
- Node.js application server.
- Express.
- NestJS.
- Nginx application configuration.
- Docker runtime.
- Docker Compose.
- React islands.
- React embedded inside Blade.
- iframe untuk menampilkan aplikasi React lama.
- Compatibility wrapper yang tetap menjalankan React.
- API backend Node sebagai perantara.
- SSR Node.
- Webpack.
- lucide-react.

Node.js dan NPM hanya boleh dipertahankan sebagai BUILD TOOL untuk:

- Vite.
- Tailwind CSS.
- Alpine modules.
- ApexCharts.
- FullCalendar.
- PDF.js.
- Tiptap.
- SortableJS.

Jangan menghapus `package.json` apabila masih dibutuhkan oleh Vite.

Namun, pastikan:

- `package.json` tidak menjalankan web server aplikasi.
- Tidak ada `react` dependency.
- Tidak ada `react-dom`.
- Tidak ada `lucide-react`.
- Tidak ada React plugin untuk Vite.
- Tidak ada TypeScript React compilation.
- Tidak ada `.tsx` yang dipakai oleh aplikasi akhir.

==================================================
5. DEPLOYMENT TARGET
==================================================

Target deployment adalah:

- Hostinger Business Web Hosting.
- Shared Hosting.
- Hostinger hPanel.
- LiteSpeed atau Apache-compatible web server.
- Hostinger SSL.
- Hostinger Cron Job.
- Hostinger SMTP.
- MariaDB bawaan Hostinger.

Aplikasi tidak boleh membutuhkan:

- Root access.
- Docker.
- Kubernetes.
- Supervisor.
- Persistent Node process.
- Persistent WebSocket server.
- Nginx custom configuration.
- Redis wajib.
- Shell daemon khusus.
- Systemd.

Document root harus mengarah ke:

`public/`

Gunakan Laravel `public/index.php` dan `.htaccess` standar yang kompatibel dengan LiteSpeed atau Apache.

==================================================
6. MIGRATION SAFETY RULES
==================================================

Sebelum mengubah source lama:

1. Audit seluruh file.
2. Buat daftar route.
3. Buat daftar page.
4. Buat daftar component.
5. Buat daftar interaction.
6. Buat daftar design token.
7. Buat daftar data model yang tersirat.
8. Buat migration mapping.

Buat file dokumentasi sementara:

`MIGRATION_MATRIX.md`

Isinya harus memetakan:

- Legacy React file.
- Legacy React component.
- Legacy route.
- Legacy state.
- Legacy service.
- Target Laravel module.
- Target Livewire component.
- Target Blade view.
- Target Alpine module.
- Migration status.
- Visual parity status.
- Functional parity status.

Buat backup reference sebelum menghapus source React.

Jika Git tersedia:

- Buat branch atau checkpoint `legacy-react-reference`.

Jika Git tidak tersedia:

- Salin source lama ke folder sementara `_legacy_reference`.

Folder sementara hanya digunakan selama migrasi.

Setelah parity terverifikasi:

- Hapus `_legacy_reference` dari hasil final.
- Jangan deploy source legacy.

Jangan menghapus source React sebelum halaman penggantinya selesai dan berhasil diverifikasi.

==================================================
7. STRATEGI MIGRASI WAJIB
==================================================

Gunakan pendekatan bertahap berikut.

PHASE 1 — AUDIT DAN FOUNDATIONS

- Audit source.
- Identifikasi semua page.
- Identifikasi global layout.
- Identifikasi CSS variables.
- Identifikasi Tailwind classes.
- Identifikasi icon.
- Identifikasi chart.
- Identifikasi table.
- Identifikasi modal.
- Identifikasi drawer.
- Identifikasi responsive layout.
- Identifikasi mock data.
- Identifikasi route.
- Identifikasi stale asset-management code.

PHASE 2 — LARAVEL FOUNDATION

- Buat Laravel project structure.
- Configure Composer.
- Configure `.env.example`.
- Configure MariaDB.
- Configure Fortify.
- Configure Livewire.
- Configure Blade.
- Configure Alpine.
- Configure Tailwind 4.1.
- Configure Vite.
- Configure private storage.
- Configure database queue.
- Configure scheduler.
- Configure notifications.
- Configure activity log.

PHASE 3 — SHARED DESIGN SYSTEM

- Port global CSS.
- Port theme variables.
- Port fonts.
- Port sidebar.
- Port topbar.
- Port profile card.
- Port buttons.
- Port inputs.
- Port dropdowns.
- Port cards.
- Port tables.
- Port badges.
- Port tabs.
- Port modal.
- Port drawer.
- Port toast.
- Port chart wrappers.
- Port responsive behavior.

PHASE 4 — PAGE MIGRATION

- Dashboard.
- Keuangan.
- Produktivitas.
- Library.
- Karier.
- History.
- Pengaturan.
- Profile access.
- Notification panel.
- Tanya AI panel.

PHASE 5 — DATA AND BUSINESS LOGIC

- Migrations.
- Models.
- Relationships.
- Services.
- Actions.
- Policies.
- Validation.
- Transactions.
- Seeders.
- Queue jobs.
- Notifications.
- File storage.
- AI services.
- Accounting engine.

PHASE 6 — FUNCTIONAL PARITY

- Semua button bekerja.
- Semua tab bekerja.
- Semua filter bekerja.
- Semua modal bekerja.
- Semua drawer bekerja.
- Semua search bekerja.
- Semua forms tersimpan.
- Semua CRUD tersedia.
- Semua chart mengambil data.
- Semua export bekerja.
- Semua upload bekerja.
- Semua empty state tersedia.
- Semua loading state tersedia.
- Semua validation tersedia.

PHASE 7 — CLEANUP

- Hapus React.
- Hapus React DOM.
- Hapus `.tsx`.
- Hapus React Vite plugin.
- Hapus Node backend.
- Hapus Docker.
- Hapus Nginx.
- Hapus dead imports.
- Hapus asset-management legacy code.
- Hapus unused package.
- Hapus unused assets.

PHASE 8 — TEST AND DEPLOYMENT

- Run tests.
- Run static analysis.
- Build assets.
- Validate routes.
- Validate database.
- Validate queue.
- Validate scheduler.
- Validate shared-hosting deployment.
- Validate visual parity.

Jangan melompati phase dan jangan berhenti setelah membuat struktur kosong.

==================================================
8. TARGET PROJECT STRUCTURE
==================================================

Gunakan struktur Laravel modular monolith tanpa package modular pihak ketiga yang tidak diperlukan.

Struktur target:

app/
├── Modules/
│   ├── Dashboard/
│   │   ├── Actions/
│   │   ├── Data/
│   │   ├── Livewire/
│   │   ├── Services/
│   │   ├── Support/
│   │   └── DashboardServiceProvider.php
│   │
│   ├── Finance/
│   │   ├── Actions/
│   │   ├── Accounting/
│   │   ├── Data/
│   │   ├── Events/
│   │   ├── Exceptions/
│   │   ├── Jobs/
│   │   ├── Livewire/
│   │   ├── Models/
│   │   ├── Notifications/
│   │   ├── Policies/
│   │   ├── Services/
│   │   ├── Support/
│   │   └── FinanceServiceProvider.php
│   │
│   ├── Productivity/
│   │   ├── Actions/
│   │   ├── Data/
│   │   ├── Jobs/
│   │   ├── Livewire/
│   │   ├── Models/
│   │   ├── Notifications/
│   │   ├── Policies/
│   │   ├── Services/
│   │   └── ProductivityServiceProvider.php
│   │
│   ├── Library/
│   │   ├── Actions/
│   │   ├── Data/
│   │   ├── Jobs/
│   │   ├── Livewire/
│   │   ├── Models/
│   │   ├── Policies/
│   │   ├── Services/
│   │   └── LibraryServiceProvider.php
│   │
│   ├── Career/
│   │   ├── Actions/
│   │   ├── Data/
│   │   ├── Jobs/
│   │   ├── Livewire/
│   │   ├── Models/
│   │   ├── Policies/
│   │   ├── Services/
│   │   └── CareerServiceProvider.php
│   │
│   ├── AI/
│   │   ├── Contracts/
│   │   ├── Data/
│   │   ├── Exceptions/
│   │   ├── Jobs/
│   │   ├── Providers/
│   │   ├── Services/
│   │   ├── Support/
│   │   └── AIServiceProvider.php
│   │
│   └── System/
│       ├── Actions/
│       ├── Backup/
│       ├── Data/
│       ├── Jobs/
│       ├── Livewire/
│       ├── Models/
│       ├── Notifications/
│       ├── Policies/
│       ├── Services/
│       └── SystemServiceProvider.php
│
├── Shared/
│   ├── Actions/
│   ├── Casts/
│   ├── Contracts/
│   ├── Data/
│   ├── Enums/
│   ├── Exceptions/
│   ├── Livewire/
│   ├── Models/
│   ├── Services/
│   ├── Support/
│   └── ValueObjects/
│
├── Http/
├── Models/
└── Providers/

resources/
├── css/
│   ├── app.css
│   ├── theme.css
│   ├── components.css
│   └── utilities.css
│
├── js/
│   ├── app.js
│   ├── bootstrap.js
│   ├── alpine/
│   │   ├── sidebar.js
│   │   ├── dropdown.js
│   │   ├── modal.js
│   │   └── tabs.js
│   ├── charts/
│   │   ├── apex-chart.js
│   │   ├── finance-chart.js
│   │   └── progress-chart.js
│   ├── calendar/
│   │   └── full-calendar.js
│   ├── pdf/
│   │   └── pdf-reader.js
│   ├── editor/
│   │   └── tiptap-editor.js
│   └── sortable/
│       └── sortable-list.js
│
└── views/
    ├── components/
    │   ├── layouts/
    │   ├── navigation/
    │   ├── ui/
    │   ├── forms/
    │   ├── tables/
    │   ├── charts/
    │   ├── overlays/
    │   └── icons/
    │
    └── livewire/
        ├── dashboard/
        ├── finance/
        ├── productivity/
        ├── library/
        ├── career/
        └── system/

routes/
├── web.php
├── auth.php
├── dashboard.php
├── finance.php
├── productivity.php
├── library.php
├── career.php
└── system.php

database/
├── factories/
├── migrations/
└── seeders/

tests/
├── Feature/
├── Unit/
├── Livewire/
└── Architecture/

Jika struktur Laravel 13 yang tersedia dalam workspace berbeda sedikit, sesuaikan dengan convention resmi project tersebut tanpa mengubah prinsip modular monolith.

==================================================
9. MODULAR MONOLITH RULES
==================================================

Setiap module harus:

- Memiliki boundary yang jelas.
- Tidak mengakses internal implementation module lain secara sembarangan.
- Menggunakan service atau contract untuk lintas module.
- Menggunakan event jika perubahan perlu diketahui module lain.
- Menggunakan Eloquent relation hanya jika domain memang berhubungan.
- Tidak membuat circular dependency.
- Tidak membuat global helper berlebihan.
- Tidak menggunakan repository layer generik tanpa alasan.
- Tidak membuat abstraction yang tidak berguna.

Gunakan:

- Action class untuk operation penting.
- Service untuk orchestration.
- Value object untuk nilai khusus.
- Enum untuk status tetap.
- DTO atau data object untuk payload kompleks.
- Policy untuk authorization.
- Form request atau Livewire validation rules.
- Laravel events untuk side effect.
- Database transaction untuk operation atomik.
- Queue job untuk proses lambat.

==================================================
10. REACT TO BLADE/LIVEWIRE CONVERSION RULES
==================================================

Konversi React secara sistematis.

React JSX:

`className="..."`

menjadi Blade:

`class="..."`

React array rendering:

`items.map(...)`

menjadi:

`@foreach ($items as $item)`

React conditional rendering:

`condition ? a : b`

menjadi salah satu:

- `@if`
- `@unless`
- `@class`
- Blade component variant
- Livewire conditional state

React useState:

- Gunakan public property Livewire untuk state yang berhubungan dengan server atau URL.
- Gunakan Alpine `x-data` untuk state visual lokal.
- Jangan menyimpan state database hanya di Alpine.

React useEffect:

- Gunakan Livewire lifecycle hook.
- Gunakan Alpine `x-init`.
- Gunakan JS module initialization.
- Gunakan event listener.
- Gunakan Laravel event atau job untuk side effect backend.

React useMemo:

- Gunakan computed property Livewire.
- Gunakan cached service result.
- Gunakan query scope.
- Jangan menghitung ulang query mahal setiap render.

React useCallback:

- Tidak perlu dipindahkan secara literal.
- Gunakan method Livewire atau function Alpine.

React context:

- Gunakan layout data.
- Livewire persistent component.
- Laravel service.
- Session.
- Auth user preferences.
- Event dispatch.
- Alpine store hanya untuk state UI global ringan.

React Router:

- Ganti dengan Laravel named routes.
- Gunakan `wire:navigate` untuk navigasi SPA-like.
- Gunakan `request()->routeIs()` untuk active navigation.
- Gunakan route model binding jika relevan.

React modal state:

- Gunakan Livewire modal state atau Alpine overlay.
- Pastikan keyboard escape, focus trap, dan backdrop bekerja.

React form:

- Gunakan Livewire form object atau component validation.
- Gunakan `wire:model`.
- Gunakan server-side validation.
- Pertahankan client feedback.
- Jangan mempercayai frontend validation sebagai satu-satunya validasi.

React tables:

- Gunakan Livewire pagination.
- Gunakan query string untuk filter.
- Gunakan server-side sorting.
- Gunakan debounce search.
- Pertahankan exact visual table.

React mock data:

- Pindahkan ke Eloquent, service, factory, dan seeder.
- Seeder harus menghasilkan data demo yang sama dengan desain saat ini.
- Jangan membuat halaman kosong setelah migration.

==================================================
11. DOM AND VISUAL PARITY RULES
==================================================

Saat memindahkan JSX ke Blade:

- Pertahankan urutan wrapper.
- Pertahankan hierarchy elemen.
- Pertahankan Tailwind class.
- Pertahankan width dan height.
- Pertahankan CSS grid.
- Pertahankan flex alignment.
- Pertahankan overflow behavior.
- Pertahankan sticky atau fixed positioning.
- Pertahankan responsive class.
- Pertahankan icon container.
- Pertahankan text truncation.
- Pertahankan tooltip position.
- Pertahankan dropdown alignment.
- Pertahankan z-index.
- Pertahankan scroll container.
- Pertahankan scrollbar behavior.
- Pertahankan table header sticky jika tersedia.

Jangan menambahkan wrapper Blade yang mengubah:

- Grid.
- Flex.
- Width.
- Gap.
- Alignment.
- Height.
- Scroll.

Gunakan Blade components yang output HTML akhirnya tetap sesuai struktur lama.

==================================================
12. GLOBAL LAYOUT MIGRATION
==================================================

Buat reusable layout utama:

`resources/views/components/layouts/app.blade.php`

Layout wajib mempertahankan:

- Sidebar kiri.
- Brand FreeSpace.
- Subtitle Personal Workspace.
- Profile card.
- Section Menu Utama.
- Dashboard.
- Keuangan.
- Produktivitas.
- Library.
- Karier.
- Section Sistem.
- Riwayat.
- Pengaturan.
- Topbar.
- Breadcrumb.
- Search.
- Tanya AI.
- Notification bell.
- Notification badge.
- Share action.
- Main content.
- Responsive drawer untuk iPad portrait.

Buat components:

- `<x-navigation.sidebar />`
- `<x-navigation.sidebar-item />`
- `<x-navigation.sidebar-group />`
- `<x-navigation.breadcrumb />`
- `<x-navigation.topbar />`
- `<x-ui.profile-card />`
- `<x-ui.search />`
- `<x-ui.notification-button />`
- `<x-ui.ai-button />`

Gunakan Alpine untuk:

- Expand/collapse sidebar.
- Parent accordion.
- Mobile sidebar drawer.
- Dropdown sederhana.
- Tooltip.
- Local overlay.
- Profile menu.

Gunakan Livewire untuk:

- Search global.
- Notification data.
- User profile data.
- Route-driven active state.
- Server-side actions.

==================================================
13. ROUTING TARGET
==================================================

Gunakan named route yang jelas.

DASHBOARD

- `dashboard`

KEUANGAN

- `finance.transactions.index`
- `finance.budgets.index`
- `finance.analysis.index`
- `finance.condition.index`
- `finance.investments.index`
- `finance.accounting.index`
- `finance.tax.index`

PRODUKTIVITAS

- `productivity.activities.index`
- `productivity.journal.index`
- `productivity.bible.index`
- `productivity.steps.index`

LIBRARY

- `library.books.index`
- `library.reader.index`
- `library.accounting-space.index`

KARIER

- `career.cv.index`
- `career.ats.index`
- `career.toefl.index`
- `career.interview.index`

SISTEM

- `system.history.index`
- `settings.preferences`
- `settings.data`
- `settings.notifications`
- `settings.security-data`

PROFILE

- `profile.show`
- `profile.edit`

Gunakan:

- Auth middleware.
- Verified middleware jika diperlukan.
- Policy.
- Single-user scoping.

Redirect:

- `/` menuju login jika belum authenticated.
- `/` menuju dashboard jika authenticated.
- Legacy `/home` menuju route `dashboard`.
- Legacy React hash route atau state route harus diarahkan ke named route yang tepat jika masih digunakan.

==================================================
14. LIVEWIRE PAGE COMPONENTS
==================================================

Gunakan Livewire full-page components.

Contoh target:

Dashboard

- `DashboardPage`

Finance

- `TransactionsPage`
- `BudgetPage`
- `AnalysisProjectionPage`
- `FinancialConditionPage`
- `InvestmentsPage`
- `AccountingPage`
- `PersonalTaxPage`

Productivity

- `ActivitiesPage`
- `DailyJournalPage`
- `BibleDailyPage`
- `StepsTrackerPage`

Library

- `BooksCollectionPage`
- `BookReaderPage`
- `AccountingSpacePage`

Career

- `CvBuilderPage`
- `AtsAnalyzerPage`
- `ToeflTrainingPage`
- `InterviewSimulatorPage`

System

- `HistoryPage`
- `PreferencesPage`
- `DataSettingsPage`
- `NotificationSettingsPage`
- `SecurityDataPage`

Gunakan:

- Livewire pagination.
- Livewire form objects.
- Livewire file upload.
- Query string synchronization.
- Computed properties.
- Lazy loading hanya bila tidak mengubah desain.
- `wire:navigate`.
- Loading indicators.
- Optimistic UI hanya bila aman.
- Events untuk integrasi library JS.

==================================================
15. ALPINE.JS RESPONSIBILITY
==================================================

Alpine hanya menangani state UI lokal seperti:

- Dropdown open/close.
- Accordion open/close.
- Sidebar drawer.
- Local tab animation.
- Tooltip.
- Modal focus behavior.
- Keyboard shortcut.
- Collapsible panel.
- Reader panel.
- Context menu.
- Local theme preview.
- Drag handle initialization.

Jangan menggunakan Alpine sebagai database.

Jangan menyimpan data bisnis penting hanya di local storage.

State bisnis harus tetap berada pada:

- Livewire.
- Laravel service.
- Session.
- Database.

Gunakan `x-cloak` untuk menghindari flash content.

==================================================
16. TAILWIND CSS MIGRATION
==================================================

Gunakan Tailwind CSS 4.1.

Pertahankan seluruh class existing selama class tersebut masih valid.

Pindahkan:

- Global CSS.
- CSS variables.
- Font declarations.
- Theme colors.
- Utility class.
- Custom scrollbar.
- Chart styles.
- Reader styles.
- Print styles.
- CV A4 styles.

Ke:

- `resources/css/app.css`
- `resources/css/theme.css`
- `resources/css/components.css`

Jangan mengganti design token.

Buat CSS variables untuk token existing jika belum terstruktur:

- Background.
- Surface.
- Border.
- Text primary.
- Text muted.
- Primary.
- Success.
- Warning.
- Danger.
- Purple.
- Chart colors.
- Radius.
- Shadow.

Jangan mengganti warna existing dengan default Tailwind hanya demi kemudahan.

==================================================
17. ICON MIGRATION
==================================================

Source lama menggunakan `lucide-react`.

Ganti dengan Heroicons.

Jangan mengubah ukuran visual icon.

Pertahankan:

- Width.
- Height.
- Stroke.
- Alignment.
- Padding.
- Icon container.
- Active color.
- Inactive color.
- Hover color.

Jika Heroicon yang identik tidak tersedia:

- Gunakan icon Heroicons yang paling dekat.
- Pertahankan semantic meaning.
- Jangan menggunakan emoji.
- Jangan menggunakan icon style campuran.

Implementasi yang diperbolehkan:

1. Blade icon components lokal dari Heroicons SVG.
2. Heroicons package yang kompatibel dengan Blade jika memang diperlukan.
3. Inline Blade SVG component.

Jangan mempertahankan `lucide-react`.

==================================================
18. JAVASCRIPT LIBRARY INTEGRATION
==================================================

APEXCHARTS

- Gunakan ApexCharts melalui Vite.
- Buat wrapper JS reusable.
- Jangan menulis chart initialization inline berulang.
- Kirim data dari Livewire sebagai JSON aman.
- Update chart melalui Livewire event.
- Destroy chart saat component di-unmount atau rerender.
- Pertahankan ukuran, warna, label, legend, tooltip, dan chart type.

FULLCALENDAR

- Gunakan FullCalendar melalui Vite.
- Integrasikan dengan Livewire.
- Event create, update, drag, resize, dan delete memanggil method Livewire.
- Jangan menyimpan perubahan hanya di browser.
- Pertahankan visual calendar existing.

PDF.JS

- Gunakan Mozilla PDF.js.
- File harus diakses melalui signed private URL.
- Pertahankan thumbnail, outline, bookmark, zoom, page navigation, search, dan notes panel.
- Jangan mengekspos path private storage.
- Sinkronkan reading progress dengan Livewire.

TIPTAP

- Jangan gunakan React Tiptap.
- Gunakan vanilla Tiptap core.
- Buat JS module reusable.
- Sinkronkan HTML atau JSON content dengan Livewire.
- Gunakan debounce.
- Sanitasi output.
- Pertahankan toolbar existing.

SORTABLEJS

- Gunakan untuk:
  - CV sections.
  - Activities.
  - Notes.
  - Category sorting.
- Setelah reorder, kirim urutan ke Livewire.
- Persist urutan ke database.
- Sediakan alternatif keyboard-accessible jika memungkinkan.

==================================================
19. DATABASE PRINCIPLES
==================================================

Semua tabel milik pengguna harus memiliki:

- Primary key.
- `user_id`.
- Foreign key.
- Index yang relevan.
- Timestamp.
- Soft delete hanya jika sesuai.
- Unique constraint yang relevan.

Semua query harus dibatasi ke user authenticated.

Jangan pernah mengambil record user lain.

Gunakan:

- Eloquent relationships.
- Query scopes.
- Database transactions.
- Eager loading.
- Pagination.
- Indexes.
- MariaDB full-text search untuk pencarian yang sesuai.

Jangan menggunakan:

- Floating point untuk uang.
- Query mentah tanpa binding.
- N+1 query.
- Mass assignment tanpa guard.
- JSON sebagai pengganti seluruh relational model tanpa alasan.

==================================================
20. DATABASE SCHEMA TARGET
==================================================

Buat migration dan model minimal berikut.

AUTH AND USER

- users
- user_preferences
- notification_preferences
- user_sessions jika dibutuhkan application-level
- personal_access metadata jika diperlukan

FINANCE

- financial_accounts
- transaction_categories
- financial_transactions
- recurring_transactions
- recurring_transaction_schedules
- budgets
- budget_items
- personal_assets
- liabilities
- receivables
- financial_goals
- investment_assets
- investment_transactions
- market_watchlists
- chart_of_accounts
- accounting_periods
- journal_entries
- journal_lines
- journal_attachments
- tax_returns
- tax_income_items
- tax_asset_items
- tax_liability_items

PRODUCTIVITY

- activities
- activity_recurrences
- activity_reminders
- daily_journals
- daily_journal_tags
- bible_readings
- bible_notes
- bible_reading_plans
- step_records
- step_targets

LIBRARY

- books
- book_categories
- book_tags
- book_tag
- reading_sessions
- book_notes
- book_highlights
- book_bookmarks
- accounting_learning_notes
- accounting_practices
- accounting_practice_attempts
- accounting_practice_answers

CAREER

- cv_documents
- cv_sections
- cv_versions
- ats_analyses
- ats_recommendations
- toefl_practice_sets
- toefl_questions
- toefl_attempts
- toefl_answers
- interview_question_bank
- interview_sessions
- interview_answers
- interview_feedback

SYSTEM

- notifications
- jobs
- failed_jobs
- activity_log
- ai_requests
- ai_results
- backup_records
- export_records
- import_records

Gunakan nama tabel dan kolom yang konsisten.

Jika source existing sudah memiliki domain data yang lebih lengkap, pertahankan fitur tersebut dan tambahkan migration yang sesuai.

==================================================
21. MONEY AND NUMERIC RULES
==================================================

Semua nilai uang harus:

- Menggunakan `brick/money`.
- Menggunakan `brick/math`.
- Tidak menggunakan floating point.
- Menyimpan currency code.
- Menyimpan nilai dalam integer minor unit atau strategy decimal yang aman.
- Menggunakan format IDR Indonesia pada UI.
- Menggunakan value object untuk operation penting.

Untuk IDR:

- Gunakan currency `IDR`.
- Jangan mengasumsikan dua digit desimal wajib.
- Gunakan formatter Indonesia.

Untuk investment foreign currency:

- Simpan currency per asset.
- Simpan exchange-rate metadata jika digunakan.
- Jangan mengubah nilai historis tanpa audit.

==================================================
22. ACCOUNTING ENGINE
==================================================

Implementasikan custom double-entry accounting engine.

Aturan:

1. Setiap journal entry memiliki minimal dua journal lines.
2. Total debit harus sama dengan total kredit.
3. Journal yang tidak balance tidak boleh diposting.
4. Draft boleh diedit.
5. Posted journal tidak boleh diubah secara langsung.
6. Koreksi journal posted menggunakan reversal atau adjusting entry.
7. Posting dilakukan dalam database transaction.
8. Saldo ledger dihitung dari journal lines posted.
9. Periode tertutup tidak boleh menerima journal baru.
10. Pembukaan periode memerlukan explicit action dan activity log.
11. Semua perubahan penting dicatat dalam immutable audit trail.

Buat service atau action seperti:

- `CreateJournalEntryAction`
- `PostJournalEntryAction`
- `ReverseJournalEntryAction`
- `CreateAdjustingEntryAction`
- `CloseAccountingPeriodAction`
- `ReopenAccountingPeriodAction`
- `GenerateTrialBalanceService`
- `GenerateLedgerService`
- `GenerateFinancialStatementsService`

Gunakan:

- `brick/money`
- `brick/math`
- Laravel DB transaction
- activity log
- policy
- validation

Jangan memindahkan perhitungan accounting utama ke JavaScript.

==================================================
23. TRANSACTION TO ACCOUNTING INTEGRATION
==================================================

Financial transaction dapat menghasilkan journal draft.

Alur:

1. Pengguna membuat transaksi.
2. Sistem menentukan mapping akun.
3. Sistem membuat draft journal.
4. Pengguna dapat review.
5. Pengguna menyetujui.
6. Journal diposting.
7. Ledger dan laporan diperbarui.

Untuk receipt AI:

1. Upload receipt.
2. Simpan file private.
3. Queue image processing.
4. Gemini Vision membaca receipt.
5. Validasi output menggunakan JSON Schema.
6. Buat draft transaction.
7. Buat draft journal.
8. Tampilkan confidence.
9. Pengguna harus mengonfirmasi.
10. Jangan auto-post.

==================================================
24. AI ARCHITECTURE
==================================================

Buat contract:

`AIProviderInterface`

Method minimal:

- `generateText`
- `generateStructured`
- `analyzeImage`
- `summarize`
- `healthCheck`

Implementasi:

- `GeminiProvider`
- `GrokProvider`

Buat:

- `AIProviderManager`
- `AIRequestService`
- `AIResponseValidator`
- `AIUsageLogger`
- `AIPrivacyService`

Aturan:

- API key hanya berada server-side.
- Jangan memasukkan API key ke JavaScript.
- Jangan memasukkan API key ke Blade.
- Gunakan environment variables.
- Gunakan encrypted cast bila key disimpan melalui settings.
- Gunakan Laravel HTTP Client.
- Gunakan timeout.
- Gunakan retry terbatas.
- Gunakan rate limit.
- Gunakan queue untuk proses lambat.
- Simpan status job.
- Validasi JSON response.
- Tangani provider failure.
- Sediakan provider fallback hanya jika diaktifkan pengguna.
- Log metadata tanpa menyimpan data sensitif berlebihan.
- Jangan mengirim seluruh PDF tanpa izin.
- Jangan mengubah tulisan pengguna tanpa konfirmasi.
- Beri label pada hasil AI.
- Jangan menyatakan output AI pasti benar.

==================================================
25. QUEUE AND SCHEDULER
==================================================

Gunakan database queue.

Queue digunakan untuk:

- Receipt OCR/vision.
- CV ATS analysis.
- Export besar.
- PDF generation.
- Word generation.
- Excel generation.
- Book metadata extraction.
- AI summary.
- Interview feedback.
- TOEFL result processing.
- Backup.
- Restore preparation.
- Notification delivery.

Karena target shared hosting tidak memiliki Supervisor:

- Jangan mensyaratkan daemon queue permanen.
- Sediakan strategi cron-compatible.
- Gunakan scheduled command untuk memproses queue secara periodik.
- Gunakan `queue:work --stop-when-empty` melalui cron jika sesuai.
- Pastikan job idempotent.
- Gunakan retry dan failed jobs.
- Jangan membuat job tanpa timeout.

Scheduler digunakan untuk:

- Reminder aktivitas.
- Reminder budget.
- Reminder jatuh tempo.
- Daily journal reminder.
- Reading reminder.
- Step target reminder.
- Automatic backup.
- Recurring transaction.
- Market-data refresh.
- Notification digest.
- Cleanup temporary exports.

Sediakan dokumentasi cron Hostinger:

`php artisan schedule:run`

dijalankan setiap menit melalui hPanel Cron Job.

==================================================
26. FILE AND DOCUMENT STORAGE
==================================================

Gunakan Spatie Media Library untuk:

- Receipt.
- Book PDF.
- Book cover.
- Journal attachment.
- CV.
- Tax attachment.
- Interview audio.
- Interview video jika diaktifkan.
- Exported reports.

Aturan:

- File pribadi berada pada private storage.
- Jangan expose URL storage publik.
- Gunakan signed URL.
- Gunakan authorization.
- Validasi MIME.
- Validasi extension.
- Validasi size.
- Generate safe filename.
- Scan duplicate jika relevan.
- Hapus temporary file.
- Gunakan media collection yang jelas.
- Jangan mempercayai nama file pengguna.

==================================================
27. DOCUMENT EXPORT
==================================================

Gunakan:

PDF

- `barryvdh/laravel-dompdf`
- Untuk report, SPT preparation, jurnal, CV jika compatible.

WORD

- `phpoffice/phpword`
- Untuk CV dan dokumen editable.

EXCEL

- `maatwebsite/excel`
- `phpoffice/phpspreadsheet`
- Untuk export transaction, accounting, tax, history.

ZIP

- `PHP ZipArchive`
- Untuk export personal data dan backup package.

Pertahankan semua tombol export yang sudah tersedia pada desain.

Gunakan queue untuk export besar.

Tampilkan:

- Preparing.
- Processing.
- Ready.
- Failed.
- Expired.

==================================================
28. AUTHENTICATION AND SINGLE-USER MODEL
==================================================

Gunakan Laravel Fortify.

Fitur:

- Login.
- Logout.
- Password reset.
- Email verification jika digunakan.
- Two-factor authentication.
- Recovery codes.
- Password confirmation.
- Session management.

FreeSpace adalah single-user personal application.

Implementasi:

- Semua data dimiliki oleh authenticated user.
- Registration dapat dinonaktifkan setelah akun utama dibuat.
- Jangan membuat role management.
- Jangan membuat admin panel organisasi.
- Jangan membuat multi-tenant logic.
- Jangan membuat user switcher.
- Jangan menampilkan user lain.

Profile card tetap menjadi akses profil pengguna.

==================================================
29. SECURITY RULES
==================================================

Gunakan:

- Argon2id.
- CSRF protection.
- Secure cookies.
- SameSite cookies.
- Session regeneration.
- Rate limiting.
- Policy.
- Authorization.
- Signed URL.
- Encrypted casts.
- Private storage.
- Password confirmation.
- 2FA.
- Server-side validation.
- Output escaping.
- Sanitization untuk rich text.
- File validation.

Jangan:

- Menggunakan `{!! !!}` untuk konten pengguna tanpa sanitasi.
- Menyimpan API key plain text.
- Menaruh secret di frontend.
- Menggunakan local storage untuk token auth.
- Menggunakan SQL string concatenation.
- Menampilkan stack trace pada production.
- Mengekspos storage path.
- Mengekspos database ID sebagai security mechanism.
- Membiarkan mass assignment tanpa aturan.
- Mengizinkan IDOR.

==================================================
30. SEARCH
==================================================

Gunakan Laravel Scout Database Engine dan MariaDB Full-Text Search.

Global search harus dapat mencari:

- Transactions.
- Activities.
- Books.
- Notes.
- CV.
- Journal entries.
- History.

Aturan:

- Scope ke authenticated user.
- Tampilkan module.
- Tampilkan entity type.
- Tampilkan context.
- Gunakan debounce.
- Tampilkan loading state.
- Gunakan pagination atau result limit.
- Jangan menggunakan external search service wajib.

==================================================
31. DASHBOARD MIGRATION
==================================================

Pertahankan Dashboard yang sekarang secara pixel-perfect.

Data Dashboard harus berasal dari service aggregation, bukan hardcoded React state.

Buat:

`DashboardSummaryService`

Sumber data:

- Financial accounts.
- Transactions.
- Budgets.
- Activities.
- Books.
- Reading sessions.
- TOEFL attempts.
- Interview sessions.
- Step records.
- Notifications.

Summary card tetap:

- Saldo Bulan Ini.
- Pemasukan Bulan Ini.
- Pengeluaran Bulan Ini.
- Sisa Budget.
- Agenda Hari Ini.
- Deadline Terdekat.
- Progress Membaca.
- Target Langkah.

Chart tetap:

- Komposisi Pengeluaran.
- Progress Mingguan.
- Pengeluaran per Kategori.

Tables tetap:

- Agenda & Deadline Terdekat.
- Transaksi Terbaru.

Gunakan eager loading dan aggregate query efisien.

==================================================
32. FINANCE MODULE MIGRATION
==================================================

Migrasikan semua halaman:

- Transaksi.
- Budget.
- Analisis & Proyeksi.
- Kondisi Keuangan.
- Investasi.
- Akuntansi.
- SPT Orang Pribadi.

TRANSAKSI

- CRUD.
- Search.
- Filter.
- Pagination.
- Recurring.
- Attachment.
- Transfer antar akun.
- Import.
- Export.
- Journal draft integration.

BUDGET

- Rencana.
- Realisasi.
- Evaluasi.
- Category cap.
- Copy previous month.
- Warning threshold.
- Budget variance.

ANALISIS & PROYEKSI

- Analysis.
- Forecast.
- Scenario.
- Server-side calculation.
- Disclaimer.
- Cached aggregates.

KONDISI KEUANGAN

- Assets.
- Liabilities.
- Receivables.
- Net worth.
- Financial goals.
- Health score.

INVESTASI

- Market.
- Watchlist.
- Portfolio.
- Transaction.
- Provider abstraction.
- Cache.
- Simulation label jika tidak ada licensed live provider.

AKUNTANSI

- Journal.
- Ledger.
- Trial balance.
- Adjustments.
- Financial statements.
- Immutable posted journals.
- Balanced debit and credit.

SPT

- Draft.
- Manual input.
- Estimation.
- Review.
- Export.
- Disclaimer bahwa filing resmi dilakukan pada kanal DJP.

==================================================
33. PRODUCTIVITY MODULE MIGRATION
==================================================

Migrasikan:

AKTIVITAS

- List.
- Calendar.
- Completed.
- Category.
- Priority.
- Reminder.
- Recurrence.
- Drag and drop.
- FullCalendar integration.

JURNAL HARIAN

- Rich editor.
- Mood.
- Reflection.
- Gratitude.
- Lesson.
- Tomorrow plan.
- Autosave.
- History.
- Export.

BIBLE HARIAN

- Reader.
- Note.
- Reflection.
- Reading plan.
- History.
- Private notes.
- Jangan menyertakan teks berlisensi tanpa izin.

STEPS TRACKER

- Manual input.
- Target.
- Trend.
- History.
- Calendar.
- Jangan mengklaim device integration jika belum ada.

==================================================
34. LIBRARY MODULE MIGRATION
==================================================

Migrasikan:

KOLEKSI BUKU

- Upload PDF.
- Metadata.
- Categories.
- Tags.
- Grid/list.
- Search.
- Favorite.
- Archive.
- Private storage.

BACA BUKU

- PDF.js reader.
- Reading progress.
- Session timer.
- Thumbnail.
- Outline.
- Search.
- Highlight.
- Bookmark.
- Page notes.
- Summary.
- Insight.

ACCOUNTING SPACE

- Accounting books.
- Accounting notes.
- T-account block.
- Journal entry block.
- Equation block.
- Practice questions.
- Attempts.
- Hint.
- Scoring.

==================================================
35. CAREER MODULE MIGRATION
==================================================

Migrasikan:

CV BUILDER

- CV list.
- Templates.
- Version history.
- Editor.
- Sortable sections.
- Live preview.
- PDF export.
- Word export.
- Autosave.

ATS ANALYZER

- Select or upload CV.
- Job description.
- Queue analysis.
- Score.
- Keyword analysis.
- Recommendation.
- History.
- Disclaimer.

TOEFL TRAINING

- Listening.
- Structure.
- Reading.
- Practice.
- Simulation.
- Result.
- Progress.
- Original or properly licensed content only.
- Estimated score disclaimer.

INTERVIEW SIMULATOR

- Question bank.
- Setup.
- Text answer.
- Audio answer.
- Optional video.
- Feedback.
- Result.
- History.
- Private recording.
- Permission flow.

==================================================
36. HISTORY MODULE MIGRATION
==================================================

Gunakan `spatie/laravel-activitylog`.

History menampilkan:

- Semua Aktivitas.
- Perubahan Data.
- Aktivitas AI.
- Login & Keamanan.

Jangan menampilkan multi-user role.

Log aktivitas penting:

- Create.
- Update.
- Delete.
- Import.
- Export.
- Upload.
- Login.
- Logout.
- AI request.
- AI result.
- Backup.
- Restore.
- Security event.

Jangan menyimpan data sensitif mentah seperti:

- Password.
- Token.
- API key.
- Full private document content.

==================================================
37. SETTINGS MODULE MIGRATION
==================================================

Migrasikan:

PREFERENSI

- Theme.
- Density.
- Text size.
- Sidebar behavior.
- Language.
- Currency.
- Number format.
- Date format.
- Time format.
- Time zone.
- Accessibility.

PENGATURAN DATA

- Accounts.
- Transaction categories.
- Activity categories.
- Book categories.
- Journal templates.
- Chart of accounts.
- Accounting periods.

PENGATURAN NOTIFIKASI

- Channels.
- Quiet hours.
- Financial notification.
- Productivity notification.
- Library notification.
- Career notification.
- System notification.

KEAMANAN & DATA

- Password.
- 2FA.
- Active sessions.
- Backup.
- Restore.
- Import.
- Export.
- Delete module data.
- Reset.
- Delete account.

==================================================
38. BACKUP AND RESTORE
==================================================

Karena deployment berada pada shared hosting:

- Jangan bergantung pada Docker volume.
- Jangan bergantung pada shell command yang mungkin dinonaktifkan.
- Jangan menjadikan `mysqldump` satu-satunya metode.

Buat backup service PHP-compatible.

Backup dapat mencakup:

- Database data.
- User settings.
- Private metadata.
- Uploaded files sesuai pilihan.
- Manifest.
- Version metadata.
- Checksum.

Gunakan:

- Laravel command.
- Queue job.
- ZipArchive.
- Private storage.

Restore harus:

1. Validate archive.
2. Validate manifest.
3. Validate version.
4. Validate checksum.
5. Create safety backup.
6. Require password confirmation.
7. Run transaction where possible.
8. Log result.
9. Report failure safely.

==================================================
39. NOTIFICATIONS
==================================================

Gunakan Laravel Notifications.

Channel:

- Database.
- Mail via Hostinger SMTP.
- Browser notification hanya sebagai optional frontend behavior jika permission tersedia.

Notification bell mengambil data database.

Support:

- Unread count.
- Mark as read.
- Mark all read.
- Open linked record.
- Pagination.
- Delete notification.

Scheduler menghasilkan reminder.

Jangan membutuhkan third-party push server untuk fungsi utama.

==================================================
40. SEEDERS AND VISUAL DEMO PARITY
==================================================

Buat seeders agar aplikasi setelah instalasi dapat menampilkan data visual yang sama seperti desain sekarang.

Seeder harus menghasilkan contoh:

Dashboard:

- Saldo Rp4,85 juta.
- Pemasukan Rp6,50 juta.
- Pengeluaran Rp3,15 juta.
- Sisa budget Rp1,35 juta.
- Agenda 5.
- Deadline 3.
- Progress membaca 68%.
- Langkah 7.420.

Finance:

- Transactions.
- Budget categories.
- Accounts.
- Assets.
- Liabilities.
- Journal entries.
- Investment demo data.

Productivity:

- Activities.
- Journal entry.
- Bible reading.
- Steps.

Library:

- Books.
- Reading progress.
- Notes.
- Highlights.
- Bookmarks.

Career:

- CV.
- ATS result.
- TOEFL result.
- Interview result.

Semua data demo harus dimiliki oleh seeded user.

Jangan hardcode data demo langsung di Blade.

==================================================
41. SHARED UI COMPONENTS
==================================================

Buat Blade components reusable.

NAVIGATION

- Sidebar.
- Sidebar group.
- Sidebar item.
- Sidebar child.
- Breadcrumb.
- Topbar.

BUTTON

- Primary.
- Secondary.
- Ghost.
- Danger.
- Icon-only.

FORM

- Input.
- Select.
- Textarea.
- Checkbox.
- Radio.
- Toggle.
- Currency input.
- Date input.
- Time input.
- File upload.
- Search input.
- Rich editor.

DISPLAY

- Summary card.
- Chart card.
- Status badge.
- Progress bar.
- Empty state.
- Alert.
- Tabs.
- Pagination.
- Skeleton.

TABLE

- Table.
- Header.
- Row.
- Cell.
- Action menu.
- Responsive wrapper.

OVERLAY

- Modal.
- Confirmation modal.
- Drawer.
- Dropdown.
- Toast.
- Tooltip.

Gunakan Blade attributes dan slots.

Jangan menduplikasi markup ratusan kali.

==================================================
42. FORM AND VALIDATION
==================================================

Semua form harus:

- Memiliki label.
- Memiliki help text.
- Memiliki error message.
- Memiliki server validation.
- Mempertahankan old input.
- Menampilkan loading state.
- Menonaktifkan double submit.
- Menampilkan success feedback.
- Menggunakan transaction untuk operasi kompleks.

Gunakan Livewire form object untuk form kompleks.

Jangan hanya mengandalkan browser validation.

==================================================
43. URL AND STATE MANAGEMENT
==================================================

Filter yang perlu dapat dibagikan harus masuk query string:

- Search.
- Tab aktif.
- Date range.
- Category.
- Status.
- Sort.
- Page.

Gunakan Livewire URL attributes atau mekanisme setara.

Jangan menyimpan semua page state secara global.

Modal state tidak perlu masuk URL kecuali detail record memang harus deep-linkable.

==================================================
44. RESPONSIVE PRESERVATION
==================================================

Pertahankan layout saat ini pada:

DESKTOP

- Sidebar fixed.
- Topbar fixed.
- Existing page width.
- Existing card grid.
- Existing tables.
- Existing charts.

IPAD LANDSCAPE

- Sidebar full atau collapsed sesuai desain existing.
- Card menjadi dua kolom bila diperlukan.
- Filter wrap.
- Table horizontal scroll.
- Modal tetap proporsional.

IPAD PORTRAIT

- Sidebar off-canvas.
- Card dua kolom atau satu kolom sesuai existing behavior.
- Modal menjadi full-screen sheet jika desain mengharuskan.
- Table horizontal scroll atau responsive card.
- Reader panel menjadi drawer.
- CV preview menjadi separate mode.

Jangan membuat bottom navigation baru.

==================================================
45. ACCESSIBILITY
==================================================

Pertahankan dan tingkatkan accessibility tanpa mengubah visual.

Pastikan:

- Semantic HTML.
- Button menggunakan `<button>`.
- Link menggunakan `<a>`.
- Label terhubung ke input.
- Keyboard navigation.
- Focus state.
- Escape menutup modal.
- Focus trap.
- Aria label pada icon-only action.
- Aria expanded pada accordion.
- Tab semantics.
- Table header semantics.
- Contrast cukup.
- Status tidak hanya berdasarkan warna.
- Chart memiliki textual summary.
- Reduced motion preference dihormati.

==================================================
46. PERFORMANCE
==================================================

Gunakan:

- Eager loading.
- Pagination.
- Query indexes.
- Cache untuk aggregate dashboard.
- Lazy loading untuk panel berat.
- Queue untuk proses lambat.
- Vite production build.
- Minified assets.
- Image optimization.
- PDF lazy rendering.
- Debounced search.
- Livewire isolated components jika diperlukan.

Jangan:

- Load seluruh transaction history sekaligus.
- Load seluruh PDF sekaligus.
- Jalankan AI request saat render.
- Jalankan aggregate query berulang dalam loop.
- Menghasilkan N+1 query.
- Mengirim data besar ke browser tanpa perlu.

==================================================
47. TESTING REQUIREMENTS
==================================================

Buat Pest tests untuk:

AUTH

- Login.
- Logout.
- 2FA.
- Password confirmation.
- Unauthorized access.

DASHBOARD

- Summary data.
- User scoping.
- Rendering.

FINANCE

- Transaction CRUD.
- Transfer.
- Budget calculation.
- Forecast validation.
- Journal balance.
- Journal posting.
- Journal reversal.
- Accounting period.
- Financial statements.
- Tax estimate.

PRODUCTIVITY

- Activity.
- Recurrence.
- Reminder.
- Journal autosave.
- Reading entry.
- Step record.

LIBRARY

- Book upload.
- Private access.
- Reading progress.
- Notes.
- Highlight.
- Bookmark.
- Practice attempt.

CAREER

- CV CRUD.
- CV version.
- ATS job.
- TOEFL attempt.
- Interview session.
- Private recording.

SYSTEM

- Activity log.
- Notification preference.
- Backup.
- Restore validation.
- Import.
- Export.
- User scoping.

LIVEWIRE

- Component rendering.
- Validation.
- Filter.
- Pagination.
- Modal action.
- File upload.
- Authorization.

ACCOUNTING UNIT TEST

- Debit equals credit.
- Unbalanced entry rejected.
- Posted entry immutable.
- Reversal works.
- Period lock works.
- Money precision.

==================================================
48. STATIC ANALYSIS AND QUALITY
==================================================

Pastikan project lulus:

- `php artisan test`
- Pest.
- PHPUnit.
- Laravel Pint.
- PHPStan.
- Larastan.
- Composer Audit.
- NPM Audit.
- Production Vite build.

Gunakan Rector hanya setelah test tersedia.

Jangan menjalankan automatic refactor besar tanpa verifikasi.

Gunakan strict typing pada class PHP bila sesuai.

Gunakan return type.

Hindari:

- `mixed` tanpa alasan.
- God class.
- God Livewire component.
- Duplicate logic.
- Fat controller.
- Static helper global.
- Magic string status.

==================================================
49. LEGACY FILE CLEANUP
==================================================

Setelah seluruh parity selesai, hapus:

- `src/app/App.tsx`
- Seluruh React `.tsx`
- React hooks
- React context
- React components
- React-specific services
- React Vite plugin
- `react`
- `react-dom`
- `lucide-react`
- Node backend lama
- `nginx`
- `docker-compose.yml`
- `Dockerfile.frontend`
- Docker file lain
- `pnpm-workspace.yaml` jika tidak lagi diperlukan
- Nginx config
- Old asset-management page
- Old asset-management assets
- Old asset-management types
- Old asset-management mock data
- Unused dependencies
- Dead CSS
- Dead image assets

Jangan menghapus:

- Vite.
- Tailwind.
- Alpine.
- ApexCharts.
- FullCalendar.
- PDF.js.
- Tiptap.
- SortableJS.
- `package.json` yang dibutuhkan build.
- `resources`.
- `public/build`.

==================================================
50. PACKAGE CONFIGURATION
==================================================

COMPOSER

Tambahkan package yang telah ditentukan:

- Laravel framework.
- Livewire.
- Fortify.
- brick/money.
- brick/math.
- spatie/laravel-activitylog.
- spatie/laravel-medialibrary.
- barryvdh/laravel-dompdf.
- phpoffice/phpword.
- phpoffice/phpspreadsheet.
- maatwebsite/excel.
- intervention/image.
- Pest dan quality packages pada require-dev.

Jangan menambahkan framework frontend baru.

NPM

Pertahankan hanya dependency yang dibutuhkan:

- Vite.
- Tailwind CSS.
- Alpine.js.
- ApexCharts.
- FullCalendar.
- PDF.js.
- Tiptap core dan extension yang diperlukan.
- SortableJS.

Hapus:

- React.
- React DOM.
- React plugin Vite.
- lucide-react.
- Type packages khusus React.
- Testing library khusus React.
- Node server package.
- Express.
- Nginx tooling.
- Docker scripts.

==================================================
51. VITE CONFIGURATION
==================================================

Configure Vite untuk Laravel.

Entry:

- `resources/css/app.css`
- `resources/js/app.js`

Jangan menggunakan React plugin.

Vite hanya melakukan:

- Asset bundling.
- CSS processing.
- JS module bundling.
- Development hot reload.
- Production build.

Laravel adalah application runtime.

Pastikan Blade menggunakan `@vite`.

==================================================
52. ENVIRONMENT CONFIGURATION
==================================================

Buat `.env.example` lengkap.

Minimal:

APP_NAME=FreeSpace
APP_ENV=
APP_KEY=
APP_DEBUG=
APP_URL=

APP_LOCALE=id
APP_FALLBACK_LOCALE=en
APP_TIMEZONE=Asia/Jakarta

DB_CONNECTION=mysql
DB_HOST=
DB_PORT=3306
DB_DATABASE=
DB_USERNAME=
DB_PASSWORD=

SESSION_DRIVER=database
QUEUE_CONNECTION=database
CACHE_STORE=database

FILESYSTEM_DISK=local

MAIL_MAILER=smtp
MAIL_HOST=
MAIL_PORT=
MAIL_USERNAME=
MAIL_PASSWORD=
MAIL_ENCRYPTION=
MAIL_FROM_ADDRESS=
MAIL_FROM_NAME=FreeSpace

GEMINI_API_KEY=
GROK_API_KEY=
AI_DEFAULT_PROVIDER=gemini

Jangan memasukkan API key nyata.

==================================================
53. HOSTINGER DEPLOYMENT FILES
==================================================

Buat dokumentasi:

`DEPLOYMENT_HOSTINGER.md`

Isi:

1. Upload project.
2. Set document root ke `public`.
3. Buat MariaDB.
4. Configure `.env`.
5. Install Composer dependency.
6. Generate app key.
7. Run migration.
8. Run seed optional.
9. Create storage link.
10. Build frontend assets sebelum upload atau melalui environment build yang tersedia.
11. Set permissions.
12. Configure cron.
13. Configure SMTP.
14. Disable debug.
15. Optimize Laravel.

Production commands:

- `composer install --no-dev --optimize-autoloader`
- `php artisan key:generate`
- `php artisan migrate --force`
- `php artisan storage:link`
- `php artisan optimize`
- `php artisan config:cache`
- `php artisan route:cache`
- `php artisan view:cache`

Sesuaikan command bila shared hosting memiliki batasan shell.

Jangan memasukkan Docker deployment.

==================================================
54. VISUAL REGRESSION VALIDATION
==================================================

Gunakan current React app sebagai baseline screenshot sebelum dihapus.

Ambil baseline untuk:

- Dashboard.
- Semua halaman Keuangan.
- Semua halaman Produktivitas.
- Semua halaman Library.
- Semua halaman Karier.
- History.
- Semua Pengaturan.
- Sidebar expanded states.
- Modal.
- Drawer.
- Responsive desktop.
- iPad landscape.
- iPad portrait.

Setelah Laravel migration:

- Render viewport yang sama.
- Bandingkan posisi.
- Bandingkan ukuran.
- Bandingkan typography.
- Bandingkan color.
- Bandingkan card.
- Bandingkan table.
- Bandingkan chart.
- Bandingkan navigation.

Jangan menyatakan selesai jika layout berubah signifikan.

==================================================
55. FUNCTIONAL PARITY CHECKLIST
==================================================

Sebelum menghapus source lama, pastikan:

GLOBAL

[ ] Login bekerja.
[ ] Logout bekerja.
[ ] 2FA bekerja.
[ ] Sidebar bekerja.
[ ] Breadcrumb bekerja.
[ ] Search bekerja.
[ ] Notification bekerja.
[ ] Tanya AI bekerja.
[ ] Profile menu bekerja.
[ ] Responsive drawer bekerja.

DASHBOARD

[ ] Cards mengambil data database.
[ ] Charts bekerja.
[ ] Tables bekerja.
[ ] Filters bekerja.
[ ] Quick Add bekerja.

FINANCE

[ ] Transactions CRUD.
[ ] Recurring transactions.
[ ] Budget.
[ ] Analysis.
[ ] Projection.
[ ] Financial condition.
[ ] Investment.
[ ] Accounting.
[ ] SPT.
[ ] Import.
[ ] Export.
[ ] Attachments.

PRODUCTIVITY

[ ] Activities.
[ ] Calendar.
[ ] Recurrence.
[ ] Reminder.
[ ] Journal.
[ ] Bible notes.
[ ] Steps.
[ ] Notifications.

LIBRARY

[ ] Upload books.
[ ] Reader.
[ ] Search PDF.
[ ] Progress.
[ ] Notes.
[ ] Highlight.
[ ] Bookmark.
[ ] Accounting Space.
[ ] Practice.

CAREER

[ ] CV editor.
[ ] CV preview.
[ ] CV export PDF.
[ ] CV export Word.
[ ] ATS.
[ ] TOEFL.
[ ] Interview.
[ ] Audio permission.
[ ] Results.
[ ] History.

SYSTEM

[ ] History.
[ ] Preferences.
[ ] Data settings.
[ ] Notification settings.
[ ] Security.
[ ] Session.
[ ] Backup.
[ ] Restore.
[ ] Import.
[ ] Export.
[ ] Destructive confirmation.

==================================================
56. VISUAL PARITY CHECKLIST
==================================================

[ ] Logo sama.
[ ] Brand sama.
[ ] Sidebar width sama.
[ ] Topbar height sama.
[ ] Profile card sama.
[ ] Menu spacing sama.
[ ] Active menu sama.
[ ] Breadcrumb sama.
[ ] Search field sama.
[ ] Tanya AI button sama.
[ ] Notification button sama.
[ ] Share button sama.
[ ] Page padding sama.
[ ] Heading sama.
[ ] Subtitle sama.
[ ] Card size sama.
[ ] Border sama.
[ ] Radius sama.
[ ] Shadow sama.
[ ] Chart size sama.
[ ] Table size sama.
[ ] Button size sama.
[ ] Modal size sama.
[ ] Drawer size sama.
[ ] Typography sama.
[ ] Color palette sama.
[ ] Responsive behavior sama.
[ ] Tidak ada redesign.

==================================================
57. PROHIBITED SHORTCUTS
==================================================

Jangan melakukan shortcut berikut:

- Jangan membungkus React app dalam Laravel.
- Jangan menggunakan iframe.
- Jangan mempertahankan Node backend.
- Jangan menggunakan Inertia.
- Jangan menggunakan React hanya untuk chart.
- Jangan membuat static Blade tanpa database.
- Jangan mengganti seluruh halaman dengan placeholder.
- Jangan menghapus fitur yang sulit.
- Jangan mengubah desain agar implementation lebih mudah.
- Jangan mengganti Livewire dengan full page reload untuk semua interaksi.
- Jangan membuat API internal berlebihan jika Livewire cukup.
- Jangan hardcode user data di view.
- Jangan menghardcode financial calculation.
- Jangan membuat fake integration.
- Jangan menyimpan secret di frontend.
- Jangan menghapus test.
- Jangan menyatakan selesai sebelum build berhasil.

==================================================
58. FAILURE HANDLING
==================================================

Jika workspace Figma AI tidak dapat menjalankan PHP atau Composer:

- Tetap buat seluruh file Laravel secara lengkap.
- Tetap buat migration.
- Tetap buat model.
- Tetap buat Livewire component.
- Tetap buat Blade view.
- Tetap buat JS module.
- Tetap buat tests.
- Tetap buat documentation.
- Jangan kembali menggunakan React.
- Jangan menyatakan bahwa React harus dipertahankan.
- Tandai command yang perlu dijalankan pada environment PHP yang sebenarnya.

Jika dependency tertentu tidak dapat di-install di workspace:

- Tambahkan dependency dengan version constraint yang sesuai.
- Buat integration code.
- Dokumentasikan install command.
- Jangan mengganti teknologi yang telah ditentukan tanpa izin.

==================================================
59. REQUIRED DELIVERABLES
==================================================

Hasil akhir harus memiliki:

1. Laravel application.
2. Composer configuration.
3. Vite configuration tanpa React.
4. Tailwind configuration.
5. Alpine initialization.
6. Livewire pages.
7. Blade components.
8. Module service providers.
9. Routes.
10. Migrations.
11. Models.
12. Relationships.
13. Policies.
14. Services.
15. Actions.
16. Jobs.
17. Notifications.
18. Seeders.
19. Factories.
20. Tests.
21. Hostinger deployment guide.
22. Migration matrix.
23. Feature parity checklist.
24. Visual parity checklist.
25. Environment example.
26. Database queue.
27. Scheduler configuration.
28. AI provider abstraction.
29. Accounting engine.
30. Private file storage.
31. Document export.
32. Backup and restore.
33. No React runtime.
34. No Node application server.
35. No Docker.
36. No Nginx dependency.
37. No legacy asset-management code.

==================================================
60. EXECUTION ORDER
==================================================

Kerjakan dalam urutan:

1. Audit repository.
2. Create migration matrix.
3. Capture legacy visual reference.
4. Initialize Laravel foundation.
5. Install and configure required Composer packages.
6. Configure Vite without React.
7. Port theme and global styles.
8. Port global layout.
9. Port shared components.
10. Port Dashboard.
11. Port Finance.
12. Port Productivity.
13. Port Library.
14. Port Career.
15. Port History.
16. Port Settings.
17. Create database schema.
18. Connect Eloquent data.
19. Implement accounting engine.
20. Implement AI service.
21. Implement queue and scheduler.
22. Implement document export.
23. Implement backup and restore.
24. Implement policies and security.
25. Create seeders.
26. Create tests.
27. Verify visual parity.
28. Verify feature parity.
29. Remove React and legacy stack.
30. Run cleanup.
31. Run test and build.
32. Create deployment documentation.

Jangan berhenti hanya setelah membuat Laravel skeleton.

==================================================
61. FINAL ACCEPTANCE COMMANDS
==================================================

Project harus siap menjalankan command berikut pada environment yang mendukung:

Composer:

- `composer install`
- `composer audit`

Laravel:

- `php artisan key:generate`
- `php artisan migrate`
- `php artisan db:seed`
- `php artisan test`
- `php artisan route:list`
- `php artisan optimize`

Code quality:

- `vendor/bin/pint --test`
- PHPStan atau Larastan command project.
- Pest test suite.

Frontend:

- `npm install`
- `npm audit`
- `npm run build`

Tidak boleh ada:

- React compilation.
- TSX compilation.
- Missing import.
- Broken route.
- Missing view.
- Unbalanced journal.
- Exposed private file.
- Exposed API key.
- Node application server.

==================================================
62. FINAL EXECUTION INSTRUCTION
==================================================

Mulai sekarang dengan mengaudit repository yang terbuka.

Gunakan aplikasi React yang sekarang hanya sebagai referensi sementara untuk mempertahankan tampilan dan perilaku.

Bangun Laravel 13 + Blade + Livewire 4 + Alpine.js sebagai implementasi final.

Pertahankan seluruh fitur, fungsi, desain, tampilan, ukuran, spacing, responsive behavior, data visualization, menu, submenu, modal, drawer, table, chart, dan interaction.

Jangan melakukan redesign.

Jangan membuat alternatif desain.

Jangan mengurangi fitur.

Jangan mengganti requirement.

Jangan mempertahankan React sebagai runtime.

Jangan mempertahankan Node backend.

Jangan mempertahankan Docker.

Jangan mempertahankan Nginx.

Jangan menggunakan Inertia.

Jangan menyelesaikan pekerjaan hanya dengan dokumentasi.

Refactor source code secara penuh sampai aplikasi FreeSpace menjadi Laravel modular monolith yang dapat dibangun dan diterapkan pada Hostinger shared hosting tanpa mengubah pengalaman visual pengguna.