ROLE AND EXECUTION MODE

Anda adalah Senior Product Designer, UX Architect, Financial Product Designer, Accounting System Designer, dan Figma Design-System Specialist.

Edit langsung desain FreeSpace yang SUDAH ADA pada file Figma ini.

Kondisi desain saat ini:

1. Branding telah berubah menjadi “FreeSpace – Personal Workspace”.
2. Topbar, profile card, search, Tanya AI, notifikasi, dan share sudah tersedia.
3. Sidebar utama dan submenu Keuangan sudah tersedia.
4. Halaman Dashboard masih menggunakan seluruh konten lama Manajemen Aset IPB.
5. Halaman Transaksi masih berupa placeholder “Segera Hadir”.
6. Halaman Keuangan lainnya belum memiliki konten lengkap.

Tugas Anda sekarang adalah:

1. Menyelesaikan halaman Dashboard FreeSpace.
2. Menyelesaikan seluruh halaman modul Keuangan.
3. Membuat reusable components, variants, states, dan prototype interaction.
4. Mempertahankan visual language desain yang sudah ada.
5. Tidak membuat desain baru dari nol.
6. Tidak mengubah struktur sidebar atau topbar yang sudah disetujui.

Jangan hanya menghasilkan penjelasan atau wireframe.

EKSEKUSI desain final dalam bentuk high-fidelity UI menggunakan frame, components, auto layout, variables, variants, dan prototype links.

==================================================
1. PRINSIP UTAMA
==================================================

FreeSpace adalah personal web application single-user untuk mahasiswa Akuntansi.

Dashboard hanya ada SATU di seluruh aplikasi.

Tidak boleh membuat:

- Dashboard Keuangan.
- Dashboard Budget.
- Dashboard Investasi.
- Dashboard Akuntansi.
- Dashboard Pajak.
- Dashboard lain di setiap modul.

Setiap halaman Keuangan langsung menampilkan fungsi utama halaman tersebut.

Gunakan struktur navigasi berikut:

Dashboard

Keuangan
- Transaksi
- Budget
- Analisis & Proyeksi
- Kondisi Keuangan
- Investasi
- Akuntansi
- SPT Orang Pribadi

Fitur detail di dalam setiap halaman harus ditempatkan sebagai:

- Tabs.
- Segmented controls.
- Filters.
- Page sections.
- Modals.
- Drawers.
- Steppers.
- Dropdown menus.

Jangan menambah submenu tingkat ketiga pada sidebar.

==================================================
2. PERTAHANKAN DESAIN YANG SUDAH ADA
==================================================

Pertahankan secara penuh:

- Lebar dan posisi sidebar.
- Tinggi dan posisi topbar.
- Brand FreeSpace di kiri atas.
- Subtitle Personal Workspace.
- Profile card pengguna.
- Search field.
- Shortcut indicator pada search.
- Tombol Tanya AI.
- Ikon notifikasi dan badge.
- Ikon share.
- Background halaman.
- Typography.
- Ukuran heading.
- Body text style.
- Warna utama.
- Warna status.
- Border.
- Border radius.
- Shadow.
- Card style.
- Table style.
- Chart style.
- Spacing system.
- Grid.
- Page padding.
- Breadcrumb.
- Active state sidebar.
- Hover state sidebar.
- Icon style.
- Auto layout yang sudah tersedia.

Jangan:

- Mengganti font.
- Membuat gradient baru.
- Membuat sidebar lebih lebar.
- Memindahkan profile card.
- Membuat topbar baru.
- Mengganti style tombol Tanya AI.
- Membuat floating navigation.
- Membuat bottom navigation untuk desktop.
- Membuat visual language baru.
- Menggunakan ilustrasi dekoratif yang tidak diperlukan.
- Membuat tampilan seperti aplikasi perbankan enterprise.
- Menggunakan dark theme pada frame utama.
- Menambahkan terlalu banyak warna baru.

==================================================
3. DATA SIMULASI YANG HARUS KONSISTEN
==================================================

Gunakan data simulasi berikut secara konsisten pada semua halaman.

Periode aktif:
Juli 2026

Saldo awal:
Rp1.500.000

Pemasukan bulan ini:
Rp6.500.000

Pengeluaran bulan ini:
Rp3.150.000

Saldo akhir:
Rp4.850.000

Budget bulanan:
Rp4.500.000

Realisasi budget:
Rp3.150.000

Sisa budget:
Rp1.350.000

Penggunaan budget:
70%

Total aset:
Rp12.800.000

Total kewajiban:
Rp2.200.000

Kekayaan bersih:
Rp10.600.000

Nilai portofolio investasi:
Rp3.400.000

Total piutang:
Rp750.000

Financial health score:
78/100

Target dana darurat:
Rp12.000.000

Dana darurat terkumpul:
Rp5.400.000

Progress target dana darurat:
45%

Target langkah:
10.000 langkah

Langkah hari ini:
7.420 langkah

Progress membaca:
124 dari 182 halaman atau 68%

Agenda hari ini:
5 aktivitas

Aktivitas selesai:
2 aktivitas

Deadline mendesak:
3 aktivitas

Semua data investasi dan pasar harus diberi label:

“Data Simulasi”

Jangan menyatakan data saham sebagai data pasar real-time.

==================================================
4. GLOBAL PAGE TEMPLATE
==================================================

Gunakan page template yang konsisten pada seluruh halaman.

Struktur:

Topbar
Breadcrumb
Page header
- Judul halaman
- Subtitle
- Primary action
- Secondary action jika diperlukan
Content area
- Summary cards
- Tabs atau segmented control
- Filters
- Main content
- Table, chart, list, atau form
Optional drawer atau modal

Pertahankan page padding seperti frame yang sekarang.

Gunakan maksimal:

- Satu primary action per halaman.
- Satu hingga dua secondary actions.
- Empat summary cards per baris.
- Lima filter utama pada satu baris.
- Lima sampai sepuluh baris tabel pada initial viewport.

Jangan memenuhi halaman dengan terlalu banyak card kecil.

==================================================
5. SIDEBAR DAN NAVIGATION STATE
==================================================

Pertahankan struktur sidebar sekarang:

MENU UTAMA
- Dashboard
- Keuangan
- Produktivitas
- Library
- Karier

SISTEM
- History
- Pengaturan

Untuk tahap ini, buat active state berikut:

1. Dashboard aktif.
2. Keuangan expanded dan Transaksi aktif.
3. Keuangan expanded dan Budget aktif.
4. Keuangan expanded dan Analisis & Proyeksi aktif.
5. Keuangan expanded dan Kondisi Keuangan aktif.
6. Keuangan expanded dan Investasi aktif.
7. Keuangan expanded dan Akuntansi aktif.
8. Keuangan expanded dan SPT Orang Pribadi aktif.

Pertahankan:

- Chevron.
- Dot indicator submenu.
- Indentation.
- Active child background.
- Active parent background.
- Item height.
- Icon size.
- Spacing.

Hanya satu parent sidebar boleh expanded pada satu waktu.

==================================================
6. DASHBOARD GLOBAL
==================================================

FRAME NAME:

FreeSpace/Desktop/Dashboard

BREADCRUMB:

Dashboard

JUDUL:

Dashboard

SUBTITLE:

Ringkasan aktivitas, keuangan, pembelajaran, dan progres pribadi.

Hapus seluruh konten lama yang berkaitan dengan:

- Dashboard Eksekutif.
- Sekolah Vokasi IPB.
- Aset.
- Kampus.
- Unit.
- Stock Opname.
- Maintenance.
- Penggantian aset.
- Nilai buku.
- Nilai perolehan.
- Kondisi aset.
- Administrasi umum.
- Program vokasi.
- Lisensi.
- Antivirus.

Jangan meninggalkan satu pun istilah Manajemen Aset IPB pada Dashboard.

--------------------------------------------------
6.1 FILTER DAN QUICK ACTION
--------------------------------------------------

Pertahankan posisi control bar di kanan atas.

Ganti control menjadi:

Dropdown 1:
Juli 2026

Dropdown 2:
Semua Akun

Dropdown 3:
Semua Kategori

Dropdown 4:
Semua Modul

Primary button:
Quick Add

Gunakan icon plus pada tombol Quick Add.

Buat dropdown atau overlay Quick Add berisi:

- Tambah Transaksi
- Tambah Aktivitas
- Tulis Jurnal
- Mulai Membaca
- Buat Jurnal Akuntansi
- Upload Bukti Transaksi

Gunakan menu compact.

Jangan mengubah ukuran tombol utama secara berlebihan.

--------------------------------------------------
6.2 SUMMARY CARDS
--------------------------------------------------

Pertahankan dua baris dengan empat card per baris.

CARD 1

Label:
Saldo Bulan Ini

Value:
Rp4,85 jt

Description:
Saldo seluruh akun aktif

Trend:
+8,4% dari bulan lalu

Status:
Positive

CARD 2

Label:
Pemasukan Bulan Ini

Value:
Rp6,50 jt

Description:
Total pemasukan Juli 2026

Trend:
+5,2% dari bulan lalu

Status:
Positive

CARD 3

Label:
Pengeluaran Bulan Ini

Value:
Rp3,15 jt

Description:
48,5% dari total pemasukan

Trend:
Turun 6,8% dari bulan lalu

Status:
Positive karena pengeluaran menurun

CARD 4

Label:
Sisa Budget

Value:
Rp1,35 jt

Description:
Dari budget Rp4,50 jt

Trend:
70% budget digunakan

Status:
Warning

CARD 5

Label:
Agenda Hari Ini

Value:
5

Description:
2 aktivitas telah selesai

Status:
Primary

CARD 6

Label:
Deadline Terdekat

Value:
3

Description:
Deadline pertama jatuh tempo besok

Status:
Danger atau Warning

CARD 7

Label:
Progress Membaca

Value:
68%

Description:
124 dari 182 halaman

Status:
Purple atau secondary existing color

CARD 8

Label:
Target Langkah

Value:
7.420

Description:
Dari target 10.000 langkah

Trend:
74,2% target tercapai

Status:
Positive

Badge pada card:

Ganti teks “Dihitung Sistem” menjadi:

Diperbarui Otomatis

Pertahankan ukuran dan style badge.

--------------------------------------------------
6.3 RINGKASAN HARI INI
--------------------------------------------------

Ganti judul section:

Ringkasan Eksekutif

menjadi:

Ringkasan Hari Ini

Isi insight:

- Kondisi keuangan bulan ini masih aman dengan sisa budget Rp1,35 juta.
- Pengeluaran terbesar berasal dari kategori Makanan sebesar 32%.
- Terdapat 3 aktivitas yang belum selesai dan satu deadline jatuh tempo besok.
- Progress membaca telah mencapai 68% atau 124 dari 182 halaman.
- Jurnal harian hari ini belum diisi.
- Target langkah telah mencapai 7.420 dari 10.000 langkah.

Gunakan indicator warna berdasarkan konteks:

- Hijau untuk kondisi baik.
- Orange untuk perhatian.
- Merah untuk deadline.
- Biru atau ungu untuk progress.

--------------------------------------------------
6.4 CHART BARIS UTAMA
--------------------------------------------------

Pertahankan tiga card visualisasi.

CARD CHART 1

Judul:
Komposisi Pengeluaran

Gunakan donut chart.

Data:

- Makanan: 32%
- Transportasi: 24%
- Pendidikan: 18%
- Hiburan: 14%
- Lainnya: 12%

Center value:
Rp3,15 jt

Center label:
Total Pengeluaran

Footer:
Data Juli 2026

CARD CHART 2

Judul:
Progress Mingguan

Gunakan horizontal progress bars.

Data:

- Aktivitas Harian: 80%
- Budget Bulanan: 70%
- Membaca Buku: 68%
- Jurnal Harian: 57%
- TOEFL Training: 45%
- Target Langkah: 74%

Footer:
Rata-rata progres keseluruhan 66%

Status warna:

- 75% ke atas: hijau.
- 50%–74%: orange.
- Di bawah 50%: merah.

CARD CHART 3

Judul:
Pengeluaran per Kategori

Gunakan horizontal bar chart.

Data:

- Makanan: Rp1.008.000
- Transportasi: Rp756.000
- Pendidikan: Rp567.000
- Hiburan: Rp441.000
- Tagihan: Rp252.000
- Lainnya: Rp126.000

Footer:
6 kategori pengeluaran ditampilkan

--------------------------------------------------
6.5 TABEL BAWAH DASHBOARD
--------------------------------------------------

TABEL KIRI

Judul:
Agenda & Deadline Terdekat

Kolom:

- Aktivitas
- Kategori
- Waktu
- Status

Rows:

1. Review materi Akuntansi Keuangan | Belajar | 09.00 | Berjalan
2. Mengerjakan latihan TOEFL | Belajar | 11.00 | Belum Mulai
3. Input pengeluaran harian | Keuangan | 17.00 | Belum Mulai
4. Membaca buku 20 halaman | Membaca | 19.00 | Belum Mulai
5. Tulis jurnal harian | Jurnal | 21.00 | Belum Mulai

Gunakan badge status existing.

TABEL KANAN

Judul:
Transaksi Terbaru

Kolom:

- Transaksi
- Kategori
- Tanggal
- Nominal

Rows:

1. Makan Siang | Makanan | 3 Jul 2026 | -Rp35.000
2. Transportasi Kampus | Transportasi | 3 Jul 2026 | -Rp22.000
3. Buku Akuntansi | Pendidikan | 2 Jul 2026 | -Rp185.000
4. Uang Saku Bulanan | Pemasukan | 1 Jul 2026 | +Rp3.000.000
5. Langganan Internet | Tagihan | 1 Jul 2026 | -Rp150.000

Gunakan:

- Hijau untuk pemasukan.
- Merah untuk pengeluaran.
- Alignment nominal ke kanan.

==================================================
7. HALAMAN TRANSAKSI
==================================================

FRAME NAME:

FreeSpace/Desktop/Keuangan/Transaksi

Hapus seluruh placeholder:

- Segera Hadir.
- Fitur Transaksi sedang dalam pengembangan.
- Loading dots placeholder.

BREADCRUMB:

Keuangan > Transaksi

JUDUL:

Transaksi

SUBTITLE:

Catat dan kelola seluruh transaksi keuangan pribadi.

PRIMARY ACTION:

Tambah Transaksi

Icon:
Plus

SECONDARY ACTION:

Import

Icon:
Arrow Up Tray

--------------------------------------------------
7.1 SUMMARY CARDS TRANSAKSI
--------------------------------------------------

Buat empat card dalam satu baris.

Card 1:
Pemasukan
Rp6.500.000
+5,2% dari bulan lalu

Card 2:
Pengeluaran
Rp3.150.000
Turun 6,8% dari bulan lalu

Card 3:
Arus Kas Bersih
Rp3.350.000
Pemasukan dikurangi pengeluaran

Card 4:
Jumlah Transaksi
48
12 transaksi minggu ini

Gunakan card style Dashboard.

--------------------------------------------------
7.2 TAB TRANSAKSI
--------------------------------------------------

Buat tabs:

- Semua Transaksi
- Pemasukan
- Pengeluaran
- Transfer
- Transaksi Berulang

Default active:
Semua Transaksi

Tambahkan badge count kecil jika sesuai:

- Semua Transaksi: 48
- Pemasukan: 7
- Pengeluaran: 36
- Transfer: 5
- Transaksi Berulang: 6

Jangan masukkan tabs ini ke sidebar.

--------------------------------------------------
7.3 FILTER BAR
--------------------------------------------------

Gunakan satu filter toolbar.

Komponen:

- Search transaksi.
- Filter periode.
- Filter akun.
- Filter kategori.
- Filter tipe.
- Tombol Reset Filter.
- Tombol Filter tambahan jika ruang terbatas.

Default:

Periode:
1–31 Juli 2026

Akun:
Semua Akun

Kategori:
Semua Kategori

Tipe:
Semua Tipe

--------------------------------------------------
7.4 TABEL TRANSAKSI
--------------------------------------------------

Kolom:

- Checkbox
- Tanggal
- Transaksi
- Kategori
- Akun
- Tipe
- Lampiran
- Nominal
- Action

Rows contoh:

1.
3 Jul 2026
Makan Siang
Makanan
E-Wallet
Pengeluaran
Ada lampiran
-Rp35.000

2.
3 Jul 2026
Transportasi Kampus
Transportasi
E-Wallet
Pengeluaran
Tidak ada
-Rp22.000

3.
2 Jul 2026
Pembelian Buku Akuntansi
Pendidikan
Bank Utama
Pengeluaran
Ada lampiran
-Rp185.000

4.
1 Jul 2026
Uang Saku Bulanan
Pemasukan
Bank Utama
Pemasukan
Tidak ada
+Rp3.000.000

5.
1 Jul 2026
Langganan Internet
Tagihan
Bank Utama
Pengeluaran
Ada lampiran
-Rp150.000

6.
1 Jul 2026
Transfer ke E-Wallet
Transfer
Bank Utama → E-Wallet
Transfer
Tidak ada
Rp500.000

7.
30 Jun 2026
Freelance Input Data
Pemasukan
Bank Utama
Pemasukan
Ada lampiran
+Rp750.000

Action menu:

- Lihat Detail.
- Edit.
- Duplikat.
- Hapus.

Buat pagination:

1 2 3 … 5

Rows per page:
10

--------------------------------------------------
7.5 MODAL TAMBAH TRANSAKSI
--------------------------------------------------

Buat modal atau right-side drawer.

Judul:
Tambah Transaksi

Segmented type:

- Pemasukan
- Pengeluaran
- Transfer

Fields:

- Nominal.
- Tanggal.
- Akun atau sumber dana.
- Kategori.
- Nama transaksi.
- Deskripsi.
- Lampiran bukti transaksi.
- Tag opsional.
- Toggle transaksi berulang.
- Frekuensi jika berulang.

Untuk Transfer:

- Akun asal.
- Akun tujuan.

Buttons:

- Batal.
- Simpan Transaksi.

Validasi:

- Nominal wajib.
- Tanggal wajib.
- Akun wajib.
- Kategori wajib untuk pemasukan atau pengeluaran.
- Akun asal dan tujuan tidak boleh sama.

Buat state:

- Default.
- Validation error.
- Uploading attachment.
- Success.

==================================================
8. HALAMAN BUDGET
==================================================

FRAME NAME:

FreeSpace/Desktop/Keuangan/Budget

BREADCRUMB:

Keuangan > Budget

JUDUL:

Budget

SUBTITLE:

Rencanakan batas pengeluaran dan pantau realisasinya.

PRIMARY ACTION:

Buat Budget

SECONDARY ACTION:

Salin Bulan Sebelumnya

TABS:

- Rencana
- Realisasi
- Evaluasi

Default active:
Rencana

--------------------------------------------------
8.1 SUMMARY CARDS BUDGET
--------------------------------------------------

Card 1:
Total Budget
Rp4.500.000

Card 2:
Realisasi
Rp3.150.000

Card 3:
Sisa Budget
Rp1.350.000

Card 4:
Penggunaan
70%

Gunakan progress indicator pada card Penggunaan.

--------------------------------------------------
8.2 TAB RENCANA
--------------------------------------------------

Tampilkan:

- Month selector Juli 2026.
- Total pemasukan yang direncanakan.
- Total budget.
- Total telah dialokasikan.
- Sisa untuk dialokasikan.

Tabel kategori:

Kolom:

- Kategori.
- Budget.
- Persentase alokasi.
- Catatan.
- Action.

Data:

Makanan:
Rp1.200.000
26,7%

Transportasi:
Rp900.000
20%

Pendidikan:
Rp750.000
16,7%

Tagihan:
Rp600.000
13,3%

Hiburan:
Rp450.000
10%

Tabungan:
Rp400.000
8,9%

Lainnya:
Rp200.000
4,4%

Tambahkan:

- Add category row.
- Inline edit.
- Total footer.
- Warning jika alokasi melebihi total budget.

--------------------------------------------------
8.3 TAB REALISASI
--------------------------------------------------

Gunakan progress bars per kategori.

Kolom:

- Kategori.
- Budget.
- Realisasi.
- Sisa.
- Progress.
- Status.

Status:

- Aman.
- Mendekati Batas.
- Terlampaui.

Data contoh:

Makanan:
Budget Rp1.200.000
Realisasi Rp1.008.000
84%
Mendekati Batas

Transportasi:
Rp900.000
Rp756.000
84%
Mendekati Batas

Pendidikan:
Rp750.000
Rp567.000
76%
Aman

Tagihan:
Rp600.000
Rp252.000
42%
Aman

Hiburan:
Rp450.000
Rp441.000
98%
Mendekati Batas

Lainnya:
Rp200.000
Rp126.000
63%
Aman

Gunakan warna status secara konsisten.

--------------------------------------------------
8.4 TAB EVALUASI
--------------------------------------------------

Tampilkan:

- Bar chart Budget vs Aktual.
- Variance summary.
- Kategori overbudget.
- Perbandingan bulan sebelumnya.
- Insight otomatis.

Insight contoh:

- Pengeluaran Hiburan telah mencapai 98% dari budget.
- Makanan dan Transportasi masing-masing telah menggunakan 84%.
- Total pengeluaran masih Rp1,35 juta di bawah budget.
- Pengeluaran bulan ini turun 6,8% dibanding Juni 2026.

Tabel evaluasi:

- Kategori.
- Budget.
- Aktual.
- Selisih.
- Variance %.
- Status.

==================================================
9. HALAMAN ANALISIS & PROYEKSI
==================================================

FRAME NAME:

FreeSpace/Desktop/Keuangan/AnalisisProyeksi

BREADCRUMB:

Keuangan > Analisis & Proyeksi

JUDUL:

Analisis & Proyeksi

SUBTITLE:

Pahami pola keuangan dan proyeksikan kondisi keuangan ke depan.

TABS:

- Analisis
- Proyeksi
- Skenario

Default active:
Analisis

Filter periode:

- 3 Bulan.
- 6 Bulan.
- 12 Bulan.
- Custom.

--------------------------------------------------
9.1 TAB ANALISIS
--------------------------------------------------

Summary cards:

- Rata-rata Pemasukan: Rp6.150.000.
- Rata-rata Pengeluaran: Rp3.320.000.
- Rata-rata Tabungan: Rp2.830.000.
- Savings Rate: 46%.

Charts:

1. Line chart pemasukan vs pengeluaran selama enam bulan.
2. Donut chart komposisi pengeluaran.
3. Bar chart pengeluaran per kategori.
4. Cash flow trend.

Buat section:

Insight Pola Keuangan

Isi:

- Pengeluaran tertinggi terjadi pada kategori Makanan.
- Pengeluaran Hiburan meningkat dibanding bulan sebelumnya.
- Savings rate masih berada di atas target 40%.
- Pengeluaran rutin mencakup 28% dari total pengeluaran.
- Arus kas tetap positif selama tiga bulan terakhir.

--------------------------------------------------
9.2 TAB PROYEKSI
--------------------------------------------------

Summary cards:

- Proyeksi Saldo Akhir Bulan.
- Estimasi Pengeluaran.
- Estimasi Tabungan.
- Proyeksi Savings Rate.

Gunakan:

Proyeksi saldo:
Rp5.250.000

Estimasi pengeluaran:
Rp3.450.000

Estimasi tabungan:
Rp3.050.000

Proyeksi savings rate:
46,9%

Charts:

- Forecast cash flow tiga bulan.
- Proyeksi saldo.
- Proyeksi pemasukan vs pengeluaran.
- Confidence range visual sederhana.

Tambahkan label:

Proyeksi berdasarkan pola transaksi enam bulan terakhir.

Jangan menyebut AI sebagai pasti benar.

Gunakan disclaimer:

“Hasil proyeksi merupakan estimasi dan dapat berubah berdasarkan transaksi aktual.”

--------------------------------------------------
9.3 TAB SKENARIO
--------------------------------------------------

Buat dua-column layout.

Kolom kiri:
Scenario Builder

Fields:

- Perubahan pendapatan.
- Pengurangan pengeluaran.
- Cicilan baru.
- Target tabungan.
- Pembelian aset.
- Periode simulasi.

Preset scenario:

- Hemat 10%.
- Pendapatan Bertambah.
- Cicilan Baru.
- Target Dana Darurat.

Kolom kanan:
Scenario Result

Cards:

- Saldo akhir.
- Total tabungan.
- Savings rate.
- Waktu mencapai target.
- Dampak terhadap cash flow.

Buat comparison:

Baseline vs Skenario

Gunakan bar chart atau comparison cards.

==================================================
10. HALAMAN KONDISI KEUANGAN
==================================================

FRAME NAME:

FreeSpace/Desktop/Keuangan/KondisiKeuangan

BREADCRUMB:

Keuangan > Kondisi Keuangan

JUDUL:

Kondisi Keuangan

SUBTITLE:

Pantau aset, kewajiban, kekayaan bersih, dan kesehatan finansial.

TABS:

- Aset
- Utang & Piutang
- Kekayaan Bersih
- Target & Kesehatan

Default active:
Aset

--------------------------------------------------
10.1 TAB ASET
--------------------------------------------------

Summary cards:

- Total Aset: Rp12.800.000.
- Kas & Rekening: Rp7.200.000.
- Investasi: Rp3.400.000.
- Aset Lainnya: Rp2.200.000.

Donut chart:
Komposisi Aset

Table:

- Nama Aset.
- Jenis.
- Nilai.
- Terakhir Diperbarui.
- Action.

Data:

Bank Utama | Rekening | Rp4.850.000
E-Wallet | Kas Digital | Rp850.000
Dana Darurat | Tabungan | Rp1.500.000
Portofolio Saham | Investasi | Rp3.400.000
Laptop | Barang | Rp1.600.000
Perangkat Lain | Barang | Rp600.000

Primary action:
Tambah Aset

--------------------------------------------------
10.2 TAB UTANG & PIUTANG
--------------------------------------------------

Summary cards:

- Total Utang: Rp2.200.000.
- Cicilan Bulanan: Rp550.000.
- Total Piutang: Rp750.000.
- Jatuh Tempo Terdekat: 12 Jul 2026.

Buat dua section:

Utang & Cicilan

Kolom:

- Nama.
- Pemberi pinjaman.
- Sisa utang.
- Cicilan.
- Jatuh tempo.
- Status.

Piutang

Kolom:

- Nama.
- Pihak terkait.
- Nominal.
- Jatuh tempo.
- Status.

Status:

- Lancar.
- Akan Jatuh Tempo.
- Terlambat.
- Lunas.

--------------------------------------------------
10.3 TAB KEKAYAAN BERSIH
--------------------------------------------------

Summary:

Total aset:
Rp12.800.000

Total kewajiban:
Rp2.200.000

Kekayaan bersih:
Rp10.600.000

Perubahan bulan ini:
+Rp850.000

Charts:

- Net worth trend enam bulan.
- Aset vs kewajiban.
- Komposisi aset.

Table history:

- Periode.
- Total aset.
- Total kewajiban.
- Kekayaan bersih.
- Perubahan.

--------------------------------------------------
10.4 TAB TARGET & KESEHATAN
--------------------------------------------------

Financial health score:

78/100

Status:
Baik

Gunakan radial score atau gauge sederhana yang sesuai design system.

Metrics:

- Savings Rate: 46%.
- Debt Ratio: 17,2%.
- Emergency Fund: 2,7 bulan.
- Cash Flow: Positif.
- Budget Discipline: 82%.

Financial goals:

1. Dana Darurat
Target Rp12.000.000
Terkumpul Rp5.400.000
45%

2. Laptop Baru
Target Rp15.000.000
Terkumpul Rp3.000.000
20%

3. Sertifikasi Profesional
Target Rp4.000.000
Terkumpul Rp1.600.000
40%

Primary action:
Tambah Target

==================================================
11. HALAMAN INVESTASI
==================================================

FRAME NAME:

FreeSpace/Desktop/Keuangan/Investasi

BREADCRUMB:

Keuangan > Investasi

JUDUL:

Investasi

SUBTITLE:

Pantau pasar, watchlist, portofolio, dan transaksi investasi.

Tampilkan badge global:

Data Simulasi

TABS:

- Market
- Watchlist
- Portofolio
- Transaksi Investasi

Default active:
Market

--------------------------------------------------
11.1 TAB MARKET
--------------------------------------------------

Market cards:

- IHSG.
- S&P 500.
- Nasdaq Composite.
- USD/IDR.

Gunakan nilai contoh dan beri label Data Simulasi.

Tambahkan toggle:

- Indonesia.
- Amerika Serikat.

Stock table:

- Kode.
- Nama Perusahaan.
- Harga.
- Perubahan.
- Volume.
- Action.

Action:

- Lihat Detail.
- Tambah ke Watchlist.

Buat search saham.

Buat stock detail drawer berisi:

- Nama.
- Kode.
- Harga simulasi.
- Perubahan.
- Mini chart.
- Ringkasan statistik.
- Button tambah watchlist.

--------------------------------------------------
11.2 TAB WATCHLIST
--------------------------------------------------

Tabel:

- Kode.
- Nama.
- Harga.
- Perubahan Harian.
- Target Harga.
- Alert.
- Action.

Tambahkan:

- Add to watchlist.
- Remove.
- Edit target.
- Toggle alert.

--------------------------------------------------
11.3 TAB PORTOFOLIO
--------------------------------------------------

Summary cards:

- Nilai Portofolio: Rp3.400.000.
- Modal: Rp3.150.000.
- Unrealized Gain: Rp250.000.
- Return: 7,9%.

Charts:

- Alokasi portofolio.
- Performa portofolio.
- Gain/loss per aset.

Table:

- Kode.
- Lot atau unit.
- Average price.
- Current price.
- Market value.
- Gain/loss.
- Return.

Gunakan label simulasi pada seluruh nilai pasar.

--------------------------------------------------
11.4 TAB TRANSAKSI INVESTASI
--------------------------------------------------

Filters:

- Beli.
- Jual.
- Dividen.
- Deposit.
- Withdrawal.

Table:

- Tanggal.
- Aset.
- Tipe.
- Jumlah.
- Harga.
- Fee.
- Total.
- Action.

Primary action:
Tambah Transaksi Investasi

==================================================
12. HALAMAN AKUNTANSI
==================================================

FRAME NAME:

FreeSpace/Desktop/Keuangan/Akuntansi

BREADCRUMB:

Keuangan > Akuntansi

JUDUL:

Akuntansi

SUBTITLE:

Kelola pencatatan double-entry hingga laporan keuangan.

TABS:

- Jurnal
- Buku Besar
- Neraca Saldo
- Penyesuaian
- Laporan Keuangan

Default active:
Jurnal

--------------------------------------------------
12.1 TAB JURNAL
--------------------------------------------------

Summary cards:

- Total Jurnal: 48.
- Draft AI: 3.
- Menunggu Persetujuan: 2.
- Jurnal Tidak Seimbang: 0.

Actions:

Primary:
Buat Jurnal

Secondary:
Upload Bukti Transaksi

Additional compact action:
Review Jurnal AI

Filters:

- Periode.
- Status.
- Sumber.
- Akun.
- Search.

Table:

- Nomor Jurnal.
- Tanggal.
- Keterangan.
- Sumber.
- Total Debit.
- Total Kredit.
- Status.
- Action.

Status:

- Draft.
- Menunggu Review.
- Disetujui.
- Ditolak.
- Diposting.

Sumber:

- Manual.
- Transaksi.
- AI Receipt.
- Penyesuaian.

--------------------------------------------------
12.2 MODAL JURNAL MANUAL
--------------------------------------------------

Fields:

- Tanggal.
- Nomor referensi.
- Keterangan.
- Lampiran.

Journal lines:

- Akun.
- Deskripsi.
- Debit.
- Kredit.
- Add row.
- Delete row.

Footer calculation:

Total Debit
Total Kredit
Selisih

Button Simpan harus disabled jika debit tidak sama dengan kredit.

Buttons:

- Simpan Draft.
- Posting Jurnal.

--------------------------------------------------
12.3 FLOW JURNAL OTOMATIS AI
--------------------------------------------------

Buat prototype flow:

Step 1:
Upload bukti transaksi.

Accepted files:

- JPG.
- PNG.
- PDF.

Step 2:
Processing.

Teks:
“AI sedang membaca bukti transaksi.”

Step 3:
Draft result.

Tampilkan:

- Merchant.
- Tanggal.
- Nominal.
- Pajak.
- Kategori.
- Akun debit.
- Akun kredit.
- Confidence indicator.

Step 4:
Review pengguna.

Actions:

- Edit.
- Setujui & Posting.
- Tolak.
- Simpan Draft.

Selalu minta persetujuan pengguna sebelum posting.

Jangan membuat AI langsung mem-posting jurnal tanpa konfirmasi.

--------------------------------------------------
12.4 TAB BUKU BESAR
--------------------------------------------------

Account selector:
Kas dan Bank

Periode:
Juli 2026

Table:

- Tanggal.
- Referensi.
- Keterangan.
- Debit.
- Kredit.
- Saldo.

Tampilkan opening balance dan closing balance.

--------------------------------------------------
12.5 TAB NERACA SALDO
--------------------------------------------------

Segmented control:

- Sebelum Penyesuaian.
- Setelah Penyesuaian.
- Setelah Penutupan.

Table:

- Kode Akun.
- Nama Akun.
- Debit.
- Kredit.

Footer:

Total Debit
Total Kredit
Balanced status

--------------------------------------------------
12.6 TAB PENYESUAIAN
--------------------------------------------------

Internal sections:

- Jurnal Penyesuaian.
- Kertas Kerja.
- Jurnal Penutup.
- Riwayat Penutupan Periode.

Jangan menjadikan section ini sebagai submenu sidebar.

Primary action:
Buat Penyesuaian

Tampilkan checklist penutupan periode.

--------------------------------------------------
12.7 TAB LAPORAN KEUANGAN
--------------------------------------------------

Internal tabs:

- Laba Rugi.
- Perubahan Ekuitas.
- Posisi Keuangan.
- Arus Kas.

Controls:

- Periode.
- Basis laporan.
- Compare period.
- Export PDF.
- Export Excel.

Gunakan struktur laporan yang rapi dan printable.

Buat badge:

Generated from Posted Journals

Versi bahasa Indonesia:

Dibentuk dari Jurnal yang Telah Diposting

==================================================
13. HALAMAN SPT ORANG PRIBADI
==================================================

FRAME NAME:

FreeSpace/Desktop/Keuangan/SPTOrangPribadi

BREADCRUMB:

Keuangan > SPT Orang Pribadi

JUDUL:

SPT Orang Pribadi

SUBTITLE:

Siapkan data dan estimasi perhitungan SPT Tahunan pribadi.

Tambahkan information banner:

“Fitur ini membantu menyiapkan dan menghitung data SPT. Pengiriman resmi tetap dilakukan melalui kanal resmi Direktorat Jenderal Pajak.”

Jangan mengklaim bahwa aplikasi mengirim SPT secara resmi.

Gunakan stepper:

1. Data Wajib Pajak
2. Penghasilan
3. Harta & Utang
4. Perhitungan
5. Review & Export

--------------------------------------------------
13.1 STEP DATA WAJIB PAJAK
--------------------------------------------------

Fields:

- Nama lengkap.
- NPWP atau NIK.
- Status PTKP.
- Status perkawinan.
- Jumlah tanggungan.
- Tahun pajak.
- Alamat.
- Nomor telepon.
- Email.

Buttons:

- Simpan Draft.
- Lanjutkan.

--------------------------------------------------
13.2 STEP PENGHASILAN
--------------------------------------------------

Sections:

- Penghasilan dari pekerjaan.
- Penghasilan usaha.
- Penghasilan lainnya.
- Penghasilan final.
- Penghasilan bukan objek pajak.
- Kredit pajak.
- Bukti potong.

Support upload attachment.

--------------------------------------------------
13.3 STEP HARTA & UTANG
--------------------------------------------------

Harta table:

- Jenis harta.
- Tahun perolehan.
- Nilai.
- Keterangan.

Utang table:

- Pemberi pinjaman.
- Tahun pinjaman.
- Saldo akhir.
- Keterangan.

Actions:

- Tambah Harta.
- Tambah Utang.

--------------------------------------------------
13.4 STEP PERHITUNGAN
--------------------------------------------------

Cards:

- Penghasilan Neto.
- PTKP.
- Penghasilan Kena Pajak.
- PPh Terutang.
- Kredit Pajak.
- Kurang atau Lebih Bayar.

Tampilkan formula summary secara readable.

Gunakan informasi:

“Hasil merupakan estimasi berdasarkan data yang dimasukkan pengguna.”

--------------------------------------------------
13.5 STEP REVIEW & EXPORT
--------------------------------------------------

Buat validation checklist:

- Data wajib pajak lengkap.
- Penghasilan lengkap.
- Harta dan utang lengkap.
- Dokumen pendukung tersedia.
- Perhitungan telah diperiksa.

Actions:

- Kembali dan Perbaiki.
- Simpan Draft.
- Export PDF.
- Export Excel.

Tambahkan status:

Draft
Siap Ditinjau
Selesai

==================================================
14. REUSABLE COMPONENTS
==================================================

Buat atau rapikan components berikut:

Navigation:

- Sidebar/NavItem/Parent.
- Sidebar/NavItem/Child.
- Sidebar/SectionLabel.
- Sidebar/Accordion.

Page:

- Page/Header.
- Breadcrumb.
- Page/ActionBar.

Cards:

- Card/Summary.
- Card/Insight.
- Card/Chart.
- Card/Progress.
- Card/Goal.
- Card/Market.

Tabs:

- Tabs/Primary.
- Tabs/Segmented.
- Tabs/WithCount.

Forms:

- Input/Text.
- Input/Currency.
- Input/Date.
- Select.
- SearchInput.
- Textarea.
- Toggle.
- Checkbox.
- Radio.
- FileUpload.
- JournalLine.

Tables:

- Table/Header.
- Table/Row.
- Table/Pagination.
- Table/EmptyState.

Status:

- Badge/Positive.
- Badge/Warning.
- Badge/Danger.
- Badge/Neutral.
- Badge/Draft.
- Badge/Approved.
- Badge/Rejected.

Feedback:

- Toast/Success.
- Toast/Error.
- Alert/Info.
- Alert/Warning.
- Modal/Confirm.
- Modal/Form.
- Drawer/Detail.

Gunakan component variants, jangan menduplikasi style secara manual.

==================================================
15. REQUIRED STATES
==================================================

Setiap halaman atau komponen utama harus memiliki state berikut jika relevan:

- Default.
- Hover.
- Focus.
- Active.
- Selected.
- Disabled.
- Loading.
- Empty.
- Error.
- Success.

Contoh empty states:

Transaksi:
“Belum ada transaksi pada periode ini.”

Budget:
“Belum ada budget untuk Juli 2026.”

Investasi:
“Watchlist masih kosong.”

Akuntansi:
“Belum ada jurnal pada periode ini.”

SPT:
“Belum ada draft SPT.”

Empty state harus memiliki satu action yang relevan.

Contoh:

- Tambah Transaksi.
- Buat Budget.
- Tambah Watchlist.
- Buat Jurnal.
- Mulai SPT.

Jangan menggunakan empty state “Segera Hadir”.

==================================================
16. INTERACTION DAN PROTOTYPE
==================================================

Buat prototype links untuk:

Sidebar:

- Dashboard menuju Dashboard.
- Transaksi menuju halaman Transaksi.
- Budget menuju halaman Budget.
- Analisis & Proyeksi menuju halaman Analisis & Proyeksi.
- Kondisi Keuangan menuju halaman Kondisi Keuangan.
- Investasi menuju halaman Investasi.
- Akuntansi menuju halaman Akuntansi.
- SPT Orang Pribadi menuju halaman SPT.

Interactions:

- Tabs berpindah state.
- Quick Add membuka overlay.
- Tambah Transaksi membuka modal atau drawer.
- Buat Budget membuka modal.
- Stock detail membuka drawer.
- Buat Jurnal membuka modal jurnal.
- Upload Bukti membuka AI processing flow.
- Stepper SPT berpindah antar-step.
- Action menu pada tabel dapat dibuka.
- Confirm delete menggunakan modal.
- Success action menampilkan toast.

Gunakan Smart Animate secara halus.

Durasi yang disarankan:

- 150–250 ms.

Jangan membuat animasi dekoratif berlebihan.

==================================================
17. RESPONSIVE DESIGN
==================================================

Buat responsive layout untuk:

1. Desktop atau laptop existing frame.
2. iPad landscape.
3. iPad portrait.

Desktop:

- Sidebar fixed.
- Topbar fixed sesuai desain.
- Content menggunakan existing grid.
- Table dapat menggunakan full width.

iPad landscape:

- Sidebar dapat tampil full atau collapsed sesuai ruang.
- Card empat kolom berubah menjadi dua kolom jika diperlukan.
- Filter dapat wrap ke baris kedua.
- Tabel tetap horizontal scroll jika terlalu lebar.

iPad portrait:

- Sidebar menjadi off-canvas drawer.
- Summary cards menjadi dua kolom.
- Tiga chart menjadi satu kolom.
- Dua tabel Dashboard menjadi satu kolom.
- Filter menggunakan wrap atau filter drawer.
- Primary action tetap terlihat.
- Modal besar dapat menjadi full-screen sheet.
- Table dapat menggunakan responsive horizontal scroll.

Jangan membuat bottom navigation baru.

==================================================
18. ACCESSIBILITY
==================================================

Pastikan:

- Contrast text memadai.
- Active state tidak hanya mengandalkan warna.
- Button memiliki label jelas.
- Icon-only button memiliki tooltip.
- Form fields memiliki labels.
- Error ditampilkan dekat field.
- Currency input mudah dibaca.
- Area klik minimal 40–44 px.
- Table header mudah dibedakan.
- Focus state terlihat.
- Status menggunakan teks dan warna.
- Chart memiliki legend.
- Data penting tidak hanya ditampilkan melalui warna.

==================================================
19. FIGMA FILE ORGANIZATION
==================================================

Gunakan page atau section Figma:

01 — Foundations
02 — Components
03 — Dashboard
04 — Keuangan
05 — Responsive
06 — Prototype

Nama frame:

FreeSpace/Desktop/Dashboard
FreeSpace/Desktop/Keuangan/Transaksi
FreeSpace/Desktop/Keuangan/Budget-Rencana
FreeSpace/Desktop/Keuangan/Budget-Realisasi
FreeSpace/Desktop/Keuangan/Budget-Evaluasi
FreeSpace/Desktop/Keuangan/Analisis
FreeSpace/Desktop/Keuangan/Proyeksi
FreeSpace/Desktop/Keuangan/Skenario
FreeSpace/Desktop/Keuangan/Kondisi-Aset
FreeSpace/Desktop/Keuangan/Kondisi-UtangPiutang
FreeSpace/Desktop/Keuangan/Kondisi-KekayaanBersih
FreeSpace/Desktop/Keuangan/Kondisi-TargetKesehatan
FreeSpace/Desktop/Keuangan/Investasi-Market
FreeSpace/Desktop/Keuangan/Investasi-Watchlist
FreeSpace/Desktop/Keuangan/Investasi-Portofolio
FreeSpace/Desktop/Keuangan/Investasi-Transaksi
FreeSpace/Desktop/Keuangan/Akuntansi-Jurnal
FreeSpace/Desktop/Keuangan/Akuntansi-BukuBesar
FreeSpace/Desktop/Keuangan/Akuntansi-NeracaSaldo
FreeSpace/Desktop/Keuangan/Akuntansi-Penyesuaian
FreeSpace/Desktop/Keuangan/Akuntansi-Laporan
FreeSpace/Desktop/Keuangan/SPT-Step1
FreeSpace/Desktop/Keuangan/SPT-Step2
FreeSpace/Desktop/Keuangan/SPT-Step3
FreeSpace/Desktop/Keuangan/SPT-Step4
FreeSpace/Desktop/Keuangan/SPT-Step5

Jangan menggunakan nama layer:

- Frame 1.
- Group 23.
- Copy 4.
- Rectangle 121.

Gunakan descriptive layer naming.

==================================================
20. EXECUTION PRIORITY
==================================================

Kerjakan dalam urutan berikut:

PHASE 1

1. Dashboard.
2. Transaksi.
3. Budget.

PHASE 2

4. Analisis & Proyeksi.
5. Kondisi Keuangan.

PHASE 3

6. Investasi.
7. Akuntansi.
8. SPT Orang Pribadi.

Meskipun dikerjakan bertahap, seluruh halaman harus menggunakan komponen dan data yang konsisten.

Jangan berhenti setelah membuat satu halaman saja.

==================================================
21. ACCEPTANCE CHECKLIST
==================================================

DASHBOARD

[ ] Judul sudah menjadi Dashboard.
[ ] Tidak ada istilah Eksekutif.
[ ] Tidak ada istilah Manajemen Aset IPB.
[ ] Delapan summary cards sudah relevan.
[ ] Chart sudah relevan dengan FreeSpace.
[ ] Table sudah menjadi agenda dan transaksi.
[ ] Quick Add tersedia.
[ ] Dashboard tetap menjadi satu-satunya Dashboard.

TRANSAKSI

[ ] Placeholder Segera Hadir sudah dihapus.
[ ] Summary cards tersedia.
[ ] Lima tabs transaksi tersedia.
[ ] Filter lengkap tersedia.
[ ] Table transaksi tersedia.
[ ] Modal tambah transaksi tersedia.
[ ] Upload lampiran tersedia.
[ ] Transaksi berulang tersedia.

BUDGET

[ ] Tabs Rencana, Realisasi, dan Evaluasi tersedia.
[ ] Budget cap dapat ditentukan.
[ ] Realisasi per kategori terlihat.
[ ] Status budget jelas.
[ ] Budget vs aktual terlihat.
[ ] Salin bulan sebelumnya tersedia.

ANALISIS & PROYEKSI

[ ] Analisis pola tersedia.
[ ] Proyeksi cash flow tersedia.
[ ] Proyeksi saldo tersedia.
[ ] Scenario builder tersedia.
[ ] Baseline vs scenario tersedia.
[ ] Disclaimer proyeksi tersedia.

KONDISI KEUANGAN

[ ] Aset tersedia.
[ ] Utang dan piutang tersedia.
[ ] Kekayaan bersih tersedia.
[ ] Financial health score tersedia.
[ ] Target keuangan tersedia.
[ ] Rasio keuangan tersedia.

INVESTASI

[ ] Market Indonesia dan AS tersedia.
[ ] Label Data Simulasi tersedia.
[ ] Watchlist tersedia.
[ ] Portofolio tersedia.
[ ] Transaksi investasi tersedia.
[ ] Stock detail drawer tersedia.

AKUNTANSI

[ ] Jurnal manual tersedia.
[ ] Upload bukti tersedia.
[ ] AI draft review tersedia.
[ ] Persetujuan pengguna wajib.
[ ] Buku besar tersedia.
[ ] Neraca saldo tersedia.
[ ] Penyesuaian tersedia.
[ ] Laporan keuangan tersedia.
[ ] Debit dan kredit tervalidasi.
[ ] Audit status terlihat.

SPT ORANG PRIBADI

[ ] Stepper tersedia.
[ ] Data wajib pajak tersedia.
[ ] Penghasilan tersedia.
[ ] Harta dan utang tersedia.
[ ] Estimasi perhitungan tersedia.
[ ] Review dan export tersedia.
[ ] Disclaimer kanal resmi tersedia.
[ ] Tidak ada klaim pengiriman resmi.

VISUAL

[ ] Topbar tetap sama.
[ ] Sidebar tetap sama.
[ ] Profile card tetap sama.
[ ] Typography tetap sama.
[ ] Color palette tetap sama.
[ ] Card style tetap sama.
[ ] Table style konsisten.
[ ] Spacing konsisten.
[ ] Responsive constraints tersedia.
[ ] Tidak ada visual language baru.

==================================================
22. FINAL INSTRUCTION
==================================================

Mulai dengan mengedit frame Dashboard lama dan frame Transaksi placeholder yang sudah tersedia.

Setelah itu, buat seluruh frame Keuangan dengan menurunkan component dan visual pattern dari desain existing.

Jangan membuat konsep alternatif.

Jangan membuat moodboard.

Jangan membuat low-fidelity wireframe.

Jangan membuat landing page.

Jangan mengubah sidebar dan topbar.

Jangan menambahkan menu baru.

Jangan menampilkan seluruh tabs sebagai submenu sidebar.

Gunakan real Indonesian UI copy.

Gunakan format Rupiah Indonesia.

Gunakan tanggal Indonesia.

Gunakan data simulasi yang konsisten.

Hasil akhir harus terlihat seperti evolusi langsung dari desain FreeSpace yang sekarang, bukan aplikasi berbeda.