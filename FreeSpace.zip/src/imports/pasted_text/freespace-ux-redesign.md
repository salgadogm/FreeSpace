ROLE AND EXECUTION MODE

Anda adalah Senior Product Designer, UX Architect, Settings Experience Designer, Privacy & Security UX Designer, Audit Log Designer, dan Figma Design-System Specialist.

Edit langsung desain FreeSpace yang SUDAH ADA pada file Figma ini.

Kondisi desain saat ini:

1. Branding telah menjadi “FreeSpace – Personal Workspace”.
2. Sidebar, topbar, profile card, search, Tanya AI, notifikasi, dan share sudah tersedia.
3. Menu History sudah tersedia sebagai single-level menu.
4. Menu Pengaturan sudah tersedia sebagai expandable parent menu.
5. Submenu Pengaturan saat ini terdiri dari:
   - Preferensi
   - Pengaturan Data
   - Pengaturan Notifikasi
   - Keamanan & Data
6. Halaman History masih menggunakan konsep lama aplikasi Manajemen Aset:
   - Judul halaman masih “Aktivitas”.
   - Masih terdapat istilah audit aset.
   - Masih terdapat banyak pengguna dan role.
   - Masih terdapat perubahan data aset.
   - Masih terdapat filter pengguna dan role.
7. Halaman Preferensi masih mencampurkan:
   - Preferensi tampilan.
   - Pengaturan notifikasi.
   - Istilah tabel aset.
8. Halaman Pengaturan Data, Pengaturan Notifikasi, serta Keamanan & Data belum dieksekusi secara lengkap.
9. FreeSpace adalah aplikasi personal single-user, bukan aplikasi organisasi multi-user.

Tugas Anda sekarang adalah:

1. Menyelesaikan halaman History.
2. Memperbaiki halaman Preferensi.
3. Mendesain dan mengeksekusi halaman Pengaturan Data.
4. Mendesain dan mengeksekusi halaman Pengaturan Notifikasi.
5. Mendesain dan mengeksekusi halaman Keamanan & Data.
6. Menghapus seluruh istilah yang masih berkaitan dengan Manajemen Aset.
7. Menghapus konsep role, operator, administrator, dan multi-user.
8. Membuat reusable components, states, modal, drawer, dan prototype interactions.
9. Mempertahankan visual language FreeSpace yang sudah tersedia.

Jangan hanya memberikan penjelasan, wireframe, atau konsep.

Eksekusi desain final high-fidelity secara langsung menggunakan:

- Existing frame.
- Components.
- Component variants.
- Auto Layout.
- Variables.
- Constraints.
- Prototype links.
- Modals.
- Drawers.
- Responsive states.

==================================================
1. STRUKTUR NAVIGASI FINAL
==================================================

Pertahankan section sidebar:

SISTEM

- History
- Pengaturan
  - Preferensi
  - Pengaturan Data
  - Pengaturan Notifikasi
  - Keamanan & Data

Aturan:

- History adalah single-level menu.
- History tidak memiliki chevron.
- History tidak memiliki submenu.
- Pengaturan adalah expandable parent menu.
- Pengaturan memiliki empat submenu.
- Tidak boleh ada hierarchy level ketiga.
- Jangan menambahkan submenu Profil.
- Halaman Profil diakses melalui profile card pengguna di kiri atas.
- Jangan membuat menu Backup terpisah.
- Backup ditempatkan di halaman Keamanan & Data.
- Notification inbox tetap diakses melalui ikon lonceng pada topbar.
- Pengaturan Notifikasi hanya mengatur preferensi notifikasi, bukan menampilkan notification inbox.

==================================================
2. PERTAHANKAN DESAIN EXISTING
==================================================

Pertahankan sepenuhnya:

- Ukuran dan posisi sidebar.
- Ukuran dan posisi topbar.
- Brand FreeSpace.
- Subtitle Personal Workspace.
- Profile card di kiri atas.
- Search field.
- Keyboard shortcut search.
- Tombol Tanya AI.
- Notification icon dan badge.
- Share button.
- Page background.
- Page padding.
- Existing grid.
- Typography.
- Font family.
- Heading hierarchy.
- Body text style.
- Warna utama.
- Warna status.
- Icon style.
- Border.
- Border radius.
- Shadow.
- Card style.
- Table style.
- Form style.
- Breadcrumb style.
- Sidebar active state.
- Sidebar hover state.
- Spacing system.
- Existing design tokens.

Jangan:

- Mengubah topbar.
- Memperlebar sidebar.
- Memindahkan profile card.
- Membuat navigation baru.
- Mengganti font.
- Membuat visual language baru.
- Membuat gradient baru.
- Membuat desain seperti enterprise admin panel.
- Menggunakan terlalu banyak summary card.
- Membuat dashboard baru.
- Menambahkan role management.
- Menambahkan user management.
- Menambahkan permission management.
- Menambahkan audit aset.
- Menggunakan istilah kampus, unit, aset, stock opname, atau maintenance.

==================================================
3. PRINSIP SINGLE-USER
==================================================

FreeSpace hanya digunakan oleh satu pengguna.

Karena itu, jangan menampilkan:

- Semua Pengguna.
- Nama pengguna berbeda-beda.
- Semua Role.
- Admin Sistem.
- Operator Aset.
- Role pengguna.
- User management.
- Permission management.
- Aktivitas pengguna lain.
- Perubahan data aset.
- Audit berdasarkan organisasi.
- Kampus.
- Unit.
- Lokasi aset.
- IP address pada seluruh aktivitas umum.

Informasi perangkat, IP, browser, dan lokasi hanya boleh ditampilkan pada konteks:

- Login & Keamanan.
- Sesi aktif.
- Riwayat login.
- Percobaan login gagal.

Untuk aktivitas sehari-hari, fokuskan informasi pada:

- Waktu.
- Modul.
- Jenis aktivitas.
- Item yang berubah.
- Ringkasan aktivitas.
- Status.
- Sumber aktivitas.

==================================================
4. DATA SIMULASI GLOBAL
==================================================

Gunakan konteks:

Tanggal aktif:
3 Juli 2026

Pengguna:
Salgado Ginting

Zona waktu:
Asia/Jakarta

Bahasa:
Bahasa Indonesia

Mata uang:
Rupiah — IDR

Tema aktif:
Terang

Aktivitas hari ini:
18

Perubahan data:
7

Aktivitas AI:
3

Login terakhir:
3 Jul 2026, 08.12

Peringatan keamanan:
0

Backup terakhir:
3 Jul 2026, 02.00

Backup otomatis:
Aktif

Frekuensi backup:
Harian

2FA:
Aktif

Sesi aktif:
2 perangkat

Gunakan data tersebut secara konsisten pada History dan Pengaturan.

==================================================
5. HALAMAN HISTORY
==================================================

FRAME NAME:

FreeSpace/Desktop/System/History-All

BREADCRUMB:

History

JUDUL:

History

SUBTITLE:

Lihat riwayat aktivitas dan perubahan penting di seluruh FreeSpace.

PRIMARY ACTION:

Unduh History

Icon:
Arrow Down Tray

Jangan menggunakan judul:

- Aktivitas.
- Activity Log.
- Audit Aset.
- Log Aset.
- Audit Trail Aset.

Menu History tetap menggunakan nama “History”, tetapi seluruh UI di dalamnya menggunakan bahasa Indonesia yang natural.

--------------------------------------------------
5.1 SUMMARY CARDS HISTORY
--------------------------------------------------

Pertahankan pola summary cards existing, tetapi gunakan lima card berikut.

CARD 1

Label:
Aktivitas Hari Ini

Value:
18

Description:
Tercatat pada 3 Juli 2026

Icon:
Activity atau Clock

Status:
Primary

CARD 2

Label:
Perubahan Data

Value:
7

Description:
Tambah, ubah, dan hapus data

Icon:
Pencil Square

Status:
Warning atau secondary

CARD 3

Label:
Aktivitas AI

Value:
3

Description:
Permintaan diproses hari ini

Icon:
Sparkles

Status:
Primary

CARD 4

Label:
Login Terakhir

Value:
08.12

Description:
Chrome pada Windows

Icon:
Arrow Right End On Rectangle

Status:
Positive

CARD 5

Label:
Peringatan Keamanan

Value:
0

Description:
Tidak ada aktivitas mencurigakan

Icon:
Shield Check

Status:
Positive

Jangan menampilkan:

- Login Pengguna sebagai jumlah sesi organisasi.
- Perubahan Data Aset.
- Aktivitas Berisiko berbasis aset.
- Gagal Validasi aset.
- Role atau user count.

--------------------------------------------------
5.2 INTERNAL TABS HISTORY
--------------------------------------------------

Gunakan tabs seperti layout existing.

Tabs:

- Semua Aktivitas
- Perubahan Data
- Aktivitas AI
- Login & Keamanan

Default active:
Semua Aktivitas

Jangan membuat tab berdasarkan user atau role.

Tab tidak menjadi submenu sidebar.

--------------------------------------------------
5.3 FILTER BAR HISTORY
--------------------------------------------------

Gunakan toolbar filter.

Komponen:

- Search history.
- Rentang tanggal.
- Filter modul.
- Filter jenis aktivitas.
- Filter status.
- Tombol Reset.

Search placeholder:

Cari aktivitas atau item...

Rentang tanggal default:

1–3 Juli 2026

Filter modul:

- Semua Modul.
- Dashboard.
- Keuangan.
- Produktivitas.
- Library.
- Karier.
- Pengaturan.
- Sistem.

Filter jenis aktivitas:

- Semua Aktivitas.
- Tambah.
- Ubah.
- Hapus.
- Buka.
- Export.
- Import.
- Upload.
- Login.
- Logout.
- Bantuan AI.
- Backup.
- Restore.

Filter status:

- Semua Status.
- Berhasil.
- Gagal.
- Dibatalkan.
- Menunggu.

Hapus filter:

- Semua Pengguna.
- Semua Role.
- Semua Unit.
- Semua Kampus.

--------------------------------------------------
5.4 TABEL SEMUA AKTIVITAS
--------------------------------------------------

Kolom:

- Waktu
- Modul
- Aktivitas
- Item
- Ringkasan
- Status
- Sumber
- Action

Data contoh:

1.

Waktu:
08.12

Modul:
Sistem

Aktivitas:
Login

Item:
Akun Pengguna

Ringkasan:
Berhasil masuk ke FreeSpace

Status:
Berhasil

Sumber:
Web

2.

Waktu:
08.35

Modul:
Keuangan

Aktivitas:
Tambah

Item:
Transaksi

Ringkasan:
Menambahkan pengeluaran Makan Siang sebesar Rp35.000

Status:
Berhasil

Sumber:
Manual

3.

Waktu:
09.10

Modul:
Produktivitas

Aktivitas:
Ubah

Item:
Aktivitas

Ringkasan:
Mengubah jadwal Review Akuntansi menjadi pukul 10.00

Status:
Berhasil

Sumber:
Manual

4.

Waktu:
10.25

Modul:
Library

Aktivitas:
Buka

Item:
Buku

Ringkasan:
Melanjutkan membaca Akuntansi Keuangan Menengah halaman 124

Status:
Berhasil

Sumber:
PDF Reader

5.

Waktu:
11.40

Modul:
Library

Aktivitas:
Tambah

Item:
Catatan

Ringkasan:
Menyimpan catatan Konsep Jurnal Penyesuaian

Status:
Berhasil

Sumber:
Manual

6.

Waktu:
13.15

Modul:
Keuangan

Aktivitas:
Bantuan AI

Item:
Jurnal Akuntansi

Ringkasan:
Memproses bukti transaksi dan menghasilkan draft jurnal

Status:
Berhasil

Sumber:
Gemini Vision

7.

Waktu:
14.05

Modul:
Produktivitas

Aktivitas:
Ubah

Item:
Steps Tracker

Ringkasan:
Memperbarui langkah harian menjadi 7.420

Status:
Berhasil

Sumber:
Input Manual

8.

Waktu:
15.20

Modul:
Pengaturan

Aktivitas:
Ubah

Item:
Preferensi

Ringkasan:
Mengubah format tanggal menjadi DD MMM YYYY

Status:
Berhasil

Sumber:
Web

Gunakan badge activity:

- Tambah.
- Ubah.
- Hapus.
- Login.
- Upload.
- Export.
- AI.

Gunakan badge status:

- Berhasil.
- Gagal.
- Dibatalkan.
- Menunggu.

Action menu:

- Lihat Detail.
- Buka Item Terkait.
- Salin Detail.

Tidak semua aktivitas harus memiliki “Buka Item Terkait”.

--------------------------------------------------
5.5 TAB PERUBAHAN DATA
--------------------------------------------------

Tampilkan hanya aktivitas yang mengubah data.

Kolom:

- Waktu.
- Modul.
- Jenis Perubahan.
- Item.
- Nilai Sebelumnya.
- Nilai Setelahnya.
- Status.
- Action.

Contoh:

Modul:
Budget

Item:
Budget Makanan

Jenis:
Ubah

Sebelumnya:
Rp1.000.000

Setelahnya:
Rp1.200.000

Contoh lain:

Modul:
Aktivitas

Item:
Review Akuntansi

Sebelumnya:
09.00

Setelahnya:
10.00

Untuk data panjang, tampilkan ringkasan dan gunakan drawer detail.

Jangan menampilkan data pribadi sensitif secara terbuka.

Untuk password atau token:

Nilai Sebelumnya:
Disembunyikan

Nilai Setelahnya:
Disembunyikan

--------------------------------------------------
5.6 TAB AKTIVITAS AI
--------------------------------------------------

Kolom:

- Waktu.
- Modul.
- Provider.
- Tindakan.
- Input Ringkas.
- Hasil.
- Status.
- Action.

Data contoh:

1.

Modul:
Akuntansi

Provider:
Gemini

Tindakan:
Analisis Bukti Transaksi

Input:
Struk makan siang

Hasil:
Draft jurnal dibuat

Status:
Disetujui Pengguna

2.

Modul:
Library

Provider:
Grok

Tindakan:
Ringkas Teks Terpilih

Input:
Halaman 124

Hasil:
Ringkasan disimpan ke catatan

Status:
Berhasil

3.

Modul:
Karier

Provider:
Gemini

Tindakan:
Analisis CV

Input:
CV Akuntansi 2026

Hasil:
ATS score 82%

Status:
Berhasil

Tambahkan label:

AI hanya memproses data setelah diminta pengguna.

Action:

- Lihat Detail.
- Lihat Sumber.
- Hapus Riwayat AI.

Gunakan confirmation modal sebelum menghapus.

--------------------------------------------------
5.7 TAB LOGIN & KEAMANAN
--------------------------------------------------

Pada tab ini baru tampilkan informasi perangkat dan IP.

Summary:

- Login berhasil: 4.
- Login gagal: 0.
- Perangkat aktif: 2.
- Aktivitas mencurigakan: 0.

Kolom:

- Waktu.
- Aktivitas.
- Perangkat.
- Browser.
- IP.
- Lokasi Perkiraan.
- Status.
- Action.

Data contoh:

3 Jul 2026, 08.12
Login
Windows Laptop
Chrome
10.0.1.45
Jakarta, Indonesia
Berhasil

2 Jul 2026, 20.35
Login
iPad
Safari
10.0.1.20
Jakarta, Indonesia
Berhasil

Tambahkan catatan:

Lokasi merupakan perkiraan berdasarkan alamat IP.

Action:

- Lihat Detail.
- Keluar dari Perangkat.
- Tandai Bukan Saya.

“Tandai Bukan Saya” membuka modal keamanan.

--------------------------------------------------
5.8 DETAIL DRAWER HISTORY
--------------------------------------------------

Buat right-side drawer.

Judul:
Detail Aktivitas

Tampilkan:

- Tanggal dan waktu.
- Modul.
- Aktivitas.
- Item.
- Ringkasan.
- Status.
- Sumber.
- Referensi internal.
- Perangkat jika relevan.
- IP jika relevan.
- Data sebelum dan setelah jika relevan.

Actions:

- Buka Item.
- Salin Detail.
- Tutup.

Jangan menampilkan internal database ID secara dominan.

--------------------------------------------------
5.9 EXPORT HISTORY
--------------------------------------------------

Button:

Unduh History

Membuka modal.

Fields:

- Rentang tanggal.
- Modul.
- Jenis aktivitas.
- Status.
- Format.

Format:

- CSV.
- Excel.
- PDF.

Buttons:

- Batal.
- Unduh.

Success toast:

History berhasil diunduh.

==================================================
6. MENU PENGATURAN
==================================================

Pengaturan adalah expandable parent menu.

Submenu:

- Preferensi
- Pengaturan Data
- Pengaturan Notifikasi
- Keamanan & Data

Pada setiap halaman:

- Pengaturan expanded.
- Child terkait aktif.
- Parent lain collapsed.

Jangan membuat halaman Dashboard Pengaturan.

==================================================
7. HALAMAN PREFERENSI
==================================================

FRAME NAME:

FreeSpace/Desktop/Settings/Preferensi

BREADCRUMB:

Pengaturan > Preferensi

JUDUL:

Preferensi

SUBTITLE:

Sesuaikan tampilan dan pengalaman penggunaan FreeSpace.

Hapus dari halaman Preferensi:

- Pengaturan Notifikasi.
- Ringkasan Mingguan.
- Peringatan Pemeliharaan Aset.
- Pembaruan aset.
- Kerapatan tabel aset.
- Semua istilah aset.
- Semua setting keamanan.
- Semua setting backup.

PRIMARY ACTION:

Simpan Perubahan

SECONDARY ACTION:

Kembalikan Default

--------------------------------------------------
7.1 SECTION TAMPILAN & ANTARMUKA
--------------------------------------------------

Buat card section:

Tampilan & Antarmuka

Fields:

Tema Visual

Options:

- Terang.
- Gelap.
- Ikuti Sistem.

Default:
Terang

Gunakan segmented control dengan preview kecil.

Kepadatan Tampilan

Options:

- Nyaman.
- Normal.
- Ringkas.

Default:
Normal

Ganti istilah “Kerapatan Data Tabel” menjadi:

Kepadatan Tampilan

Deskripsi:

Mengatur jarak antarbaris, card, dan elemen antarmuka.

Ukuran Teks

Options:

- Kecil.
- Normal.
- Besar.

Default:
Normal

Perilaku Sidebar

Options:

- Selalu Terbuka.
- Collapse Otomatis pada Layar Kecil.
- Ingat Kondisi Terakhir.

Default:
Ingat Kondisi Terakhir

Animasi Antarmuka

Toggle:
Aktif

Deskripsi:

Menggunakan transisi ringan saat berpindah halaman dan membuka panel.

--------------------------------------------------
7.2 SECTION BAHASA & REGIONAL
--------------------------------------------------

Card section:

Bahasa & Regional

Fields:

Bahasa

Default:
Bahasa Indonesia

Options:

- Bahasa Indonesia.
- English.

Mata Uang

Default:
IDR — Rupiah Indonesia

Format Angka

Default:
1.250.000,00

Options:

- 1.250.000,00
- 1,250,000.00

Format Tanggal

Default:
3 Jul 2026

Options:

- 3 Jul 2026.
- 03/07/2026.
- 2026-07-03.
- Jumat, 3 Juli 2026.

Format Waktu

Default:
24 Jam

Options:

- 24 Jam.
- 12 Jam.

Zona Waktu

Default:
Asia/Jakarta — GMT+7

Hari Pertama Minggu

Default:
Senin

Options:

- Senin.
- Minggu.

--------------------------------------------------
7.3 SECTION AKSESIBILITAS
--------------------------------------------------

Card section:

Aksesibilitas

Fields:

Kontras Tinggi

Toggle:
Tidak Aktif

Kurangi Animasi

Toggle:
Tidak Aktif

Perbesar Area Klik

Toggle:
Aktif

Deskripsi:

Memperbesar area interaksi tanpa mengubah ukuran visual elemen.

Garis Fokus Keyboard

Toggle:
Aktif

Deskripsi:

Menampilkan indikator fokus saat navigasi menggunakan keyboard.

--------------------------------------------------
7.4 SAVE STATE PREFERENSI
--------------------------------------------------

Buttons berada pada bagian bawah kanan.

- Kembalikan Default.
- Simpan Perubahan.

States:

- Default.
- Unsaved changes.
- Saving.
- Saved.
- Error.

Ketika ada perubahan belum disimpan, tampilkan indicator:

Perubahan belum disimpan

Success toast:

Preferensi berhasil diperbarui.

Confirmation untuk reset:

Judul:
Kembalikan Preferensi Default?

Isi:
Seluruh preferensi tampilan dan regional akan dikembalikan ke pengaturan awal.

==================================================
8. HALAMAN PENGATURAN DATA
==================================================

FRAME NAME:

FreeSpace/Desktop/Settings/PengaturanData-Finance

BREADCRUMB:

Pengaturan > Pengaturan Data

JUDUL:

Pengaturan Data

SUBTITLE:

Kelola kategori, akun, template, dan data dasar yang digunakan FreeSpace.

Jangan memasukkan:

- Import database penuh.
- Export database penuh.
- Backup.
- Restore.
- Hapus seluruh data.
- Keamanan.

Fungsi tersebut berada pada Keamanan & Data.

--------------------------------------------------
8.1 INTERNAL TABS PENGATURAN DATA
--------------------------------------------------

Tabs:

- Keuangan
- Produktivitas
- Library
- Akuntansi

Default active:
Keuangan

Tabs tidak menjadi submenu sidebar.

--------------------------------------------------
8.2 TAB KEUANGAN
--------------------------------------------------

Sections:

1. Akun & Sumber Dana
2. Kategori Transaksi
3. Kategori Budget

AKUN & SUMBER DANA

Table columns:

- Nama Akun.
- Jenis.
- Saldo Awal.
- Status.
- Default.
- Action.

Data:

Bank Utama
Bank
Rp1.500.000
Aktif
Default

E-Wallet
Dompet Digital
Rp500.000
Aktif

Tunai
Kas
Rp250.000
Aktif

Actions:

- Tambah Akun.
- Edit.
- Nonaktifkan.
- Jadikan Default.

Jenis akun:

- Kas.
- Bank.
- Dompet Digital.
- Tabungan.
- Investasi.
- Lainnya.

KATEGORI TRANSAKSI

Table columns:

- Nama.
- Tipe.
- Icon.
- Digunakan.
- Status.
- Action.

Data:

Makanan
Pengeluaran
18 transaksi
Aktif

Transportasi
Pengeluaran
12 transaksi
Aktif

Pendidikan
Pengeluaran
6 transaksi
Aktif

Uang Saku
Pemasukan
3 transaksi
Aktif

Freelance
Pemasukan
2 transaksi
Aktif

Actions:

- Tambah Kategori.
- Edit.
- Nonaktifkan.
- Gabungkan Kategori.
- Hapus.

Kategori yang sudah digunakan tidak boleh langsung dihapus.

Gunakan warning:

Kategori telah digunakan oleh transaksi dan hanya dapat dinonaktifkan atau digabungkan.

KATEGORI BUDGET

Tampilkan kategori yang dapat diberi budget.

Fields:

- Nama.
- Batas Default.
- Alert Threshold.
- Status.

Contoh threshold:

80%

--------------------------------------------------
8.3 TAB PRODUKTIVITAS
--------------------------------------------------

Sections:

1. Kategori Aktivitas.
2. Template Jurnal.
3. Target Default.

KATEGORI AKTIVITAS

Data:

- Belajar.
- Keuangan.
- Membaca.
- Jurnal.
- Pribadi.
- Kesehatan.

Fields:

- Nama.
- Icon.
- Warna.
- Jumlah aktivitas.
- Status.
- Action.

TEMPLATE JURNAL

Data:

- Refleksi Harian.
- Gratitude Journal.
- Evaluasi Mingguan.
- Review Bulanan.

Card atau table menampilkan:

- Nama template.
- Section yang digunakan.
- Terakhir diperbarui.
- Status.
- Action.

Actions:

- Buat Template.
- Edit.
- Duplikat.
- Nonaktifkan.
- Hapus.

TARGET DEFAULT

Fields:

- Target langkah harian.
- Target membaca harian.
- Target aktivitas selesai.
- Waktu pengingat jurnal.

Default:

Target langkah:
10.000

Target membaca:
20 halaman

Target aktivitas:
5

Pengingat jurnal:
21.00

--------------------------------------------------
8.4 TAB LIBRARY
--------------------------------------------------

Sections:

1. Kategori Buku.
2. Tag Buku.
3. Preferensi Upload.

KATEGORI BUKU

Data:

- Akuntansi.
- Keuangan.
- Produktivitas.
- Karier.
- Rohani.
- Pengembangan Diri.
- Lainnya.

Columns:

- Nama.
- Jumlah Buku.
- Status.
- Action.

TAG BUKU

Data:

- Kuliah.
- Referensi.
- Favorit.
- Ujian.
- Dibaca Ulang.

PREFERENSI UPLOAD

Fields:

Cover default:

- Gunakan halaman pertama.
- Gunakan cover sistem.
- Tanya setiap upload.

Default category:

Lainnya

Duplicate detection:

Aktif

--------------------------------------------------
8.5 TAB AKUNTANSI
--------------------------------------------------

Sections:

1. Daftar Akun.
2. Periode Akuntansi.
3. Template Jurnal.

DAFTAR AKUN

Columns:

- Kode.
- Nama Akun.
- Tipe.
- Saldo Normal.
- Status.
- Action.

Contoh:

101
Kas
Aset
Debit
Aktif

102
Bank
Aset
Debit
Aktif

201
Utang
Liabilitas
Kredit
Aktif

301
Modal
Ekuitas
Kredit
Aktif

401
Pendapatan
Pendapatan
Kredit
Aktif

501
Beban
Beban
Debit
Aktif

Actions:

- Tambah Akun.
- Edit.
- Nonaktifkan.
- Lihat Penggunaan.

Akun sistem inti tidak boleh dihapus.

PERIODE AKUNTANSI

Fields:

- Tahun aktif.
- Bulan aktif.
- Tanggal awal.
- Tanggal akhir.
- Status periode.

Status:

- Terbuka.
- Dikunci.
- Ditutup.

Jangan izinkan perubahan jurnal pada periode ditutup tanpa proses pembukaan ulang.

TEMPLATE JURNAL

Data:

- Pembelian Tunai.
- Pendapatan Tunai.
- Pembayaran Tagihan.
- Transfer Antar-Akun.

==================================================
9. MODAL PENGELOLAAN DATA
==================================================

Buat reusable modal:

Tambah Data

Variants:

- Tambah Akun.
- Tambah Kategori.
- Tambah Template.
- Tambah Daftar Akun.
- Tambah Tag.

Fields menyesuaikan jenis data.

Buttons:

- Batal.
- Simpan.

Required states:

- Default.
- Validation error.
- Saving.
- Success.
- Duplicate name warning.

Duplicate warning:

Nama tersebut sudah digunakan.

==================================================
10. HALAMAN PENGATURAN NOTIFIKASI
==================================================

FRAME NAME:

FreeSpace/Desktop/Settings/Notifikasi

BREADCRUMB:

Pengaturan > Pengaturan Notifikasi

JUDUL:

Pengaturan Notifikasi

SUBTITLE:

Atur jenis, saluran, dan waktu notifikasi yang ingin Anda terima.

PRIMARY ACTION:

Simpan Perubahan

SECONDARY ACTION:

Kirim Notifikasi Uji

Jangan meletakkan setting notifikasi pada Preferensi.

--------------------------------------------------
10.1 SECTION SALURAN NOTIFIKASI
--------------------------------------------------

Card section:

Saluran Notifikasi

Channels:

Notifikasi dalam Aplikasi

Toggle:
Aktif

Deskripsi:
Ditampilkan melalui ikon lonceng pada topbar.

Notifikasi Browser

Toggle:
Aktif

Status:
Izin diberikan

Email

Toggle:
Aktif

Alamat:
salgadoginting@example.com

Jangan menampilkan email nyata jika tidak tersedia. Gunakan contoh visual.

Options per channel:

- Aktivitas penting saja.
- Semua notifikasi.
- Nonaktif.

--------------------------------------------------
10.2 SECTION JADWAL & MODE TENANG
--------------------------------------------------

Card section:

Jadwal Notifikasi

Mode Tenang

Toggle:
Aktif

Waktu mulai:
22.00

Waktu selesai:
07.00

Hari aktif:
Setiap Hari

Saat mode tenang aktif:

- Notifikasi non-penting ditunda.
- Peringatan keamanan tetap dikirim.
- Deadline mendesak tetap dapat dikirim jika pengguna mengizinkan.

Ringkasan Harian

Toggle:
Aktif

Waktu:
07.30

Ringkasan Mingguan

Toggle:
Aktif

Hari:
Senin

Waktu:
08.00

--------------------------------------------------
10.3 SECTION NOTIFIKASI KEUANGAN
--------------------------------------------------

Card section:

Keuangan

Budget Mendekati Batas

Toggle:
Aktif

Threshold:
80%

Budget Terlampaui

Toggle:
Aktif

Transaksi Berulang

Toggle:
Aktif

Waktu:
1 hari sebelumnya

Jatuh Tempo Utang & Piutang

Toggle:
Aktif

Waktu:
3 hari sebelumnya

Target Keuangan

Toggle:
Aktif

Frekuensi:
Mingguan

Draft Jurnal AI Menunggu Review

Toggle:
Aktif

Laporan Keuangan Selesai Dibentuk

Toggle:
Aktif

--------------------------------------------------
10.4 SECTION NOTIFIKASI PRODUKTIVITAS
--------------------------------------------------

Card section:

Produktivitas

Aktivitas Mendatang

Toggle:
Aktif

Default reminder:
1 hari sebelumnya

Deadline Aktivitas

Toggle:
Aktif

Waktu:
1 hari dan 1 jam sebelumnya

Pengingat Jurnal Harian

Toggle:
Aktif

Waktu:
21.00

Pengingat Bacaan Alkitab

Toggle:
Aktif

Waktu:
06.30

Target Membaca

Toggle:
Aktif

Waktu:
19.00

Target Langkah

Toggle:
Aktif

Waktu:
19.00

Condition:

Kirim hanya jika target belum tercapai.

--------------------------------------------------
10.5 SECTION NOTIFIKASI LIBRARY & KARIER
--------------------------------------------------

Card section:

Library & Karier

Rencana Membaca

Toggle:
Aktif

Buku Belum Dilanjutkan

Toggle:
Aktif

Frekuensi:
7 hari tanpa aktivitas

Jadwal Latihan TOEFL

Toggle:
Aktif

Jadwal Simulasi Interview

Toggle:
Aktif

Hasil Analisis ATS

Toggle:
Aktif

--------------------------------------------------
10.6 SECTION SISTEM & KEAMANAN
--------------------------------------------------

Card section:

Sistem & Keamanan

Login dari Perangkat Baru

Toggle:
Aktif dan tidak dapat dinonaktifkan sepenuhnya

Percobaan Login Gagal

Toggle:
Aktif

Backup Berhasil

Toggle:
Tidak Aktif

Backup Gagal

Toggle:
Aktif

Restore Data Selesai

Toggle:
Aktif

Pembaruan FreeSpace

Toggle:
Aktif

--------------------------------------------------
10.7 NOTIFIKASI UJI
--------------------------------------------------

Button:

Kirim Notifikasi Uji

Membuka modal.

Fields:

- Saluran.
- Jenis notifikasi.

Saluran:

- Dalam Aplikasi.
- Browser.
- Email.

Buttons:

- Batal.
- Kirim Uji.

Success toast:

Notifikasi uji berhasil dikirim.

Error:

Notifikasi browser belum diizinkan.

Action:

Izinkan Notifikasi Browser

==================================================
11. HALAMAN KEAMANAN & DATA
==================================================

FRAME NAME:

FreeSpace/Desktop/Settings/SecurityData

BREADCRUMB:

Pengaturan > Keamanan & Data

JUDUL:

Keamanan & Data

SUBTITLE:

Kelola keamanan akun, sesi aktif, backup, serta data pribadi Anda.

Jangan membuat submenu tambahan di sidebar.

Gunakan internal tabs:

- Keamanan
- Sesi Aktif
- Backup & Restore
- Import & Export
- Zona Berbahaya

Default active:
Keamanan

--------------------------------------------------
11.1 TAB KEAMANAN
--------------------------------------------------

SECTION PASSWORD

Judul:
Password

Tampilkan:

Terakhir diubah:
18 Juni 2026

Button:
Ubah Password

Modal fields:

- Password saat ini.
- Password baru.
- Konfirmasi password baru.

Password requirements:

- Minimal 12 karakter.
- Mengandung huruf besar.
- Mengandung huruf kecil.
- Mengandung angka.
- Mengandung simbol.

Gunakan password strength indicator.

SECTION TWO-FACTOR AUTHENTICATION

Status:
Aktif

Method:
Authenticator App

Actions:

- Lihat Recovery Codes.
- Buat Ulang Recovery Codes.
- Nonaktifkan 2FA.

Nonaktifkan 2FA membutuhkan:

- Password.
- Kode autentikasi.

SECTION LOGIN PROTECTION

Options:

Notifikasi login perangkat baru:
Aktif

Blokir sementara setelah login gagal:
Aktif

Session timeout:
8 jam

Remember this device:
30 hari

--------------------------------------------------
11.2 TAB SESI AKTIF
--------------------------------------------------

Summary:

Sesi aktif:
2 perangkat

Table atau device cards:

1.

Perangkat:
Windows Laptop

Browser:
Chrome

Lokasi:
Jakarta, Indonesia

IP:
10.0.1.45

Terakhir aktif:
Sekarang

Status:
Perangkat Saat Ini

2.

Perangkat:
iPad

Browser:
Safari

Lokasi:
Jakarta, Indonesia

IP:
10.0.1.20

Terakhir aktif:
2 Jul 2026, 20.35

Status:
Aktif

Actions:

- Keluar dari Sesi.
- Tandai Bukan Saya.

Global action:

Keluar dari Semua Perangkat Lain

Gunakan confirmation modal.

--------------------------------------------------
11.3 TAB BACKUP & RESTORE
--------------------------------------------------

Summary cards:

CARD 1

Label:
Backup Otomatis

Value:
Aktif

Description:
Berjalan setiap hari pukul 02.00

CARD 2

Label:
Backup Terakhir

Value:
3 Jul 2026

Description:
Pukul 02.00

CARD 3

Label:
Ukuran Backup

Value:
48,6 MB

Description:
Database dan file metadata

CARD 4

Label:
Status

Value:
Berhasil

Description:
Tidak ada masalah ditemukan

AUTOMATIC BACKUP SETTINGS

Fields:

Backup otomatis:
Aktif

Frekuensi:

- Harian.
- Mingguan.
- Bulanan.

Default:
Harian

Waktu:
02.00

Retensi:

- Simpan 7 backup terakhir.
- Simpan 14 backup terakhir.
- Simpan 30 backup terakhir.

Default:
14

Isi backup:

- Data aplikasi.
- Pengaturan.
- Catatan.
- Metadata file.
- File upload.

Gunakan informasi ruang penyimpanan jika tersedia.

MANUAL BACKUP

Button:
Buat Backup Sekarang

States:

- Preparing.
- Processing.
- Compressing.
- Completed.
- Failed.

Success:

Backup berhasil dibuat.

BACKUP HISTORY

Columns:

- Tanggal.
- Jenis.
- Ukuran.
- Isi.
- Status.
- Action.

Actions:

- Download.
- Restore.
- Hapus.

RESTORE FLOW

Restore harus menggunakan modal bertahap.

Step 1:
Pilih backup.

Step 2:
Tampilkan detail backup.

Step 3:
Peringatan data saat ini akan diganti.

Step 4:
Masukkan password.

Step 5:
Konfirmasi Restore.

Tambahkan checkbox:

Saya memahami bahwa data saat ini dapat diganti oleh isi backup.

Jangan membuat restore berjalan hanya dengan satu klik.

--------------------------------------------------
11.4 TAB IMPORT & EXPORT
--------------------------------------------------

EXPORT PERSONAL DATA

Judul:
Export Data FreeSpace

Pilihan modul:

- Semua Data.
- Keuangan.
- Produktivitas.
- Library.
- Karier.
- History.
- Pengaturan.

Format:

- ZIP.
- JSON.
- CSV.
- Excel.

Pilihan:

Sertakan file upload

Toggle:
Aktif

Button:
Buat File Export

State:

- Preparing.
- Ready to Download.
- Expired.

Tampilkan expiry:

File export tersedia selama 24 jam.

IMPORT DATA

Judul:
Import Data

Format yang diterima:

- CSV.
- Excel.
- JSON.
- ZIP backup FreeSpace.

Flow:

1. Pilih file.
2. Validasi file.
3. Mapping kolom jika diperlukan.
4. Preview data.
5. Pilih mode import.
6. Konfirmasi.

Mode import:

- Tambahkan data baru.
- Perbarui data yang sesuai.
- Lewati data duplikat.

Jangan langsung memasukkan data tanpa preview.

Validation result:

- Valid rows.
- Invalid rows.
- Duplicate rows.
- Missing fields.

Actions:

- Download Error Report.
- Perbaiki Mapping.
- Mulai Import.

--------------------------------------------------
11.5 TAB ZONA BERBAHAYA
--------------------------------------------------

Gunakan card dengan border danger yang tetap mengikuti visual language existing.

SECTION HAPUS DATA MODUL

Judul:
Hapus Data Modul

Description:
Menghapus seluruh data pada modul tertentu tanpa menghapus akun.

Module options:

- Keuangan.
- Produktivitas.
- Library.
- Karier.
- History.

Button:
Pilih Data untuk Dihapus

Flow:

- Pilih modul.
- Tampilkan jumlah data terdampak.
- Masukkan password.
- Ketik nama modul sebagai konfirmasi.
- Hapus Permanen.

SECTION RESET FREESPACE

Judul:
Reset FreeSpace

Description:
Menghapus seluruh data pengguna dan mengembalikan aplikasi seperti baru.

Button:
Reset Seluruh Data

Requirement:

Pengguna harus mengetik:

RESET FREESPACE

SECTION HAPUS AKUN

Judul:
Hapus Akun

Description:
Menghapus akun, data, file, catatan, dan pengaturan secara permanen.

Button:
Hapus Akun

Confirmation requires:

- Password.
- Kode 2FA jika aktif.
- Ketik HAPUS AKUN.
- Checkbox persetujuan.
- Final confirmation modal.

Jangan menggunakan destructive action tanpa konfirmasi berlapis.

==================================================
12. PROFILE CARD BEHAVIOR
==================================================

Profile card di kiri atas tetap dipertahankan.

Click profile card membuka halaman atau dropdown Profil.

Dropdown dapat berisi:

- Lihat Profil.
- Edit Profil.
- Pengaturan.
- Keluar.

Jangan menambahkan submenu Profil pada Pengaturan.

Jangan memindahkan profile card ke topbar.

==================================================
13. EMPTY STATES
==================================================

HISTORY EMPTY

Title:
Belum ada aktivitas

Description:
Aktivitas yang Anda lakukan di FreeSpace akan muncul di sini.

Jangan menampilkan CTA yang tidak diperlukan.

PERUBAHAN DATA EMPTY

Title:
Belum ada perubahan data

Description:
Perubahan tambah, edit, atau hapus akan dicatat secara otomatis.

AKTIVITAS AI EMPTY

Title:
Belum ada aktivitas AI

Description:
Riwayat penggunaan bantuan AI akan muncul setelah Anda menggunakan fitur AI.

LOGIN EMPTY

Title:
Belum ada riwayat login

Description:
Riwayat login akan muncul setelah akun digunakan pada perangkat.

BACKUP EMPTY

Title:
Belum ada backup

Description:
Buat backup pertama untuk melindungi data FreeSpace Anda.

Action:
Buat Backup

IMPORT EMPTY

Title:
Belum ada proses import

Description:
Upload file untuk mulai mengimpor data.

==================================================
14. LOADING, ERROR, DAN SUCCESS STATES
==================================================

Loading:

- Skeleton summary cards.
- Skeleton table.
- Settings saving indicator.
- Backup progress.
- Restore progress.
- Export preparing.
- Import validation.

Errors:

- History gagal dimuat.
- Pengaturan gagal disimpan.
- Backup gagal dibuat.
- Restore gagal.
- File import tidak valid.
- Export gagal dibuat.
- Password salah.
- Kode 2FA tidak valid.
- Sesi gagal dikeluarkan.
- Notifikasi uji gagal dikirim.

Success toast:

- Pengaturan berhasil disimpan.
- Preferensi berhasil diperbarui.
- Notifikasi uji berhasil dikirim.
- Backup berhasil dibuat.
- Restore berhasil diselesaikan.
- Export berhasil dibuat.
- Import berhasil diselesaikan.
- Password berhasil diubah.
- Sesi berhasil dikeluarkan.
- Data berhasil dihapus.

==================================================
15. REUSABLE COMPONENTS
==================================================

Buat atau rapikan components berikut.

HISTORY

- History/SummaryCard.
- History/Tab.
- History/ActivityBadge.
- History/StatusBadge.
- History/TableRow.
- History/ChangeComparison.
- History/DetailDrawer.
- History/ExportModal.

SETTINGS

- Settings/SectionCard.
- Settings/SectionHeader.
- Settings/Row.
- Settings/ToggleRow.
- Settings/SelectRow.
- Settings/RadioGroup.
- Settings/SegmentedControl.
- Settings/UnsavedIndicator.
- Settings/SaveBar.

DATA SETTINGS

- DataSettings/Table.
- DataSettings/CategoryRow.
- DataSettings/AccountRow.
- DataSettings/TemplateCard.
- DataSettings/Modal.

SECURITY

- Security/DeviceCard.
- Security/SessionRow.
- Security/PasswordStrength.
- Security/TwoFactorCard.
- Security/SecurityStatus.

BACKUP

- Backup/SummaryCard.
- Backup/HistoryRow.
- Backup/Progress.
- Backup/RestoreStepper.
- Backup/StatusBadge.

IMPORT EXPORT

- DataTransfer/Dropzone.
- DataTransfer/MappingTable.
- DataTransfer/ValidationSummary.
- DataTransfer/Progress.

GLOBAL

- Tabs/Primary.
- SearchInput.
- Select.
- Toggle.
- Radio.
- Checkbox.
- Input/Text.
- Input/Password.
- Input/Time.
- Modal/Form.
- Modal/Confirm.
- Modal/Destructive.
- Drawer/Detail.
- Table/Header.
- Table/Row.
- Badge/Positive.
- Badge/Warning.
- Badge/Danger.
- Badge/Neutral.
- Toast/Success.
- Toast/Error.
- Alert/Info.
- Alert/Warning.
- Alert/Danger.

Gunakan component variants dan existing design tokens.

Jangan membuat style duplikat secara manual.

==================================================
16. REQUIRED COMPONENT STATES
==================================================

Buat state:

- Default.
- Hover.
- Focus.
- Active.
- Selected.
- Disabled.
- Loading.
- Empty.
- Error.
- Success.
- Saving.
- Saved.
- Unsaved.
- Enabled.
- Disabled.
- Connected.
- Not Connected.
- Processing.
- Completed.
- Failed.
- Warning.
- Destructive Confirmation.

History status:

- Berhasil.
- Gagal.
- Dibatalkan.
- Menunggu.

Backup status:

- Diproses.
- Berhasil.
- Gagal.
- Kedaluwarsa.

Session status:

- Perangkat Saat Ini.
- Aktif.
- Kedaluwarsa.
- Dikeluarkan.

==================================================
17. PROTOTYPE INTERACTIONS
==================================================

SIDEBAR

- History menuju halaman History.
- Preferensi menuju halaman Preferensi.
- Pengaturan Data menuju halaman Pengaturan Data.
- Pengaturan Notifikasi menuju halaman Pengaturan Notifikasi.
- Keamanan & Data menuju halaman Keamanan & Data.

HISTORY

- Tab berpindah state.
- Filter mengubah tabel.
- Click row membuka detail drawer.
- Unduh History membuka modal.
- Tandai Bukan Saya membuka security modal.
- Keluar dari Perangkat membuka confirmation.

PREFERENSI

- Theme selector mengubah preview.
- Toggle dapat diubah.
- Simpan menampilkan success toast.
- Reset membuka confirmation.

PENGATURAN DATA

- Tabs berpindah modul.
- Tambah data membuka modal.
- Edit membuka populated modal.
- Delete membuka confirmation.
- Nonaktifkan mengubah status.
- Merge category membuka mapping modal.

NOTIFIKASI

- Toggle dapat diubah.
- Quiet hours menampilkan time input.
- Notification test membuka modal.
- Save menampilkan toast.

KEAMANAN & DATA

- Ubah Password membuka modal.
- 2FA membuka configuration flow.
- Device action membuka confirmation.
- Backup manual menampilkan progress.
- Restore membuka stepper.
- Export menampilkan preparing state.
- Import menggunakan multi-step flow.
- Destructive actions membutuhkan typed confirmation.

Gunakan Smart Animate:

150–250 ms

Jangan menggunakan animasi dekoratif berlebihan.

==================================================
18. RESPONSIVE DESIGN
==================================================

Buat responsive layout untuk:

1. Desktop atau laptop.
2. iPad landscape.
3. iPad portrait.

DESKTOP

- Sidebar fixed.
- Topbar fixed sesuai design existing.
- Summary cards dapat lima kolom jika ruang cukup.
- Settings card full-width.
- Table full-width.

IPAD LANDSCAPE

- Summary cards berubah menjadi tiga dan dua kolom.
- Filter dapat wrap.
- Table menggunakan horizontal scroll.
- Settings row tetap mempertahankan label dan control.

IPAD PORTRAIT

- Sidebar menjadi off-canvas drawer.
- Summary cards dua kolom.
- History filter masuk filter drawer.
- History table dapat menjadi activity cards.
- Settings controls ditumpuk di bawah label.
- Button save tetap mudah ditemukan.
- Modal besar menjadi full-screen sheet.
- Restore stepper menjadi vertical.
- Device cards menjadi satu kolom.

Jangan membuat bottom navigation baru.

==================================================
19. ACCESSIBILITY
==================================================

Pastikan:

- Area klik minimal 40–44 px.
- Form memiliki label.
- Toggle memiliki label dan deskripsi.
- Status tidak hanya menggunakan warna.
- Icon-only button memiliki tooltip.
- Focus state terlihat.
- Table header mudah dibedakan.
- Filter dapat digunakan dengan keyboard.
- Tab memiliki active indicator jelas.
- Password strength memiliki teks.
- Destructive action memiliki peringatan jelas.
- Text confirmation mudah dipahami.
- Contrast memadai.
- Setting tidak hanya bergantung pada icon.
- Tema gelap memiliki contrast yang cukup.
- Error ditampilkan dekat field.
- Data sensitif disamarkan.

==================================================
20. FIGMA FILE ORGANIZATION
==================================================

Gunakan section atau page:

01 — Foundations
02 — Components
03 — Dashboard
04 — Keuangan
05 — Produktivitas
06 — Library
07 — Karier
08 — System
09 — Responsive
10 — Prototype

Frame names:

FreeSpace/Desktop/System/History-All
FreeSpace/Desktop/System/History-Changes
FreeSpace/Desktop/System/History-AI
FreeSpace/Desktop/System/History-Security

FreeSpace/Desktop/Settings/Preferensi
FreeSpace/Desktop/Settings/PengaturanData-Keuangan
FreeSpace/Desktop/Settings/PengaturanData-Produktivitas
FreeSpace/Desktop/Settings/PengaturanData-Library
FreeSpace/Desktop/Settings/PengaturanData-Akuntansi
FreeSpace/Desktop/Settings/Notifikasi
FreeSpace/Desktop/Settings/Security
FreeSpace/Desktop/Settings/Sessions
FreeSpace/Desktop/Settings/Backup
FreeSpace/Desktop/Settings/ImportExport
FreeSpace/Desktop/Settings/DangerZone

Overlay names:

FreeSpace/Overlay/History/Detail
FreeSpace/Overlay/History/Export
FreeSpace/Overlay/History/UnknownLogin
FreeSpace/Overlay/Settings/EditData
FreeSpace/Overlay/Settings/TestNotification
FreeSpace/Overlay/Security/ChangePassword
FreeSpace/Overlay/Security/TwoFactor
FreeSpace/Overlay/Security/LogoutSession
FreeSpace/Overlay/Backup/Restore
FreeSpace/Overlay/Data/Import
FreeSpace/Overlay/Data/Export
FreeSpace/Overlay/Data/DeleteModule
FreeSpace/Overlay/Data/Reset
FreeSpace/Overlay/Data/DeleteAccount

Jangan menggunakan nama layer:

- Frame 1.
- Group 12.
- Rectangle 43.
- Copy.
- New Component.

Gunakan descriptive layer naming.

==================================================
21. EXECUTION PRIORITY
==================================================

Kerjakan dengan urutan berikut:

PHASE 1

1. History — Semua Aktivitas.
2. History — Perubahan Data.
3. History — Aktivitas AI.
4. History — Login & Keamanan.
5. Detail drawer dan export modal.

PHASE 2

6. Perbaiki Preferensi.
7. Hapus pengaturan notifikasi dari Preferensi.
8. Hapus seluruh istilah aset.

PHASE 3

9. Pengaturan Data — Keuangan.
10. Pengaturan Data — Produktivitas.
11. Pengaturan Data — Library.
12. Pengaturan Data — Akuntansi.
13. Modal tambah dan edit.

PHASE 4

14. Pengaturan Notifikasi.
15. Notification test.
16. Quiet hours.

PHASE 5

17. Keamanan.
18. Sesi Aktif.
19. Backup & Restore.
20. Import & Export.
21. Zona Berbahaya.

Gunakan komponen existing dan reusable component secara konsisten.

Jangan berhenti setelah menyelesaikan halaman History saja.

==================================================
22. ACCEPTANCE CHECKLIST
==================================================

HISTORY

[ ] Judul halaman menjadi History.
[ ] Subtitle sudah sesuai FreeSpace.
[ ] Tidak ada istilah aset.
[ ] Tidak ada multi-user.
[ ] Tidak ada role.
[ ] Tidak ada Admin Sistem.
[ ] Tidak ada Operator Aset.
[ ] Tidak ada filter pengguna.
[ ] Tidak ada filter role.
[ ] Tabs History tersedia.
[ ] Filter modul tersedia.
[ ] Tabel aktivitas tersedia.
[ ] Detail drawer tersedia.
[ ] Export tersedia.
[ ] Informasi IP hanya muncul pada Login & Keamanan.

PREFERENSI

[ ] Hanya berisi preferensi pengalaman penggunaan.
[ ] Tema tersedia.
[ ] Kepadatan tampilan tersedia.
[ ] Bahasa tersedia.
[ ] Mata uang tersedia.
[ ] Format tanggal tersedia.
[ ] Zona waktu tersedia.
[ ] Aksesibilitas tersedia.
[ ] Pengaturan notifikasi tidak berada di Preferensi.
[ ] Tidak ada istilah tabel aset.
[ ] Save dan reset tersedia.

PENGATURAN DATA

[ ] Tabs Keuangan tersedia.
[ ] Tabs Produktivitas tersedia.
[ ] Tabs Library tersedia.
[ ] Tabs Akuntansi tersedia.
[ ] Akun dan sumber dana tersedia.
[ ] Kategori transaksi tersedia.
[ ] Kategori aktivitas tersedia.
[ ] Template jurnal tersedia.
[ ] Kategori buku tersedia.
[ ] Daftar akun tersedia.
[ ] Modal tambah dan edit tersedia.
[ ] Data yang sudah digunakan tidak dapat dihapus sembarangan.

PENGATURAN NOTIFIKASI

[ ] Saluran notifikasi tersedia.
[ ] Mode tenang tersedia.
[ ] Ringkasan harian tersedia.
[ ] Keuangan tersedia.
[ ] Produktivitas tersedia.
[ ] Library dan Karier tersedia.
[ ] Keamanan tersedia.
[ ] Notification test tersedia.
[ ] Notification inbox tetap di topbar.

KEAMANAN & DATA

[ ] Password tersedia.
[ ] Two-factor authentication tersedia.
[ ] Sesi aktif tersedia.
[ ] Keluar perangkat tersedia.
[ ] Backup otomatis tersedia.
[ ] Backup manual tersedia.
[ ] Restore menggunakan stepper.
[ ] Import memiliki preview.
[ ] Export tersedia.
[ ] Hapus data modul tersedia.
[ ] Reset tersedia.
[ ] Hapus akun tersedia.
[ ] Destructive action membutuhkan konfirmasi berlapis.

VISUAL

[ ] Topbar tidak berubah.
[ ] Sidebar tidak berubah.
[ ] Profile card tetap sama.
[ ] Typography konsisten.
[ ] Card style konsisten.
[ ] Table style konsisten.
[ ] Form style konsisten.
[ ] Tidak ada visual language baru.
[ ] Tidak ada hierarchy sidebar level 3.
[ ] Tidak ada Dashboard baru.

==================================================
23. FINAL EXECUTION INSTRUCTION
==================================================

Mulai dengan mengedit halaman History yang sedang aktif.

Ganti seluruh isi lama yang masih berhubungan dengan Manajemen Aset menjadi History personal FreeSpace.

Setelah itu:

1. Perbaiki halaman Preferensi.
2. Pisahkan seluruh setting notifikasi ke halaman Pengaturan Notifikasi.
3. Buat Pengaturan Data.
4. Buat Keamanan & Data.
5. Buat seluruh modal, drawer, state, dan prototype interactions.

Jangan membuat konsep alternatif.

Jangan membuat moodboard.

Jangan membuat low-fidelity wireframe.

Jangan mengubah sidebar.

Jangan mengubah topbar.

Jangan menambahkan role atau user management.

Jangan menambahkan submenu baru.

Jangan menjadikan internal tabs sebagai submenu sidebar.

Gunakan bahasa Indonesia yang natural.

Gunakan format tanggal dan waktu Indonesia.

Gunakan data simulasi yang konsisten.

Hasil akhir harus terlihat sebagai kelanjutan langsung dari desain FreeSpace yang sekarang, bukan aplikasi yang berbeda.