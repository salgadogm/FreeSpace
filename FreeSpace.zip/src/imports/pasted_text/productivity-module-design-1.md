ROLE AND EXECUTION MODE

Anda adalah Senior Product Designer, UX Architect, Productivity Application Designer, Interaction Designer, dan Figma Design-System Specialist.

Edit langsung desain FreeSpace yang SUDAH ADA pada file Figma ini.

Kondisi desain saat ini:

1. Branding telah menjadi “FreeSpace – Personal Workspace”.
2. Sidebar, topbar, profile card, search, Tanya AI, notifikasi, dan share sudah tersedia.
3. Parent menu Produktivitas sudah tersedia dan dapat diperluas.
4. Submenu Produktivitas sudah terdiri dari:
   - Aktivitas
   - Jurnal Harian
   - Bible Harian
   - Steps Tracker
5. Halaman Aktivitas masih berupa placeholder “Segera Hadir”.
6. Halaman Produktivitas lainnya belum memiliki konten lengkap.
7. Visual language dan komponen dasar FreeSpace sudah tersedia dari Dashboard dan modul Keuangan.

Tugas Anda sekarang adalah:

1. Menghapus seluruh placeholder pada modul Produktivitas.
2. Mendesain dan mengeksekusi halaman Aktivitas.
3. Mendesain dan mengeksekusi halaman Jurnal Harian.
4. Mendesain dan mengeksekusi halaman Bible Harian.
5. Mendesain dan mengeksekusi halaman Steps Tracker.
6. Membuat reusable components, variants, states, dan prototype interactions.
7. Menggunakan komponen dan visual pattern yang sudah tersedia.
8. Mempertahankan layout, visual identity, dan information architecture yang sudah disetujui.

Jangan hanya menghasilkan wireframe, penjelasan, atau konsep.

Eksekusi desain final dalam bentuk high-fidelity UI menggunakan:

- Frame.
- Component.
- Component variants.
- Auto Layout.
- Variables.
- Constraints.
- Prototype links.
- Overlay.
- Modal.
- Drawer.
- Responsive states.

==================================================
1. PRINSIP UTAMA PRODUKTIVITAS
==================================================

Modul Produktivitas digunakan oleh satu pengguna untuk mengelola aktivitas pribadi, menulis jurnal harian, membaca dan merefleksikan Alkitab, serta mencatat jumlah langkah harian.

Struktur sidebar tetap:

Produktivitas
- Aktivitas
- Jurnal Harian
- Bible Harian
- Steps Tracker

Tidak boleh menambahkan submenu tingkat ketiga pada sidebar.

Fungsi detail harus ditempatkan sebagai:

- Tabs.
- Segmented controls.
- Filters.
- Calendar views.
- Page sections.
- Form.
- Modal.
- Drawer.
- Dropdown.
- Toolbar.

Jangan membuat:

- Dashboard Produktivitas.
- Dashboard Aktivitas.
- Dashboard Jurnal.
- Dashboard Bible.
- Dashboard Steps.
- Menu Analytics Produktivitas.
- Submenu Daftar Aktivitas.
- Submenu Kalender.
- Submenu Aktivitas Selesai.
- Submenu Tulis Jurnal.
- Submenu Riwayat Jurnal.
- Submenu Baca Alkitab.
- Submenu Riwayat Bacaan.
- Submenu Input Langkah.
- Submenu Riwayat Langkah.

Dashboard global tetap menjadi satu-satunya Dashboard dalam aplikasi.

==================================================
2. PERTAHANKAN DESAIN EXISTING
==================================================

Pertahankan sepenuhnya:

- Lebar dan posisi sidebar.
- Tinggi dan posisi topbar.
- Logo FreeSpace.
- Subtitle Personal Workspace.
- Profile card di kiri atas.
- Search field.
- Shortcut indicator pada search.
- Tombol Tanya AI.
- Notification button dan badge.
- Share button.
- Background aplikasi.
- Page padding.
- Grid.
- Typography.
- Font family.
- Font size hierarchy.
- Warna utama.
- Warna status.
- Icon style.
- Border.
- Border radius.
- Shadow.
- Card style.
- Table style.
- Form style.
- Breadcrumb style.
- Active state sidebar.
- Hover state sidebar.
- Spacing system.
- Existing design tokens.

Jangan:

- Membuat visual language baru.
- Mengganti font.
- Membuat gradient baru.
- Memperbesar sidebar.
- Memindahkan profile card.
- Mengubah topbar.
- Membuat floating navigation.
- Membuat bottom navigation desktop.
- Menambahkan ilustrasi dekoratif berlebihan.
- Menggunakan warna baru tanpa alasan.
- Membuat tampilan seperti aplikasi enterprise.
- Membuat konten terlalu padat.
- Mengubah tampilan menjadi dark mode pada frame utama.
- Menggunakan card dengan style berbeda dari Dashboard dan Keuangan.

==================================================
3. DATA SIMULASI YANG KONSISTEN
==================================================

Gunakan konteks tanggal:

Hari:
Jumat

Tanggal:
3 Juli 2026

Agenda hari ini:
5 aktivitas

Aktivitas selesai:
2 aktivitas

Aktivitas belum selesai:
3 aktivitas

Deadline mendesak:
1 aktivitas

Aktivitas berulang aktif:
4 aktivitas

Jurnal harian hari ini:
Belum diisi

Streak jurnal:
6 hari

Progress bacaan Alkitab:
12 hari konsisten

Bacaan hari ini:
Mazmur 23

Catatan bacaan:
1 draft refleksi

Target langkah harian:
10.000 langkah

Langkah hari ini:
7.420 langkah

Progress langkah:
74,2%

Rata-rata langkah tujuh hari:
7.865 langkah

Streak target langkah:
4 hari

Gunakan data tersebut secara konsisten di seluruh halaman Produktivitas dan Dashboard global.

==================================================
4. GLOBAL PAGE TEMPLATE
==================================================

Gunakan template yang konsisten pada semua halaman Produktivitas.

Struktur:

Topbar
Breadcrumb
Page header
- Judul halaman
- Subtitle
- Primary action
- Secondary action jika diperlukan
Content area
- Summary cards jika relevan
- Tabs atau segmented control
- Filter toolbar
- Main content
- Table, calendar, editor, reader, atau chart
Optional modal atau drawer

Gunakan maksimal:

- Satu primary action utama per halaman.
- Satu atau dua secondary actions.
- Empat summary cards dalam satu baris.
- Empat sampai lima filter utama.
- Lima sampai sepuluh row pada initial viewport.
- Tiga sampai empat section besar dalam satu halaman.

Jangan memenuhi halaman dengan terlalu banyak card kecil.

==================================================
5. SIDEBAR DAN ACTIVE STATE
==================================================

Untuk seluruh frame Produktivitas:

- Parent Produktivitas harus expanded.
- Keuangan collapsed.
- Library collapsed.
- Karier collapsed.
- Pengaturan collapsed.

Buat active state berikut:

1. Produktivitas expanded dan Aktivitas aktif.
2. Produktivitas expanded dan Jurnal Harian aktif.
3. Produktivitas expanded dan Bible Harian aktif.
4. Produktivitas expanded dan Steps Tracker aktif.

Pertahankan:

- Parent icon.
- Child dot indicator.
- Indentation.
- Chevron.
- Active child background.
- Parent active state.
- Item height.
- Spacing.
- Font weight.
- Border radius.

Hanya satu child aktif pada satu waktu.

==================================================
6. HALAMAN AKTIVITAS
==================================================

FRAME NAME:

FreeSpace/Desktop/Produktivitas/Aktivitas

Hapus seluruh placeholder:

- Segera Hadir.
- Fitur Aktivitas sedang dalam pengembangan.
- Loading dots.
- Empty development state.

BREADCRUMB:

Produktivitas > Aktivitas

JUDUL:

Aktivitas

SUBTITLE:

Kelola jadwal, prioritas, dan aktivitas harian Anda.

PRIMARY ACTION:

Tambah Aktivitas

Icon:
Plus

SECONDARY ACTION:

Atur Kategori

Icon:
Tag atau Adjustments

--------------------------------------------------
6.1 SUMMARY CARDS AKTIVITAS
--------------------------------------------------

Buat empat summary cards dalam satu baris.

CARD 1

Label:
Agenda Hari Ini

Value:
5

Description:
2 aktivitas telah selesai

Status:
Primary

CARD 2

Label:
Belum Selesai

Value:
3

Description:
Masih perlu diselesaikan hari ini

Status:
Warning

CARD 3

Label:
Deadline Terdekat

Value:
Besok

Description:
Tugas Akuntansi Keuangan

Status:
Danger

CARD 4

Label:
Aktivitas Berulang

Value:
4

Description:
Aktif pada minggu ini

Status:
Neutral atau secondary

Gunakan card style yang sama dengan Dashboard dan modul Keuangan.

--------------------------------------------------
6.2 INTERNAL VIEW NAVIGATION
--------------------------------------------------

Buat tabs atau segmented control:

- Daftar
- Kalender
- Selesai

Default active:
Daftar

Jangan menjadikan ketiga view ini sebagai submenu sidebar.

Tambahkan view switcher jika sesuai:

- List view.
- Compact view.

--------------------------------------------------
6.3 FILTER TOOLBAR
--------------------------------------------------

Gunakan filter toolbar dengan komponen:

- Search aktivitas.
- Filter tanggal.
- Filter kategori.
- Filter prioritas.
- Filter status.
- Tombol Reset.

Default:

Tanggal:
Hari Ini

Kategori:
Semua Kategori

Prioritas:
Semua Prioritas

Status:
Semua Status

Search placeholder:

Cari aktivitas...

--------------------------------------------------
6.4 TAB DAFTAR
--------------------------------------------------

Gunakan kombinasi section berdasarkan waktu.

SECTION:

Pagi

Aktivitas:

1.
Review materi Akuntansi Keuangan
09.00–10.00
Kategori: Belajar
Prioritas: Tinggi
Status: Berjalan

2.
Mengerjakan latihan TOEFL
11.00–12.00
Kategori: Belajar
Prioritas: Sedang
Status: Belum Mulai

SECTION:

Sore

3.
Input pengeluaran harian
17.00–17.15
Kategori: Keuangan
Prioritas: Tinggi
Status: Belum Mulai

SECTION:

Malam

4.
Membaca buku 20 halaman
19.00–20.00
Kategori: Membaca
Prioritas: Sedang
Status: Belum Mulai

5.
Tulis jurnal harian
21.00–21.20
Kategori: Jurnal
Prioritas: Rendah
Status: Belum Mulai

Setiap item aktivitas harus menampilkan:

- Checkbox selesai.
- Judul.
- Waktu.
- Kategori.
- Priority badge.
- Recurring icon jika berulang.
- Reminder icon jika pengingat aktif.
- Status.
- More action menu.

Action menu:

- Lihat Detail.
- Edit.
- Tandai Selesai.
- Duplikat.
- Jadwalkan Ulang.
- Hapus.

Gunakan drag handle jika SortableJS pattern akan digunakan.

Jangan membuat tampilan seperti tabel keuangan jika list card lebih cocok dengan desain existing.

--------------------------------------------------
6.5 TAB KALENDER
--------------------------------------------------

Gunakan FullCalendar-style layout yang tetap konsisten dengan visual FreeSpace.

Buat controls:

- Hari.
- Minggu.
- Bulan.
- Hari Ini.
- Previous.
- Next.

Default view:
Minggu

Gunakan minggu:

29 Juni–5 Juli 2026

Tampilkan aktivitas sesuai waktu:

- Review materi Akuntansi Keuangan.
- Latihan TOEFL.
- Input pengeluaran harian.
- Membaca buku.
- Jurnal harian.

Gunakan warna berdasarkan kategori secara halus:

- Belajar.
- Keuangan.
- Membaca.
- Jurnal.
- Pribadi.

Gunakan warna design system existing.

Jangan menggunakan terlalu banyak warna mencolok.

Interaksi:

- Click event membuka detail drawer.
- Drag and drop mengubah jadwal.
- Resize event mengubah durasi.
- Click slot kosong membuka modal Tambah Aktivitas dengan waktu terisi otomatis.

--------------------------------------------------
6.6 TAB SELESAI
--------------------------------------------------

Tampilkan aktivitas yang telah diselesaikan.

Filter:

- Hari Ini.
- Minggu Ini.
- Bulan Ini.
- Custom.

Data contoh:

1.
Sarapan dan persiapan kuliah
07.00
Selesai 07.40

2.
Merapikan catatan kuliah
08.00
Selesai 08.35

3.
Review transaksi kemarin
2 Jul 2026
Selesai

Tampilkan:

- Completion time.
- Original schedule.
- Category.
- Restore action.
- Delete permanently melalui confirmation modal.

--------------------------------------------------
6.7 MODAL TAMBAH AKTIVITAS
--------------------------------------------------

Buat modal atau right-side drawer.

Judul:
Tambah Aktivitas

Fields:

- Nama aktivitas.
- Deskripsi.
- Tanggal.
- Waktu mulai.
- Waktu selesai.
- All-day toggle.
- Kategori.
- Prioritas.
- Status awal.
- Pengingat.
- Aktivitas berulang.
- Catatan tambahan.

Pilihan prioritas:

- Rendah.
- Sedang.
- Tinggi.

Pilihan pengingat:

- Saat kegiatan dimulai.
- 10 menit sebelumnya.
- 30 menit sebelumnya.
- 1 jam sebelumnya.
- 1 hari sebelumnya.
- Custom.

Default pengingat untuk aktivitas penting:
1 hari sebelumnya

Aktivitas berulang:

Toggle:
Ulangi Aktivitas

Frekuensi:

- Harian.
- Mingguan.
- Bulanan.
- Custom.

Fields tambahan:

- Interval.
- Hari pengulangan.
- Tanggal berakhir.
- Tidak pernah berakhir.

Buttons:

- Batal.
- Simpan Aktivitas.

Validasi:

- Nama aktivitas wajib.
- Tanggal wajib.
- Waktu selesai tidak boleh lebih awal dari waktu mulai.
- Tanggal selesai tidak boleh lebih awal dari tanggal mulai.
- Reminder harus berada sebelum waktu aktivitas.
- Minimal satu hari dipilih untuk pengulangan mingguan.

Buat state:

- Default.
- Validation error.
- Saving.
- Success.
- Conflict warning.

Conflict warning:

“Waktu aktivitas bertabrakan dengan jadwal lain.”

Pilihan:

- Tetap Simpan.
- Ubah Waktu.

--------------------------------------------------
6.8 DETAIL DRAWER AKTIVITAS
--------------------------------------------------

Buat right-side detail drawer.

Tampilkan:

- Judul aktivitas.
- Status.
- Tanggal.
- Waktu.
- Durasi.
- Kategori.
- Prioritas.
- Reminder.
- Repeat pattern.
- Deskripsi.
- Riwayat perubahan.

Actions:

- Tandai Selesai.
- Edit.
- Jadwalkan Ulang.
- Hapus.

==================================================
7. HALAMAN JURNAL HARIAN
==================================================

FRAME NAME:

FreeSpace/Desktop/Produktivitas/JurnalHarian

BREADCRUMB:

Produktivitas > Jurnal Harian

JUDUL:

Jurnal Harian

SUBTITLE:

Catat aktivitas, refleksi, dan pelajaran dari hari Anda.

PRIMARY ACTION:

Tulis Jurnal Hari Ini

Icon:
Pencil Square

SECONDARY ACTION:

Lihat Riwayat

--------------------------------------------------
7.1 SUMMARY CARDS JURNAL
--------------------------------------------------

Buat empat cards.

CARD 1

Label:
Status Hari Ini

Value:
Belum Diisi

Description:
Mulai menulis jurnal hari ini

Status:
Warning

CARD 2

Label:
Streak Jurnal

Value:
6 Hari

Description:
Pertahankan konsistensi Anda

Status:
Positive

CARD 3

Label:
Jurnal Bulan Ini

Value:
12

Description:
Dari 31 hari pada Juli

Status:
Primary

CARD 4

Label:
Mood Terbanyak

Value:
Produktif

Description:
Berdasarkan jurnal bulan ini

Status:
Secondary

--------------------------------------------------
7.2 INTERNAL TABS
--------------------------------------------------

Buat tabs:

- Tulis Jurnal
- Riwayat Jurnal

Default active:
Tulis Jurnal

Jangan menjadikan kedua tab sebagai submenu sidebar.

--------------------------------------------------
7.3 TAB TULIS JURNAL
--------------------------------------------------

Buat date navigator:

Previous day
Jumat, 3 Juli 2026
Next day
Today button

Gunakan layout dua kolom pada desktop.

KOLOM KIRI:

Form jurnal utama.

KOLOM KANAN:

Ringkasan hari dan prompt refleksi.

Bagian jurnal:

1. Mood Hari Ini

Pilihan:

- Sangat Baik.
- Baik.
- Biasa.
- Kurang Baik.
- Buruk.

Gunakan icon atau simple expression icon yang tetap netral dan konsisten.

2. Aktivitas Hari Ini

Tampilkan aktivitas yang selesai secara otomatis dari menu Aktivitas.

Data:

- Sarapan dan persiapan kuliah.
- Merapikan catatan kuliah.

Tambahkan field:

Aktivitas penting lainnya...

3. Cerita Hari Ini

Gunakan rich-text editor Tiptap.

Placeholder:

Apa yang terjadi hari ini?

Toolbar sederhana:

- Bold.
- Italic.
- Bullet list.
- Numbered list.
- Quote.
- Link.

4. Hal yang Disyukuri

Berikan tiga input singkat.

Placeholder:

- Saya bersyukur untuk...
- Hal baik yang saya alami...
- Orang atau kejadian yang saya hargai...

5. Pelajaran Hari Ini

Textarea.

Placeholder:

Apa hal penting yang Anda pelajari hari ini?

6. Refleksi Diri

Textarea.

Placeholder:

Apa yang sudah berjalan baik dan apa yang perlu diperbaiki?

7. Rencana Besok

Checklist atau simple list.

Placeholder:

Apa yang ingin Anda prioritaskan besok?

8. Tag

Contoh:

- Kuliah.
- Produktif.
- Keuangan.
- Belajar.
- Pribadi.

9. Lampiran opsional

Mendukung:

- Gambar.
- PDF.

Buttons:

- Simpan Draft.
- Simpan Jurnal.

Tambahkan autosave indicator:

Tersimpan otomatis beberapa detik lalu

Jangan menampilkan waktu autosave yang tidak realistis.

--------------------------------------------------
7.4 PANEL RINGKASAN HARI
--------------------------------------------------

Tampilkan pada kolom kanan:

Judul:
Ringkasan Hari Ini

Isi:

- 2 dari 5 aktivitas selesai.
- 7.420 langkah tercatat.
- Rp57.000 pengeluaran hari ini.
- 20 halaman target membaca.
- Jurnal belum disimpan.

Tambahkan section:

Prompt Refleksi

Contoh pertanyaan:

- Apa pencapaian kecil yang paling berarti hari ini?
- Apa satu hal yang dapat dilakukan lebih baik besok?
- Apa yang membuat Anda merasa bersyukur?

Tambahkan tombol kecil:

Gunakan Prompt Ini

Jangan membuat seluruh jurnal diisi otomatis oleh AI.

AI hanya boleh membantu memberi prompt atau merapikan tulisan setelah pengguna meminta.

--------------------------------------------------
7.5 TAB RIWAYAT JURNAL
--------------------------------------------------

Gunakan kombinasi calendar heatmap dan list jurnal.

Filter:

- Bulan.
- Mood.
- Tag.
- Status.
- Search.

Calendar:

Juli 2026

Tandai tanggal yang memiliki jurnal.

List jurnal:

1.
2 Jul 2026
Hari yang cukup produktif
Mood: Baik
Tags: Kuliah, Produktif

2.
1 Jul 2026
Awal bulan dan evaluasi keuangan
Mood: Biasa
Tags: Keuangan, Refleksi

3.
30 Jun 2026
Persiapan target bulan baru
Mood: Baik
Tags: Planning

Setiap item menampilkan:

- Date.
- Title atau excerpt.
- Mood.
- Tags.
- Last updated.
- More actions.

Actions:

- Buka.
- Edit.
- Duplikat sebagai template.
- Export PDF.
- Hapus.

--------------------------------------------------
7.6 JOURNAL ENTRY DETAIL
--------------------------------------------------

Buat full entry view atau drawer.

Tampilkan:

- Tanggal.
- Mood.
- Isi jurnal.
- Gratitude.
- Lesson learned.
- Reflection.
- Plan for tomorrow.
- Tags.
- Attachments.
- Created and last updated.

Actions:

- Edit.
- Export PDF.
- Hapus.

==================================================
8. HALAMAN BIBLE HARIAN
==================================================

FRAME NAME:

FreeSpace/Desktop/Produktivitas/BibleHarian

BREADCRUMB:

Produktivitas > Bible Harian

JUDUL:

Bible Harian

SUBTITLE:

Baca Alkitab dan catat intisari, nilai, serta refleksi pribadi.

PRIMARY ACTION:

Mulai Membaca

Icon:
Book Open

SECONDARY ACTION:

Rencana Bacaan

--------------------------------------------------
8.1 SUMMARY CARDS BIBLE HARIAN
--------------------------------------------------

Buat empat cards.

CARD 1

Label:
Bacaan Hari Ini

Value:
Mazmur 23

Description:
6 ayat dalam bacaan hari ini

Status:
Primary

CARD 2

Label:
Streak Membaca

Value:
12 Hari

Description:
Konsisten sejak 22 Juni 2026

Status:
Positive

CARD 3

Label:
Progress Rencana

Value:
40%

Description:
12 dari 30 hari

Status:
Secondary

CARD 4

Label:
Catatan Refleksi

Value:
11

Description:
1 draft belum selesai

Status:
Warning

--------------------------------------------------
8.2 INTERNAL TABS
--------------------------------------------------

Buat tabs:

- Baca Alkitab
- Catatan & Refleksi
- Riwayat Bacaan

Default active:
Baca Alkitab

Jangan menjadikan tab ini sebagai submenu sidebar.

--------------------------------------------------
8.3 TAB BACA ALKITAB
--------------------------------------------------

Gunakan reader layout.

Desktop:
Dua kolom.

KOLOM KIRI:
Reader Alkitab.

KOLOM KANAN:
Catatan dan refleksi.

Reader toolbar:

- Pilih kitab.
- Pilih pasal.
- Previous chapter.
- Next chapter.
- Font size.
- Line spacing.
- Reader theme jika tersedia.
- Bookmark chapter.

Default:

Kitab:
Mazmur

Pasal:
23

Tampilkan struktur ayat bernomor.

Gunakan teks placeholder atau sumber Alkitab yang telah memiliki izin penggunaan.

Jangan memasukkan teks ayat lengkap tanpa memastikan sumber dan lisensinya.

Pada prototype, cukup gunakan:

- Nomor ayat.
- Baris placeholder yang menyerupai paragraf.
- Satu atau dua excerpt pendek sebagai contoh visual.

Setiap ayat memiliki interaction:

- Select.
- Highlight.
- Bookmark.
- Add note.
- Copy reference.

Highlight colors:

- Kuning lembut.
- Hijau lembut.
- Biru lembut.
- Ungu lembut.

Gunakan warna yang tidak bertabrakan dengan design system utama.

--------------------------------------------------
8.4 PANEL CATATAN BACAAN
--------------------------------------------------

Judul:

Catatan Bacaan

Fields:

1. Ayat yang Berkesan

Menampilkan references yang dipilih.

Contoh:

Mazmur 23:1–3

2. Intisari Bacaan

Textarea.

Placeholder:

Apa inti dari bacaan hari ini?

3. Nilai yang Dipelajari

Input tags atau bullet list.

Contoh:

- Kepercayaan.
- Pengharapan.
- Ketenangan.

4. Makna Pribadi

Textarea.

Placeholder:

Apa makna bacaan ini bagi kehidupan Anda saat ini?

5. Refleksi

Rich-text field.

Placeholder:

Tuliskan refleksi pribadi Anda...

6. Penerapan

Textarea.

Placeholder:

Apa tindakan nyata yang ingin Anda lakukan?

7. Doa Pribadi

Textarea dengan privacy indicator.

Placeholder:

Tuliskan doa pribadi Anda...

Buttons:

- Simpan Draft.
- Tandai Selesai.
- Simpan Refleksi.

Tambahkan privacy label:

Pribadi — hanya dapat dilihat oleh Anda

--------------------------------------------------
8.5 RENCANA BACAAN
--------------------------------------------------

Buat modal atau dedicated panel.

Judul:

Rencana Bacaan

Tampilkan current plan:

30 Hari Mazmur dan Amsal

Progress:
12 dari 30 hari

Status:
Berjalan

Data beberapa hari:

Hari 12:
Mazmur 23
Hari Ini

Hari 13:
Mazmur 24
Besok

Hari 14:
Amsal 4
5 Jul 2026

Actions:

- Lanjutkan Rencana.
- Ubah Jadwal.
- Tandai Hari Selesai.
- Hentikan Rencana.

Tambahkan opsi:

Buat Rencana Baru

Fields:

- Nama rencana.
- Tanggal mulai.
- Frekuensi.
- Target selesai.
- Daftar bacaan.

--------------------------------------------------
8.6 TAB CATATAN & REFLEKSI
--------------------------------------------------

Tampilkan catatan sebagai card list.

Filters:

- Kitab.
- Tanggal.
- Tag atau nilai.
- Status.
- Search.

Data:

1.
Mazmur 23
3 Jul 2026
Kepercayaan dan ketenangan
Status: Draft

2.
Mazmur 22
2 Jul 2026
Tetap berharap dalam kesulitan
Status: Selesai

3.
Amsal 3
1 Jul 2026
Percaya dalam setiap keputusan
Status: Selesai

Setiap card menampilkan:

- Reference.
- Date.
- Excerpt refleksi.
- Values atau tags.
- Status.
- More action.

Actions:

- Buka.
- Edit.
- Export PDF.
- Hapus.

--------------------------------------------------
8.7 TAB RIWAYAT BACAAN
--------------------------------------------------

Tampilkan:

- Reading calendar.
- Streak.
- Progress plan.
- Total chapters read.
- Total notes created.

Table:

- Tanggal.
- Bacaan.
- Durasi.
- Catatan.
- Status.

Data contoh:

3 Jul 2026 | Mazmur 23 | 15 menit | 1 draft | Dibaca
2 Jul 2026 | Mazmur 22 | 18 menit | 1 catatan | Selesai
1 Jul 2026 | Amsal 3 | 20 menit | 1 catatan | Selesai
30 Jun 2026 | Mazmur 21 | 12 menit | Tidak ada | Selesai

==================================================
9. HALAMAN STEPS TRACKER
==================================================

FRAME NAME:

FreeSpace/Desktop/Produktivitas/StepsTracker

BREADCRUMB:

Produktivitas > Steps Tracker

JUDUL:

Steps Tracker

SUBTITLE:

Catat dan pantau progres langkah harian Anda.

PRIMARY ACTION:

Input Langkah

Icon:
Plus atau Pencil

SECONDARY ACTION:

Atur Target

--------------------------------------------------
9.1 SUMMARY CARDS STEPS
--------------------------------------------------

Buat empat cards.

CARD 1

Label:
Langkah Hari Ini

Value:
7.420

Description:
74,2% dari target harian

Status:
Primary

CARD 2

Label:
Target Harian

Value:
10.000

Description:
Sisa 2.580 langkah

Status:
Neutral

CARD 3

Label:
Rata-rata 7 Hari

Value:
7.865

Description:
Naik 6,4% dari minggu lalu

Status:
Positive

CARD 4

Label:
Streak Target

Value:
4 Hari

Description:
Target tercapai berturut-turut

Status:
Positive

--------------------------------------------------
9.2 MAIN PROGRESS SECTION
--------------------------------------------------

Buat dua-column layout.

KOLOM KIRI:

Daily progress card.

Gunakan radial progress atau donut chart.

Center value:
7.420

Center label:
dari 10.000 langkah

Progress:
74,2%

Di bawah chart:

- Sisa 2.580 langkah.
- Estimasi 1,8 km lagi.
- Target belum tercapai.

Gunakan estimation label:

Estimasi jarak dapat berbeda tergantung panjang langkah pengguna.

KOLOM KANAN:

Hourly progress atau daily breakdown.

Tampilkan horizontal bars:

06.00–09.00:
1.250 langkah

09.00–12.00:
2.100 langkah

12.00–15.00:
1.480 langkah

15.00–18.00:
1.390 langkah

18.00–21.00:
1.200 langkah

Jika input hanya berupa total harian dan tidak ada data per jam, tampilkan breakdown sebagai data simulasi atau sembunyikan section.

Jangan mengklaim data sensor otomatis jika belum ada integrasi perangkat.

--------------------------------------------------
9.3 TREND MINGGUAN
--------------------------------------------------

Buat line atau bar chart.

Judul:
Tren Langkah Mingguan

Data:

Senin:
8.200

Selasa:
10.450

Rabu:
7.800

Kamis:
9.150

Jumat:
7.420

Sabtu:
6.900

Minggu:
5.600

Target line:
10.000

Gunakan indicator target yang mudah dibaca.

Tambahkan summary:

- Rata-rata: 7.865 langkah.
- Hari terbaik: Selasa.
- Target tercapai: 1 dari 7 hari.

Sesuaikan data apabila total dan rata-rata perlu konsisten secara matematis.

--------------------------------------------------
9.4 KALENDER LANGKAH
--------------------------------------------------

Buat calendar heatmap untuk Juli 2026.

Intensitas berdasarkan jumlah langkah:

- 0–3.999.
- 4.000–6.999.
- 7.000–9.999.
- 10.000 atau lebih.

Pastikan legend menggunakan teks dan warna.

Jangan hanya mengandalkan warna.

Click tanggal membuka detail atau edit record.

--------------------------------------------------
9.5 RIWAYAT LANGKAH
--------------------------------------------------

Buat table.

Kolom:

- Tanggal.
- Jumlah Langkah.
- Target.
- Progress.
- Status.
- Sumber.
- Action.

Data:

3 Jul 2026 | 7.420 | 10.000 | 74,2% | Belum Tercapai | Input Manual
2 Jul 2026 | 9.150 | 10.000 | 91,5% | Hampir Tercapai | Input Manual
1 Jul 2026 | 7.800 | 10.000 | 78% | Belum Tercapai | Input Manual
30 Jun 2026 | 10.450 | 10.000 | 104,5% | Tercapai | Input Manual
29 Jun 2026 | 8.200 | 10.000 | 82% | Belum Tercapai | Input Manual

Action menu:

- Lihat.
- Edit.
- Hapus.

--------------------------------------------------
9.6 MODAL INPUT LANGKAH
--------------------------------------------------

Judul:

Input Langkah Harian

Fields:

- Tanggal.
- Jumlah langkah.
- Target hari tersebut.
- Sumber data.
- Catatan.

Sumber data:

- Input Manual.
- Perangkat.
- Aplikasi Kesehatan.

Untuk implementasi awal:

Default:
Input Manual

Pilihan Perangkat dan Aplikasi Kesehatan dapat diberi label:

Belum Terhubung

Jangan membuat integrasi palsu.

Buttons:

- Batal.
- Simpan Langkah.

Validasi:

- Tanggal wajib.
- Jumlah langkah wajib.
- Jumlah langkah tidak boleh negatif.
- Target minimal lebih dari 0.
- Satu record utama per tanggal.

Jika tanggal sudah memiliki data:

“Data langkah pada tanggal ini sudah tersedia.”

Actions:

- Perbarui Data.
- Batal.

--------------------------------------------------
9.7 MODAL ATUR TARGET
--------------------------------------------------

Judul:

Atur Target Langkah

Fields:

- Target harian.
- Berlaku mulai.
- Hari aktif.
- Target akhir pekan opsional.
- Reminder.

Default:

Target harian:
10.000

Reminder:
19.00

Toggle:

Ingatkan jika target belum tercapai

Buttons:

- Batal.
- Simpan Target.

==================================================
10. EMPTY, LOADING, ERROR, DAN SUCCESS STATES
==================================================

Setiap halaman harus memiliki state relevan.

AKTIVITAS EMPTY STATE

Title:
Belum ada aktivitas

Description:
Tambahkan aktivitas pertama untuk mulai menyusun jadwal Anda.

Action:
Tambah Aktivitas

JURNAL EMPTY STATE

Title:
Belum ada jurnal

Description:
Mulai catat cerita dan refleksi dari hari Anda.

Action:
Tulis Jurnal

BIBLE EMPTY STATE

Title:
Belum ada riwayat bacaan

Description:
Mulai membaca dan simpan refleksi pertama Anda.

Action:
Mulai Membaca

STEPS EMPTY STATE

Title:
Belum ada data langkah

Description:
Input jumlah langkah hari ini untuk mulai memantau progres.

Action:
Input Langkah

Jangan menggunakan:

- Segera Hadir.
- Sedang Dikembangkan.
- Coming Soon.

Buat loading state:

- Skeleton cards.
- Skeleton list.
- Skeleton chart.
- Skeleton editor.

Buat error state:

- Gagal memuat data.
- Gagal menyimpan.
- File gagal diunggah.
- Jadwal bertabrakan.
- Data tidak valid.

Buat success toast:

- Aktivitas berhasil ditambahkan.
- Jurnal berhasil disimpan.
- Refleksi berhasil disimpan.
- Data langkah berhasil diperbarui.

==================================================
11. NOTIFICATION BEHAVIOR
==================================================

Notifikasi tetap diakses melalui ikon lonceng pada topbar.

Jangan membuat notification inbox pada sidebar Produktivitas.

Contoh notifikasi Produktivitas:

- Aktivitas “Review materi Akuntansi Keuangan” dimulai dalam 30 menit.
- Deadline tugas Akuntansi jatuh tempo besok.
- Jurnal harian hari ini belum diisi.
- Bacaan Alkitab hari ini belum diselesaikan.
- Sisa 2.580 langkah untuk mencapai target hari ini.

Pengaturan notifikasi tetap berada pada menu Pengaturan.

Aktivitas dengan reminder H-1 harus memiliki indicator reminder aktif.

==================================================
12. AI ASSISTANCE
==================================================

Tombol Tanya AI tetap berada pada topbar.

Jangan membuat menu AI baru pada sidebar.

AI dapat digunakan secara kontekstual untuk:

Aktivitas:

- Menyarankan jadwal.
- Memecah aktivitas besar menjadi langkah kecil.
- Menyarankan prioritas.

Jurnal Harian:

- Memberikan pertanyaan refleksi.
- Merapikan tata bahasa atas permintaan pengguna.
- Membuat ringkasan jurnal atas persetujuan pengguna.

Bible Harian:

- Membantu menyusun pertanyaan refleksi.
- Membantu merangkum catatan pribadi.
- Tidak menggantikan teks Alkitab.
- Tidak mengubah arti ayat.
- Tidak menampilkan interpretasi sebagai kebenaran mutlak.

Steps Tracker:

- Memberikan motivasi.
- Menyarankan target bertahap.
- Tidak memberikan diagnosis medis.

Semua bantuan AI harus dipicu oleh pengguna.

Jangan mengubah atau menyimpan tulisan pengguna tanpa konfirmasi.

==================================================
13. REUSABLE COMPONENTS
==================================================

Buat atau rapikan components berikut.

NAVIGATION

- Sidebar/NavItem/Parent.
- Sidebar/NavItem/Child.
- Sidebar/Accordion.
- Breadcrumb.

PAGE

- Page/Header.
- Page/ActionBar.
- Page/FilterBar.

ACTIVITY

- Activity/ListItem.
- Activity/CalendarEvent.
- Activity/PriorityBadge.
- Activity/StatusBadge.
- Activity/DetailDrawer.
- Activity/RepeatIndicator.
- Activity/ReminderIndicator.

JOURNAL

- Journal/MoodSelector.
- Journal/Editor.
- Journal/PromptCard.
- Journal/EntryCard.
- Journal/CalendarDay.
- Journal/AutosaveIndicator.

BIBLE

- Bible/VerseRow.
- Bible/ReferenceSelector.
- Bible/HighlightMenu.
- Bible/NotePanel.
- Bible/ReadingPlanItem.
- Bible/ReflectionCard.

STEPS

- Steps/ProgressRing.
- Steps/TrendChart.
- Steps/HistoryRow.
- Steps/CalendarCell.
- Steps/TargetCard.

GLOBAL

- Card/Summary.
- Card/Chart.
- Card/Insight.
- Tabs/Primary.
- Tabs/Segmented.
- Input/Text.
- Input/Date.
- Input/Time.
- Input/Number.
- Select.
- SearchInput.
- Textarea.
- RichTextEditor.
- Checkbox.
- Toggle.
- FileUpload.
- Modal/Form.
- Drawer/Detail.
- Table/Header.
- Table/Row.
- Badge/Positive.
- Badge/Warning.
- Badge/Danger.
- Badge/Neutral.
- Toast/Success.
- Toast/Error.
- Alert/Info.
- Alert/Warning.

Gunakan component variants.

Jangan menduplikasi component dengan style manual.

==================================================
14. REQUIRED COMPONENT STATES
==================================================

Buat state berikut jika relevan:

- Default.
- Hover.
- Focus.
- Active.
- Selected.
- Checked.
- Completed.
- Disabled.
- Loading.
- Empty.
- Error.
- Success.
- Draft.
- Autosaved.
- Conflict.

Activity status:

- Belum Mulai.
- Berjalan.
- Selesai.
- Terlambat.
- Dibatalkan.

Journal status:

- Draft.
- Tersimpan.
- Diperbarui.

Bible note status:

- Draft.
- Selesai.

Steps status:

- Belum Tercapai.
- Hampir Tercapai.
- Tercapai.
- Melebihi Target.

==================================================
15. PROTOTYPE INTERACTIONS
==================================================

Buat prototype links untuk:

SIDEBAR

- Aktivitas menuju halaman Aktivitas.
- Jurnal Harian menuju halaman Jurnal Harian.
- Bible Harian menuju halaman Bible Harian.
- Steps Tracker menuju halaman Steps Tracker.

AKTIVITAS

- Tambah Aktivitas membuka modal.
- Tab Daftar berpindah ke list.
- Tab Kalender berpindah ke calendar.
- Tab Selesai berpindah ke completed list.
- Click aktivitas membuka detail drawer.
- Checkbox menyelesaikan aktivitas.
- Drag calendar event mengubah jadwal.
- Delete membuka confirmation modal.

JURNAL

- Tulis Jurnal Hari Ini membuka editor.
- Mood selector dapat dipilih.
- Simpan Draft menampilkan draft state.
- Simpan Jurnal menampilkan success toast.
- Riwayat membuka entry list.
- Click entry membuka detail.
- Previous dan next day berpindah tanggal.

BIBLE

- Pilih kitab dan pasal mengubah reader state.
- Click ayat membuka highlight toolbar.
- Add note memasukkan reference ke panel catatan.
- Simpan Refleksi menampilkan success toast.
- Rencana Bacaan membuka modal.
- Click history membuka reading detail.

STEPS

- Input Langkah membuka modal.
- Atur Target membuka modal.
- Click tanggal kalender membuka detail.
- Edit history membuka form berisi data.
- Save menampilkan progress terbaru.
- Target tercapai menampilkan success state.

Gunakan Smart Animate yang halus.

Durasi:

150–250 ms

Jangan membuat animasi dekoratif berlebihan.

==================================================
16. RESPONSIVE DESIGN
==================================================

Buat responsive layout untuk:

1. Desktop atau laptop existing frame.
2. iPad landscape.
3. iPad portrait.

DESKTOP

- Sidebar fixed.
- Topbar fixed sesuai desain.
- Summary cards empat kolom.
- Calendar menggunakan full-width.
- Reader Bible dua kolom.
- Journal editor dua kolom.
- Steps progress dua kolom.

IPAD LANDSCAPE

- Sidebar dapat tampil penuh atau collapsed.
- Summary cards menjadi dua kolom jika diperlukan.
- Filter dapat wrap.
- Calendar mempertahankan weekly view.
- Journal dan Bible dapat tetap dua kolom dengan rasio lebih kecil.
- Table menggunakan horizontal scroll jika diperlukan.

IPAD PORTRAIT

- Sidebar menjadi off-canvas drawer.
- Summary cards dua kolom.
- Filter masuk ke filter drawer jika ruang terbatas.
- Calendar default menjadi day atau agenda view.
- Journal editor menjadi satu kolom.
- Bible reader dan note panel menjadi stacked layout.
- Steps progress menjadi satu kolom.
- Modal besar menjadi full-screen sheet.
- Primary action tetap mudah diakses.

Jangan membuat bottom navigation baru.

==================================================
17. ACCESSIBILITY
==================================================

Pastikan:

- Area klik minimal 40–44 px.
- Semua form memiliki label.
- Placeholder tidak menggantikan label.
- Focus state terlihat.
- Status tidak hanya dibedakan berdasarkan warna.
- Priority menggunakan teks dan warna.
- Calendar event dapat dibuka tanpa hover.
- Mood selector memiliki text label.
- Highlight Bible memiliki label warna.
- Chart memiliki legend.
- Calendar heatmap memiliki legend teks.
- Rich-text toolbar memiliki tooltip.
- Icon-only button memiliki tooltip.
- Error ditampilkan dekat field.
- Contrast memadai.
- Keyboard navigation diperhitungkan.
- Completed item tetap terbaca.
- Text tidak terlalu kecil.

==================================================
18. FIGMA FILE ORGANIZATION
==================================================

Gunakan section atau page:

01 — Foundations
02 — Components
03 — Dashboard
04 — Keuangan
05 — Produktivitas
06 — Responsive
07 — Prototype

Nama frame:

FreeSpace/Desktop/Produktivitas/Aktivitas-Daftar
FreeSpace/Desktop/Produktivitas/Aktivitas-Kalender
FreeSpace/Desktop/Produktivitas/Aktivitas-Selesai
FreeSpace/Desktop/Produktivitas/Jurnal-Tulis
FreeSpace/Desktop/Produktivitas/Jurnal-Riwayat
FreeSpace/Desktop/Produktivitas/Bible-Baca
FreeSpace/Desktop/Produktivitas/Bible-Refleksi
FreeSpace/Desktop/Produktivitas/Bible-Riwayat
FreeSpace/Desktop/Produktivitas/Steps-Overview
FreeSpace/Desktop/Produktivitas/Steps-History

Overlay:

FreeSpace/Overlay/Aktivitas/Tambah
FreeSpace/Overlay/Aktivitas/Detail
FreeSpace/Overlay/Jurnal/Detail
FreeSpace/Overlay/Bible/RencanaBacaan
FreeSpace/Overlay/Steps/Input
FreeSpace/Overlay/Steps/Target

Jangan menggunakan nama:

- Frame 1.
- Group 23.
- Copy.
- Rectangle.
- New Component.

Gunakan descriptive layer names.

==================================================
19. EXECUTION PRIORITY
==================================================

Kerjakan dalam urutan berikut:

PHASE 1

1. Aktivitas — Daftar.
2. Modal Tambah Aktivitas.
3. Aktivitas — Kalender.
4. Aktivitas — Selesai.

PHASE 2

5. Jurnal Harian — Tulis.
6. Jurnal Harian — Riwayat.
7. Detail jurnal.

PHASE 3

8. Bible Harian — Reader.
9. Catatan & Refleksi.
10. Riwayat Bacaan.
11. Rencana Bacaan.

PHASE 4

12. Steps Tracker — Overview.
13. Input Langkah.
14. Atur Target.
15. Riwayat dan kalender langkah.

Gunakan component yang sama untuk semua tahap.

Jangan berhenti setelah membuat halaman Aktivitas saja.

==================================================
20. ACCEPTANCE CHECKLIST
==================================================

GLOBAL

[ ] Topbar tidak berubah.
[ ] Sidebar tidak berubah ukurannya.
[ ] Profile card tetap sama.
[ ] Produktivitas tetap memiliki empat submenu.
[ ] Tidak ada hierarchy sidebar level 3.
[ ] Tidak ada Dashboard tambahan.
[ ] Tidak ada placeholder Segera Hadir.
[ ] Typography tetap konsisten.
[ ] Warna tetap konsisten.
[ ] Card dan form mengikuti design system existing.

AKTIVITAS

[ ] Halaman Daftar tersedia.
[ ] Halaman Kalender tersedia.
[ ] Aktivitas Selesai tersedia.
[ ] Tambah Aktivitas tersedia.
[ ] Prioritas tersedia.
[ ] Kategori tersedia.
[ ] Deadline tersedia.
[ ] Reminder H-1 tersedia.
[ ] Aktivitas berulang tersedia.
[ ] Conflict warning tersedia.
[ ] Detail drawer tersedia.

JURNAL HARIAN

[ ] Editor jurnal tersedia.
[ ] Mood tersedia.
[ ] Aktivitas hari ini tersedia.
[ ] Cerita hari ini tersedia.
[ ] Gratitude tersedia.
[ ] Pelajaran tersedia.
[ ] Refleksi tersedia.
[ ] Rencana besok tersedia.
[ ] Autosave tersedia.
[ ] Draft tersedia.
[ ] Riwayat jurnal tersedia.
[ ] Export PDF tersedia.

BIBLE HARIAN

[ ] Reader tersedia.
[ ] Kitab dan pasal dapat dipilih.
[ ] Highlight tersedia.
[ ] Bookmark tersedia.
[ ] Catatan ayat tersedia.
[ ] Intisari tersedia.
[ ] Nilai yang dipelajari tersedia.
[ ] Makna pribadi tersedia.
[ ] Refleksi tersedia.
[ ] Penerapan tersedia.
[ ] Doa pribadi tersedia.
[ ] Rencana bacaan tersedia.
[ ] Riwayat bacaan tersedia.
[ ] Privacy indicator tersedia.
[ ] Tidak ada teks Alkitab tanpa sumber atau izin yang jelas.

STEPS TRACKER

[ ] Input manual tersedia.
[ ] Target langkah tersedia.
[ ] Progress harian tersedia.
[ ] Trend mingguan tersedia.
[ ] Calendar heatmap tersedia.
[ ] Riwayat tersedia.
[ ] Edit data tersedia.
[ ] Status target tersedia.
[ ] Tidak ada klaim integrasi perangkat palsu.
[ ] Sumber input ditampilkan.

RESPONSIVE

[ ] Desktop tersedia.
[ ] iPad landscape tersedia.
[ ] iPad portrait tersedia.
[ ] Calendar responsif.
[ ] Reader responsif.
[ ] Editor jurnal responsif.
[ ] Modal menjadi sheet pada layar sempit.
[ ] Table dapat horizontal scroll.

==================================================
21. FINAL EXECUTION INSTRUCTION
==================================================

Mulai dengan mengedit frame Aktivitas placeholder yang sedang aktif.

Hapus card “Segera Hadir” dan ganti seluruh area konten dengan halaman Aktivitas final.

Setelah halaman Aktivitas selesai, buat seluruh frame Jurnal Harian, Bible Harian, dan Steps Tracker menggunakan komponen, spacing, typography, dan visual pattern yang sama.

Jangan membuat konsep alternatif.

Jangan membuat moodboard.

Jangan membuat landing page.

Jangan membuat low-fidelity wireframe.

Jangan mengubah sidebar.

Jangan mengubah topbar.

Jangan menambahkan menu baru.

Jangan menjadikan tabs sebagai submenu sidebar.

Gunakan bahasa Indonesia yang natural.

Gunakan tanggal dan format waktu Indonesia.

Gunakan data simulasi yang konsisten.

Hasil akhir harus terlihat sebagai kelanjutan langsung dari desain FreeSpace yang sekarang, bukan aplikasi yang berbeda.