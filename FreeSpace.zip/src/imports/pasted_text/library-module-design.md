ROLE AND EXECUTION MODE

Anda adalah Senior Product Designer, UX Architect, Digital Library Product Designer, PDF Reader Experience Designer, Learning Management Designer, Accounting Education Designer, dan Figma Design-System Specialist.

Edit langsung desain FreeSpace yang SUDAH ADA pada file Figma ini.

Kondisi desain saat ini:

1. Branding telah menjadi “FreeSpace – Personal Workspace”.
2. Sidebar, topbar, profile card, search, Tanya AI, notifikasi, dan share sudah tersedia.
3. Parent menu Library sudah tersedia dan dapat diperluas.
4. Submenu Library sudah terdiri dari:
   - Koleksi Buku
   - Baca Buku
   - Accounting Space
5. Halaman Koleksi Buku masih berupa placeholder “Segera Hadir”.
6. Halaman Baca Buku dan Accounting Space belum memiliki konten lengkap.
7. Visual language dan komponen dasar sudah tersedia dari Dashboard, Keuangan, dan Produktivitas.

Tugas Anda sekarang adalah:

1. Menghapus seluruh placeholder pada modul Library.
2. Mendesain dan mengeksekusi halaman Koleksi Buku.
3. Mendesain dan mengeksekusi halaman Baca Buku.
4. Mendesain dan mengeksekusi halaman Accounting Space.
5. Membuat reusable components, variants, responsive states, dan prototype interactions.
6. Menggunakan komponen dan visual pattern existing FreeSpace.
7. Mengintegrasikan alur upload buku, membaca PDF, mencatat, menyorot, membuat ringkasan, dan latihan jurnal akuntansi.
8. Mempertahankan visual identity dan information architecture yang sudah disetujui.

Jangan hanya menghasilkan wireframe, penjelasan, atau konsep.

Eksekusi desain final high-fidelity menggunakan:

- Frame.
- Components.
- Component variants.
- Auto Layout.
- Variables.
- Constraints.
- Prototype links.
- Overlays.
- Modals.
- Drawers.
- Responsive states.

==================================================
1. PRINSIP UTAMA MODUL LIBRARY
==================================================

Library adalah pusat buku digital pribadi pengguna.

Modul ini memiliki tiga fungsi utama:

1. Koleksi Buku
   Digunakan untuk menyimpan, mengelola, mencari, mengategorikan, dan mengunggah buku PDF.

2. Baca Buku
   Digunakan untuk membaca PDF, menandai halaman, membuat highlight, mencatat per halaman, menulis ringkasan, dan memantau progres membaca.

3. Accounting Space
   Digunakan untuk membaca buku akuntansi, mengorganisasi catatan akuntansi, dan melakukan latihan jurnal berdasarkan materi yang dipelajari.

Struktur sidebar harus tetap:

Library
- Koleksi Buku
- Baca Buku
- Accounting Space

Tidak boleh menambahkan hierarchy level ketiga pada sidebar.

Jangan membuat submenu sidebar seperti:

- Semua Buku.
- Upload Buku.
- Favorit.
- Sedang Dibaca.
- Selesai Dibaca.
- Arsip.
- Catatan per Halaman.
- Highlight.
- Bookmark.
- Ringkasan.
- Latihan Jurnal.
- Buku Akuntansi.
- Catatan Akuntansi.

Fitur detail harus ditempatkan sebagai:

- Tabs.
- Filters.
- Page sections.
- Toolbar.
- Reader panels.
- Drawers.
- Modals.
- Dropdown menus.
- Segmented controls.

Jangan membuat:

- Dashboard Library.
- Dashboard Buku.
- Dashboard Accounting Space.
- Menu File Manager baru.
- Menu Notes terpisah di sidebar.
- Menu AI Library di sidebar.
- Navigasi lebih dari dua tingkat.

Dashboard global tetap menjadi satu-satunya Dashboard dalam aplikasi.

==================================================
2. PERTAHANKAN DESAIN EXISTING
==================================================

Pertahankan sepenuhnya:

- Ukuran dan posisi sidebar.
- Ukuran dan posisi topbar.
- Brand FreeSpace.
- Subtitle Personal Workspace.
- Profile card di kiri atas.
- Search field.
- Shortcut indicator.
- Tombol Tanya AI.
- Notification button dan badge.
- Share button.
- Page background.
- Page padding.
- Existing grid.
- Typography.
- Font family.
- Heading hierarchy.
- Body text style.
- Warna utama.
- Warna status.
- Icon style.
- Border.
- Border radius.
- Shadow.
- Card style.
- Table style.
- Form style.
- Breadcrumb style.
- Sidebar active state.
- Sidebar hover state.
- Spacing system.
- Existing design tokens.

Jangan:

- Membuat visual language baru.
- Mengganti font.
- Membuat gradient baru.
- Memperlebar sidebar.
- Memindahkan profile card.
- Mengubah topbar.
- Membuat navigation rail tambahan.
- Membuat bottom navigation pada desktop.
- Menambahkan ilustrasi dekoratif berlebihan.
- Menggunakan terlalu banyak warna.
- Membuat halaman terlihat seperti marketplace buku.
- Membuat desain seperti perpustakaan universitas enterprise.
- Mengubah desain utama menjadi dark theme.
- Menggunakan card yang tidak konsisten dengan halaman lain.
- Menghapus whitespace yang sudah menjadi karakter desain FreeSpace.

==================================================
3. DATA SIMULASI YANG HARUS KONSISTEN
==================================================

Gunakan data simulasi berikut pada seluruh modul Library.

Periode aktif:
Juli 2026

Total koleksi:
18 buku

Sedang dibaca:
4 buku

Selesai dibaca:
7 buku

Belum dibaca:
7 buku

Buku favorit:
5 buku

Total halaman dibaca bulan ini:
426 halaman

Waktu membaca bulan ini:
14 jam 35 menit

Streak membaca:
8 hari

Target membaca harian:
20 halaman

Progress buku aktif:
124 dari 182 halaman

Persentase progress buku aktif:
68%

Buku terakhir dibaca:
Akuntansi Keuangan Menengah

Halaman terakhir:
124

Catatan aktif:
17 catatan

Highlight aktif:
26 highlight

Bookmark aktif:
9 bookmark

Buku akuntansi:
8 buku

Catatan akuntansi:
24 catatan

Latihan jurnal selesai:
15 latihan

Rata-rata skor latihan:
86%

Gunakan tanggal:

3 Juli 2026

==================================================
4. GLOBAL PAGE TEMPLATE
==================================================

Gunakan page template konsisten pada seluruh halaman Library.

Struktur:

Topbar
Breadcrumb
Page header
- Judul halaman
- Subtitle
- Primary action
- Secondary action jika diperlukan
Content area
- Summary cards jika relevan
- Tabs atau segmented control
- Search dan filters
- Main content
- Grid, list, reader, notes, atau practice area
Optional modal atau drawer

Gunakan maksimal:

- Satu primary action per halaman.
- Satu atau dua secondary actions.
- Empat summary cards per row.
- Lima filter utama dalam satu toolbar.
- Empat sampai enam book cards per row sesuai ruang.
- Tiga sampai empat section besar pada initial viewport.

Jangan memenuhi halaman dengan terlalu banyak panel kecil.

==================================================
5. SIDEBAR DAN ACTIVE STATE
==================================================

Untuk seluruh frame Library:

- Parent Library harus expanded.
- Keuangan collapsed.
- Produktivitas collapsed.
- Karier collapsed.
- Pengaturan collapsed.

Buat active state berikut:

1. Library expanded dan Koleksi Buku aktif.
2. Library expanded dan Baca Buku aktif.
3. Library expanded dan Accounting Space aktif.

Pertahankan:

- Parent icon.
- Child dot indicator.
- Indentation.
- Chevron.
- Active child background.
- Parent active state.
- Item height.
- Spacing.
- Font weight.
- Border radius.

Hanya satu child aktif pada satu waktu.

==================================================
6. HALAMAN KOLEKSI BUKU
==================================================

FRAME NAME:

FreeSpace/Desktop/Library/KoleksiBuku

Hapus seluruh placeholder:

- Segera Hadir.
- Fitur Koleksi Buku sedang dalam pengembangan.
- Loading dots.
- Development empty state.

BREADCRUMB:

Library > Koleksi Buku

JUDUL:

Koleksi Buku

SUBTITLE:

Kelola, organisir, dan temukan seluruh koleksi buku digital Anda.

PRIMARY ACTION:

Upload Buku

Icon:
Arrow Up Tray atau Plus

SECONDARY ACTION:

Kelola Kategori

Icon:
Tag

--------------------------------------------------
6.1 SUMMARY CARDS KOLEKSI
--------------------------------------------------

Buat empat summary cards.

CARD 1

Label:
Total Koleksi

Value:
18

Description:
Buku tersimpan dalam library

Status:
Primary

CARD 2

Label:
Sedang Dibaca

Value:
4

Description:
Buku dengan progres aktif

Status:
Warning atau secondary

CARD 3

Label:
Selesai Dibaca

Value:
7

Description:
Buku telah diselesaikan

Status:
Positive

CARD 4

Label:
Halaman Bulan Ini

Value:
426

Description:
Dibaca selama Juli 2026

Status:
Secondary

Gunakan card style yang sama dengan Dashboard dan modul lainnya.

--------------------------------------------------
6.2 INTERNAL TABS
--------------------------------------------------

Buat tabs:

- Semua Buku
- Sedang Dibaca
- Selesai
- Favorit
- Arsip

Default active:
Semua Buku

Tambahkan count badge jika sesuai:

- Semua Buku: 18
- Sedang Dibaca: 4
- Selesai: 7
- Favorit: 5
- Arsip: 2

Jangan menjadikan tabs ini sebagai submenu sidebar.

--------------------------------------------------
6.3 FILTER DAN VIEW TOOLBAR
--------------------------------------------------

Buat toolbar:

- Search buku.
- Filter kategori.
- Filter status.
- Filter format.
- Sort.
- Grid view.
- List view.
- Reset filter.

Search placeholder:

Cari judul, penulis, atau tag...

Kategori:

- Semua Kategori.
- Akuntansi.
- Keuangan.
- Produktivitas.
- Karier.
- Rohani.
- Pengembangan Diri.
- Lainnya.

Status:

- Semua Status.
- Belum Dibaca.
- Sedang Dibaca.
- Selesai.
- Diarsipkan.

Format:

- PDF.

Sort:

- Terbaru Ditambahkan.
- Terakhir Dibaca.
- Judul A–Z.
- Penulis A–Z.
- Progress Tertinggi.
- Progress Terendah.

Default view:
Grid

--------------------------------------------------
6.4 GRID KOLEKSI BUKU
--------------------------------------------------

Buat book card component.

Setiap card menampilkan:

- Cover buku.
- Judul.
- Penulis.
- Kategori.
- File type badge.
- Jumlah halaman.
- Progress bar jika pernah dibaca.
- Status.
- Favorite icon.
- More action menu.

Gunakan cover placeholder profesional dan sederhana.

Jangan menggunakan cover buku berhak cipta tanpa izin.

Gunakan abstract cover atau generated placeholder.

Data buku contoh:

1.
Akuntansi Keuangan Menengah
Penulis: Modul Pembelajaran Pribadi
Kategori: Akuntansi
182 halaman
Progress: 68%
Status: Sedang Dibaca
Favorit: Ya

2.
Dasar-Dasar Akuntansi
Penulis: Materi Kuliah
Kategori: Akuntansi
240 halaman
Progress: 100%
Status: Selesai
Favorit: Ya

3.
Analisis Laporan Keuangan
Penulis: Bahan Belajar
Kategori: Keuangan
215 halaman
Progress: 35%
Status: Sedang Dibaca

4.
Manajemen Keuangan Pribadi
Penulis: Koleksi Pribadi
Kategori: Keuangan
156 halaman
Progress: 0%
Status: Belum Dibaca

5.
Strategi Belajar Efektif
Penulis: Koleksi Pribadi
Kategori: Produktivitas
134 halaman
Progress: 100%
Status: Selesai

6.
Persiapan Karier Akuntansi
Penulis: Koleksi Pribadi
Kategori: Karier
198 halaman
Progress: 12%
Status: Sedang Dibaca

7.
Catatan Refleksi Harian
Penulis: Koleksi Pribadi
Kategori: Rohani
120 halaman
Progress: 100%
Status: Selesai

8.
Audit dan Pengendalian Internal
Penulis: Materi Kuliah
Kategori: Akuntansi
260 halaman
Progress: 0%
Status: Belum Dibaca

More action menu:

- Buka Buku.
- Lanjutkan Membaca.
- Lihat Detail.
- Tambah ke Favorit.
- Ubah Kategori.
- Ganti Cover.
- Rename.
- Download File Asli.
- Arsipkan.
- Hapus.

Gunakan confirmation modal untuk Hapus.

--------------------------------------------------
6.5 LIST VIEW
--------------------------------------------------

Buat alternative list view.

Kolom:

- Buku.
- Penulis.
- Kategori.
- Progress.
- Halaman.
- Terakhir Dibaca.
- Status.
- Action.

Data harus sama dengan grid view.

List view tidak perlu menjadi frame utama terpisah jika dapat dibuat sebagai component variant.

--------------------------------------------------
6.6 MODAL UPLOAD BUKU
--------------------------------------------------

Buat modal atau right-side drawer.

Judul:

Upload Buku

Upload area:

- Drag and drop.
- Browse file.

Format yang diterima:

PDF

Batas ukuran awal:

Maksimal 50 MB per file

Tambahkan catatan:

Pastikan pengguna hanya mengunggah dokumen yang dimiliki atau memiliki izin untuk digunakan.

Fields setelah file dipilih:

- Judul buku.
- Penulis.
- Kategori.
- Tag.
- Bahasa.
- Tahun terbit.
- Jumlah halaman otomatis.
- Deskripsi opsional.
- Cover buku.
- Status awal.
- Mulai membaca setelah upload toggle.

Status awal:

- Belum Dibaca.
- Sedang Dibaca.
- Selesai.

Cover options:

- Ambil halaman pertama sebagai cover.
- Upload cover manual.
- Gunakan cover default.

Buttons:

- Batal.
- Upload Buku.

Upload states:

1. Default.
2. File selected.
3. Uploading.
4. Processing PDF.
5. Success.
6. Unsupported file.
7. File too large.
8. Corrupt PDF.
9. Duplicate file warning.

Duplicate warning:

“Buku dengan file yang sama sudah tersedia di koleksi.”

Actions:

- Buka Buku Lama.
- Tetap Upload sebagai Salinan.
- Batal.

--------------------------------------------------
6.7 DETAIL DRAWER BUKU
--------------------------------------------------

Buat right-side drawer.

Tampilkan:

- Cover.
- Judul.
- Penulis.
- Kategori.
- Tags.
- Format.
- File size.
- Total halaman.
- Progress.
- Terakhir dibaca.
- Tanggal ditambahkan.
- Total waktu membaca.
- Jumlah catatan.
- Jumlah highlight.
- Jumlah bookmark.
- Deskripsi.

Actions:

- Lanjutkan Membaca.
- Mulai dari Awal.
- Edit Informasi.
- Favorite.
- Download.
- Arsipkan.
- Hapus.

Tambahkan recent reading activity:

- Terakhir dibaca pada halaman 124.
- 3 Jul 2026, 20.15.
- Durasi sesi 27 menit.

==================================================
7. HALAMAN BACA BUKU
==================================================

FRAME NAME:

FreeSpace/Desktop/Library/BacaBuku

BREADCRUMB:

Library > Baca Buku

JUDUL:

Baca Buku

SUBTITLE:

Lanjutkan membaca, mencatat, dan menyimpan insight dari buku Anda.

PRIMARY ACTION:

Lanjutkan Membaca

Icon:
Book Open

SECONDARY ACTION:

Pilih Buku

--------------------------------------------------
7.1 READING OVERVIEW
--------------------------------------------------

Sebelum reader dibuka, buat halaman overview.

Summary cards:

CARD 1

Label:
Buku Aktif

Value:
4

Description:
Sedang dalam proses membaca

CARD 2

Label:
Halaman Bulan Ini

Value:
426

Description:
Target bulan 600 halaman

CARD 3

Label:
Waktu Membaca

Value:
14j 35m

Description:
Selama Juli 2026

CARD 4

Label:
Streak Membaca

Value:
8 Hari

Description:
Pertahankan konsistensi membaca

--------------------------------------------------
7.2 BUKU TERAKHIR DIBACA
--------------------------------------------------

Buat feature card besar.

Judul buku:

Akuntansi Keuangan Menengah

Penulis:

Modul Pembelajaran Pribadi

Progress:

124 dari 182 halaman

Persentase:

68%

Terakhir dibaca:

Hari ini, 20.15

Durasi sesi terakhir:

27 menit

Tampilkan:

- Cover.
- Progress bar.
- Tombol Lanjutkan Halaman 124.
- Tombol Buka Catatan.
- Tombol Mulai dari Awal.
- Bookmark terakhir.

--------------------------------------------------
7.3 SEDANG DIBACA
--------------------------------------------------

Buat horizontal atau grid book cards.

Data:

- Akuntansi Keuangan Menengah — 68%.
- Analisis Laporan Keuangan — 35%.
- Persiapan Karier Akuntansi — 12%.
- Manajemen Keuangan Pribadi — 8%.

Setiap card:

- Cover.
- Judul.
- Progress.
- Last page.
- Continue button.

--------------------------------------------------
7.4 RIWAYAT MEMBACA
--------------------------------------------------

Buat table atau activity list.

Kolom:

- Tanggal.
- Buku.
- Halaman.
- Durasi.
- Catatan.
- Progress.

Data:

3 Jul 2026
Akuntansi Keuangan Menengah
Hal. 118–124
27 menit
2 catatan
68%

2 Jul 2026
Akuntansi Keuangan Menengah
Hal. 106–117
34 menit
3 catatan
64%

1 Jul 2026
Analisis Laporan Keuangan
Hal. 68–75
22 menit
1 catatan
35%

30 Jun 2026
Persiapan Karier Akuntansi
Hal. 18–23
16 menit
Tidak ada
12%

==================================================
8. PDF READER INTERFACE
==================================================

FRAME NAME:

FreeSpace/Desktop/Library/Reader

Gunakan Mozilla PDF.js style integration, tetapi seluruh UI harus mengikuti visual FreeSpace.

Reader harus mempertahankan topbar global dan sidebar.

Main reader area menggunakan tiga bagian:

1. Left navigation panel.
2. Main PDF canvas.
3. Right notes panel.

Gunakan resizable panel jika memungkinkan.

--------------------------------------------------
8.1 LEFT NAVIGATION PANEL
--------------------------------------------------

Buat compact side panel dalam area reader.

Tabs:

- Thumbnail.
- Outline.
- Bookmark.

Thumbnail:

- Menampilkan miniature halaman.
- Active page memiliki border primary.
- Nomor halaman terlihat.

Outline:

- Daftar chapter atau heading PDF jika tersedia.
- Jika outline tidak tersedia, tampilkan empty state yang relevan.

Bookmark:

- Daftar halaman yang diberi bookmark.
- Menampilkan page number dan label opsional.

Panel dapat di-collapse.

Jangan mengubah sidebar utama aplikasi.

--------------------------------------------------
8.2 READER TOOLBAR
--------------------------------------------------

Toolbar reader berisi:

- Back ke Baca Buku.
- Judul buku.
- Previous page.
- Page input.
- Total page.
- Next page.
- Zoom out.
- Zoom percentage.
- Zoom in.
- Fit width.
- Fit page.
- Rotate.
- Search dalam PDF.
- Highlight mode.
- Bookmark page.
- Add note.
- Fullscreen.
- More actions.

Contoh:

124 / 182

Zoom default:

100%

More actions:

- Download PDF.
- Print.
- Buka Informasi Buku.
- Pergi ke Halaman.
- Reset Zoom.

Gunakan tooltip untuk icon-only buttons.

--------------------------------------------------
8.3 MAIN PDF CANVAS
--------------------------------------------------

Tampilkan PDF page dalam canvas yang bersih.

Ketentuan:

- Centered page.
- Background reader sedikit berbeda dari page white.
- Shadow halus pada halaman.
- Vertical scroll.
- Page gap konsisten.
- Current page indicator.
- Text selection.
- Search result highlight.
- Loading skeleton.

Jangan menggunakan isi buku berhak cipta sebagai contoh penuh.

Gunakan halaman placeholder dengan:

- Heading.
- Paragraph blocks.
- Table sederhana.
- Diagram sederhana.
- Nomor halaman.

--------------------------------------------------
8.4 RIGHT NOTES PANEL
--------------------------------------------------

Buat tab panel:

- Catatan
- Highlight
- Ringkasan
- Insight

Default active:
Catatan

Panel dapat di-collapse.

CATATAN

Fields:

- Judul catatan.
- Halaman aktif.
- Rich-text note.
- Tags.
- Pin note.

Auto reference:

Halaman 124

Placeholder:

Tuliskan catatan dari halaman ini...

Toolbar:

- Bold.
- Italic.
- Bullet.
- Numbered list.
- Quote.
- Link.

Button:

Simpan Catatan

HIGHLIGHT

Tampilkan daftar highlight:

- Text excerpt.
- Page.
- Color.
- Note optional.
- Created date.

Actions:

- Pergi ke Highlight.
- Edit Note.
- Ubah Warna.
- Hapus.

RINGKASAN

Fields:

- Ringkasan halaman aktif.
- Ringkasan chapter.
- Ringkasan buku.

Gunakan label yang jelas.

Jangan mengisi ringkasan secara otomatis tanpa aksi pengguna.

INSIGHT

Fields:

- Ide Utama.
- Hal Baru yang Dipelajari.
- Penerapan.
- Pertanyaan Lanjutan.
- Kesimpulan Pribadi.

--------------------------------------------------
8.5 HIGHLIGHT INTERACTION
--------------------------------------------------

Saat pengguna memilih teks, tampilkan floating contextual toolbar:

- Highlight kuning.
- Highlight hijau.
- Highlight biru.
- Highlight ungu.
- Add Note.
- Copy.
- Tanya AI.

Tanya AI hanya menggunakan teks yang dipilih sebagai konteks.

Jangan mengirim seluruh buku ke AI tanpa izin eksplisit pengguna.

--------------------------------------------------
8.6 BOOKMARK
--------------------------------------------------

Saat bookmark ditekan:

- Simpan halaman aktif.
- Berikan opsi label.
- Contoh label:
  “Konsep penting”.
  “Lanjut dari sini”.
  “Materi ujian”.

Success toast:

Halaman berhasil ditambahkan ke bookmark.

--------------------------------------------------
8.7 READING PROGRESS
--------------------------------------------------

Reader harus merekam:

- Halaman aktif.
- Persentase progress.
- Waktu sesi.
- Last opened.
- Pages read.
- Session duration.

Tampilkan compact session indicator:

Sesi membaca: 18 menit

Tampilkan progress bar di bawah toolbar atau bagian atas reader.

Jangan mengganggu area membaca.

--------------------------------------------------
8.8 END OF BOOK STATE
--------------------------------------------------

Ketika halaman terakhir selesai:

Tampilkan modal:

Judul:
Anda telah menyelesaikan buku ini

Isi:

- Total halaman.
- Total waktu membaca.
- Jumlah catatan.
- Jumlah highlight.
- Jumlah bookmark.

Actions:

- Tandai Selesai.
- Tulis Kesimpulan.
- Baca Ulang.
- Kembali ke Library.

==================================================
9. MODAL PILIH BUKU
==================================================

Buat modal.

Judul:

Pilih Buku untuk Dibaca

Komponen:

- Search.
- Filter kategori.
- Sedang Dibaca.
- Belum Dibaca.
- Recent books.

Setiap item:

- Cover.
- Judul.
- Penulis.
- Progress.
- Button Buka.

==================================================
10. ACCOUNTING SPACE
==================================================

FRAME NAME:

FreeSpace/Desktop/Library/AccountingSpace

BREADCRUMB:

Library > Accounting Space

JUDUL:

Accounting Space

SUBTITLE:

Pelajari materi akuntansi, susun catatan, dan latih pencatatan jurnal.

PRIMARY ACTION:

Mulai Belajar

Icon:
Academic Cap atau Book Open

SECONDARY ACTION:

Tambah Catatan

--------------------------------------------------
10.1 SUMMARY CARDS ACCOUNTING SPACE
--------------------------------------------------

Buat empat summary cards.

CARD 1

Label:
Buku Akuntansi

Value:
8

Description:
Tersimpan dalam Library

Status:
Primary

CARD 2

Label:
Catatan Akuntansi

Value:
24

Description:
6 catatan dibuat bulan ini

Status:
Secondary

CARD 3

Label:
Latihan Selesai

Value:
15

Description:
Dari 20 latihan tersedia

Status:
Positive

CARD 4

Label:
Rata-Rata Skor

Value:
86%

Description:
Naik 4% dari bulan lalu

Status:
Positive

--------------------------------------------------
10.2 INTERNAL TABS ACCOUNTING SPACE
--------------------------------------------------

Buat tabs:

- Buku Akuntansi
- Catatan Akuntansi
- Latihan Jurnal

Default active:
Buku Akuntansi

Jangan menjadikan ketiga tab sebagai submenu sidebar.

==================================================
11. TAB BUKU AKUNTANSI
==================================================

Tampilkan hanya buku dengan kategori Akuntansi atau Keuangan.

Toolbar:

- Search.
- Filter mata kuliah.
- Filter status baca.
- Sort.
- Grid/List.

Filter mata kuliah:

- Pengantar Akuntansi.
- Akuntansi Keuangan.
- Akuntansi Biaya.
- Akuntansi Manajemen.
- Perpajakan.
- Audit.
- Sistem Informasi Akuntansi.

Book card tambahan menampilkan:

- Mata kuliah.
- Topik utama.
- Progress.
- Jumlah catatan.
- Jumlah latihan terkait.

Data:

1.
Akuntansi Keuangan Menengah
Mata kuliah: Akuntansi Keuangan
Progress: 68%
Catatan: 8
Latihan: 5

2.
Dasar-Dasar Akuntansi
Mata kuliah: Pengantar Akuntansi
Progress: 100%
Catatan: 6
Latihan: 4

3.
Audit dan Pengendalian Internal
Mata kuliah: Audit
Progress: 0%
Catatan: 0
Latihan: 3

4.
Analisis Laporan Keuangan
Mata kuliah: Akuntansi Keuangan
Progress: 35%
Catatan: 4
Latihan: 3

Actions:

- Baca Buku.
- Lihat Catatan.
- Mulai Latihan.
- Tambah ke Rencana Belajar.

==================================================
12. TAB CATATAN AKUNTANSI
==================================================

Gunakan layout dua kolom.

KOLOM KIRI:

Navigation dan daftar catatan.

KOLOM KANAN:

Editor catatan.

--------------------------------------------------
12.1 SIDEBAR CATATAN INTERNAL
--------------------------------------------------

Buat navigation internal, bukan sidebar aplikasi.

Groups:

- Semua Catatan.
- Favorit.
- Terbaru.
- Berdasarkan Buku.
- Berdasarkan Topik.

Topik:

- Persamaan Dasar Akuntansi.
- Siklus Akuntansi.
- Jurnal Umum.
- Buku Besar.
- Neraca Saldo.
- Penyesuaian.
- Laporan Keuangan.
- Aset.
- Liabilitas.
- Ekuitas.
- Pendapatan.
- Beban.

Tambahkan search:

Cari catatan...

--------------------------------------------------
12.2 LIST CATATAN
--------------------------------------------------

Data contoh:

1.
Konsep Jurnal Penyesuaian
Sumber: Akuntansi Keuangan Menengah
Halaman 118–124
Diperbarui 3 Jul 2026

2.
Perbedaan Beban Akrual dan Dibayar Dimuka
Sumber: Akuntansi Keuangan Menengah
Halaman 97
Diperbarui 2 Jul 2026

3.
Tahapan Siklus Akuntansi
Sumber: Dasar-Dasar Akuntansi
Halaman 45–53
Diperbarui 1 Jul 2026

4.
Analisis Current Ratio
Sumber: Analisis Laporan Keuangan
Halaman 68–75
Diperbarui 30 Jun 2026

Setiap item:

- Judul.
- Sumber buku.
- Page reference.
- Tag.
- Favorite.
- Updated date.

--------------------------------------------------
12.3 EDITOR CATATAN
--------------------------------------------------

Fields:

- Judul.
- Mata kuliah.
- Topik.
- Sumber buku.
- Referensi halaman.
- Tags.
- Rich-text content.
- Related notes.
- Attachment.

Toolbar:

- Heading.
- Bold.
- Italic.
- Underline.
- Bullet.
- Numbered list.
- Checklist.
- Quote.
- Table.
- Code.
- Formula block.
- Link.

Tambahkan accounting blocks:

- Journal entry block.
- Accounting equation block.
- T-account block.
- Formula block.

Contoh formula:

Aset = Liabilitas + Ekuitas

Autosave indicator:

Tersimpan otomatis

Actions:

- Simpan.
- Favorite.
- Export PDF.
- Create Practice Question.
- Delete.

--------------------------------------------------
12.4 RELATED NOTES
--------------------------------------------------

Tampilkan section:

Catatan Terkait

Contoh:

- Jurnal Umum.
- Posting Buku Besar.
- Neraca Saldo Sebelum Penyesuaian.

Jangan menghubungkan catatan secara otomatis tanpa memberi pengguna kontrol.

==================================================
13. TAB LATIHAN JURNAL
==================================================

Buat practice overview.

Summary:

- Latihan tersedia: 20.
- Selesai: 15.
- Benar: 13.
- Rata-rata skor: 86%.

Filter:

- Tingkat kesulitan.
- Topik.
- Status.
- Sumber buku.

Kesulitan:

- Dasar.
- Menengah.
- Lanjutan.

Topik:

- Jurnal Umum.
- Penyesuaian.
- Penutup.
- Transaksi Kas.
- Piutang.
- Persediaan.
- Aset Tetap.
- Utang.
- Pendapatan.
- Beban.

--------------------------------------------------
13.1 DAFTAR LATIHAN
--------------------------------------------------

Gunakan practice cards atau table.

Data:

1.
Pembelian Perlengkapan Secara Tunai
Topik: Jurnal Umum
Kesulitan: Dasar
Status: Selesai
Skor: 100%

2.
Pendapatan Diterima Dimuka
Topik: Jurnal Penyesuaian
Kesulitan: Menengah
Status: Belum Dikerjakan

3.
Penyusutan Peralatan
Topik: Jurnal Penyesuaian
Kesulitan: Menengah
Status: Selesai
Skor: 80%

4.
Penutupan Akun Pendapatan dan Beban
Topik: Jurnal Penutup
Kesulitan: Lanjutan
Status: Sedang Dikerjakan

5.
Pembelian Persediaan Secara Kredit
Topik: Persediaan
Kesulitan: Menengah
Status: Belum Dikerjakan

Actions:

- Mulai Latihan.
- Ulangi.
- Lihat Pembahasan.
- Tandai untuk Nanti.

==================================================
14. INTERFACE LATIHAN JURNAL
==================================================

FRAME NAME:

FreeSpace/Desktop/Library/AccountingSpace/LatihanJurnal

Gunakan layout dua kolom.

KOLOM KIRI:

Soal dan informasi transaksi.

KOLOM KANAN:

Journal entry form.

--------------------------------------------------
14.1 SOAL LATIHAN
--------------------------------------------------

Contoh soal:

“Pada 3 Juli 2026, perusahaan membeli perlengkapan kantor secara tunai sebesar Rp1.200.000.”

Tampilkan:

- Nomor soal.
- Topik.
- Tingkat kesulitan.
- Sumber materi.
- Petunjuk.
- Progress latihan.

Contoh:

Soal 3 dari 10

Actions:

- Sebelumnya.
- Selanjutnya.
- Tandai Ragu-Ragu.

--------------------------------------------------
14.2 FORM JURNAL
--------------------------------------------------

Kolom:

- Akun.
- Debit.
- Kredit.
- Keterangan.

Initial rows:
2

Actions:

- Tambah Baris.
- Hapus Baris.
- Reset Jawaban.

Footer:

Total Debit
Total Kredit
Selisih

Button:

Periksa Jawaban

Disabled jika total debit dan kredit belum seimbang.

--------------------------------------------------
14.3 HASIL PEMERIKSAAN
--------------------------------------------------

Correct state:

Judul:
Jawaban Benar

Penjelasan:

Perlengkapan bertambah sehingga dicatat di sisi debit. Kas berkurang sehingga dicatat di sisi kredit.

Jurnal benar:

Debit:
Perlengkapan Rp1.200.000

Kredit:
Kas Rp1.200.000

Actions:

- Lanjut Soal Berikutnya.
- Lihat Materi Terkait.

Incorrect state:

Judul:
Jawaban Belum Tepat

Tampilkan:

- Baris salah.
- Selisih debit dan kredit.
- Hint bertahap.
- Opsi coba lagi.

Jangan langsung menampilkan jawaban lengkap pada percobaan pertama.

Hint levels:

1. Identifikasi akun yang berubah.
2. Tentukan apakah akun bertambah atau berkurang.
3. Tentukan posisi debit atau kredit.

Actions:

- Coba Lagi.
- Tampilkan Hint.
- Lihat Pembahasan.

--------------------------------------------------
14.4 RIWAYAT LATIHAN
--------------------------------------------------

Buat table.

Kolom:

- Tanggal.
- Latihan.
- Topik.
- Percobaan.
- Skor.
- Durasi.
- Status.

Data:

3 Jul 2026
Penyusutan Peralatan
Penyesuaian
2
80%
8 menit
Selesai

2 Jul 2026
Pembelian Perlengkapan
Jurnal Umum
1
100%
5 menit
Selesai

1 Jul 2026
Pendapatan Diterima Dimuka
Penyesuaian
3
70%
12 menit
Selesai

==================================================
15. AI ASSISTANCE
==================================================

Tombol Tanya AI tetap berada pada topbar.

Jangan membuat AI sebagai submenu Library.

AI boleh digunakan secara kontekstual untuk:

Koleksi Buku:

- Membantu menyarankan kategori.
- Membantu membuat tag.
- Membantu membaca metadata dari PDF.
- Membantu membuat deskripsi singkat.

Baca Buku:

- Meringkas teks yang dipilih.
- Menjelaskan konsep dari halaman aktif.
- Membuat pertanyaan belajar.
- Membantu merapikan catatan.
- Menemukan istilah dalam buku.

Accounting Space:

- Menjelaskan konsep akuntansi.
- Membuat latihan berdasarkan catatan.
- Memberikan hint bertahap.
- Memeriksa struktur jurnal.
- Membantu menghubungkan catatan terkait.

Aturan wajib AI:

- AI hanya aktif setelah dipicu pengguna.
- Jangan otomatis mengirim seluruh isi PDF.
- Gunakan teks yang dipilih atau halaman yang disetujui pengguna.
- Tampilkan halaman sumber pada jawaban AI.
- Bedakan isi buku, catatan pengguna, dan hasil AI.
- Jangan mengganti catatan pengguna tanpa konfirmasi.
- Jangan langsung mem-posting jurnal ke modul Akuntansi.
- Jangan menyatakan penjelasan AI selalu benar.
- Sediakan tombol:
  - Gunakan.
  - Edit.
  - Salin.
  - Buang.

Tambahkan label:

Dibuat dengan bantuan AI

pada konten hasil AI.

==================================================
16. KETERKAITAN DENGAN MODUL LAIN
==================================================

Library harus terhubung secara logis dengan modul lain.

Dashboard:

- Menampilkan progress membaca.
- Menampilkan buku terakhir dibaca.

Produktivitas:

- Aktivitas membaca dapat dibuat dari buku.
- Target membaca harian dapat menjadi aktivitas.
- Sesi membaca dapat muncul pada jurnal harian.

Akuntansi:

- Latihan jurnal Accounting Space tidak langsung masuk ke jurnal akuntansi aktual.
- Pengguna dapat memilih:
  “Salin sebagai Draft Jurnal”
- Berikan warning:
  “Pastikan jurnal berasal dari transaksi nyata sebelum diposting.”

History:

- Upload buku.
- Membuka buku.
- Menyimpan catatan.
- Menyelesaikan latihan.
- Menghapus buku.

==================================================
17. FILE MANAGEMENT DAN PRIVACY
==================================================

File buku harus dianggap sebagai file pribadi.

Tampilkan privacy indicator jika diperlukan:

Pribadi — hanya dapat diakses oleh Anda

Jangan membuat file buku menjadi publik secara default.

Buat status:

- Uploading.
- Processing.
- Ready.
- Failed.
- Archived.
- Deleted.

Pada delete modal:

Judul:
Hapus Buku?

Isi:

Buku, progres, catatan, highlight, dan bookmark terkait akan dihapus.

Tambahkan checkbox opsional:

Hapus juga seluruh catatan terkait

Actions:

- Batal.
- Hapus Buku.

Gunakan destructive button style.

==================================================
18. EMPTY STATES
==================================================

KOLEKSI BUKU

Title:
Koleksi buku masih kosong

Description:
Upload buku PDF pertama untuk mulai membangun library pribadi Anda.

Action:
Upload Buku

SEDANG DIBACA

Title:
Belum ada buku yang sedang dibaca

Description:
Pilih buku dari koleksi dan mulai sesi membaca pertama Anda.

Action:
Pilih Buku

FAVORIT

Title:
Belum ada buku favorit

Description:
Tandai buku penting agar lebih mudah ditemukan.

ACCOUNTING SPACE

Title:
Belum ada buku akuntansi

Description:
Tambahkan buku berkategori Akuntansi untuk mulai menggunakan Accounting Space.

Action:
Upload Buku Akuntansi

CATATAN

Title:
Belum ada catatan

Description:
Buka buku dan buat catatan dari materi yang sedang dipelajari.

Action:
Buka Buku

LATIHAN

Title:
Belum ada latihan yang sesuai

Description:
Ubah filter atau buat latihan dari catatan akuntansi Anda.

Action:
Buat Latihan

Jangan menggunakan:

- Segera Hadir.
- Sedang Dikembangkan.
- Coming Soon.

==================================================
19. LOADING, ERROR, DAN SUCCESS STATES
==================================================

Loading:

- Skeleton summary cards.
- Skeleton book cards.
- Skeleton thumbnails.
- PDF loading indicator.
- Note saving indicator.
- AI processing indicator.
- Upload progress.

Errors:

- PDF gagal dimuat.
- File rusak.
- Format tidak didukung.
- Upload terputus.
- Gagal menyimpan catatan.
- Gagal menyimpan progress.
- Halaman tidak ditemukan.
- AI gagal memproses teks.
- Latihan gagal dimuat.

Success toasts:

- Buku berhasil diunggah.
- Informasi buku berhasil diperbarui.
- Progress membaca berhasil disimpan.
- Catatan berhasil disimpan.
- Highlight berhasil ditambahkan.
- Bookmark berhasil ditambahkan.
- Latihan berhasil diselesaikan.
- Buku berhasil diarsipkan.

==================================================
20. REUSABLE COMPONENTS
==================================================

Buat atau rapikan components berikut.

NAVIGATION

- Sidebar/NavItem/Parent.
- Sidebar/NavItem/Child.
- Sidebar/Accordion.
- Breadcrumb.

PAGE

- Page/Header.
- Page/ActionBar.
- Page/FilterBar.

LIBRARY

- Book/Card.
- Book/Card/List.
- Book/Cover.
- Book/Progress.
- Book/StatusBadge.
- Book/DetailDrawer.
- Book/UploadDropzone.
- Book/MetadataForm.

READER

- Reader/Toolbar.
- Reader/PageCanvas.
- Reader/Thumbnail.
- Reader/OutlineItem.
- Reader/BookmarkItem.
- Reader/SearchResult.
- Reader/HighlightToolbar.
- Reader/ProgressBar.
- Reader/SessionTimer.

NOTES

- Note/Card.
- Note/ListItem.
- Note/Editor.
- Note/Reference.
- Note/Tag.
- Note/AutosaveIndicator.
- Note/RelatedItem.

ACCOUNTING SPACE

- Accounting/BookCard.
- Accounting/JournalBlock.
- Accounting/TAccount.
- Accounting/EquationBlock.
- Accounting/PracticeCard.
- Accounting/JournalLine.
- Accounting/Hint.
- Accounting/AnswerResult.
- Accounting/ScoreBadge.

GLOBAL

- Card/Summary.
- Tabs/Primary.
- Tabs/Segmented.
- SearchInput.
- Select.
- TextInput.
- Textarea.
- RichTextEditor.
- FileUpload.
- Toggle.
- Checkbox.
- Badge/Positive.
- Badge/Warning.
- Badge/Danger.
- Badge/Neutral.
- Modal/Form.
- Modal/Confirm.
- Drawer/Detail.
- Table/Header.
- Table/Row.
- Toast/Success.
- Toast/Error.
- Alert/Info.
- Alert/Warning.

Gunakan component variants.

Jangan menduplikasi component secara manual.

==================================================
21. REQUIRED COMPONENT STATES
==================================================

Buat state berikut jika relevan:

- Default.
- Hover.
- Focus.
- Active.
- Selected.
- Disabled.
- Loading.
- Empty.
- Error.
- Success.
- Uploading.
- Processing.
- Ready.
- Archived.
- Favorited.
- Bookmarked.
- Highlighted.
- Draft.
- Autosaved.
- Completed.

Book status:

- Belum Dibaca.
- Sedang Dibaca.
- Selesai.
- Diarsipkan.

Note status:

- Draft.
- Tersimpan.
- Diperbarui.

Practice status:

- Belum Dikerjakan.
- Sedang Dikerjakan.
- Selesai.
- Perlu Diulang.

==================================================
22. PROTOTYPE INTERACTIONS
==================================================

Buat prototype links untuk:

SIDEBAR

- Koleksi Buku menuju Koleksi Buku.
- Baca Buku menuju Baca Buku.
- Accounting Space menuju Accounting Space.

KOLEKSI BUKU

- Upload Buku membuka modal.
- Click book card membuka detail drawer.
- Buka Buku menuju Reader.
- Favorite mengubah state.
- Grid/List mengubah view.
- Filter mengubah book list.
- Hapus membuka confirmation modal.

BACA BUKU

- Lanjutkan Membaca membuka halaman Reader pada halaman 124.
- Pilih Buku membuka modal.
- Click recent book membuka Reader.
- Click history membuka reading session detail.

READER

- Previous/Next mengubah halaman.
- Page input menuju halaman tertentu.
- Zoom mengubah canvas.
- Bookmark menyimpan halaman.
- Select text membuka highlight toolbar.
- Add Note membuka notes panel.
- Search membuka search results.
- Click thumbnail berpindah halaman.
- Click bookmark berpindah halaman.
- Collapse panel memperluas canvas.
- Finish book membuka completion modal.

ACCOUNTING SPACE

- Tab Buku berpindah ke list buku.
- Tab Catatan berpindah ke note workspace.
- Tab Latihan berpindah ke practice overview.
- Click catatan membuka editor.
- Mulai Latihan membuka exercise frame.
- Periksa Jawaban membuka result state.
- Hint membuka hint bertahap.
- Lihat Materi Terkait membuka buku pada halaman sumber.

Gunakan Smart Animate halus.

Durasi:

150–250 ms

Jangan membuat animasi dekoratif berlebihan.

==================================================
23. RESPONSIVE DESIGN
==================================================

Buat responsive layout untuk:

1. Desktop atau laptop existing frame.
2. iPad landscape.
3. iPad portrait.

DESKTOP

- Sidebar fixed.
- Topbar fixed sesuai desain.
- Summary cards empat kolom.
- Book grid empat sampai enam kolom sesuai frame.
- Reader menggunakan left panel, canvas, dan right panel.
- Accounting notes menggunakan dua kolom.
- Practice menggunakan dua kolom.

IPAD LANDSCAPE

- Sidebar dapat full atau collapsed.
- Summary cards dua kolom jika diperlukan.
- Book grid tiga kolom.
- Reader left panel dapat overlay.
- Notes panel dapat tetap visible atau collapsible.
- Filter dapat wrap.
- Practice tetap dua kolom jika ruang cukup.

IPAD PORTRAIT

- Sidebar menjadi off-canvas drawer.
- Summary cards dua kolom.
- Book grid dua kolom.
- Filter masuk drawer atau sheet.
- Reader fokus pada canvas.
- Thumbnail dan notes panel menjadi slide-over drawer.
- Reader toolbar dapat horizontal scroll.
- Accounting notes menjadi satu kolom.
- Practice soal dan jurnal menjadi stacked layout.
- Modal besar menjadi full-screen sheet.

Jangan membuat bottom navigation baru.

==================================================
24. ACCESSIBILITY
==================================================

Pastikan:

- Area klik minimal 40–44 px.
- Book title tidak terlalu kecil.
- Progress tidak hanya dibedakan melalui warna.
- Status memiliki teks.
- Icon-only button memiliki tooltip.
- Reader dapat digunakan dengan keyboard.
- Page input memiliki label.
- Zoom controls mudah dipahami.
- Highlight color memiliki text label.
- Search result dapat dinavigasi.
- Rich-text toolbar memiliki tooltip.
- Form upload memiliki label.
- Error tampil dekat field.
- Contrast memadai.
- Focus state terlihat.
- PDF canvas tidak menjadi satu-satunya sumber informasi.
- Thumbnail memiliki page number.
- Journal debit/kredit memiliki label jelas.
- Jawaban salah tidak hanya ditandai merah.

==================================================
25. FIGMA FILE ORGANIZATION
==================================================

Gunakan section atau page:

01 — Foundations
02 — Components
03 — Dashboard
04 — Keuangan
05 — Produktivitas
06 — Library
07 — Responsive
08 — Prototype

Nama frame:

FreeSpace/Desktop/Library/Koleksi-Grid
FreeSpace/Desktop/Library/Koleksi-List
FreeSpace/Desktop/Library/Koleksi-Favorit
FreeSpace/Desktop/Library/Baca-Overview
FreeSpace/Desktop/Library/Reader
FreeSpace/Desktop/Library/Reader-NotesOpen
FreeSpace/Desktop/Library/Reader-Search
FreeSpace/Desktop/Library/Accounting-Buku
FreeSpace/Desktop/Library/Accounting-Catatan
FreeSpace/Desktop/Library/Accounting-Latihan
FreeSpace/Desktop/Library/Accounting-Practice
FreeSpace/Desktop/Library/Accounting-ResultCorrect
FreeSpace/Desktop/Library/Accounting-ResultIncorrect

Overlay:

FreeSpace/Overlay/Library/UploadBuku
FreeSpace/Overlay/Library/DetailBuku
FreeSpace/Overlay/Library/PilihBuku
FreeSpace/Overlay/Library/HapusBuku
FreeSpace/Overlay/Reader/Bookmark
FreeSpace/Overlay/Reader/Completion
FreeSpace/Overlay/Accounting/Hint

Jangan menggunakan nama:

- Frame 1.
- Group 23.
- Copy.
- Rectangle.
- New Component.

Gunakan descriptive layer naming.

==================================================
26. EXECUTION PRIORITY
==================================================

Kerjakan dalam urutan berikut:

PHASE 1

1. Koleksi Buku — Grid.
2. Modal Upload Buku.
3. Detail Buku.
4. List view dan filter states.

PHASE 2

5. Baca Buku — Overview.
6. Reader utama.
7. Notes panel.
8. Highlight dan bookmark.
9. Reading history.
10. Completion state.

PHASE 3

11. Accounting Space — Buku Akuntansi.
12. Catatan Akuntansi.
13. Note editor.
14. Latihan Jurnal overview.
15. Practice interface.
16. Correct dan incorrect result.

Gunakan komponen yang sama secara konsisten.

Jangan berhenti setelah membuat halaman Koleksi Buku saja.

==================================================
27. ACCEPTANCE CHECKLIST
==================================================

GLOBAL

[ ] Topbar tidak berubah.
[ ] Sidebar tidak berubah.
[ ] Profile card tetap sama.
[ ] Library tetap memiliki tiga submenu.
[ ] Tidak ada hierarchy level 3.
[ ] Tidak ada Dashboard Library.
[ ] Tidak ada placeholder Segera Hadir.
[ ] Typography konsisten.
[ ] Warna konsisten.
[ ] Card, form, table, dan modal konsisten.

KOLEKSI BUKU

[ ] Upload PDF tersedia.
[ ] Grid view tersedia.
[ ] List view tersedia.
[ ] Search tersedia.
[ ] Filter kategori tersedia.
[ ] Filter status tersedia.
[ ] Favorit tersedia.
[ ] Arsip tersedia.
[ ] Detail buku tersedia.
[ ] Progress membaca tersedia.
[ ] Duplicate warning tersedia.
[ ] Hapus buku memiliki confirmation.

BACA BUKU

[ ] Overview tersedia.
[ ] Buku terakhir dibaca tersedia.
[ ] Recent books tersedia.
[ ] PDF reader tersedia.
[ ] Thumbnail tersedia.
[ ] Outline tersedia.
[ ] Bookmark tersedia.
[ ] Search PDF tersedia.
[ ] Zoom tersedia.
[ ] Highlight tersedia.
[ ] Catatan per halaman tersedia.
[ ] Ringkasan tersedia.
[ ] Insight tersedia.
[ ] Progress membaca tersimpan.
[ ] Reading history tersedia.
[ ] End-of-book state tersedia.

ACCOUNTING SPACE

[ ] Buku akuntansi tersedia.
[ ] Catatan akuntansi tersedia.
[ ] Rich-text editor tersedia.
[ ] Referensi halaman tersedia.
[ ] Journal block tersedia.
[ ] T-account block tersedia.
[ ] Equation block tersedia.
[ ] Latihan jurnal tersedia.
[ ] Debit dan kredit tervalidasi.
[ ] Hint bertahap tersedia.
[ ] Result benar dan salah tersedia.
[ ] Riwayat latihan tersedia.
[ ] Skor tersedia.

AI

[ ] AI hanya aktif atas permintaan pengguna.
[ ] Teks sumber ditampilkan.
[ ] Page reference tersedia.
[ ] Tidak seluruh PDF dikirim tanpa izin.
[ ] Konten AI diberi label.
[ ] Pengguna harus mengonfirmasi sebelum menggunakan hasil AI.

RESPONSIVE

[ ] Desktop tersedia.
[ ] iPad landscape tersedia.
[ ] iPad portrait tersedia.
[ ] Reader responsif.
[ ] Notes panel responsif.
[ ] Book grid responsif.
[ ] Practice interface responsif.
[ ] Modal menjadi sheet pada layar kecil.

==================================================
28. FINAL EXECUTION INSTRUCTION
==================================================

Mulai dengan mengedit frame Koleksi Buku placeholder yang sedang aktif.

Hapus card “Segera Hadir” dan ganti seluruh area konten dengan halaman Koleksi Buku final.

Setelah Koleksi Buku selesai, buat halaman Baca Buku, PDF Reader, Accounting Space, Catatan Akuntansi, dan Latihan Jurnal menggunakan visual pattern yang sama.

Jangan membuat konsep alternatif.

Jangan membuat moodboard.

Jangan membuat landing page.

Jangan membuat low-fidelity wireframe.

Jangan mengubah sidebar.

Jangan mengubah topbar.

Jangan menambahkan menu baru.

Jangan menjadikan internal tabs sebagai submenu sidebar.

Gunakan bahasa Indonesia yang natural.

Gunakan tanggal Indonesia.

Gunakan data simulasi yang konsisten.

Hasil akhir harus terlihat sebagai kelanjutan langsung dari desain FreeSpace yang sekarang, bukan aplikasi yang berbeda.