ROLE

Anda adalah Senior Product Designer, Information Architect, dan Figma Design-System Specialist.

Tugas Anda adalah mengedit desain website yang SUDAH ADA pada file Figma ini. Desain awal merupakan dashboard “Aset SV IPB – Manajemen Aset”, tetapi sekarang akan digunakan sebagai fondasi visual untuk aplikasi personal bernama “FreeSpace”.

Ini adalah proses MIGRASI INFORMASI DAN NAVIGASI, bukan proses redesign visual.

Gunakan frame, component, instance, auto layout, typography, spacing, warna, border, shadow, radius, grid, icon style, topbar, sidebar, profile card, dan komposisi desain yang sudah ada sebagai sumber visual utama.

Jangan membuat desain baru dari nol.

==================================================
1. TUJUAN UTAMA
==================================================

Ubah struktur menu dan submenu pada sidebar agar sesuai dengan requirement aplikasi FreeSpace.

Pertahankan seluruh gaya visual desain yang sekarang, terutama:

- Ukuran dan posisi sidebar.
- Ukuran dan posisi topbar.
- Profile user card di kiri atas.
- Search field pada topbar.
- Tombol “Tanya AI”.
- Ikon notifikasi beserta badge.
- Ikon share atau action lainnya.
- Sistem typography.
- Warna utama.
- Warna background.
- Border.
- Border radius.
- Shadow.
- Padding dan spacing.
- Ketebalan icon.
- Active state.
- Hover state.
- Bentuk submenu.
- Indentasi submenu.
- Bentuk chevron.
- Struktur layout halaman.
- Grid pada main content.
- Semua card, chart, table, dan komponen pada area konten utama.

Jangan mengubah identitas visual desain menjadi gaya baru.

Hasil akhir harus terlihat seperti desain yang sama, tetapi telah digunakan untuk aplikasi FreeSpace.

==================================================
2. RUANG LINGKUP PERUBAHAN
==================================================

Perubahan yang diperbolehkan:

1. Mengganti nama aplikasi pada area brand.
2. Mengganti subtitle aplikasi.
3. Mengganti nama section sidebar.
4. Mengganti seluruh menu dan submenu sidebar.
5. Mengganti icon menu agar relevan dengan fungsi baru.
6. Mengganti breadcrumb agar sesuai dengan halaman yang aktif.
7. Mengganti judul halaman dan subtitle halaman hanya jika diperlukan untuk menyesuaikan halaman aktif.
8. Membuat component variants untuk kondisi sidebar collapsed, expanded, active, dan inactive.
9. Menambahkan kemampuan scroll pada daftar navigasi jika tingginya melebihi viewport.

Perubahan yang TIDAK diperbolehkan:

1. Mengubah struktur visual topbar.
2. Memindahkan profile user card.
3. Mengganti ukuran sidebar.
4. Mengubah layout utama.
5. Mengganti font.
6. Mengubah design token.
7. Mengubah warna utama desain.
8. Mengubah bentuk card.
9. Mengubah desain search field.
10. Mengubah desain tombol Tanya AI.
11. Mengubah desain ikon notifikasi.
12. Mengubah dashboard menjadi gaya baru.
13. Membuat sidebar kedua.
14. Membuat dashboard terpisah pada setiap modul.
15. Menambahkan navigation rail baru.
16. Menambahkan floating navigation.
17. Menampilkan seluruh submenu secara bersamaan.
18. Memasukkan fitur yang seharusnya berupa tab halaman menjadi submenu sidebar.

Area main content yang saat ini berisi data aset, chart, table, dan card manajemen aset JANGAN didesain ulang dalam tahap ini.

Fokus tahap ini adalah:

- Branding dasar FreeSpace.
- Sidebar navigation.
- Menu hierarchy.
- Submenu hierarchy.
- Navigation states.
- Breadcrumb dan page identity.

Konten dashboard FreeSpace akan dikerjakan pada tahap terpisah.

==================================================
3. IDENTITAS APLIKASI
==================================================

Ganti teks brand pada sidebar kiri atas:

Sebelumnya:
Aset SV IPB

Menjadi:
FreeSpace

Ganti subtitle:

Sebelumnya:
Manajemen Aset

Menjadi:
Personal Workspace

Ketentuan:

- Pertahankan posisi wordmark.
- Pertahankan ukuran container.
- Pertahankan jarak antara logo, nama, dan subtitle.
- Pertahankan text style yang sekarang.
- Jangan memperbesar nama aplikasi secara berlebihan.
- Jangan mengubah bentuk area brand.
- Jangan mengubah tinggi header sidebar.

Jika belum tersedia logo resmi FreeSpace:

- Pertahankan circular logo container yang ada.
- Gunakan icon placeholder yang sederhana dan netral.
- Jangan membuat logo kompleks.
- Jangan mengubah ukuran circular logo.
- Jangan mengubah alignment vertikalnya.

Profile user card di bawah brand harus tetap dipertahankan.

Jangan mengubah:

- Avatar.
- Posisi avatar.
- Nama atau username yang ditampilkan.
- Tombol dropdown.
- Background card.
- Border.
- Radius.
- Padding.
- Tinggi profile card.

==================================================
4. PRINSIP INFORMATION ARCHITECTURE
==================================================

FreeSpace adalah personal web application untuk satu pengguna, khususnya mahasiswa Akuntansi.

Navigasi harus:

- Ringkas.
- Mudah dipahami.
- Tidak terasa seperti aplikasi enterprise besar.
- Tidak memiliki submenu berlebihan.
- Tidak memiliki menu yang saling tumpang tindih.
- Tidak memiliki Dashboard pada setiap modul.
- Tidak memasukkan setiap fitur kecil sebagai submenu.
- Menggunakan tab, filter, modal, drawer, section, atau segmented control untuk fitur tingkat lanjut.

Dashboard hanya ada SATU di seluruh aplikasi.

Jangan membuat:

- Dashboard Keuangan.
- Dashboard Produktivitas.
- Dashboard Library.
- Dashboard Karier.
- Dashboard Akuntansi.
- Dashboard Investasi.
- Dashboard TOEFL.
- Dashboard lainnya.

Menu Analytics juga tidak boleh menjadi menu utama tersendiri.

Analytics harus muncul pada:

- Dashboard utama.
- Halaman Budget.
- Halaman Analisis & Proyeksi.
- Halaman terkait sesuai konteks.

==================================================
5. STRUKTUR SIDEBAR FINAL
==================================================

Gunakan hierarchy berikut secara persis.

MENU UTAMA

Dashboard

Keuangan
- Transaksi
- Budget
- Analisis & Proyeksi
- Kondisi Keuangan
- Investasi
- Akuntansi
- SPT Orang Pribadi

Produktivitas
- Aktivitas
- Jurnal Harian
- Bible Harian
- Steps Tracker

Library
- Koleksi Buku
- Baca Buku
- Accounting Space

Karier
- CV Builder
- ATS Analyzer
- TOEFL Training
- Interview Simulator

SISTEM

History

Profil & Pengaturan
- Profil
- Preferensi
- Pengaturan Data
- Pengaturan Notifikasi
- Keamanan & Data

==================================================
6. STRUKTUR VISUAL SIDEBAR
==================================================

Pertahankan pola desain sidebar yang ada saat ini.

Gunakan dua section label:

1. MENU UTAMA
2. SISTEM

Section label harus menggunakan visual style yang sama dengan label seperti “MASTER DATA”, “TRANSAKSI”, atau “SISTEM” pada desain lama:

- Uppercase.
- Ukuran kecil.
- Letter spacing yang sama.
- Warna muted.
- Padding horizontal yang sama.
- Margin atas dan bawah yang sama.

Susunan visual:

Brand FreeSpace
Profile user card

MENU UTAMA
Dashboard
Keuangan
Produktivitas
Library
Karier

SISTEM
History
Profil & Pengaturan

Jangan membuat terlalu banyak section label.

Jangan membuat section terpisah untuk setiap modul.

Jangan membuat label:

- Keuangan sebagai section tanpa parent menu.
- Produktivitas sebagai section tanpa parent menu.
- Library sebagai section tanpa parent menu.
- Karier sebagai section tanpa parent menu.

Keuangan, Produktivitas, Library, Karier, dan Profil & Pengaturan harus menjadi expandable parent menu.

==================================================
7. ATURAN DASHBOARD
==================================================

Dashboard adalah single-level menu.

Dashboard:

- Tidak memiliki chevron.
- Tidak memiliki submenu.
- Tidak memiliki child bernama Eksekutif.
- Tidak memiliki child bernama Analitik.
- Tidak memiliki child bernama Keuangan.
- Tidak memiliki child bernama Kondisi.
- Tidak memiliki child bernama Monitoring.
- Tidak memiliki child bernama Utilisasi.
- Tidak memiliki child lainnya.

Hapus submenu Dashboard lama:

- Eksekutif
- Analitik
- Keuangan
- Kondisi
- Monitoring
- Utilisasi
- Pengadaan
- Maintenance

Pada kondisi default frame utama:

- Dashboard menjadi menu aktif.
- Gunakan active background yang sama seperti desain lama.
- Gunakan text weight aktif yang sama.
- Gunakan icon active state yang sama.
- Semua parent menu lain dalam kondisi collapsed.

Breadcrumb pada topbar:

Sebelumnya:
Dashboard > Eksekutif

Menjadi:
Dashboard

Jangan menampilkan second-level breadcrumb ketika Dashboard aktif.

Judul halaman:

Dashboard

Subtitle halaman:

Ringkasan aktivitas, keuangan, pembelajaran, dan progres pribadi.

Hanya ubah teks judul dan subtitle. Jangan mengubah posisi, ukuran, style, atau spacing.

==================================================
8. MENU KEUANGAN
==================================================

Keuangan adalah expandable parent menu.

Children:

1. Transaksi
2. Budget
3. Analisis & Proyeksi
4. Kondisi Keuangan
5. Investasi
6. Akuntansi
7. SPT Orang Pribadi

Jangan menampilkan fitur berikut sebagai submenu tambahan pada sidebar:

Pada Transaksi:

- Semua Transaksi
- Pemasukan
- Pengeluaran
- Transfer
- Transaksi Berulang
- Tambah Transaksi
- Kategori
- Sumber Dana
- Lampiran

Fitur tersebut akan ditempatkan sebagai:

- Tabs.
- Filter.
- Button.
- Form.
- Modal.
- Page section.

Pada Budget, jangan membuat sidebar child tambahan:

- Rencana
- Realisasi
- Evaluasi

Ketiganya harus menjadi tab pada halaman Budget.

Pada Analisis & Proyeksi, jangan membuat sidebar child tambahan:

- Analisis
- Proyeksi
- Skenario

Ketiganya harus menjadi tab pada halaman Analisis & Proyeksi.

Pada Kondisi Keuangan, jangan membuat sidebar child tambahan:

- Aset
- Utang & Piutang
- Kekayaan Bersih
- Target & Kesehatan Keuangan

Keempatnya harus menjadi tab atau segmented navigation pada halaman Kondisi Keuangan.

Pada Investasi, jangan membuat sidebar child tambahan:

- Market
- Watchlist
- Portofolio
- Transaksi Investasi
- Saham Indonesia
- Saham Amerika Serikat
- Indeks Pasar
- Detail Emiten

Fitur tersebut menjadi tab, filter, atau section halaman Investasi.

Pada Akuntansi, jangan membuat sidebar child tambahan:

- Jurnal
- Buku Besar
- Neraca Saldo
- Penyesuaian
- Laporan Keuangan
- Jurnal Manual
- Jurnal Otomatis
- Review AI
- Upload Bukti Transaksi

Semua fitur tersebut akan menjadi internal page navigation di modul Akuntansi.

Pada SPT Orang Pribadi, jangan membuat sidebar child tambahan:

- Data Wajib Pajak
- Penghasilan
- Harta dan Utang
- Perhitungan SPT
- Ringkasan dan Export

Gunakan stepper atau tabs di dalam halaman SPT Orang Pribadi.

==================================================
9. MENU PRODUKTIVITAS
==================================================

Produktivitas adalah expandable parent menu.

Children:

1. Aktivitas
2. Jurnal Harian
3. Bible Harian
4. Steps Tracker

Jangan membuat child tambahan pada Aktivitas untuk:

- Daftar Aktivitas
- Kalender
- Aktivitas Selesai
- Prioritas
- Deadline
- Aktivitas Berulang
- Pengingat H-1
- Kategori

Gunakan tabs, filters, badges, atau page sections.

Jangan membuat child tambahan pada Jurnal Harian untuk:

- Tulis Jurnal
- Riwayat Jurnal
- Mood
- Refleksi
- Hal yang Disyukuri
- Pelajaran Hari Ini
- Rencana Besok

Gunakan tabs, editor state, atau sections pada halaman Jurnal Harian.

Jangan membuat child tambahan pada Bible Harian untuk:

- Baca Alkitab
- Catatan dan Refleksi
- Riwayat Bacaan
- Highlight
- Bookmark
- Intisari
- Value
- Makna

Gunakan internal tabs atau reader toolbar.

Jangan membuat child tambahan pada Steps Tracker untuk:

- Input Langkah
- Riwayat
- Progress
- Statistik Harian
- Statistik Mingguan
- Statistik Bulanan

Gunakan filters dan page sections.

==================================================
10. MENU LIBRARY
==================================================

Library adalah expandable parent menu.

Children:

1. Koleksi Buku
2. Baca Buku
3. Accounting Space

Jangan membuat child tambahan pada Koleksi Buku untuk:

- Semua Buku
- Upload Buku
- Kategori Buku
- Favorit
- Arsip

Gunakan filter, tabs, dan upload button.

Jangan membuat child tambahan pada Baca Buku untuk:

- Sedang Dibaca
- Riwayat Bacaan
- PDF Viewer
- Highlight
- Bookmark
- Catatan per Halaman
- Ringkasan
- Kesimpulan
- Progress Membaca

Fitur tersebut berada di reader interface.

Jangan membuat child tambahan pada Accounting Space untuk:

- Buku Akuntansi
- Catatan Akuntansi
- Latihan Jurnal

Gunakan tabs pada halaman Accounting Space.

==================================================
11. MENU KARIER
==================================================

Karier adalah expandable parent menu.

Children:

1. CV Builder
2. ATS Analyzer
3. TOEFL Training
4. Interview Simulator

Jangan membuat child tambahan pada CV Builder untuk:

- Daftar CV
- Editor CV
- Preview
- Export
- Informasi Pribadi
- Pendidikan
- Pengalaman
- Skill
- Sertifikasi
- Proyek

Gunakan internal editor navigation atau step navigation.

Jangan membuat child tambahan pada ATS Analyzer untuk:

- Analisis CV
- Riwayat Analisis
- Upload CV
- Job Description
- ATS Score
- Keyword Matching
- Rekomendasi
- Optimasi AI

Gunakan tabs atau sections.

Jangan membuat child tambahan pada TOEFL Training untuk:

- Latihan
- Simulasi Tes
- Hasil
- Progress
- Listening
- Structure
- Reading

Gunakan tabs atau pre-test selection interface.

Jangan membuat child tambahan pada Interview Simulator untuk:

- Latihan Interview
- Simulasi Interview
- Hasil dan Feedback
- Akuntansi
- Audit
- Keuangan
- Perpajakan

Gunakan tabs, cards, atau setup screen sebelum simulasi.

==================================================
12. HISTORY
==================================================

History adalah single-level menu.

History:

- Tidak memiliki chevron.
- Tidak memiliki submenu.
- Menggunakan icon history atau clock.
- Ditempatkan pada section SISTEM.
- Digunakan untuk melihat riwayat aktivitas pengguna di seluruh modul.

Jangan membuat submenu berdasarkan modul di bawah History.

Filter modul akan ditempatkan di halaman History.

==================================================
13. PROFIL & PENGATURAN
==================================================

Profil & Pengaturan adalah expandable parent menu.

Children:

1. Profil
2. Preferensi
3. Pengaturan Data
4. Pengaturan Notifikasi
5. Keamanan & Data

Pengaturan Notifikasi berarti halaman untuk mengatur preferensi notifikasi.

Inbox notifikasi tetap diakses melalui ikon lonceng pada topbar.

Jangan menambahkan menu “Notifikasi” lain sebagai notification inbox pada sidebar.

Keamanan & Data nantinya mencakup:

- Ubah Password
- Two-Factor Authentication
- Backup Otomatis
- Backup Manual
- Restore Data
- Import Data
- Export Data
- Hapus Data

Semua fungsi tersebut tidak perlu dibuat sebagai submenu sidebar.

==================================================
14. TOPBAR
==================================================

Pertahankan topbar yang ada secara penuh.

Jangan mengubah:

- Tinggi topbar.
- Background.
- Border bawah.
- Posisi breadcrumb.
- Search field.
- Lebar search field.
- Shortcut indicator di dalam search.
- Tombol Tanya AI.
- Style tombol Tanya AI.
- Ikon Tanya AI.
- Notification button.
- Notification badge.
- Share button.
- Spacing antar-action.
- Alignment vertikal.

Tombol “Tanya AI” tetap berada di topbar.

Tanya AI tidak menjadi menu sidebar.

Search tetap berada di topbar.

Notifikasi tetap berada di topbar.

Share/action button tetap dipertahankan.

Profile user tetap berada pada bagian atas sidebar, bukan dipindahkan ke topbar.

==================================================
15. ICONOGRAPHY
==================================================

Gunakan gaya icon yang sama dengan desain saat ini.

Ketentuan:

- Gunakan line icon.
- Gunakan stroke width yang konsisten.
- Pertahankan ukuran icon lama.
- Pertahankan icon container.
- Jangan menggunakan icon 3D.
- Jangan menggunakan icon berwarna-warni.
- Jangan mencampur beberapa gaya icon.
- Prioritaskan Heroicons atau icon set yang sama dengan desain lama.

Rekomendasi pemetaan icon:

Dashboard:
Squares 2x2 atau Home

Keuangan:
Wallet atau Banknotes

Transaksi:
Arrows Right Left atau Receipt

Budget:
Chart Pie

Analisis & Proyeksi:
Presentation Chart Line

Kondisi Keuangan:
Scale atau Banknotes

Investasi:
Arrow Trending Up

Akuntansi:
Calculator atau Book Open

SPT Orang Pribadi:
Document Text

Produktivitas:
Check Circle atau Clipboard Document Check

Aktivitas:
Calendar Days

Jurnal Harian:
Pencil Square

Bible Harian:
Book Open

Steps Tracker:
Map atau Map Pin

Library:
Book Open

Koleksi Buku:
Rectangle Stack

Baca Buku:
Book Open atau Eye

Accounting Space:
Academic Cap

Karier:
Briefcase

CV Builder:
Document Plus

ATS Analyzer:
Document Magnifying Glass

TOEFL Training:
Language

Interview Simulator:
Chat Bubble Left Right

History:
Clock atau Arrow Path

Profil & Pengaturan:
Cog 6 Tooth

Gunakan icon parent menu pada baris parent.

Submenu dapat menggunakan dot indicator seperti pada desain lama apabila itu adalah pola existing.

==================================================
16. INTERACTION DAN STATE
==================================================

Buat sidebar sebagai reusable component.

Buat state berikut:

1. Default
2. Hover
3. Active
4. Expanded
5. Collapsed
6. Active child
7. Disabled jika pattern tersebut sudah tersedia

Aturan accordion:

- Dashboard tidak expandable.
- History tidak expandable.
- Keuangan expandable.
- Produktivitas expandable.
- Library expandable.
- Karier expandable.
- Profil & Pengaturan expandable.
- Hanya satu parent menu yang terbuka pada satu waktu.
- Membuka parent baru menutup parent sebelumnya.
- Chevron mengarah ke kanan ketika collapsed.
- Chevron berputar ke bawah ketika expanded.
- Gunakan durasi prototype transition yang halus.
- Jangan menggunakan animasi mencolok.
- Gunakan Smart Animate apabila sesuai dengan component structure.

Active parent:

- Gunakan background yang sama dengan active menu lama.
- Gunakan font weight yang sama.
- Gunakan warna text yang sama.
- Gunakan icon color yang sama.

Active child:

- Gunakan bentuk highlight child yang sama dengan child “Eksekutif” pada desain lama.
- Pertahankan indentation.
- Pertahankan dot indicator.
- Pertahankan radius.
- Pertahankan tinggi item.

Hover:

- Gunakan perubahan background ringan.
- Jangan menambahkan shadow baru.
- Jangan mengubah ukuran item.
- Jangan menggeser layout.

==================================================
17. DEFAULT STATE FRAME UTAMA
==================================================

Pada frame utama yang menggantikan screenshot saat ini:

- Dashboard aktif.
- Dashboard tidak memiliki submenu.
- Keuangan collapsed.
- Produktivitas collapsed.
- Library collapsed.
- Karier collapsed.
- Profil & Pengaturan collapsed.
- History inactive.
- Breadcrumb hanya menunjukkan Dashboard.
- Topbar tetap sama.
- Profile user card tetap sama.
- Main dashboard layout tetap sama.

Karena semua parent collapsed, sidebar utama harus terlihat ringkas dan tidak penuh.

==================================================
18. COMPONENT VARIANTS YANG HARUS DIBUAT
==================================================

Buat variant atau preview state untuk:

Variant A:
Dashboard aktif, semua parent collapsed.

Variant B:
Keuangan expanded, Transaksi aktif.

Variant C:
Produktivitas expanded, Aktivitas aktif.

Variant D:
Library expanded, Koleksi Buku aktif.

Variant E:
Karier expanded, CV Builder aktif.

Variant F:
Profil & Pengaturan expanded, Profil aktif.

Variant G:
History aktif, semua accordion collapsed.

Tidak perlu menduplikasi seluruh halaman untuk semua variant jika component variants sudah dapat menunjukkan state tersebut.

Gunakan component properties seperti:

- activeParent
- activeChild
- expandedSection
- sidebarCollapsed
- showSectionLabel

Nama properties harus jelas dan konsisten.

==================================================
19. AUTO LAYOUT DAN COMPONENT STRUCTURE
==================================================

Gunakan Auto Layout pada sidebar.

Struktur yang direkomendasikan:

Sidebar
- Brand block
- Profile card
- Navigation scroll container
  - Section label: MENU UTAMA
  - Dashboard item
  - Keuangan accordion
  - Produktivitas accordion
  - Library accordion
  - Karier accordion
  - Section label: SISTEM
  - History item
  - Profil & Pengaturan accordion
- Bottom utility area jika sudah tersedia pada design system

Pertahankan:

- Existing sidebar width.
- Existing horizontal padding.
- Existing gap.
- Existing item height.
- Existing submenu indentation.
- Existing vertical rhythm.

Navigation scroll container harus:

- Mengisi sisa tinggi sidebar.
- Scroll secara vertikal jika konten lebih tinggi daripada viewport.
- Tidak membuat seluruh halaman ikut bergeser.
- Tidak menutupi profile card.
- Tidak menutupi bottom utility area.

Gunakan text resizing:

- Fixed atau Hug Contents sesuai component lama.
- Hindari text overflow.
- Hindari menu terpotong.
- Jangan mengecilkan font hanya untuk memaksakan teks masuk.
- Pertahankan ukuran text existing.

Nama submenu seperti:

- Analisis & Proyeksi
- SPT Orang Pribadi
- Interview Simulator
- Profil & Pengaturan
- Pengaturan Notifikasi

harus tetap terbaca jelas.

==================================================
20. RESPONSIVE BEHAVIOR
==================================================

Prioritas utama:

1. Laptop desktop.
2. iPad landscape.
3. iPad portrait.

Desktop:

- Sidebar tampil penuh.
- Topbar tampil penuh.
- Profile card tampil penuh.
- Label menu dan submenu tampil penuh.

iPad landscape:

- Pertahankan sidebar apabila ruang cukup.
- Jika existing system mendukung collapse, gunakan collapsed state.
- Jangan mengubah gaya visual.
- Main content tetap menggunakan existing responsive grid.

iPad portrait:

- Sidebar berubah menjadi off-canvas drawer.
- Gunakan komponen sidebar yang sama.
- Jangan membuat navigation design baru.
- Profile card tetap berada di bagian atas drawer.
- Topbar tetap mempertahankan search dan action sesuai ruang.
- Sidebar drawer menutup setelah child menu dipilih.

Mobile, apabila dibuat:

- Gunakan hamburger untuk membuka sidebar drawer.
- Jangan mengubah hierarchy.
- Jangan membuat bottom navigation baru.
- Jangan memindahkan semua menu menjadi icon-only bottom bar.

==================================================
21. ACCESSIBILITY
==================================================

Pastikan:

- Area klik menu cukup besar.
- Text tidak terlalu kecil.
- Kontras active dan inactive tetap terbaca.
- Active state tidak hanya dibedakan berdasarkan warna.
- Chevron memiliki state yang jelas.
- Focus state dapat ditambahkan tanpa merusak visual.
- Icon memiliki label pada prototype atau component description.
- Menu tidak bergantung pada hover untuk dapat dibuka.

==================================================
22. LARANGAN KHUSUS
==================================================

Jangan membuat menu berikut:

- Overview
- Data Aset
- Peralatan & Mesin
- Aset Tak Berwujud
- Aset Tetap Lainnya
- Alat Angkutan
- Lokasi & Ruangan
- Penanggung Jawab
- Mutasi Aset
- Perbaikan
- Stock Opname
- Pengadaan
- Maintenance
- Dokumen Aset
- Aktivitas Aset
- Pengguna

Hapus semua istilah yang berhubungan dengan sistem Manajemen Aset IPB dari sidebar.

Jangan membuat:

- Menu Dashboard dengan submenu.
- Menu Analytics terpisah.
- Menu AI Assistant di sidebar.
- Menu File Manager di sidebar.
- Menu notification inbox di sidebar.
- Menu Backup terpisah di sidebar.
- Menu Settings lama yang berdiri sendiri.
- Menu Help Center lama apabila tidak dibutuhkan.
- Menu dengan tiga atau empat tingkat hierarchy.
- Semua detail fitur sebagai submenu.

Maksimal hierarchy sidebar:

Level 1:
Parent menu.

Level 2:
Child menu.

Tidak boleh ada level 3 di sidebar.

==================================================
23. NAMING CONSISTENCY
==================================================

Gunakan label persis berikut:

FreeSpace
Personal Workspace
Dashboard
Keuangan
Transaksi
Budget
Analisis & Proyeksi
Kondisi Keuangan
Investasi
Akuntansi
SPT Orang Pribadi
Produktivitas
Aktivitas
Jurnal Harian
Bible Harian
Steps Tracker
Library
Koleksi Buku
Baca Buku
Accounting Space
Karier
CV Builder
ATS Analyzer
TOEFL Training
Interview Simulator
History
Profil & Pengaturan
Profil
Preferensi
Pengaturan Data
Pengaturan Notifikasi
Keamanan & Data

Jangan mengganti menjadi sinonim tanpa alasan.

Jangan menggunakan campuran istilah lain seperti:

- Finance Center
- Money Manager
- Career Center
- Books
- Daily Log
- Tax Center

Gunakan bahasa Indonesia sesuai daftar, kecuali nama fitur yang memang telah ditentukan dalam bahasa Inggris.

==================================================
24. FIGMA LAYER NAMING
==================================================

Rapikan nama layer dan component.

Contoh:

Sidebar/FreeSpace
Sidebar/Brand
Sidebar/ProfileCard
Sidebar/SectionLabel
Sidebar/NavItem
Sidebar/NavItem/Parent
Sidebar/NavItem/Child
Sidebar/Accordion
Sidebar/State/DashboardActive
Sidebar/State/FinanceExpanded
Sidebar/State/ProductivityExpanded
Sidebar/State/LibraryExpanded
Sidebar/State/CareerExpanded
Sidebar/State/SettingsExpanded

Gunakan nama layer yang mudah dibaca.

Hindari nama:

- Frame 123
- Group 88
- Rectangle 141
- Copy 5
- New Component

Jangan detach existing component kecuali benar-benar diperlukan.

Gunakan overrides pada instance selama memungkinkan.

==================================================
25. OUTPUT YANG DIHARAPKAN
==================================================

Hasil akhir harus mencakup:

1. Existing desktop frame yang telah diperbarui.
2. Brand FreeSpace pada sidebar.
3. Profile card yang tetap sama.
4. Topbar yang tetap sama.
5. Dashboard sebagai single menu.
6. Struktur sidebar baru.
7. Accordion state yang konsisten.
8. Sidebar component variants.
9. Active dan hover state.
10. Breadcrumb Dashboard.
11. Tidak ada istilah Manajemen Aset pada sidebar.
12. Tidak ada menu yang tidak berasal dari requirement.
13. Tidak ada perubahan visual besar.
14. Tidak ada redesign dashboard.
15. Tidak ada penambahan dashboard lain.
16. Tidak ada hierarchy lebih dari dua tingkat.

==================================================
26. ACCEPTANCE CHECKLIST
==================================================

Sebelum menyelesaikan desain, periksa seluruh poin berikut.

VISUAL PRESERVATION

[ ] Sidebar memiliki ukuran yang sama.
[ ] Topbar memiliki ukuran yang sama.
[ ] Profile user card tetap di posisi semula.
[ ] Search field tetap sama.
[ ] Tombol Tanya AI tetap sama.
[ ] Notification button tetap sama.
[ ] Share button tetap sama.
[ ] Typography tetap sama.
[ ] Color palette tetap sama.
[ ] Border dan shadow tetap sama.
[ ] Main content tidak didesain ulang.

BRANDING

[ ] Nama aplikasi menjadi FreeSpace.
[ ] Subtitle menjadi Personal Workspace.
[ ] Logo container tidak berubah.
[ ] Profile user tidak berubah.

NAVIGATION

[ ] Dashboard hanya satu.
[ ] Dashboard tidak memiliki submenu.
[ ] Keuangan memiliki tujuh children.
[ ] Produktivitas memiliki empat children.
[ ] Library memiliki tiga children.
[ ] Karier memiliki empat children.
[ ] History tidak memiliki submenu.
[ ] Profil & Pengaturan memiliki lima children.
[ ] Tidak ada hierarchy level 3.
[ ] Tidak semua accordion terbuka bersamaan.

FEATURE PLACEMENT

[ ] Tab Budget tidak dijadikan submenu.
[ ] Tab Analisis & Proyeksi tidak dijadikan submenu.
[ ] Tab Kondisi Keuangan tidak dijadikan submenu.
[ ] Detail Akuntansi tidak dijadikan submenu.
[ ] Detail SPT tidak dijadikan submenu.
[ ] Detail reader tidak dijadikan submenu.
[ ] Detail CV tidak dijadikan submenu.
[ ] Detail TOEFL tidak dijadikan submenu.
[ ] Detail Interview tidak dijadikan submenu.
[ ] Notification inbox tetap di topbar.
[ ] Tanya AI tetap di topbar.
[ ] Backup berada di Keamanan & Data.
[ ] Analytics tidak menjadi menu utama.

CLEANUP

[ ] Semua menu lama manajemen aset telah dihapus.
[ ] Tidak ada teks “Eksekutif” di bawah Dashboard.
[ ] Tidak ada teks “Data Aset”.
[ ] Tidak ada teks “Stock Opname”.
[ ] Tidak ada teks “Maintenance”.
[ ] Tidak ada teks “Pengadaan”.
[ ] Tidak ada submenu lama yang tersisa.
[ ] Layer telah diberi nama dengan jelas.

==================================================
27. FINAL EXECUTION INSTRUCTION
==================================================

Edit frame yang sekarang secara langsung.

Jangan membuat konsep alternatif.

Jangan membuat moodboard.

Jangan membuat desain baru.

Jangan mengganti visual language.

Jangan menambahkan fitur di luar requirement.

Pertahankan seluruh desain existing dan lakukan perubahan secara presisi hanya pada:

- App identity.
- Sidebar label.
- Menu.
- Submenu.
- Icon navigation.
- Navigation state.
- Breadcrumb.
- Page title identity.

Tujuan akhirnya adalah agar pengguna tetap mengenali desain lama secara visual, tetapi seluruh navigation architecture-nya sudah menjadi aplikasi FreeSpace.