
  # FreeSpace

  This is a code bundle for FreeSpace. The original project is available at https://www.figma.com/design/ts1T6by0DWWQJwaS1MxbOp/FreeSpace.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  