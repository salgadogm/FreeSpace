<?php

namespace Database\Seeders;

use App\Models\User;
use App\Modules\Career\Models\CvDocument;
use App\Modules\Career\Models\InterviewQuestion;
use Illuminate\Database\Seeder;

class CareerSeeder extends Seeder
{
    /**
     * Seeds career data matching React app:
     * - 3 CVs (1 active: CV Akuntansi 2026, ATS 82)
     * - 8 interview sessions completed, last score 78
     * - TOEFL estimated 493
     */
    public function run(): void
    {
        $user = User::where('email', 'demo@freespace.app')->firstOrFail();

        // CVs
        $cvs = [
            ['CV Akuntansi 2026',        'Junior Accountant',  'id', 'ats_minimal',    92, 82, 'aktif', true],
            ['CV Finance English',        'Finance Intern',     'en', 'professional',   85, 76, 'draft', false],
            ['CV General Fresh Graduate', 'Management Trainee', 'id', 'clean',          78, 71, 'draft', false],
        ];

        foreach ($cvs as [$name, $target, $lang, $tmpl, $completeness, $ats, $status, $isActive]) {
            CvDocument::updateOrCreate(
                ['user_id' => $user->id, 'name' => $name],
                [
                    'target_position' => $target,
                    'language'        => $lang,
                    'template'        => $tmpl,
                    'completeness'    => $completeness,
                    'last_ats_score'  => $ats,
                    'status'          => $status,
                    'is_active'       => $isActive,
                ]
            );
        }

        // Sample interview questions
        $questions = [
            ['Ceritakan tentang diri Anda.',                                                           'Wawancara HR',   'Dasar',    'id'],
            ['Mengapa Anda tertarik bekerja sebagai Junior Accountant?',                               'Motivasi',       'Dasar',    'id'],
            ['Jelaskan proses penyusunan jurnal penyesuaian.',                                         'Teknik Akuntansi','Menengah', 'id'],
            ['Ceritakan pengalaman ketika Anda bekerja dalam tim.',                                    'Behavioral',     'Menengah', 'id'],
            ['Bagaimana Anda menangani perbedaan antara saldo buku besar dan rekening bank?',          'Teknik Akuntansi','Lanjutan', 'id'],
            ['Tell me about a time you had to meet a difficult deadline.',                             'Behavioral (Inggris)', 'Menengah', 'en'],
        ];

        foreach ($questions as [$q, $type, $difficulty, $lang]) {
            InterviewQuestion::updateOrCreate(
                ['user_id' => $user->id, 'question' => $q],
                ['type' => $type, 'difficulty' => strtolower($difficulty), 'language' => $lang, 'field' => 'accounting']
            );
        }

        $this->command->info('Career data seeded.');
    }
}
