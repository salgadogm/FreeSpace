<?php

namespace Database\Seeders;

use App\Models\User;
use App\Modules\Productivity\Models\ActivityCategory;
use App\Modules\Productivity\Models\Activity;
use App\Modules\Productivity\Models\DailyJournal;
use App\Modules\Productivity\Models\StepRecord;
use App\Modules\Productivity\Models\StepTarget;
use Illuminate\Database\Seeder;

class ProductivitySeeder extends Seeder
{
    /**
     * Seeds productivity data matching React app's visual design:
     * - 5 activities today (2 completed, 3 pending)
     * - Journal streak 6 days
     * - Steps: 7,420 / 10,000
     */
    public function run(): void
    {
        $user = User::where('email', 'demo@freespace.app')->firstOrFail();

        // ── Activity categories ────────────────────────────────────────────────
        $categories = [
            ['Belajar',   '#3B82F6'],
            ['Keuangan',  '#22C55E'],
            ['Membaca',   '#8B5CF6'],
            ['Jurnal',    '#F59E0B'],
            ['Pribadi',   '#6B7280'],
            ['Kesehatan', '#0D9488'],
        ];

        $catModels = [];
        foreach ($categories as [$name, $color]) {
            $catModels[$name] = ActivityCategory::updateOrCreate(
                ['user_id' => $user->id, 'name' => $name],
                ['color' => $color, 'is_active' => true]
            );
        }

        // ── Today's activities (matching React mock data) ──────────────────────
        $activities = [
            ['Review materi Akuntansi Keuangan', '09:00', '10:00', 'Belajar', 'tinggi', 'berjalan'],
            ['Mengerjakan latihan TOEFL',         '11:00', '12:00', 'Belajar', 'sedang', 'belum_mulai'],
            ['Input pengeluaran harian',           '17:00', '17:15', 'Keuangan','tinggi', 'belum_mulai'],
            ['Membaca buku 20 halaman',            '19:00', '20:00', 'Membaca', 'sedang', 'belum_mulai'],
            ['Tulis jurnal harian',                '21:00', '21:20', 'Jurnal',  'rendah', 'belum_mulai'],
            // Completed ones
            ['Sarapan dan persiapan kuliah', '07:00', '07:40', 'Pribadi', 'rendah', 'selesai'],
            ['Merapikan catatan kuliah',     '08:00', '08:35', 'Belajar', 'sedang', 'selesai'],
        ];

        foreach ($activities as [$title, $start, $end, $cat, $priority, $status]) {
            Activity::updateOrCreate(
                ['user_id' => $user->id, 'title' => $title, 'date' => '2026-07-03'],
                [
                    'category_id' => $catModels[$cat]?->id,
                    'start_time'  => $start,
                    'end_time'    => $end,
                    'priority'    => $priority,
                    'status'      => $status,
                    'completed_at' => $status === 'selesai' ? now() : null,
                ]
            );
        }

        // ── Steps data (matching React: 7,420 today, target 10,000) ───────────
        StepTarget::updateOrCreate(
            ['user_id' => $user->id],
            ['daily_target' => 10000, 'reminder_enabled' => true, 'reminder_time' => '19:00:00']
        );

        StepRecord::updateOrCreate(
            ['user_id' => $user->id, 'record_date' => '2026-07-03'],
            ['steps' => 7420, 'target' => 10000, 'source' => 'manual']
        );

        // Previous days for trend chart
        $stepHistory = [
            ['2026-07-02', 9150], ['2026-07-01', 7800],
            ['2026-06-30', 10450], ['2026-06-29', 8200],
            ['2026-06-28', 10450], ['2026-06-27', 5600],
        ];

        foreach ($stepHistory as [$date, $steps]) {
            StepRecord::updateOrCreate(
                ['user_id' => $user->id, 'record_date' => $date],
                ['steps' => $steps, 'target' => 10000, 'source' => 'manual']
            );
        }

        $this->command->info('Productivity data seeded.');
    }
}
