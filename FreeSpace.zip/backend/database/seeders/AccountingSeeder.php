<?php

namespace Database\Seeders;

use App\Models\User;
use App\Modules\Accounting\Models\ChartOfAccounts;
use App\Modules\Accounting\Models\AccountingPeriod;
use Illuminate\Database\Seeder;

class AccountingSeeder extends Seeder
{
    /**
     * Seeds default chart of accounts and an active accounting period.
     */
    public function run(): void
    {
        $user = User::where('email', 'demo@freespace.app')->firstOrFail();

        // ── Default chart of accounts ─────────────────────────────────────────
        $accounts = [
            ['101', 'Kas',                   'asset',    'debit',  true],
            ['102', 'Bank',                  'asset',    'debit',  true],
            ['103', 'Piutang Usaha',         'asset',    'debit',  false],
            ['104', 'Perlengkapan Kantor',   'asset',    'debit',  false],
            ['110', 'Peralatan',             'asset',    'debit',  false],
            ['201', 'Utang Usaha',           'liability','credit', true],
            ['202', 'Utang Gaji',            'liability','credit', false],
            ['301', 'Modal',                 'equity',   'credit', true],
            ['302', 'Laba Ditahan',          'equity',   'credit', false],
            ['401', 'Pendapatan Jasa',       'revenue',  'credit', true],
            ['402', 'Pendapatan Lain-lain',  'revenue',  'credit', false],
            ['501', 'Beban Gaji',            'expense',  'debit',  false],
            ['502', 'Beban Sewa',            'expense',  'debit',  false],
            ['503', 'Beban Listrik',         'expense',  'debit',  false],
            ['504', 'Beban Perlengkapan',    'expense',  'debit',  false],
            ['505', 'Beban Penyusutan',      'expense',  'debit',  false],
            ['506', 'Beban Lain-lain',       'expense',  'debit',  false],
        ];

        foreach ($accounts as [$code, $name, $type, $normal, $isSystem]) {
            ChartOfAccounts::updateOrCreate(
                ['user_id' => $user->id, 'code' => $code],
                ['name' => $name, 'type' => $type, 'normal_balance' => $normal, 'is_system' => $isSystem, 'is_active' => true]
            );
        }

        // ── Active accounting period (July 2026) ──────────────────────────────
        AccountingPeriod::updateOrCreate(
            ['user_id' => $user->id, 'name' => 'Juli 2026'],
            ['start_date' => '2026-07-01', 'end_date' => '2026-07-31', 'status' => 'open']
        );

        $this->command->info('Accounting data seeded.');
    }
}
