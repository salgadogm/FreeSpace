<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            UserSeeder::class,
            FinanceSeeder::class,
            AccountingSeeder::class,
            ProductivitySeeder::class,
            LibrarySeeder::class,
            CareerSeeder::class,
        ]);
    }
}
