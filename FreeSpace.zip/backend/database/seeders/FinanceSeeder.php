<?php

namespace Database\Seeders;

use App\Models\User;
use App\Modules\Finance\Models\FinancialAccount;
use App\Modules\Finance\Models\TransactionCategory;
use App\Modules\Finance\Models\FinancialTransaction;
use App\Modules\Finance\Models\Budget;
use Illuminate\Database\Seeder;

class FinanceSeeder extends Seeder
{
    /**
     * Seeds finance data matching the React app's visual design.
     * Dashboard shows: Saldo Rp4.85 juta, Pemasukan Rp6.5 juta, Pengeluaran Rp3.15 juta.
     */
    public function run(): void
    {
        $user = User::where('email', 'demo@freespace.app')->firstOrFail();

        // ── Accounts ──────────────────────────────────────────────────────────
        $bankAccount = FinancialAccount::updateOrCreate(
            ['user_id' => $user->id, 'name' => 'Bank Utama'],
            ['type' => 'bank', 'initial_balance_minor' => 150000000, 'is_default' => true, 'currency' => 'IDR']
        );

        $eWallet = FinancialAccount::updateOrCreate(
            ['user_id' => $user->id, 'name' => 'E-Wallet'],
            ['type' => 'dompet_digital', 'initial_balance_minor' => 50000000, 'currency' => 'IDR']
        );

        $cash = FinancialAccount::updateOrCreate(
            ['user_id' => $user->id, 'name' => 'Tunai'],
            ['type' => 'kas', 'initial_balance_minor' => 25000000, 'currency' => 'IDR']
        );

        // ── Categories ────────────────────────────────────────────────────────
        $categories = [
            ['Makanan', 'expense', '#3B82F6'],
            ['Transportasi', 'expense', '#8B5CF6'],
            ['Pendidikan', 'expense', '#22C55E'],
            ['Hiburan', 'expense', '#F59E0B'],
            ['Tagihan', 'expense', '#EF4444'],
            ['Lainnya', 'expense', '#6B7280'],
            ['Uang Saku', 'income', '#22C55E'],
            ['Freelance', 'income', '#3B82F6'],
            ['Beasiswa', 'income', '#8B5CF6'],
        ];

        $catModels = [];
        foreach ($categories as [$name, $type, $color]) {
            $catModels[$name] = TransactionCategory::updateOrCreate(
                ['user_id' => $user->id, 'name' => $name],
                ['type' => $type, 'color' => $color, 'is_active' => true]
            );
        }

        // ── Transactions (matching React mock data) ────────────────────────────
        $transactions = [
            // Income
            ['Uang Saku Bulan Juli', 'income', 650000000, '2026-07-01', 'Uang Saku', $bankAccount->id],
            // Expenses matching design: total ~Rp3.15 juta
            ['Makan Siang', 'expense', 3500000, '2026-07-03', 'Makanan', $eWallet->id],
            ['Transportasi Online', 'expense', 2500000, '2026-07-03', 'Transportasi', $eWallet->id],
            ['Beli Buku Akuntansi', 'expense', 8500000, '2026-07-02', 'Pendidikan', $bankAccount->id],
            ['Langganan Streaming', 'expense', 5900000, '2026-07-01', 'Hiburan', $bankAccount->id],
            ['Token Listrik', 'expense', 10000000, '2026-07-01', 'Tagihan', $bankAccount->id],
            ['Makan Malam', 'expense', 4500000, '2026-07-02', 'Makanan', $cash->id],
        ];

        foreach ($transactions as [$desc, $type, $amount, $date, $catName, $accountId]) {
            FinancialTransaction::updateOrCreate(
                ['user_id' => $user->id, 'description' => $desc, 'transaction_date' => $date],
                [
                    'type'              => $type,
                    'amount_minor'      => $amount,
                    'currency'          => 'IDR',
                    'category_id'       => $catModels[$catName]?->id,
                    'account_id'        => $accountId,
                    'transaction_date'  => $date,
                ]
            );
        }

        // ── Budget ────────────────────────────────────────────────────────────
        Budget::updateOrCreate(
            ['user_id' => $user->id, 'name' => 'Budget Juli 2026'],
            [
                'amount_minor' => 450000000,  // Rp4.5 juta
                'currency'     => 'IDR',
                'period'       => 'monthly',
                'start_date'   => '2026-07-01',
                'end_date'     => '2026-07-31',
                'alert_threshold' => 80,
                'is_active'    => true,
            ]
        );

        $this->command->info('Finance data seeded.');
    }
}
