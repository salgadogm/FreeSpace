<?php

namespace Database\Seeders;

use App\Models\User;
use App\Modules\Library\Models\Book;
use App\Modules\Library\Models\BookCategory;
use Illuminate\Database\Seeder;

class LibrarySeeder extends Seeder
{
    /**
     * Seeds library data matching React app's visual design:
     * - 18 books total (4 reading, 7 finished, 7 unread)
     * - Active book: Akuntansi Keuangan Menengah at 68%
     */
    public function run(): void
    {
        $user = User::where('email', 'demo@freespace.app')->firstOrFail();

        // Categories
        $cats = [];
        foreach (['Akuntansi','Keuangan','Produktivitas','Karier','Rohani','Pengembangan Diri','Lainnya'] as $name) {
            $cats[$name] = BookCategory::updateOrCreate(['user_id' => $user->id, 'name' => $name]);
        }

        // Books
        $books = [
            ['Akuntansi Keuangan Menengah', 'Modul Pembelajaran Pribadi', 'Akuntansi', 182, 68,  'sedang_dibaca', true,  '2026-07-03 20:15:00'],
            ['Dasar-Dasar Akuntansi',        'Materi Kuliah',              'Akuntansi', 240, 100, 'selesai',       true,  '2026-06-28'],
            ['Analisis Laporan Keuangan',     'Bahan Belajar',              'Keuangan',  215, 35,  'sedang_dibaca', false, '2026-07-01'],
            ['Manajemen Keuangan Pribadi',    'Koleksi Pribadi',            'Keuangan',  156, 8,   'sedang_dibaca', false, '2026-06-30'],
            ['Strategi Belajar Efektif',      'Koleksi Pribadi',            'Produktivitas',134,100,'selesai',      true,  '2026-06-20'],
            ['Persiapan Karier Akuntansi',    'Koleksi Pribadi',            'Karier',    198, 12,  'sedang_dibaca', false, '2026-06-29'],
            ['Catatan Refleksi Harian',       'Koleksi Pribadi',            'Rohani',    120, 100, 'selesai',       true,  '2026-06-15'],
            ['Audit dan Pengendalian Internal','Materi Kuliah',             'Akuntansi', 260, 0,   'belum_dibaca',  false, null],
        ];

        foreach ($books as [$title, $author, $cat, $pages, $pct, $status, $fav, $lastRead]) {
            $currentPage = $pages > 0 ? (int) round($pages * $pct / 100) : 0;
            Book::updateOrCreate(
                ['user_id' => $user->id, 'title' => $title],
                [
                    'category_id'     => $cats[$cat]->id,
                    'author'          => $author,
                    'total_pages'     => $pages,
                    'read_percentage' => $pct,
                    'current_page'    => $currentPage,
                    'status'          => $status,
                    'is_favorite'     => $fav,
                    'last_read_at'    => $lastRead,
                    'file_status'     => 'ready',
                    'language'        => 'id',
                ]
            );
        }

        $this->command->info('Library data seeded.');
    }
}
