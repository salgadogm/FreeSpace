<?php

namespace Database\Seeders;

use App\Models\User;
use App\Modules\System\Models\NotificationPreference;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Seed the demo user matching the React app's visual design data.
     * All mock data in the React app belongs to: Salgado Ginting.
     */
    public function run(): void
    {
        $user = User::updateOrCreate(
            ['email' => 'demo@freespace.app'],
            [
                'name'       => 'Salgado Ginting',
                'password'   => Hash::make('FreeSpace2026!'),
                'language'   => 'id',
                'timezone'   => 'Asia/Jakarta',
                'theme'      => 'light',
                'density'    => 'normal',
                'currency'   => 'IDR',
                'date_format' => 'd M Y',
                'time_format' => '24h',
                'email_verified_at' => now(),
            ]
        );

        // Notification preferences
        NotificationPreference::updateOrCreate(
            ['user_id' => $user->id],
            [
                'in_app_enabled'   => true,
                'email_enabled'    => true,
                'budget_approaching' => true,
                'journal_reminder' => true,
                'journal_reminder_time' => '21:00:00',
                'bible_reminder'   => true,
                'bible_reminder_time' => '06:30:00',
                'steps_reminder'   => true,
            ]
        );

        $this->command->info("Demo user created: demo@freespace.app / FreeSpace2026!");
    }
}
