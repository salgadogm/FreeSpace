<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // ── Book categories ────────────────────────────────────────────────────
        Schema::create('book_categories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // ── Books ──────────────────────────────────────────────────────────────
        Schema::create('books', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('category_id')->nullable()->constrained('book_categories')->nullOnDelete();
            $table->string('title');
            $table->string('author')->nullable();
            $table->text('description')->nullable();
            $table->string('language', 5)->default('id');
            $table->integer('total_pages')->nullable();
            $table->string('isbn', 30)->nullable();
            $table->year('published_year')->nullable();
            $table->json('tags')->nullable();
            $table->enum('status', ['belum_dibaca','sedang_dibaca','selesai','diarsipkan'])->default('belum_dibaca');
            $table->boolean('is_favorite')->default(false);
            $table->integer('current_page')->default(0);
            $table->integer('read_percentage')->default(0);
            $table->timestamp('last_read_at')->nullable();
            $table->enum('file_status', ['uploading','processing','ready','failed'])->default('processing');
            $table->unsignedBigInteger('file_size_bytes')->nullable();
            $table->string('subject')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->fullText('title');
        });

        // ── Book tags (pivot) ──────────────────────────────────────────────────
        Schema::create('book_tags', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->timestamps();
            $table->unique(['user_id', 'name']);
        });

        Schema::create('book_tag', function (Blueprint $table) {
            $table->foreignId('book_id')->constrained()->cascadeOnDelete();
            $table->foreignId('book_tag_id')->constrained()->cascadeOnDelete();
            $table->primary(['book_id', 'book_tag_id']);
        });

        // ── Reading sessions ───────────────────────────────────────────────────
        Schema::create('reading_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('book_id')->constrained()->cascadeOnDelete();
            $table->integer('start_page');
            $table->integer('end_page');
            $table->integer('pages_read');
            $table->timestamp('started_at');
            $table->timestamp('ended_at')->nullable();
            $table->integer('duration_minutes')->nullable();
            $table->timestamps();
            $table->index(['user_id', 'started_at']);
        });

        // ── Book bookmarks ─────────────────────────────────────────────────────
        Schema::create('book_bookmarks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('book_id')->constrained()->cascadeOnDelete();
            $table->integer('page_number');
            $table->string('label')->nullable();
            $table->timestamps();
        });

        // ── Book highlights ────────────────────────────────────────────────────
        Schema::create('book_highlights', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('book_id')->constrained()->cascadeOnDelete();
            $table->integer('page_number');
            $table->text('text_excerpt');
            $table->string('color', 20)->default('yellow');
            $table->text('note')->nullable();
            $table->timestamps();
        });

        // ── Book notes ─────────────────────────────────────────────────────────
        Schema::create('book_notes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('book_id')->nullable()->constrained()->nullOnDelete();
            $table->string('title');
            $table->string('subject')->nullable();
            $table->string('topic')->nullable();
            $table->integer('page_reference')->nullable();
            $table->string('page_range', 20)->nullable();
            $table->longText('content');            // Tiptap HTML/JSON
            $table->json('tags')->nullable();
            $table->boolean('is_favorite')->default(false);
            $table->enum('status', ['draft','tersimpan','diperbarui'])->default('tersimpan');
            $table->timestamps();
            $table->softDeletes();
            $table->fullText(['title', 'content']);
        });

        // ── Accounting learning notes (Accounting Space) ───────────────────────
        Schema::create('accounting_learning_notes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('book_id')->nullable()->constrained()->nullOnDelete();
            $table->string('title');
            $table->string('subject')->nullable();
            $table->string('topic')->nullable();
            $table->string('page_reference', 20)->nullable();
            $table->longText('content');
            $table->json('tags')->nullable();
            $table->boolean('is_favorite')->default(false);
            $table->enum('status', ['draft','tersimpan','diperbarui'])->default('tersimpan');
            $table->integer('sort_order')->default(0);
            $table->timestamps();
            $table->softDeletes();
        });

        // ── Accounting practices (Latihan Jurnal) ─────────────────────────────
        Schema::create('accounting_practices', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('title');
            $table->text('scenario');
            $table->string('topic');
            $table->enum('difficulty', ['dasar','menengah','lanjutan'])->default('dasar');
            $table->foreignId('book_id')->nullable()->constrained()->nullOnDelete();
            $table->json('correct_answer');   // [{account, debit, credit}]
            $table->text('explanation');
            $table->json('hints');
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        Schema::create('accounting_practice_attempts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('practice_id')->constrained('accounting_practices')->cascadeOnDelete();
            $table->integer('attempt_number')->default(1);
            $table->integer('score')->default(0);
            $table->integer('duration_seconds')->nullable();
            $table->enum('status', ['selesai','perlu_diulang'])->default('selesai');
            $table->timestamps();
        });

        Schema::create('accounting_practice_answers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('attempt_id')->constrained('accounting_practice_attempts')->cascadeOnDelete();
            $table->string('account_name');
            $table->bigInteger('debit_amount_minor')->default(0);
            $table->bigInteger('credit_amount_minor')->default(0);
            $table->string('description')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('accounting_practice_answers');
        Schema::dropIfExists('accounting_practice_attempts');
        Schema::dropIfExists('accounting_practices');
        Schema::dropIfExists('accounting_learning_notes');
        Schema::dropIfExists('book_notes');
        Schema::dropIfExists('book_highlights');
        Schema::dropIfExists('book_bookmarks');
        Schema::dropIfExists('reading_sessions');
        Schema::dropIfExists('book_tag');
        Schema::dropIfExists('book_tags');
        Schema::dropIfExists('books');
        Schema::dropIfExists('book_categories');
    }
};
