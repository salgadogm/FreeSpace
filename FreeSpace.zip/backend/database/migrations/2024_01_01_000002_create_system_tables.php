<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Cache
        Schema::create('cache', function (Blueprint $table) {
            $table->string('key')->primary();
            $table->mediumText('value');
            $table->integer('expiration');
        });

        Schema::create('cache_locks', function (Blueprint $table) {
            $table->string('key')->primary();
            $table->string('owner');
            $table->integer('expiration');
        });

        // Queue
        Schema::create('jobs', function (Blueprint $table) {
            $table->id();
            $table->string('queue')->index();
            $table->longText('payload');
            $table->unsignedTinyInteger('attempts');
            $table->unsignedInteger('reserved_at')->nullable();
            $table->unsignedInteger('available_at');
            $table->unsignedInteger('created_at');
        });

        Schema::create('job_batches', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->string('name');
            $table->integer('total_jobs');
            $table->integer('pending_jobs');
            $table->integer('failed_jobs');
            $table->longText('failed_job_ids');
            $table->mediumText('options')->nullable();
            $table->integer('cancelled_at')->nullable();
            $table->integer('created_at');
            $table->integer('finished_at')->nullable();
        });

        Schema::create('failed_jobs', function (Blueprint $table) {
            $table->id();
            $table->string('uuid')->unique();
            $table->text('connection');
            $table->text('queue');
            $table->longText('payload');
            $table->longText('exception');
            $table->timestamp('failed_at')->useCurrent();
        });

        // Laravel Notifications
        Schema::create('notifications', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('type');
            $table->morphs('notifiable');
            $table->text('data');
            $table->timestamp('read_at')->nullable();
            $table->timestamps();
        });

        // Activity Log (spatie/laravel-activitylog)
        Schema::create('activity_log', function (Blueprint $table) {
            $table->id();
            $table->string('log_name')->nullable()->index();
            $table->text('description');
            $table->nullableMorphs('subject', 'subject');
            $table->string('event')->nullable();
            $table->nullableMorphs('causer', 'causer');
            $table->json('properties')->nullable();
            $table->uuid('batch_uuid')->nullable();
            $table->timestamps();
        });

        // Notification preferences (per user)
        Schema::create('notification_preferences', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();

            // Channels
            $table->boolean('in_app_enabled')->default(true);
            $table->boolean('email_enabled')->default(true);
            $table->boolean('browser_enabled')->default(true);

            // Quiet hours
            $table->boolean('quiet_hours_enabled')->default(true);
            $table->time('quiet_start')->default('22:00:00');
            $table->time('quiet_end')->default('07:00:00');

            // Finance
            $table->boolean('budget_approaching')->default(true);
            $table->integer('budget_threshold')->default(80);
            $table->boolean('budget_exceeded')->default(true);
            $table->boolean('recurring_transaction')->default(true);
            $table->boolean('due_date_reminder')->default(true);
            $table->boolean('ai_draft_ready')->default(true);

            // Productivity
            $table->boolean('activity_reminder')->default(true);
            $table->boolean('activity_deadline')->default(true);
            $table->boolean('journal_reminder')->default(true);
            $table->time('journal_reminder_time')->default('21:00:00');
            $table->boolean('bible_reminder')->default(true);
            $table->time('bible_reminder_time')->default('06:30:00');
            $table->boolean('steps_reminder')->default(true);
            $table->time('steps_reminder_time')->default('19:00:00');

            // Library
            $table->boolean('reading_plan_reminder')->default(true);
            $table->boolean('book_unread_reminder')->default(true);

            // Career
            $table->boolean('toefl_reminder')->default(true);
            $table->boolean('interview_reminder')->default(true);
            $table->boolean('ats_result_ready')->default(true);

            // System
            $table->boolean('new_device_login')->default(true);
            $table->boolean('failed_login')->default(true);
            $table->boolean('backup_success')->default(false);
            $table->boolean('backup_failed')->default(true);
            $table->boolean('app_update')->default(true);

            $table->timestamps();
        });

        // AI requests log
        Schema::create('ai_requests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('provider', 20);    // gemini | grok | gemini_vision
            $table->string('module', 50);
            $table->string('action', 100);
            $table->text('prompt_summary')->nullable();
            $table->enum('status', ['pending','processing','completed','failed'])->default('pending');
            $table->string('error_message')->nullable();
            $table->unsignedInteger('input_tokens')->nullable();
            $table->unsignedInteger('output_tokens')->nullable();
            $table->unsignedInteger('duration_ms')->nullable();
            $table->foreignId('job_id')->nullable()->constrained('jobs')->nullOnDelete();
            $table->timestamps();

            $table->index(['user_id', 'created_at']);
        });

        // Export records
        Schema::create('export_records', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('module', 50);
            $table->string('type', 50);       // pdf|excel|word|zip|csv
            $table->string('filename');
            $table->string('disk', 30)->default('exports');
            $table->string('path')->nullable();
            $table->unsignedBigInteger('file_size')->nullable();
            $table->enum('status', ['preparing','processing','ready','failed','expired'])->default('preparing');
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'status']);
        });

        // Backup records
        Schema::create('backup_records', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->enum('type', ['auto','manual'])->default('manual');
            $table->string('filename');
            $table->string('disk', 30)->default('backups');
            $table->string('path')->nullable();
            $table->unsignedBigInteger('file_size')->nullable();
            $table->string('checksum', 64)->nullable();
            $table->json('manifest')->nullable();
            $table->enum('status', ['processing','completed','failed'])->default('processing');
            $table->text('error_message')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('backup_records');
        Schema::dropIfExists('export_records');
        Schema::dropIfExists('ai_requests');
        Schema::dropIfExists('notification_preferences');
        Schema::dropIfExists('activity_log');
        Schema::dropIfExists('notifications');
        Schema::dropIfExists('failed_jobs');
        Schema::dropIfExists('job_batches');
        Schema::dropIfExists('jobs');
        Schema::dropIfExists('cache_locks');
        Schema::dropIfExists('cache');
    }
};
