<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // ── Activity categories ────────────────────────────────────────────────
        Schema::create('activity_categories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('color', 10)->default('#111827');
            $table->string('icon', 50)->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // ── Activities ────────────────────────────────────────────────────────
        Schema::create('activities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('category_id')->nullable()->constrained('activity_categories')->nullOnDelete();
            $table->string('title');
            $table->text('description')->nullable();
            $table->date('date');
            $table->time('start_time')->nullable();
            $table->time('end_time')->nullable();
            $table->boolean('all_day')->default(false);
            $table->enum('priority', ['rendah','sedang','tinggi'])->default('sedang');
            $table->enum('status', ['belum_mulai','berjalan','selesai','terlambat','dibatalkan'])->default('belum_mulai');
            $table->timestamp('completed_at')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['user_id', 'date']);
            $table->index(['user_id', 'status']);
        });

        // ── Activity recurrences ───────────────────────────────────────────────
        Schema::create('activity_recurrences', function (Blueprint $table) {
            $table->id();
            $table->foreignId('activity_id')->constrained()->cascadeOnDelete();
            $table->enum('frequency', ['daily','weekly','monthly','custom']);
            $table->json('days_of_week')->nullable();  // [1,3,5] = Mon,Wed,Fri
            $table->integer('interval')->default(1);
            $table->date('end_date')->nullable();
            $table->boolean('never_ends')->default(false);
            $table->timestamps();
        });

        // ── Activity reminders ─────────────────────────────────────────────────
        Schema::create('activity_reminders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('activity_id')->constrained()->cascadeOnDelete();
            $table->string('remind_before', 30);    // '10m', '30m', '1h', '1d'
            $table->boolean('sent')->default(false);
            $table->timestamp('scheduled_at')->nullable();
            $table->timestamps();
        });

        // ── Daily journals ─────────────────────────────────────────────────────
        Schema::create('daily_journals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->date('journal_date');
            $table->string('title')->nullable();
            $table->enum('mood', ['sangat_baik','baik','biasa','kurang_baik','buruk'])->nullable();
            $table->longText('story')->nullable();
            $table->json('gratitude')->nullable();
            $table->text('lesson')->nullable();
            $table->text('reflection')->nullable();
            $table->json('tomorrow_plan')->nullable();
            $table->json('tags')->nullable();
            $table->enum('status', ['draft','tersimpan','diperbarui'])->default('draft');
            $table->timestamps();
            $table->unique(['user_id', 'journal_date']);
        });

        Schema::create('daily_journal_tags', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('tag_name');
            $table->timestamps();
            $table->unique(['user_id', 'tag_name']);
        });

        // ── Bible reading ──────────────────────────────────────────────────────
        Schema::create('bible_readings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('book_name');
            $table->integer('chapter');
            $table->date('reading_date');
            $table->integer('duration_minutes')->nullable();
            $table->enum('status', ['dibaca','selesai'])->default('dibaca');
            $table->timestamps();
            $table->index(['user_id', 'reading_date']);
        });

        Schema::create('bible_notes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('reading_id')->nullable()->constrained('bible_readings')->nullOnDelete();
            $table->string('verse_reference')->nullable();
            $table->text('essence')->nullable();
            $table->json('values_learned')->nullable();
            $table->text('personal_meaning')->nullable();
            $table->text('reflection')->nullable();
            $table->text('application')->nullable();
            $table->text('prayer')->nullable(); // stored encrypted
            $table->enum('status', ['draft','selesai'])->default('draft');
            $table->timestamps();
        });

        Schema::create('bible_reading_plans', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->text('description')->nullable();
            $table->date('start_date');
            $table->date('end_date')->nullable();
            $table->enum('status', ['berjalan','selesai','dihentikan'])->default('berjalan');
            $table->json('schedule')->nullable(); // day → reading mapping
            $table->integer('current_day')->default(1);
            $table->timestamps();
        });

        // ── Steps records ──────────────────────────────────────────────────────
        Schema::create('step_records', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->date('record_date');
            $table->integer('steps');
            $table->integer('target');
            $table->enum('source', ['manual','device','health_app'])->default('manual');
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->unique(['user_id', 'record_date']);
        });

        Schema::create('step_targets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->integer('daily_target')->default(10000);
            $table->integer('weekend_target')->nullable();
            $table->json('active_days')->nullable(); // [1,2,3,4,5]
            $table->time('reminder_time')->default('19:00:00');
            $table->boolean('reminder_enabled')->default(true);
            $table->date('effective_from')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('step_targets');
        Schema::dropIfExists('step_records');
        Schema::dropIfExists('bible_reading_plans');
        Schema::dropIfExists('bible_notes');
        Schema::dropIfExists('bible_readings');
        Schema::dropIfExists('daily_journal_tags');
        Schema::dropIfExists('daily_journals');
        Schema::dropIfExists('activity_reminders');
        Schema::dropIfExists('activity_recurrences');
        Schema::dropIfExists('activities');
        Schema::dropIfExists('activity_categories');
    }
};
