<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // ── Chart of accounts ──────────────────────────────────────────────────
        Schema::create('chart_of_accounts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('code', 20);
            $table->string('name');
            $table->enum('type', ['asset','liability','equity','revenue','expense']);
            $table->enum('normal_balance', ['debit','credit']);
            $table->boolean('is_active')->default(true);
            $table->boolean('is_system')->default(false); // cannot be deleted
            $table->integer('sort_order')->default(0);
            $table->timestamps();
            $table->unique(['user_id', 'code']);
        });

        // ── Accounting periods ─────────────────────────────────────────────────
        Schema::create('accounting_periods', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->date('start_date');
            $table->date('end_date');
            $table->enum('status', ['open','locked','closed'])->default('open');
            $table->timestamp('locked_at')->nullable();
            $table->timestamp('closed_at')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'status']);
        });

        // ── Journal entries (IMMUTABLE after posting) ──────────────────────────
        Schema::create('journal_entries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('period_id')->nullable()->constrained('accounting_periods')->nullOnDelete();
            $table->string('entry_number', 30);
            $table->date('entry_date');
            $table->string('description');
            $table->string('reference', 100)->nullable();
            $table->enum('status', ['draft','posted','reversed'])->default('draft');
            $table->foreignId('reversed_by')->nullable()->constrained('journal_entries')->nullOnDelete();
            $table->enum('source', ['manual','ai_generated','import','transaction_auto'])->default('manual');
            $table->foreignId('transaction_id')->nullable()->constrained('financial_transactions')->nullOnDelete();
            $table->foreignId('ai_request_id')->nullable()->constrained('ai_requests')->nullOnDelete();
            $table->timestamp('posted_at')->nullable();
            $table->foreignId('posted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->unique(['user_id', 'entry_number']);
            $table->index(['user_id', 'entry_date']);
            $table->index(['user_id', 'status']);
        });

        // ── Journal lines (debit = credit enforced at app level) ───────────────
        Schema::create('journal_lines', function (Blueprint $table) {
            $table->id();
            $table->foreignId('journal_entry_id')->constrained()->cascadeOnDelete();
            $table->foreignId('account_id')->constrained('chart_of_accounts');
            $table->bigInteger('debit_amount_minor')->default(0);
            $table->bigInteger('credit_amount_minor')->default(0);
            $table->string('description', 255)->nullable();
            $table->timestamps();
        });

        // ── Tax returns (SPT Orang Pribadi draft) ─────────────────────────────
        Schema::create('tax_returns', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->integer('tax_year');
            $table->enum('status', ['draft','review','exported'])->default('draft');
            $table->json('metadata')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->unique(['user_id', 'tax_year']);
        });

        Schema::create('tax_income_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tax_return_id')->constrained()->cascadeOnDelete();
            $table->string('description');
            $table->bigInteger('amount_minor');
            $table->string('source_type', 50)->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tax_income_items');
        Schema::dropIfExists('tax_returns');
        Schema::dropIfExists('journal_lines');
        Schema::dropIfExists('journal_entries');
        Schema::dropIfExists('accounting_periods');
        Schema::dropIfExists('chart_of_accounts');
    }
};
