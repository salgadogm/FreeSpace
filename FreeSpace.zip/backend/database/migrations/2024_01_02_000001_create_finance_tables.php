<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // ── Financial accounts (bank, e-wallet, cash, etc.) ───────────────────
        Schema::create('financial_accounts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->enum('type', ['kas','bank','dompet_digital','tabungan','investasi','lainnya'])->default('kas');
            $table->bigInteger('initial_balance_minor')->default(0); // brick/money: minor unit
            $table->string('currency', 10)->default('IDR');
            $table->boolean('is_active')->default(true);
            $table->boolean('is_default')->default(false);
            $table->string('color', 10)->nullable();
            $table->string('icon', 50)->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        // ── Transaction categories ─────────────────────────────────────────────
        Schema::create('transaction_categories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->enum('type', ['income','expense'])->default('expense');
            $table->string('icon', 50)->nullable();
            $table->string('color', 10)->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // ── Financial transactions ─────────────────────────────────────────────
        Schema::create('financial_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('category_id')->nullable()->constrained('transaction_categories')->nullOnDelete();
            $table->foreignId('account_id')->nullable()->constrained('financial_accounts')->nullOnDelete();
            $table->foreignId('transfer_to_account_id')->nullable()->constrained('financial_accounts')->nullOnDelete();
            $table->foreignId('parent_id')->nullable()->constrained('financial_transactions')->nullOnDelete();
            $table->enum('type', ['income','expense','transfer'])->default('expense');
            $table->bigInteger('amount_minor');                       // brick/money minor unit
            $table->bigInteger('transfer_amount_minor')->nullable(); // for transfer
            $table->string('currency', 10)->default('IDR');
            $table->string('description');
            $table->text('notes')->nullable();
            $table->date('transaction_date');
            $table->boolean('is_recurring')->default(false);
            $table->enum('recurring_frequency', ['daily','weekly','monthly','yearly'])->nullable();
            $table->date('recurring_end_date')->nullable();
            $table->json('tags')->nullable();
            $table->boolean('ai_generated')->default(false);
            $table->foreignId('ai_request_id')->nullable()->constrained('ai_requests')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['user_id', 'transaction_date']);
            $table->index(['user_id', 'type']);
            $table->fullText(['description', 'notes']);
        });

        // ── Recurring transaction schedules ────────────────────────────────────
        Schema::create('recurring_transaction_schedules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('transaction_id')->constrained('financial_transactions')->cascadeOnDelete();
            $table->date('next_due_date');
            $table->date('last_generated')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Budgets ────────────────────────────────────────────────────────────
        Schema::create('budgets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('category_id')->nullable()->constrained('transaction_categories')->nullOnDelete();
            $table->string('name');
            $table->bigInteger('amount_minor');
            $table->string('currency', 10)->default('IDR');
            $table->integer('alert_threshold')->default(80);
            $table->enum('period', ['monthly','weekly','yearly'])->default('monthly');
            $table->date('start_date');
            $table->date('end_date')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Budget items (per category breakdown) ──────────────────────────────
        Schema::create('budget_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('budget_id')->constrained()->cascadeOnDelete();
            $table->foreignId('category_id')->constrained('transaction_categories')->cascadeOnDelete();
            $table->bigInteger('allocated_minor');
            $table->timestamps();
        });

        // ── Personal assets (non-investment: rumah, kendaraan, etc.) ──────────
        Schema::create('personal_assets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('category', 50);
            $table->bigInteger('acquisition_value_minor');
            $table->bigInteger('current_value_minor');
            $table->string('currency', 10)->default('IDR');
            $table->date('acquisition_date')->nullable();
            $table->text('notes')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Liabilities ────────────────────────────────────────────────────────
        Schema::create('liabilities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->enum('type', ['hutang','pinjaman','kpr','kartu_kredit','lainnya'])->default('lainnya');
            $table->bigInteger('original_amount_minor');
            $table->bigInteger('remaining_amount_minor');
            $table->string('currency', 10)->default('IDR');
            $table->decimal('interest_rate', 5, 2)->nullable();
            $table->date('due_date')->nullable();
            $table->boolean('is_active')->default(true);
            $table->text('notes')->nullable();
            $table->timestamps();
        });

        // ── Receivables ────────────────────────────────────────────────────────
        Schema::create('receivables', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('description');
            $table->string('debtor_name')->nullable();
            $table->bigInteger('amount_minor');
            $table->string('currency', 10)->default('IDR');
            $table->date('due_date')->nullable();
            $table->enum('status', ['pending','partially_paid','paid','written_off'])->default('pending');
            $table->bigInteger('paid_amount_minor')->default(0);
            $table->timestamps();
        });

        // ── Financial goals ────────────────────────────────────────────────────
        Schema::create('financial_goals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->bigInteger('target_amount_minor');
            $table->bigInteger('current_amount_minor')->default(0);
            $table->string('currency', 10)->default('IDR');
            $table->date('target_date')->nullable();
            $table->string('icon', 50)->nullable();
            $table->string('color', 10)->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Investment assets ──────────────────────────────────────────────────
        Schema::create('investment_assets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->enum('type', ['saham','reksa_dana','obligasi','emas','kripto','deposito','lainnya'])->default('lainnya');
            $table->string('ticker', 30)->nullable();
            $table->string('currency', 10)->default('IDR');
            $table->decimal('quantity', 18, 8);
            $table->bigInteger('avg_price_minor');
            $table->bigInteger('current_price_minor')->nullable();
            $table->timestamp('price_updated_at')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Market watchlists ──────────────────────────────────────────────────
        Schema::create('market_watchlists', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('ticker', 30);
            $table->string('name')->nullable();
            $table->string('type', 20)->default('saham');
            $table->string('currency', 10)->default('IDR');
            $table->bigInteger('current_price_minor')->nullable();
            $table->timestamp('price_updated_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('market_watchlists');
        Schema::dropIfExists('investment_assets');
        Schema::dropIfExists('financial_goals');
        Schema::dropIfExists('receivables');
        Schema::dropIfExists('liabilities');
        Schema::dropIfExists('personal_assets');
        Schema::dropIfExists('budget_items');
        Schema::dropIfExists('budgets');
        Schema::dropIfExists('recurring_transaction_schedules');
        Schema::dropIfExists('financial_transactions');
        Schema::dropIfExists('transaction_categories');
        Schema::dropIfExists('financial_accounts');
    }
};
