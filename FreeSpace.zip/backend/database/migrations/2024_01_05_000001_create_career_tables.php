<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // ── CV documents ───────────────────────────────────────────────────────
        Schema::create('cv_documents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('target_position')->nullable();
            $table->string('language', 5)->default('id');
            $table->string('template', 50)->default('ats_minimal');
            $table->integer('completeness')->default(0);
            $table->integer('last_ats_score')->nullable();
            $table->enum('status', ['draft','aktif','diarsipkan'])->default('draft');
            $table->boolean('is_active')->default(false);
            $table->integer('sort_order')->default(0);
            $table->timestamps();
            $table->softDeletes();
        });

        // ── CV sections ────────────────────────────────────────────────────────
        Schema::create('cv_sections', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cv_id')->constrained('cv_documents')->cascadeOnDelete();
            $table->string('section_key', 50);  // personal_info, summary, education, etc.
            $table->string('label')->nullable();
            $table->longText('content_json');    // section-specific structured JSON
            $table->boolean('is_visible')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // ── CV versions (immutable snapshots) ─────────────────────────────────
        Schema::create('cv_versions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cv_id')->constrained('cv_documents')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('version_label', 20);
            $table->text('change_description')->nullable();
            $table->longText('snapshot_json');   // full CV content snapshot
            $table->enum('source', ['manual','ats_recommendation','import'])->default('manual');
            $table->timestamps();
        });

        // ── ATS analyses ───────────────────────────────────────────────────────
        Schema::create('ats_analyses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('cv_id')->nullable()->constrained('cv_documents')->nullOnDelete();
            $table->string('target_position')->nullable();
            $table->string('company_name')->nullable();
            $table->text('job_description');
            $table->integer('overall_score')->nullable();
            $table->json('score_breakdown')->nullable();
            $table->json('keywords_found')->nullable();
            $table->json('keywords_missing')->nullable();
            $table->json('keywords_overused')->nullable();
            $table->json('section_analysis')->nullable();
            $table->json('recommendations')->nullable();
            $table->enum('status', ['pending','processing','completed','failed'])->default('pending');
            $table->foreignId('ai_request_id')->nullable()->constrained('ai_requests')->nullOnDelete();
            $table->timestamps();

            $table->index(['user_id', 'created_at']);
        });

        Schema::create('ats_recommendations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('analysis_id')->constrained('ats_analyses')->cascadeOnDelete();
            $table->enum('priority', ['tinggi','sedang','rendah'])->default('sedang');
            $table->string('section');
            $table->text('description');
            $table->string('estimated_impact')->nullable();
            $table->enum('status', ['pending','applied','dismissed'])->default('pending');
            $table->timestamps();
        });

        // ── TOEFL practice sets ────────────────────────────────────────────────
        Schema::create('toefl_practice_sets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->enum('section', ['listening','structure','reading']);
            $table->string('title')->nullable();
            $table->string('topic')->nullable();
            $table->enum('difficulty', ['dasar','menengah','lanjutan','campuran'])->default('menengah');
            $table->integer('question_count')->default(10);
            $table->boolean('is_timed')->default(false);
            $table->integer('time_limit_minutes')->nullable();
            $table->boolean('show_answers_immediately')->default(true);
            $table->timestamps();
        });

        Schema::create('toefl_questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('practice_set_id')->constrained('toefl_practice_sets')->cascadeOnDelete();
            $table->enum('type', ['multiple_choice','error_identification']);
            $table->text('question_text');
            $table->json('options');              // A, B, C, D
            $table->integer('correct_option');    // 0-3
            $table->text('explanation');
            $table->string('concept')->nullable();
            $table->string('audio_path')->nullable(); // for listening
            $table->text('passage')->nullable();      // for reading
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        Schema::create('toefl_attempts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('practice_set_id')->nullable()->constrained('toefl_practice_sets')->nullOnDelete();
            $table->enum('type', ['practice','simulation']);
            $table->integer('listening_score')->nullable();
            $table->integer('structure_score')->nullable();
            $table->integer('reading_score')->nullable();
            $table->integer('estimated_total')->nullable();
            $table->integer('correct_count')->nullable();
            $table->integer('total_questions')->nullable();
            $table->integer('duration_seconds')->nullable();
            $table->enum('status', ['in_progress','completed','abandoned'])->default('in_progress');
            $table->timestamps();
        });

        Schema::create('toefl_answers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('attempt_id')->constrained('toefl_attempts')->cascadeOnDelete();
            $table->foreignId('question_id')->constrained('toefl_questions')->cascadeOnDelete();
            $table->integer('selected_option')->nullable();
            $table->boolean('is_correct')->nullable();
            $table->boolean('is_marked')->default(false);
            $table->integer('time_spent_seconds')->nullable();
            $table->timestamps();
        });

        // ── Interview sessions ─────────────────────────────────────────────────
        Schema::create('interview_question_bank', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->text('question');
            $table->string('type', 50);         // hr|behavioral|teknikal|motivasi
            $table->string('field', 50)->nullable(); // accounting|finance|audit
            $table->enum('difficulty', ['dasar','menengah','lanjutan'])->default('menengah');
            $table->string('language', 5)->default('id');
            $table->boolean('is_saved')->default(false);
            $table->timestamps();
        });

        Schema::create('interview_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('target_position')->nullable();
            $table->string('field', 50)->nullable();
            $table->string('interview_type', 30)->nullable();
            $table->string('answer_mode', 20)->default('text'); // text|audio|video
            $table->string('language', 5)->default('id');
            $table->string('interviewer_style', 20)->default('profesional');
            $table->integer('question_count')->default(8);
            $table->integer('overall_score')->nullable();
            $table->integer('duration_minutes')->nullable();
            $table->json('competency_scores')->nullable();
            $table->json('strengths')->nullable();
            $table->json('improvements')->nullable();
            $table->enum('status', ['in_progress','completed','cancelled'])->default('in_progress');
            $table->foreignId('ai_request_id')->nullable()->constrained('ai_requests')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('interview_answers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('session_id')->constrained('interview_sessions')->cascadeOnDelete();
            $table->foreignId('question_id')->nullable()->constrained('interview_question_bank')->nullOnDelete();
            $table->text('question_text');
            $table->longText('answer_text')->nullable();
            $table->string('audio_path')->nullable();  // private storage
            $table->string('video_path')->nullable();  // private storage
            $table->integer('score')->nullable();
            $table->json('feedback')->nullable();
            $table->integer('duration_seconds')->nullable();
            $table->timestamps();
        });

        Schema::create('interview_feedback', function (Blueprint $table) {
            $table->id();
            $table->foreignId('session_id')->constrained('interview_sessions')->cascadeOnDelete();
            $table->foreignId('answer_id')->nullable()->constrained('interview_answers')->nullOnDelete();
            $table->text('strengths_summary')->nullable();
            $table->text('improvements_summary')->nullable();
            $table->json('action_plan')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('interview_feedback');
        Schema::dropIfExists('interview_answers');
        Schema::dropIfExists('interview_sessions');
        Schema::dropIfExists('interview_question_bank');
        Schema::dropIfExists('toefl_answers');
        Schema::dropIfExists('toefl_attempts');
        Schema::dropIfExists('toefl_questions');
        Schema::dropIfExists('toefl_practice_sets');
        Schema::dropIfExists('ats_recommendations');
        Schema::dropIfExists('ats_analyses');
        Schema::dropIfExists('cv_versions');
        Schema::dropIfExists('cv_sections');
        Schema::dropIfExists('cv_documents');
    }
};
