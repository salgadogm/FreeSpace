# DEPLOYMENT GUIDE — FreeSpace on Hostinger Shared Hosting

## Prerequisites
- Hostinger Business Web Hosting plan
- PHP 8.3 enabled in hPanel
- MariaDB database created
- SSH access (optional but recommended)
- Composer installed (or use Hostinger's terminal)

---

## Step 1: Upload Project Files

Upload **all files** from the `backend/` directory to your hosting via:
- hPanel File Manager
- FTP/SFTP client (FileZilla, etc.)
- Git deployment (if available)

**Recommended target directory:** `public_html/freespace/`

---

## Step 2: Set Document Root

In hPanel → Websites → Your Domain → Advanced → Document Root:

```
public_html/freespace/public
```

This ensures `public/index.php` is the entry point and all other files are protected.

---

## Step 3: Create MariaDB Database

In hPanel → Databases → MySQL Databases:

1. Create database: `freespace`
2. Create user: `freespace_user`
3. Set strong password
4. Assign user to database with ALL privileges

---

## Step 4: Configure Environment

Copy and edit `.env.example` to `.env`:

```bash
cp .env.example .env
```

Update these values:

```env
APP_ENV=production
APP_DEBUG=false
APP_URL=https://yourdomain.com

DB_CONNECTION=mariadb
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=freespace
DB_USERNAME=freespace_user
DB_PASSWORD=your_strong_password

MAIL_HOST=smtp.hostinger.com
MAIL_PORT=587
MAIL_USERNAME=your@domain.com
MAIL_PASSWORD=your_email_password
MAIL_FROM_ADDRESS=noreply@domain.com

GEMINI_API_KEY=your_gemini_api_key
GROK_API_KEY=your_grok_api_key
```

---

## Step 5: Install Composer Dependencies

Via SSH or Hostinger Terminal:

```bash
cd public_html/freespace
composer install --no-dev --optimize-autoloader
```

> **Note:** If composer is not available, install it first:
> `php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');" && php composer-setup.php && mv composer.phar /usr/local/bin/composer`

---

## Step 6: Generate Application Key

```bash
php artisan key:generate
```

---

## Step 7: Run Database Migrations

```bash
php artisan migrate --force
```

---

## Step 8: Run Seeders (Optional — for demo data)

```bash
php artisan db:seed
```

Demo credentials after seeding:
- Email: `demo@freespace.app`
- Password: `FreeSpace2026!`

---

## Step 9: Create Storage Link

```bash
php artisan storage:link
```

---

## Step 10: Build Frontend Assets

**Option A — Build locally then upload:**
```bash
# On your local machine:
cd backend
npm install
npm run build
# Upload the generated public/build/ directory
```

**Option B — Build on server (if Node.js available):**
```bash
npm install
npm run build
```

---

## Step 11: Set File Permissions

```bash
chmod -R 755 storage
chmod -R 755 bootstrap/cache
chmod 600 .env
```

---

## Step 12: Configure Cron Job

In hPanel → Advanced → Cron Jobs, add:

**Command:**
```
/usr/local/bin/php /home/username/public_html/freespace/artisan schedule:run >> /dev/null 2>&1
```

**Frequency:** Every minute (`* * * * *`)

This runs the Laravel scheduler which handles:
- Recurring transactions
- Activity reminders
- Budget alerts
- Daily journal reminders
- Bible reading reminders
- Steps reminders
- Automatic backups (daily at 02:00)
- Queue processing (`queue:work --stop-when-empty`)
- Temporary export cleanup

---

## Step 13: Configure SMTP (Hostinger)

Hostinger SMTP settings:
```
Host:       smtp.hostinger.com
Port:       587
Security:   TLS
Username:   your@domain.com
Password:   your_email_password
```

---

## Step 14: Disable Debug Mode

Ensure in `.env`:
```env
APP_ENV=production
APP_DEBUG=false
```

---

## Step 15: Optimize Laravel

```bash
php artisan optimize
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan event:cache
```

---

## Deployment Commands Summary

Run in order on production:

```bash
composer install --no-dev --optimize-autoloader
php artisan key:generate
php artisan migrate --force
php artisan storage:link
php artisan optimize
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

---

## Maintenance Commands

```bash
# Clear all caches
php artisan optimize:clear

# Process queue manually (useful for testing)
php artisan queue:work --once

# Run scheduler manually
php artisan schedule:run

# Tail logs
tail -f storage/logs/laravel.log

# Create manual backup
php artisan freespace:backup-user-data
```

---

## Troubleshooting

**500 Error:**
1. Check `storage/logs/laravel.log`
2. Ensure `APP_DEBUG=false` in production
3. Verify storage permissions

**Queue not working:**
1. Verify cron job is set correctly
2. Run `php artisan queue:work --once` manually to test

**PDF.js not loading:**
1. Ensure `public/vendor/pdf.worker.min.js` exists
2. Run `npm run build` to regenerate assets

**File upload failing:**
1. Check `FILESYSTEM_DISK=local` in `.env`
2. Verify `storage/app/private` is writable
3. Check `php artisan storage:link` was run

---

## Security Checklist

- [x] APP_DEBUG=false in production
- [x] APP_KEY is set and secret
- [x] .env has restricted permissions (600)
- [x] Document root points to public/
- [x] Database password is strong
- [x] HTTPS is enabled (Hostinger SSL)
- [x] Session cookies are secure
- [x] CSRF protection active
- [x] Rate limiting configured
- [x] 2FA available via Laravel Fortify
- [x] AI API keys are server-side only
