<?php

return [

    'default' => env('FILESYSTEM_DISK', 'local'),

    'disks' => [

        'local' => [
            'driver' => 'local',
            'root'   => storage_path('app/private'),
            'serve'  => true,
            'throw'  => false,
            'visibility' => 'private',
        ],

        'public' => [
            'driver'     => 'local',
            'root'       => storage_path('app/public'),
            'url'        => env('APP_URL').'/storage',
            'visibility' => 'public',
            'throw'      => false,
        ],

        // User media (books, attachments) – private by default
        'media' => [
            'driver'     => 'local',
            'root'       => storage_path('app/media'),
            'visibility' => 'private',
            'throw'      => false,
        ],

        // Generated exports (temporary, cleaned up by scheduler)
        'exports' => [
            'driver'     => 'local',
            'root'       => storage_path('app/exports'),
            'visibility' => 'private',
            'throw'      => false,
        ],

        // Backup archives
        'backups' => [
            'driver'     => 'local',
            'root'       => storage_path('app/backups'),
            'visibility' => 'private',
            'throw'      => false,
        ],

    ],

    'links' => [
        public_path('storage') => storage_path('app/public'),
    ],

];
