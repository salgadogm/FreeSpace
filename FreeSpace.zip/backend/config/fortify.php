<?php

use App\Providers\RouteServiceProvider;
use Laravel\Fortify\Features;

return [

    'guard'          => 'web',
    'middleware'     => ['web'],
    'auth_middleware' => 'auth',
    'passwords'      => 'users',
    'username'       => 'email',
    'email'          => 'email',
    'lowercase_usernames' => env('FORTIFY_LOWERCASE_USERNAMES', true),
    'home'           => '/',
    'prefix'         => '',
    'domain'         => null,
    'redirects'      => [],
    'limiters'       => [
        'login'     => 'login',
        'two-factor' => 'two-factor',
    ],
    'views'          => true,
    'features'       => [
        Features::registration(),
        Features::resetPasswords(),
        Features::emailVerification(),
        Features::updateProfileInformation(),
        Features::updatePasswords(),
        Features::twoFactorAuthentication([
            'confirm'        => true,
            'confirmPassword' => true,
        ]),
    ],

];
