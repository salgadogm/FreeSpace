<?php

return [

    'driver' => env('SCOUT_DRIVER', 'database'),

    'prefix' => env('SCOUT_PREFIX', ''),

    'queue' => [
        'connection' => env('SCOUT_QUEUE_CONNECTION', false),
        'queue'      => env('SCOUT_QUEUE', 'scout'),
    ],

    'after_commit' => false,
    'soft_delete'  => false,

    'identify' => env('SCOUT_IDENTIFY', false),

    'algolia' => [
        'id'     => env('ALGOLIA_APP_ID', ''),
        'secret' => env('ALGOLIA_SECRET', ''),
    ],

    'meilisearch' => [
        'host' => env('MEILISEARCH_HOST', 'http://localhost:7700'),
        'key'  => env('MEILISEARCH_KEY'),
        'index-settings' => [],
    ],

    'typesense' => [
        'client-settings' => [
            'api_key' => env('TYPESENSE_API_KEY', 'xyz'),
            'nodes'   => [['host' => env('TYPESENSE_HOST', 'localhost'), 'port' => '8108', 'protocol' => 'http']],
            'retries' => 3,
            'connection_timeout_seconds' => 2,
        ],
    ],

];
