<?php

return [

    'default_provider' => env('AI_DEFAULT_PROVIDER', 'gemini'),

    'providers' => [

        'gemini' => [
            'api_key'    => env('GEMINI_API_KEY'),
            'model'      => env('GEMINI_MODEL', 'gemini-2.0-flash'),
            'base_url'   => 'https://generativelanguage.googleapis.com/v1beta',
            'timeout'    => (int) env('AI_TIMEOUT', 30),
            'max_retries' => (int) env('AI_MAX_RETRIES', 2),
        ],

        'gemini_vision' => [
            'api_key' => env('GEMINI_VISION_API_KEY', env('GEMINI_API_KEY')),
            'model'   => env('GEMINI_VISION_MODEL', 'gemini-2.0-flash'),
            'timeout' => (int) env('AI_TIMEOUT', 60),
        ],

        'grok' => [
            'api_key'    => env('GROK_API_KEY'),
            'model'      => env('GROK_MODEL', 'grok-3-mini'),
            'base_url'   => 'https://api.x.ai/v1',
            'timeout'    => (int) env('AI_TIMEOUT', 30),
            'max_retries' => (int) env('AI_MAX_RETRIES', 2),
        ],

    ],

    'fallback' => env('AI_FALLBACK_ENABLED', false),

    'rate_limit' => [
        'max_requests_per_minute' => 60,
    ],

    'queue' => [
        'connection' => env('AI_QUEUE_CONNECTION', 'database'),
        'queue'      => 'ai',
    ],

];
