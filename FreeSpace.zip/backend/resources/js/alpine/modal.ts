import Alpine from 'alpinejs';

/**
 * Alpine component for modal/drawer overlays.
 * Usage: x-data="modal()"
 */
Alpine.data('modal', (initialOpen = false) => ({
    open: initialOpen,

    show() {
        this.open = true;
        document.body.style.overflow = 'hidden';
    },

    hide() {
        this.open = false;
        document.body.style.overflow = '';
    },

    toggle() {
        this.open ? this.hide() : this.show();
    },

    // Keyboard: Escape closes
    handleKeydown(event: KeyboardEvent) {
        if (event.key === 'Escape' && this.open) {
            this.hide();
        }
    },
}));

/**
 * Alpine component for confirmation modal.
 * Usage: x-data="confirmModal(callback)"
 */
Alpine.data('confirmModal', (onConfirm: () => void) => ({
    open: false,
    confirmText: '',
    requiredText: '',

    show(required = '') {
        this.open = true;
        this.requiredText = required;
        this.confirmText = '';
        document.body.style.overflow = 'hidden';
    },

    hide() {
        this.open = false;
        document.body.style.overflow = '';
    },

    canConfirm(): boolean {
        return !this.requiredText || this.confirmText === this.requiredText;
    },

    confirm() {
        if (this.canConfirm()) {
            onConfirm();
            this.hide();
        }
    },
}));
