import Alpine from 'alpinejs';

type ToastType = 'success' | 'error' | 'info' | 'warning';

interface Toast {
    id: number;
    type: ToastType;
    message: string;
}

/**
 * Alpine store for toast notifications.
 * Usage: $store.toast.show('message', 'success')
 * Also listens to Livewire dispatch('toast') events.
 */
Alpine.store('toast', {
    items: [] as Toast[],
    nextId: 1,

    show(message: string, type: ToastType = 'success', duration = 3500) {
        const id = this.nextId++;
        this.items.push({ id, type, message });
        setTimeout(() => this.dismiss(id), duration);
    },

    dismiss(id: number) {
        this.items = this.items.filter((t) => t.id !== id);
    },

    icon(type: ToastType): string {
        const icons: Record<ToastType, string> = {
            success: '✓',
            error:   '✕',
            info:    'ℹ',
            warning: '⚠',
        };
        return icons[type];
    },
});

// Listen for Livewire toast events
document.addEventListener('livewire:init', () => {
    Livewire.on('toast', ({ type, message }: { type: ToastType; message: string }) => {
        Alpine.store('toast').show(message, type);
    });
});
