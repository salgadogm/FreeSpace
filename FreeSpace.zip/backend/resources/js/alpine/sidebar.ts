import Alpine from 'alpinejs';

/**
 * Alpine store for sidebar state.
 * Handles: expand/collapse, accordion menus, mobile drawer.
 */
Alpine.store('sidebar', {
    open: true,       // desktop sidebar visible
    mobileOpen: false,
    openMenu: null as string | null,

    toggle() {
        this.open = !this.open;
    },

    toggleMobile() {
        this.mobileOpen = !this.mobileOpen;
    },

    closeMobile() {
        this.mobileOpen = false;
    },

    openAccordion(menu: string) {
        this.openMenu = this.openMenu === menu ? null : menu;
    },

    isAccordionOpen(menu: string): boolean {
        return this.openMenu === menu;
    },
});

/**
 * Sidebar component for each accordion group.
 */
Alpine.data('sidebarGroup', (menuId: string) => ({
    get isOpen(): boolean {
        return Alpine.store('sidebar').openMenu === menuId;
    },
    toggle() {
        Alpine.store('sidebar').openAccordion(menuId);
    },
}));
