import { Calendar } from '@fullcalendar/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import listPlugin from '@fullcalendar/list';

/**
 * FullCalendar wrapper for Livewire integration.
 * Dispatches events back to Livewire component.
 *
 * Usage in Blade:
 * <div wire:ignore x-data="fullCalendar(@js($config))" x-init="init()"></div>
 */
(window as any).fullCalendar = function(config: Record<string, any> = {}) {
    return {
        calendar: null as Calendar | null,

        init() {
            const el = this.$el;
            const component = this;

            this.calendar = new Calendar(el, {
                plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin, listPlugin],
                initialView: config.view ?? 'timeGridWeek',
                locale: config.locale ?? 'id',
                firstDay: config.firstDay ?? 1, // Monday
                headerToolbar: false, // Livewire controls toolbar
                events: config.events ?? [],
                editable: true,
                selectable: true,
                height: 'auto',

                // Drag/resize → update on server
                eventDrop: (info) => {
                    component.$wire.onEventDrop({
                        id: info.event.id,
                        start: info.event.startStr,
                        end: info.event.endStr,
                    });
                },

                eventResize: (info) => {
                    component.$wire.onEventResize({
                        id: info.event.id,
                        start: info.event.startStr,
                        end: info.event.endStr,
                    });
                },

                // Click on event → open detail
                eventClick: (info) => {
                    component.$wire.onEventClick(info.event.id);
                },

                // Click on empty slot → open create with time pre-filled
                select: (info) => {
                    component.$wire.onSlotSelect({
                        start: info.startStr,
                        end: info.endStr,
                    });
                },
            });

            this.calendar.render();
        },

        // Call from Livewire to update events
        updateEvents(events: any[]) {
            this.calendar?.removeAllEvents();
            this.calendar?.addEventSource(events);
        },

        changeView(view: string) {
            this.calendar?.changeView(view);
        },

        next() { this.calendar?.next(); },
        prev() { this.calendar?.prev(); },
        today() { this.calendar?.today(); },

        destroy() { this.calendar?.destroy(); },
    };
};
