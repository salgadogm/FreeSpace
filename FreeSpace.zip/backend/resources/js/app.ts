import './bootstrap';
import Alpine from 'alpinejs';
import Focus from '@alpinejs/focus';
import Collapse from '@alpinejs/collapse';
import Morph from '@alpinejs/morph';
import Mask from '@alpinejs/mask';
import Anchor from '@alpinejs/anchor';

// Alpine plugins
Alpine.plugin(Focus);
Alpine.plugin(Collapse);
Alpine.plugin(Morph);
Alpine.plugin(Mask);
Alpine.plugin(Anchor);

// Import Alpine components/stores
import './alpine/sidebar';
import './alpine/modal';
import './alpine/dropdown';
import './alpine/tabs';
import './alpine/toast';

// Import chart wrappers
import './charts/apex-chart';
import './charts/progress-chart';

// Import calendar
import './calendar/full-calendar';

// Import editor
import './editor/tiptap-editor';

// Import PDF reader
import './pdf/pdf-reader';

// Import sortable
import './sortable/sortable-list';

// Start Alpine
window.Alpine = Alpine;
Alpine.start();
