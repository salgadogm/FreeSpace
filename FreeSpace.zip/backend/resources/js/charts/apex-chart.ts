import ApexCharts from 'apexcharts';

/**
 * ApexCharts wrapper for Livewire integration.
 *
 * Usage in Blade:
 * <div wire:ignore x-data="apexChart(@js($options))" x-init="init()" @chart-update.window="update($event.detail)"></div>
 */
export function initApexChart() {
    (window as any).apexChart = function(initialOptions: ApexCharts.ApexOptions) {
        return {
            chart: null as ApexCharts | null,
            options: initialOptions,

            init() {
                this.chart = new ApexCharts(this.$el, this.buildOptions(this.options));
                this.chart.render();

                // Rebuild chart on Livewire navigation
                this.$el.addEventListener('freespace:page-loaded', () => {
                    this.chart?.destroy();
                    this.chart = new ApexCharts(this.$el, this.buildOptions(this.options));
                    this.chart.render();
                });
            },

            update(newOptions: Partial<ApexCharts.ApexOptions>) {
                this.chart?.updateOptions(newOptions);
            },

            destroy() {
                this.chart?.destroy();
            },

            buildOptions(opts: ApexCharts.ApexOptions): ApexCharts.ApexOptions {
                return {
                    ...opts,
                    chart: {
                        ...opts.chart,
                        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                        toolbar: { show: false },
                        animations: { enabled: true, speed: 250 },
                    },
                };
            },
        };
    };
}

initApexChart();
