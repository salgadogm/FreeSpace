import { Editor, type Extensions } from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import Highlight from '@tiptap/extension-highlight';
import Link from '@tiptap/extension-link';
import Underline from '@tiptap/extension-underline';
import TextAlign from '@tiptap/extension-text-align';
import Table from '@tiptap/extension-table';
import TableRow from '@tiptap/extension-table-row';
import TableCell from '@tiptap/extension-table-cell';
import TableHeader from '@tiptap/extension-table-header';

/**
 * Tiptap editor wrapper for Livewire.
 * Syncs content via wire:model-compatible approach.
 *
 * Usage:
 * <div x-data="tiptapEditor({ wireModel: 'content', placeholder: '...', toolbar: 'full' })">
 *   <div x-ref="editorEl"></div>
 * </div>
 */
(window as any).tiptapEditor = function(config: {
    wireModel?: string;
    placeholder?: string;
    toolbar?: 'simple' | 'full' | 'accounting';
    initialContent?: string;
    onUpdate?: (html: string) => void;
} = {}) {
    return {
        editor: null as Editor | null,
        content: config.initialContent ?? '',
        isFocused: false,

        init() {
            const extensions: Extensions = [
                StarterKit.configure({ heading: { levels: [1, 2, 3] } }),
                Placeholder.configure({ placeholder: config.placeholder ?? 'Tulis di sini...' }),
                Highlight.configure({ multicolor: true }),
                Link.configure({ openOnClick: false }),
                Underline,
                TextAlign.configure({ types: ['heading', 'paragraph'] }),
            ];

            if (config.toolbar === 'full' || config.toolbar === 'accounting') {
                extensions.push(
                    Table.configure({ resizable: true }),
                    TableRow,
                    TableCell,
                    TableHeader,
                );
            }

            this.editor = new Editor({
                element: this.$refs.editorEl,
                extensions,
                content: this.content,
                onUpdate: ({ editor }) => {
                    const html = editor.getHTML();
                    this.content = html;

                    if (config.onUpdate) {
                        config.onUpdate(html);
                    }

                    // Sync with Livewire via debounced dispatch
                    this.$el.dispatchEvent(new CustomEvent('tiptap-update', {
                        detail: { content: html },
                        bubbles: true,
                    }));
                },
                onFocus: () => { this.isFocused = true; },
                onBlur:  () => { this.isFocused = false; },
            });
        },

        setContent(html: string) {
            this.editor?.commands.setContent(html);
        },

        getHTML(): string {
            return this.editor?.getHTML() ?? '';
        },

        // Toolbar actions
        toggleBold() { this.editor?.chain().focus().toggleBold().run(); },
        toggleItalic() { this.editor?.chain().focus().toggleItalic().run(); },
        toggleUnderline() { this.editor?.chain().focus().toggleUnderline().run(); },
        toggleBulletList() { this.editor?.chain().focus().toggleBulletList().run(); },
        toggleOrderedList() { this.editor?.chain().focus().toggleOrderedList().run(); },
        toggleBlockquote() { this.editor?.chain().focus().toggleBlockquote().run(); },
        toggleCode() { this.editor?.chain().focus().toggleCode().run(); },
        insertTable() { this.editor?.chain().focus().insertTable({ rows: 3, cols: 3 }).run(); },

        isActive(name: string): boolean {
            return this.editor?.isActive(name) ?? false;
        },

        destroy() { this.editor?.destroy(); },
    };
};
