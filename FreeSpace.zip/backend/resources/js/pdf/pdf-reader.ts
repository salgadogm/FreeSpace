import * as pdfjsLib from 'pdfjs-dist';

// Set worker source
pdfjsLib.GlobalWorkerOptions.workerSrc = '/vendor/pdf.worker.min.js';

/**
 * PDF.js reader for Livewire.
 *
 * Usage:
 * <div x-data="pdfReader({ url: @js($signedUrl), initialPage: @js($currentPage) })">
 *   <canvas x-ref="canvas"></canvas>
 * </div>
 */
(window as any).pdfReader = function(config: {
    url: string;
    initialPage?: number;
    scale?: number;
    onPageChange?: (page: number, total: number) => void;
} = { url: '' }) {
    return {
        pdf: null as any,
        currentPage: config.initialPage ?? 1,
        totalPages: 0,
        scale: config.scale ?? 1.2,
        loading: false,
        sessionSeconds: 0,
        sessionTimer: null as ReturnType<typeof setInterval> | null,

        async init() {
            if (!config.url) return;

            this.loading = true;
            try {
                this.pdf = await pdfjsLib.getDocument({
                    url: config.url,
                    withCredentials: true,
                }).promise;

                this.totalPages = this.pdf.numPages;
                await this.renderPage(this.currentPage);
            } catch (err) {
                console.error('PDF load error:', err);
                this.$dispatch('pdf-error', { message: 'Gagal memuat PDF.' });
            } finally {
                this.loading = false;
            }

            // Session timer
            this.sessionTimer = setInterval(() => {
                this.sessionSeconds++;
                if (this.sessionSeconds % 30 === 0) {
                    this.saveProgress();
                }
            }, 1000);
        },

        async renderPage(pageNum: number) {
            if (!this.pdf) return;
            const page = await this.pdf.getPage(pageNum);
            const viewport = page.getViewport({ scale: this.scale });
            const canvas = this.$refs.canvas as HTMLCanvasElement;
            const ctx = canvas.getContext('2d')!;
            canvas.width  = viewport.width;
            canvas.height = viewport.height;

            await page.render({ canvasContext: ctx, viewport }).promise;
        },

        async goTo(page: number) {
            if (page < 1 || page > this.totalPages) return;
            this.currentPage = page;
            await this.renderPage(page);
            config.onPageChange?.(page, this.totalPages);
            this.saveProgress();
        },

        async next() { await this.goTo(this.currentPage + 1); },
        async prev() { await this.goTo(this.currentPage - 1); },

        setScale(scale: number) {
            this.scale = Math.max(0.5, Math.min(3, scale));
            this.renderPage(this.currentPage);
        },

        progress(): number {
            return this.totalPages ? Math.round((this.currentPage / this.totalPages) * 100) : 0;
        },

        sessionTime(): string {
            const m = Math.floor(this.sessionSeconds / 60);
            const s = this.sessionSeconds % 60;
            return `${m}:${String(s).padStart(2, '0')}`;
        },

        saveProgress() {
            this.$wire?.call('saveReadingProgress', {
                page: this.currentPage,
                total: this.totalPages,
                sessionSeconds: this.sessionSeconds,
            });
        },

        destroy() {
            if (this.sessionTimer) clearInterval(this.sessionTimer);
            this.saveProgress();
            this.pdf?.destroy();
        },
    };
};
