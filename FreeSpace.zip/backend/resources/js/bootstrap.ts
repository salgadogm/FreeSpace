import axios from 'axios';

window.axios = axios;
window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

// CSRF token for Livewire / Laravel requests
const csrfToken = document.head.querySelector('meta[name="csrf-token"]');
if (csrfToken) {
    window.axios.defaults.headers.common['X-CSRF-TOKEN'] = (csrfToken as HTMLMetaElement).content;
}

// Global Livewire event helpers
document.addEventListener('livewire:init', () => {
    // Re-init third-party libraries after Livewire navigates
    Livewire.hook('navigate.end', () => {
        window.dispatchEvent(new Event('freespace:page-loaded'));
    });
});

export {};
