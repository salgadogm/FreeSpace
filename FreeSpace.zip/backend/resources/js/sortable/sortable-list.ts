import Sortable from 'sortablejs';

/**
 * SortableJS wrapper for Livewire.
 * Sends updated order to Livewire after drag.
 *
 * Usage:
 * <ul x-data="sortableList('reorderItems')" x-init="init()">
 *   <li data-id="1" data-sort-handle=".handle">...</li>
 * </ul>
 */
(window as any).sortableList = function(livewireMethod: string, options: Sortable.Options = {}) {
    return {
        sortable: null as Sortable | null,

        init() {
            this.sortable = Sortable.create(this.$el, {
                animation: 150,
                handle: '[data-sort-handle]',
                ghostClass: 'sortable-ghost',
                chosenClass: 'sortable-chosen',
                dragClass: 'sortable-drag',
                ...options,

                onEnd: () => {
                    const items = [...this.$el.querySelectorAll('[data-id]')];
                    const order = items.map((el, index) => ({
                        id: (el as HTMLElement).dataset.id,
                        sort: index + 1,
                    }));
                    this.$wire[livewireMethod](order);
                },
            });
        },

        destroy() {
            this.sortable?.destroy();
        },
    };
};
