@props([
    'label',
    'value',
    'description' => null,
    'color'       => '#111827',
    'icon'        => null,
])

<div class="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col gap-2">
    <div class="flex items-center justify-between">
        <span class="text-xs text-gray-500">{{ $label }}</span>
        @if($icon)
            <div class="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                 style="background-color: {{ $color }}18; color: {{ $color }}">
                <x-dynamic-component :component="'heroicon-o-' . $icon" class="w-4 h-4"/>
            </div>
        @endif
    </div>
    <p class="text-2xl font-bold text-gray-900 leading-tight">{{ $value }}</p>
    @if($description)
        <p class="text-[11px] text-gray-400 leading-snug">{{ $description }}</p>
    @endif
</div>
