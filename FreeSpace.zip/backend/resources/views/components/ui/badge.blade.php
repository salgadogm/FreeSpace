@props([
    'color'   => '#6B7280',
    'bg'      => '#F3F4F6',
    'size'    => 'sm', // sm | xs
    'rounded' => 'full',
])

@php
    $sizeClass = match($size) {
        'xs'    => 'text-[10px] px-2 py-0.5',
        default => 'text-xs px-2.5 py-0.5',
    };
@endphp

<span class="inline-flex items-center font-semibold rounded-full {{ $sizeClass }}"
      style="color: {{ $color }}; background-color: {{ $bg }}">
    {{ $slot }}
</span>
