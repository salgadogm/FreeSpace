@props(['href', 'active' => false, 'icon' => null])

<a href="{{ $href }}"
   wire:navigate
   @class([
       'flex items-center gap-2.5 px-3 py-2 rounded-lg transition-colors',
       'bg-gray-100' => $active,
       'hover:bg-gray-50' => !$active,
   ])
   aria-current="{{ $active ? 'page' : 'false' }}">

    @if($icon)
        <x-dynamic-component :component="'heroicon-o-' . $icon"
            @class(['w-[15px] h-[15px] shrink-0', 'text-gray-700' => $active, 'text-gray-400' => !$active]) />
    @endif

    <span @class(['text-sm flex-1', 'font-semibold text-gray-800' => $active, 'text-gray-500' => !$active])>
        {{ $slot }}
    </span>

</a>
