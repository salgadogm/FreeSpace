@props(['href', 'active' => false])

<a href="{{ $href }}"
   wire:navigate
   @class([
       'flex items-center gap-2 px-2 py-1.5 rounded-lg cursor-pointer transition-colors',
       'bg-gray-100' => $active,
       'hover:bg-gray-50' => !$active,
   ])
   aria-current="{{ $active ? 'page' : 'false' }}">

    <div @class([
        'w-1.5 h-1.5 rounded-full shrink-0',
        'bg-gray-600' => $active,
        'border border-gray-400' => !$active,
    ])></div>

    <span @class(['text-xs', 'text-gray-800 font-medium' => $active, 'text-gray-500' => !$active])>
        {{ $slot }}
    </span>
</a>
