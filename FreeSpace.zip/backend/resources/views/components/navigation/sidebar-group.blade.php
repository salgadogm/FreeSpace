@props(['menuId', 'label', 'icon' => null, 'active' => false])

<div x-data="sidebarGroup('{{ $menuId }}')" x-cloak>
    {{-- Parent button --}}
    <button @click="toggle()"
            @class([
                'w-full flex items-center gap-2.5 px-3 py-2 rounded-lg cursor-pointer transition-colors',
                'bg-gray-100' => $active,
                'hover:bg-gray-50' => !$active,
            ])
            :aria-expanded="isOpen">

        @if($icon)
            <x-dynamic-component :component="'heroicon-o-' . $icon"
                @class(['w-[15px] h-[15px] shrink-0', 'text-gray-700' => $active, 'text-gray-400' => !$active]) />
        @endif

        <span @class(['text-sm flex-1 text-left', 'font-semibold text-gray-800' => $active, 'text-gray-500' => !$active])>
            {{ $label }}
        </span>

        {{-- Chevron --}}
        <svg class="w-[13px] h-[13px] text-gray-400 shrink-0 transition-transform"
             :class="{ 'rotate-180': isOpen }"
             fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="m19 9-7 7-7-7"/>
        </svg>
    </button>

    {{-- Children --}}
    <div x-show="isOpen"
         x-collapse
         class="ml-6 mt-0.5 mb-1 flex flex-col gap-0.5 border-l border-gray-200 pl-3">
        {{ $slot }}
    </div>
</div>
