<!DOCTYPE html>
<html lang="{{ auth()->user()?->language ?? app()->getLocale() }}" x-data x-cloak>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? config('app.name', 'FreeSpace') }} — FreeSpace</title>

    {{-- Favicon --}}
    <link rel="icon" type="image/png" href="{{ asset('favicon.png') }}">

    {{-- Fonts: system stack, no external font loading --}}

    {{-- Styles + Vite --}}
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    {{-- Livewire styles --}}
    @livewireStyles
</head>
<body class="bg-gray-50 antialiased" @keydown.escape.window="$dispatch('close-modal')">

    {{-- ── Toast container (Alpine) ─────────────────────────────────────────── --}}
    <div class="toast-container" x-data x-cloak>
        <template x-for="toast in $store.toast.items" :key="toast.id">
            <div class="toast"
                 :class="{
                     'toast-success': toast.type === 'success',
                     'toast-error':   toast.type === 'error',
                     'toast-info':    toast.type === 'info',
                     'toast-warning': toast.type === 'warning',
                 }"
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0 translate-x-8"
                 x-transition:enter-end="opacity-100 translate-x-0"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0">
                <span x-text="$store.toast.icon(toast.type)" class="text-base"></span>
                <span x-text="toast.message" class="flex-1 text-sm"></span>
                <button @click="$store.toast.dismiss(toast.id)" class="opacity-60 hover:opacity-100 ml-2">
                    <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>
        </template>
    </div>

    {{-- ── App shell ────────────────────────────────────────────────────────── --}}
    <div class="flex h-screen overflow-hidden">

        {{-- ── Mobile sidebar overlay ──────────────────────────────────────── --}}
        <div class="fixed inset-0 z-40 bg-black/40 lg:hidden"
             x-data x-show="$store.sidebar.mobileOpen"
             x-transition:enter="transition-opacity ease-out duration-200"
             x-transition:enter-start="opacity-0"
             x-transition:enter-end="opacity-100"
             x-transition:leave="transition-opacity ease-in duration-150"
             x-transition:leave-end="opacity-0"
             @click="$store.sidebar.closeMobile()"
             x-cloak></div>

        {{-- ── Sidebar ──────────────────────────────────────────────────────── --}}
        <aside class="sidebar fixed lg:relative z-50 lg:z-auto h-screen transform transition-transform duration-300 ease-in-out"
               :class="{ '-translate-x-full': !$store.sidebar.mobileOpen, 'translate-x-0': $store.sidebar.mobileOpen }"
               class="lg:translate-x-0"
               x-data>

            {{-- Brand --}}
            <div class="flex items-center gap-2 px-2 mb-4">
                <img src="{{ asset('images/logo.png') }}" alt="FreeSpace Logo"
                     class="w-12 h-12 rounded-lg object-cover shrink-0">
                <div class="flex flex-col justify-center h-12 -translate-y-0.5">
                    <div class="text-base font-bold text-gray-900 leading-tight">FreeSpace</div>
                    <div class="text-[11.5px] text-gray-400 mt-0.5 leading-tight">Personal Workspace</div>
                </div>
            </div>

            {{-- Profile Card --}}
            <div class="relative" x-data="{ open: false }">
                <div @click="open = !open"
                     class="w-full h-[43px] flex items-center gap-[12px] pl-[3.5px] pr-[10px] rounded-[8px] cursor-pointer transition-all border border-[#EFEFEF] shadow-[0_2px_8px_rgba(0,0,0,0.04)]"
                     :class="open ? 'bg-[#F3F4F6]' : 'bg-[#FAFAFA] hover:bg-[#F3F4F6]'">
                    <div class="w-[36px] h-[36px] bg-white rounded-full shrink-0 overflow-hidden">
                        @if(auth()->user()?->avatar_path)
                            <img src="{{ Storage::url(auth()->user()->avatar_path) }}" alt="Avatar" class="w-full h-full object-cover">
                        @else
                            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                                <circle cx="50" cy="50" r="50" fill="#E5E7EB"/>
                                <circle cx="50" cy="37" r="18" fill="#9CA3AF"/>
                                <ellipse cx="50" cy="87" rx="30" ry="24" fill="#9CA3AF"/>
                            </svg>
                        @endif
                    </div>
                    <span class="flex-1 text-[16px] font-semibold text-[#061A33] min-w-0 truncate tracking-tight">
                        {{ Str::limit(auth()->user()?->name ?? 'Pengguna', 10) }}
                    </span>
                    <div class="w-[25px] h-[25px] rounded-full bg-white flex items-center justify-center shrink-0 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#A0A4AA" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="m7 15 5 5 5-5"/><path d="m7 9 5-5 5 5"/>
                        </svg>
                    </div>
                </div>
                {{-- Profile dropdown --}}
                <div x-show="open" @click.outside="open = false"
                     x-transition:enter="transition ease-out duration-100"
                     x-transition:enter-start="opacity-0 scale-95"
                     x-transition:enter-end="opacity-100 scale-100"
                     x-transition:leave="transition ease-in duration-75"
                     x-transition:leave-end="opacity-0 scale-95"
                     class="absolute top-full left-0 mt-2 w-full bg-white border border-gray-200 shadow-[0_4px_24px_rgba(0,0,0,0.08)] rounded-xl z-50 overflow-hidden py-1.5"
                     x-cloak>
                    <div class="px-3 py-2.5 border-b border-gray-100 mb-1 bg-gray-50/50">
                        <p class="text-sm font-bold text-gray-900">{{ auth()->user()?->name }}</p>
                        <p class="text-[10px] text-gray-500 mt-0.5">{{ auth()->user()?->email }}</p>
                    </div>
                    <a href="{{ route('profile.show') }}" wire:navigate class="flex items-center gap-2.5 px-3 py-2 hover:bg-gray-50 text-xs text-gray-700 font-medium transition-colors">
                        <x-heroicon-o-user class="w-3.5 h-3.5 text-gray-500"/> Profil Saya
                    </a>
                    <div class="my-1 border-t border-gray-100"></div>
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button type="submit" class="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-red-50 text-xs text-red-600 font-medium transition-colors">
                            <x-heroicon-o-arrow-right-start-on-rectangle class="w-3.5 h-3.5"/> Keluar
                        </button>
                    </form>
                </div>
            </div>

            <div class="my-3 border-t border-gray-100"></div>

            {{-- Navigation --}}
            <nav class="flex-1 flex flex-col gap-0.5 overflow-y-auto" aria-label="Menu utama">
                <p class="text-[9px] font-semibold uppercase tracking-widest text-gray-400 px-3 mb-1.5">
                    {{ auth()->user()?->language === 'en' ? 'Main Menu' : 'Menu Utama' }}
                </p>

                {{-- Dashboard --}}
                <x-navigation.sidebar-item
                    :href="route('dashboard')"
                    :active="request()->routeIs('dashboard')"
                    icon="layout-dashboard">
                    Dashboard
                </x-navigation.sidebar-item>

                {{-- Keuangan --}}
                <x-navigation.sidebar-group
                    menu-id="keuangan"
                    :label="auth()->user()?->language === 'en' ? 'Finance' : 'Keuangan'"
                    icon="banknotes"
                    :active="request()->routeIs('finance.*')">
                    <x-navigation.sidebar-child :href="route('finance.transactions.index')" :active="request()->routeIs('finance.transactions.*')">
                        {{ auth()->user()?->language === 'en' ? 'Transactions' : 'Transaksi' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('finance.budgets.index')" :active="request()->routeIs('finance.budgets.*')">Budget</x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('finance.analysis.index')" :active="request()->routeIs('finance.analysis.*')">
                        {{ auth()->user()?->language === 'en' ? 'Analysis & Projection' : 'Analisis & Proyeksi' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('finance.condition.index')" :active="request()->routeIs('finance.condition.*')">
                        {{ auth()->user()?->language === 'en' ? 'Financial Health' : 'Kondisi Keuangan' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('finance.investments.index')" :active="request()->routeIs('finance.investments.*')">
                        {{ auth()->user()?->language === 'en' ? 'Investment' : 'Investasi' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('finance.accounting.index')" :active="request()->routeIs('finance.accounting.*')">
                        {{ auth()->user()?->language === 'en' ? 'Accounting' : 'Akuntansi' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('finance.tax.index')" :active="request()->routeIs('finance.tax.*')">
                        {{ auth()->user()?->language === 'en' ? 'Personal Tax' : 'SPT Orang Pribadi' }}
                    </x-navigation.sidebar-child>
                </x-navigation.sidebar-group>

                {{-- Produktivitas --}}
                <x-navigation.sidebar-group
                    menu-id="produktivitas"
                    :label="auth()->user()?->language === 'en' ? 'Productivity' : 'Produktivitas'"
                    icon="check-circle"
                    :active="request()->routeIs('productivity.*')">
                    <x-navigation.sidebar-child :href="route('productivity.activities.index')" :active="request()->routeIs('productivity.activities.*')">
                        {{ auth()->user()?->language === 'en' ? 'Activities' : 'Aktivitas' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('productivity.journal.index')" :active="request()->routeIs('productivity.journal.*')">
                        {{ auth()->user()?->language === 'en' ? 'Daily Journal' : 'Jurnal Harian' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('productivity.bible.index')" :active="request()->routeIs('productivity.bible.*')">
                        {{ auth()->user()?->language === 'en' ? 'Daily Bible' : 'Renungan Harian' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('productivity.steps.index')" :active="request()->routeIs('productivity.steps.*')">
                        {{ auth()->user()?->language === 'en' ? 'Steps Tracker' : 'Pelacak Langkah' }}
                    </x-navigation.sidebar-child>
                </x-navigation.sidebar-group>

                {{-- Library --}}
                <x-navigation.sidebar-group
                    menu-id="library"
                    :label="auth()->user()?->language === 'en' ? 'Library' : 'Perpustakaan'"
                    icon="book-open"
                    :active="request()->routeIs('library.*')">
                    <x-navigation.sidebar-child :href="route('library.books.index')" :active="request()->routeIs('library.books.*')">
                        {{ auth()->user()?->language === 'en' ? 'Book Collection' : 'Koleksi Buku' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('library.reader.index')" :active="request()->routeIs('library.reader.*')">
                        {{ auth()->user()?->language === 'en' ? 'Read Book' : 'Baca Buku' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('library.accounting-space.index')" :active="request()->routeIs('library.accounting-space.*')">
                        {{ auth()->user()?->language === 'en' ? 'Accounting Space' : 'Ruang Akuntansi' }}
                    </x-navigation.sidebar-child>
                </x-navigation.sidebar-group>

                {{-- Karier --}}
                <x-navigation.sidebar-group
                    menu-id="karier"
                    :label="auth()->user()?->language === 'en' ? 'Career' : 'Karier'"
                    icon="briefcase"
                    :active="request()->routeIs('career.*')">
                    <x-navigation.sidebar-child :href="route('career.cv.index')" :active="request()->routeIs('career.cv.*')">
                        {{ auth()->user()?->language === 'en' ? 'CV Builder' : 'Pembuat CV' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('career.ats.index')" :active="request()->routeIs('career.ats.*')">
                        {{ auth()->user()?->language === 'en' ? 'ATS Analyzer' : 'Analisis ATS' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('career.toefl.index')" :active="request()->routeIs('career.toefl.*')">
                        {{ auth()->user()?->language === 'en' ? 'TOEFL Training' : 'Latihan TOEFL' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('career.interview.index')" :active="request()->routeIs('career.interview.*')">
                        {{ auth()->user()?->language === 'en' ? 'Interview Simulator' : 'Simulator Wawancara' }}
                    </x-navigation.sidebar-child>
                </x-navigation.sidebar-group>

                <div class="my-3 border-t border-gray-100"></div>

                <p class="text-[9px] font-semibold uppercase tracking-widest text-gray-400 px-3 mb-1.5">
                    {{ auth()->user()?->language === 'en' ? 'System' : 'Sistem' }}
                </p>

                {{-- Riwayat --}}
                <x-navigation.sidebar-item
                    :href="route('system.history.index')"
                    :active="request()->routeIs('system.history.*')"
                    icon="clock">
                    {{ auth()->user()?->language === 'en' ? 'History' : 'Riwayat' }}
                </x-navigation.sidebar-item>

                {{-- Pengaturan --}}
                <x-navigation.sidebar-group
                    menu-id="pengaturan"
                    :label="auth()->user()?->language === 'en' ? 'Settings' : 'Pengaturan'"
                    icon="cog-6-tooth"
                    :active="request()->routeIs('settings.*')">
                    <x-navigation.sidebar-child :href="route('settings.preferences')" :active="request()->routeIs('settings.preferences')">
                        {{ auth()->user()?->language === 'en' ? 'Preferences' : 'Preferensi' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('settings.data')" :active="request()->routeIs('settings.data')">
                        {{ auth()->user()?->language === 'en' ? 'Data Settings' : 'Pengaturan Data' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('settings.notifications')" :active="request()->routeIs('settings.notifications')">
                        {{ auth()->user()?->language === 'en' ? 'Notifications' : 'Pengaturan Notifikasi' }}
                    </x-navigation.sidebar-child>
                    <x-navigation.sidebar-child :href="route('settings.security-data')" :active="request()->routeIs('settings.security-data')">
                        {{ auth()->user()?->language === 'en' ? 'Security & Data' : 'Keamanan & Data' }}
                    </x-navigation.sidebar-child>
                </x-navigation.sidebar-group>
            </nav>

        </aside>
        {{-- ── End sidebar ─────────────────────────────────────────────────── --}}

        {{-- ── Main area ────────────────────────────────────────────────────── --}}
        <div class="flex flex-col flex-1 min-w-0 overflow-hidden">

            {{-- ── Topbar ────────────────────────────────────────────────────── --}}
            <header class="topbar" x-data>
                {{-- Breadcrumb + logo --}}
                <div class="flex items-center shrink-0 gap-2.5" style="min-width: 250px">
                    <img src="{{ asset('images/logo.png') }}" alt="FreeSpace Logo" class="w-7 h-7 object-contain">
                    @isset($breadcrumbs)
                        <div class="flex items-center gap-2.5">
                            @foreach($breadcrumbs as $crumb)
                                <svg class="w-4 h-4 text-[#8A8A8A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="m9 18 6-6-6-6"/></svg>
                                <h1 class="text-[15px] tracking-tight {{ $loop->last ? 'font-semibold text-[#171717]' : 'font-medium text-[#6F737A]' }}">{{ $crumb }}</h1>
                            @endforeach
                        </div>
                    @endisset
                </div>

                {{-- Spacer --}}
                <div class="flex-1"></div>

                {{-- Search --}}
                <div class="relative" x-data="{ open: false }">
                    <div class="flex items-center gap-2 bg-white border border-[#E5E5E5] rounded-[8px] px-3 h-[38px] w-64 cursor-text"
                         @click="open = true">
                        <svg class="w-3.5 h-3.5 text-[#9CA3AF] shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                        <span class="text-[13px] text-[#9CA3AF] flex-1">{{ auth()->user()?->language === 'en' ? 'Search...' : 'Cari...' }}</span>
                        <span class="text-[9px] font-semibold text-[#9CA3AF] bg-[#F3F4F6] px-1.5 py-0.5 rounded shrink-0">⌘K</span>
                    </div>
                    {{-- Global search modal --}}
                    <div x-show="open" @click.outside="open = false" x-cloak
                         class="fixed inset-0 z-50 flex items-start justify-center pt-20"
                         @keydown.escape.window="open = false">
                        <div class="fixed inset-0 bg-black/40" @click="open = false"></div>
                        <livewire:system.global-search />
                    </div>
                </div>

                {{-- Tanya AI button --}}
                <button @click="$dispatch('open-ai-panel')"
                        class="flex items-center gap-1.5 h-[38px] pl-3 pr-4 rounded-[8px] border border-[#6B7280] bg-white transition-colors hover:bg-gray-100"
                        title="{{ auth()->user()?->language === 'en' ? 'Ask AI' : 'Tanya AI' }}">
                    <img src="{{ asset('images/ai-logo.png') }}" alt="AI Logo" class="w-7 h-7 object-contain rounded-md">
                    <span class="text-[14px] font-medium text-[#6B7280]">
                        {{ auth()->user()?->language === 'en' ? 'Ask AI' : 'Tanya AI' }}
                    </span>
                </button>

                {{-- Notifications --}}
                <livewire:system.notification-button />

                {{-- Share --}}
                <button @click="$dispatch('open-share-modal')"
                        class="w-[38px] h-[38px] rounded-[8px] border border-[#6B7280] bg-white flex items-center justify-center hover:bg-gray-50 transition-colors"
                        title="{{ auth()->user()?->language === 'en' ? 'Share' : 'Bagikan' }}">
                    <svg class="w-[18px] h-[18px] text-[#6B7280]" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186zm0-12.814a2.25 2.25 0 1 0 3.936-2.185 2.25 2.25 0 0 0-3.936 2.185z"/>
                    </svg>
                </button>

                {{-- Mobile sidebar toggle --}}
                <button class="lg:hidden w-[38px] h-[38px] rounded-[8px] border border-gray-200 bg-white flex items-center justify-center hover:bg-gray-50 transition-colors ml-1"
                        @click="$store.sidebar.toggleMobile()">
                    <svg class="w-[18px] h-[18px] text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"/></svg>
                </button>
            </header>
            {{-- ── End topbar ─────────────────────────────────────────────── --}}

            {{-- ── Page content ────────────────────────────────────────────── --}}
            <main class="page-content" id="main-content">
                {{ $slot }}
            </main>

        </div>
        {{-- ── End main area ────────────────────────────────────────────────── --}}

    </div>
    {{-- ── End app shell ────────────────────────────────────────────────────── --}}

    {{-- ── AI Panel (slide-in from right) ─────────────────────────────────── --}}
    <livewire:system.ai-panel />

    {{-- ── Livewire scripts --}}
    @livewireScripts

    {{-- ── Route for wire:navigate ─────────────────────────────────────────── --}}
    @stack('scripts')

</body>
</html>
