@props([
    'title'  => '',
    'width'  => '380px',
    'show'   => true,
    'side'   => 'right', // right | left
])

<div x-data="{ show: @js($show) }"
     x-show="show"
     x-cloak
     @close-drawer.window="show = false">

    {{-- Backdrop --}}
    <div class="fixed inset-0 z-50 bg-black/30"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         @click="show = false"></div>

    {{-- Drawer --}}
    <div class="fixed top-0 {{ $side === 'right' ? 'right-0' : 'left-0' }} h-screen bg-white shadow-2xl z-50 flex flex-col"
         style="width: {{ $width }}"
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="{{ $side === 'right' ? 'translate-x-full' : '-translate-x-full' }}"
         x-transition:enter-end="translate-x-0"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-end="{{ $side === 'right' ? 'translate-x-full' : '-translate-x-full' }}"
         @keydown.escape.window="show = false"
         x-trap.noscroll="show"
         role="dialog"
         aria-modal="true">

        @if($title)
            <div class="flex items-center justify-between px-5 py-4 border-b border-gray-100 shrink-0">
                <h2 class="text-sm font-bold text-gray-900">{{ $title }}</h2>
                <button @click="show = false" class="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors" aria-label="Tutup">
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12"/></svg>
                </button>
            </div>
        @endif

        {{ $slot }}

    </div>

</div>
