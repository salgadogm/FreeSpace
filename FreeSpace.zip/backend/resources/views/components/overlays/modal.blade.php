@props([
    'title'  => '',
    'size'   => 'md', // sm | md | lg | xl | full
    'show'   => true,
])

@php
    $widthClass = match($size) {
        'sm'   => 'w-[380px]',
        'lg'   => 'w-[600px]',
        'xl'   => 'w-[720px]',
        'full' => 'w-full max-w-4xl',
        default => 'w-[440px]',
    };
@endphp

<div x-data="{ show: @js($show) }"
     x-show="show"
     x-cloak
     @close-modal.window="show = false">

    {{-- Backdrop --}}
    <div class="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         @click="show = false"></div>

    {{-- Modal --}}
    <div class="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-white rounded-2xl shadow-2xl {{ $widthClass }}"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-end="opacity-0 scale-95"
         @keydown.escape.window="show = false"
         x-trap.noscroll="show"
         role="dialog"
         aria-modal="true"
         aria-label="{{ $title }}">

        @if($title)
            <div class="flex items-center justify-between px-5 py-4 border-b border-gray-100">
                <h2 class="text-sm font-bold text-gray-900">{{ $title }}</h2>
                <button @click="show = false" class="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors" aria-label="Tutup">
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12"/></svg>
                </button>
            </div>
        @endif

        {{ $slot }}

    </div>

</div>
