{{-- Dashboard page — preserves exact visual design from React source --}}
<div class="page-content">
    {{-- Topbar --}}
    @php
        $breadcrumbs = ['Dashboard'];
    @endphp

    <x-navigation.topbar :breadcrumbs="$breadcrumbs" />

    {{-- Content --}}
    <div class="px-8 py-6 space-y-5">

        {{-- Summary cards --}}
        <div class="grid grid-cols-4 gap-4">
            <x-ui.summary-card
                label="{{ auth()->user()->language === 'en' ? 'Balance This Month' : 'Saldo Bulan Ini' }}"
                :value="'Rp' . number_format(($summary['balance'] ?? 0) / 100, 0, ',', '.')"
                :description="'Juli ' . now()->year"
                color="#111827"
                icon="banknotes"/>

            <x-ui.summary-card
                label="{{ auth()->user()->language === 'en' ? 'Income' : 'Pemasukan' }}"
                :value="'Rp' . number_format(($summary['income'] ?? 0) / 100, 0, ',', '.')"
                :description="auth()->user()->language === 'en' ? 'This month' : 'Bulan ini'"
                color="#22C55E"
                icon="arrow-trending-up"/>

            <x-ui.summary-card
                label="{{ auth()->user()->language === 'en' ? 'Expenses' : 'Pengeluaran' }}"
                :value="'Rp' . number_format(($summary['expense'] ?? 0) / 100, 0, ',', '.')"
                :description="auth()->user()->language === 'en' ? 'This month' : 'Bulan ini'"
                color="#EF4444"
                icon="arrow-trending-down"/>

            <x-ui.summary-card
                label="{{ auth()->user()->language === 'en' ? 'Budget Remaining' : 'Sisa Budget' }}"
                :value="'Rp' . number_format(($summary['budget_remaining'] ?? 0) / 100, 0, ',', '.')"
                :description="auth()->user()->language === 'en' ? 'Available for the month' : 'Tersedia bulan ini'"
                color="#3B82F6"
                icon="wallet"/>
        </div>

        {{-- Productivity + Steps cards --}}
        <div class="grid grid-cols-4 gap-4">
            <x-ui.summary-card
                label="{{ auth()->user()->language === 'en' ? 'Today\'s Agenda' : 'Agenda Hari Ini' }}"
                :value="$summary['today_activities'] ?? 0"
                :description="($summary['completed_today'] ?? 0) . ' selesai'"
                color="#8B5CF6"
                icon="calendar-days"/>

            <x-ui.summary-card
                label="{{ auth()->user()->language === 'en' ? 'Upcoming Deadlines' : 'Deadline Terdekat' }}"
                :value="$summary['upcoming_deadlines'] ?? 0"
                :description="auth()->user()->language === 'en' ? 'Next 7 days' : '7 hari ke depan'"
                color="#F59E0B"
                icon="exclamation-circle"/>

            <x-ui.summary-card
                label="{{ auth()->user()->language === 'en' ? 'Reading Progress' : 'Progress Membaca' }}"
                :value="($summary['active_book']?->read_percentage ?? 0) . '%'"
                :description="$summary['active_book']?->title ?? '-'"
                color="#0D9488"
                icon="book-open"/>

            <x-ui.summary-card
                label="{{ auth()->user()->language === 'en' ? 'Steps Today' : 'Langkah Hari Ini' }}"
                :value="number_format($summary['today_steps'] ?? 0, 0, ',', '.')"
                :description="($summary['steps_percentage'] ?? 0) . '% dari target'"
                color="#22C55E"
                icon="arrow-path"/>
        </div>

        {{-- Charts row --}}
        <div class="grid grid-cols-3 gap-4">

            {{-- Expense composition donut --}}
            <div class="chart-container" wire:ignore>
                <h3 class="text-sm font-semibold text-gray-800 mb-3">
                    {{ auth()->user()->language === 'en' ? 'Expense Composition' : 'Komposisi Pengeluaran' }}
                </h3>
                <div id="chart-expense-donut"
                     x-data="apexChart(@js($this->getDonutChartOptions()))"
                     x-init="init()"
                     @chart-update.window="update($event.detail)"
                     style="height:180px">
                </div>
            </div>

            {{-- Weekly progress --}}
            <div class="chart-container">
                <h3 class="text-sm font-semibold text-gray-800 mb-3">
                    {{ auth()->user()->language === 'en' ? 'Weekly Progress' : 'Progress Mingguan' }}
                </h3>
                <div class="space-y-3">
                    @foreach($this->getWeeklyProgress() as $item)
                        <div>
                            <div class="flex items-center justify-between mb-1">
                                <span class="text-xs text-gray-600">{{ $item['label'] }}</span>
                                <span class="text-xs font-semibold text-gray-800">{{ $item['pct'] }}%</span>
                            </div>
                            <div class="progress-track">
                                <div class="progress-fill" style="width:{{ $item['pct'] }}%; background-color:{{ $item['color'] }}"></div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            {{-- Expense by category bars --}}
            <div class="chart-container">
                <h3 class="text-sm font-semibold text-gray-800 mb-3">
                    {{ auth()->user()->language === 'en' ? 'Expense by Category' : 'Pengeluaran per Kategori' }}
                </h3>
                <div class="space-y-2">
                    @php $maxCat = collect($monthlyExpenseByCategory)->max('value') ?: 1; @endphp
                    @foreach($monthlyExpenseByCategory as $cat)
                        <div>
                            <div class="flex items-center justify-between mb-0.5">
                                <span class="text-xs text-gray-600 truncate w-20">{{ $cat['name'] }}</span>
                                <span class="text-xs font-semibold text-gray-700">{{ $cat['formatted'] }}</span>
                            </div>
                            <div class="progress-track">
                                <div class="progress-fill bg-blue-500" style="width:{{ round($cat['value'] / $maxCat * 100) }}%"></div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

        </div>

        {{-- Bottom tables --}}
        <div class="grid grid-cols-2 gap-4">

            {{-- Today's agenda --}}
            <div class="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                <div class="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between">
                    <h3 class="text-sm font-semibold text-gray-800">
                        {{ auth()->user()->language === 'en' ? 'Agenda & Deadlines' : 'Agenda & Deadline Terdekat' }}
                    </h3>
                    <a href="{{ route('productivity.activities.index') }}" wire:navigate class="text-xs text-gray-500 hover:text-gray-700 transition-colors">
                        {{ auth()->user()->language === 'en' ? 'See all' : 'Lihat semua' }} →
                    </a>
                </div>
                <div class="divide-y divide-gray-50">
                    @forelse($todayActivities as $activity)
                        <div class="px-5 py-3 flex items-center gap-3">
                            <div class="w-1.5 h-1.5 rounded-full shrink-0" style="background-color:{{ $activity->category?->color ?? '#9CA3AF' }}"></div>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-medium text-gray-800 truncate {{ $activity->status === 'selesai' ? 'line-through text-gray-400' : '' }}">
                                    {{ $activity->title }}
                                </p>
                                @if($activity->start_time)
                                    <p class="text-xs text-gray-400">{{ \Carbon\Carbon::parse($activity->start_time)->format('H.i') }}–{{ \Carbon\Carbon::parse($activity->end_time)->format('H.i') }}</p>
                                @endif
                            </div>
                            <x-ui.badge :color="match($activity->status) {
                                'selesai'    => '#22C55E',
                                'berjalan'   => '#3B82F6',
                                'terlambat'  => '#EF4444',
                                default      => '#6B7280',
                            }" :bg="match($activity->status) {
                                'selesai'    => '#DCFCE7',
                                'berjalan'   => '#DBEAFE',
                                'terlambat'  => '#FEE2E2',
                                default      => '#F3F4F6',
                            }" size="xs">{{ $activity->status }}</x-ui.badge>
                        </div>
                    @empty
                        <div class="px-5 py-8 text-center text-sm text-gray-400">
                            {{ auth()->user()->language === 'en' ? 'No activities today' : 'Tidak ada aktivitas hari ini' }}
                        </div>
                    @endforelse
                </div>
            </div>

            {{-- Recent transactions --}}
            <div class="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                <div class="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between">
                    <h3 class="text-sm font-semibold text-gray-800">
                        {{ auth()->user()->language === 'en' ? 'Recent Transactions' : 'Transaksi Terbaru' }}
                    </h3>
                    <a href="{{ route('finance.transactions.index') }}" wire:navigate class="text-xs text-gray-500 hover:text-gray-700 transition-colors">
                        {{ auth()->user()->language === 'en' ? 'See all' : 'Lihat semua' }} →
                    </a>
                </div>
                <div class="divide-y divide-gray-50">
                    @forelse($recentTransactions as $tx)
                        <div class="px-5 py-3 flex items-center gap-3">
                            <div class="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                                 style="background-color:{{ $tx->category?->color ? $tx->category->color . '20' : '#F3F4F6' }}">
                                <x-heroicon-o-banknotes class="w-4 h-4 text-gray-400"/>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-medium text-gray-800 truncate">{{ $tx->description }}</p>
                                <p class="text-xs text-gray-400">{{ $tx->transaction_date->format('d M Y') }}</p>
                            </div>
                            <span class="text-sm font-semibold {{ $tx->type->value === 'income' ? 'text-green-600' : 'text-red-500' }} shrink-0">
                                {{ $tx->type->value === 'income' ? '+' : '-' }}{{ $tx->formattedAmount() }}
                            </span>
                        </div>
                    @empty
                        <div class="px-5 py-8 text-center text-sm text-gray-400">
                            {{ auth()->user()->language === 'en' ? 'No recent transactions' : 'Belum ada transaksi' }}
                        </div>
                    @endforelse
                </div>
            </div>

        </div>
    </div>
</div>

@push('scripts')
<script>
// Initialize charts after Livewire renders
document.addEventListener('livewire:navigated', () => {
    window.dispatchEvent(new Event('freespace:page-loaded'));
});
</script>
@endpush
