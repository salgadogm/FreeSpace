<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Masuk — FreeSpace</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen bg-gray-50 flex items-center justify-center p-4" x-data>

    <div class="w-full max-w-sm">
        {{-- Brand --}}
        <div class="flex items-center justify-center gap-3 mb-8">
            <img src="{{ asset('images/logo.png') }}" alt="FreeSpace" class="w-12 h-12 rounded-xl">
            <div>
                <p class="text-xl font-bold text-gray-900">FreeSpace</p>
                <p class="text-xs text-gray-400">Personal Workspace</p>
            </div>
        </div>

        {{-- Card --}}
        <div class="bg-white rounded-2xl border border-gray-200 shadow-sm p-8">
            <h1 class="text-xl font-bold text-gray-900 mb-1">Masuk ke Akun</h1>
            <p class="text-xs text-gray-500 mb-6">Selamat datang kembali.</p>

            @if ($errors->any())
                <div class="bg-red-50 border border-red-200 rounded-xl p-3 mb-4 flex items-start gap-2">
                    <svg class="w-4 h-4 text-red-500 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"/></svg>
                    <div class="text-xs text-red-700">{{ $errors->first() }}</div>
                </div>
            @endif

            <form method="POST" action="{{ route('login') }}" class="space-y-4">
                @csrf

                <div>
                    <label for="email" class="block text-xs font-medium text-gray-700 mb-1.5">Email</label>
                    <input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus
                           class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-gray-900/20 focus:border-gray-400 transition-colors"
                           placeholder="nama@email.com">
                </div>

                <div>
                    <label for="password" class="block text-xs font-medium text-gray-700 mb-1.5">Password</label>
                    <input id="password" type="password" name="password" required
                           class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-gray-900/20 focus:border-gray-400 transition-colors"
                           placeholder="••••••••••••">
                </div>

                <div class="flex items-center justify-between">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="remember" class="rounded border-gray-300 text-gray-900">
                        <span class="text-xs text-gray-600">Ingat saya</span>
                    </label>
                    <a href="{{ route('password.request') }}" class="text-xs text-gray-600 hover:text-gray-900 underline transition-colors">
                        Lupa password?
                    </a>
                </div>

                <button type="submit"
                        class="w-full py-2.5 text-sm font-semibold text-white bg-gray-900 rounded-xl hover:bg-black transition-colors">
                    Masuk
                </button>

            </form>

            @if(config('app.registration_enabled', true))
                <p class="text-center text-xs text-gray-500 mt-5">
                    Belum punya akun?
                    <a href="{{ route('register') }}" class="text-gray-900 font-semibold underline">Daftar</a>
                </p>
            @endif
        </div>
    </div>

</body>
</html>
