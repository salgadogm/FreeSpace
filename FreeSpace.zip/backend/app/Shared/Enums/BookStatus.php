<?php

namespace App\Shared\Enums;

enum BookStatus: string
{
    case BelumDibaca  = 'belum_dibaca';
    case SedangDibaca = 'sedang_dibaca';
    case Selesai      = 'selesai';
    case Diarsipkan   = 'diarsipkan';

    public function label(): string
    {
        return match($this) {
            self::BelumDibaca  => 'Belum Dibaca',
            self::SedangDibaca => 'Sedang Dibaca',
            self::Selesai      => 'Selesai',
            self::Diarsipkan   => 'Diarsipkan',
        };
    }

    public function badgeClass(): string
    {
        return match($this) {
            self::BelumDibaca  => 'bg-gray-100 text-gray-500',
            self::SedangDibaca => 'bg-blue-50 text-blue-700',
            self::Selesai      => 'bg-green-50 text-green-700',
            self::Diarsipkan   => 'bg-gray-100 text-gray-400',
        };
    }
}
