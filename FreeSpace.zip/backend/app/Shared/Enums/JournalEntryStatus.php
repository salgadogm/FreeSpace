<?php

namespace App\Shared\Enums;

enum JournalEntryStatus: string
{
    case Draft    = 'draft';
    case Posted   = 'posted';
    case Reversed = 'reversed';

    public function label(): string
    {
        return match($this) {
            self::Draft    => 'Draft',
            self::Posted   => 'Diposting',
            self::Reversed => 'Dibalik',
        };
    }

    public function isImmutable(): bool
    {
        return $this === self::Posted || $this === self::Reversed;
    }
}
