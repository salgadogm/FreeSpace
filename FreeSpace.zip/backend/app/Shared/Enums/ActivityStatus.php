<?php

namespace App\Shared\Enums;

enum ActivityStatus: string
{
    case BelumMulai  = 'belum_mulai';
    case Berjalan    = 'berjalan';
    case Selesai     = 'selesai';
    case Terlambat   = 'terlambat';
    case Dibatalkan  = 'dibatalkan';

    public function label(): string
    {
        return match($this) {
            self::BelumMulai => 'Belum Mulai',
            self::Berjalan   => 'Berjalan',
            self::Selesai    => 'Selesai',
            self::Terlambat  => 'Terlambat',
            self::Dibatalkan => 'Dibatalkan',
        };
    }

    public function color(): string
    {
        return match($this) {
            self::BelumMulai => '#6B7280',
            self::Berjalan   => '#3B82F6',
            self::Selesai    => '#22C55E',
            self::Terlambat  => '#EF4444',
            self::Dibatalkan => '#9CA3AF',
        };
    }

    public function bg(): string
    {
        return match($this) {
            self::BelumMulai => '#F3F4F6',
            self::Berjalan   => '#DBEAFE',
            self::Selesai    => '#DCFCE7',
            self::Terlambat  => '#FEE2E2',
            self::Dibatalkan => '#F3F4F6',
        };
    }
}
