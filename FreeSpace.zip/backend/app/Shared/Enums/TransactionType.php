<?php

namespace App\Shared\Enums;

enum TransactionType: string
{
    case Income   = 'income';
    case Expense  = 'expense';
    case Transfer = 'transfer';

    public function label(): string
    {
        return match($this) {
            self::Income   => 'Pemasukan',
            self::Expense  => 'Pengeluaran',
            self::Transfer => 'Transfer',
        };
    }

    public function color(): string
    {
        return match($this) {
            self::Income   => '#22C55E',
            self::Expense  => '#EF4444',
            self::Transfer => '#3B82F6',
        };
    }
}
