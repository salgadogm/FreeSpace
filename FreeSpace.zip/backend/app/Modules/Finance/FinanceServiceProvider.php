<?php

namespace App\Modules\Finance;

use Illuminate\Support\ServiceProvider;

class FinanceServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(Services\FinancialSummaryService::class);
        $this->app->singleton(Services\BudgetAnalysisService::class);
        $this->app->singleton(Services\RecurringTransactionService::class);
        $this->app->singleton(Services\FinancialForecastService::class);
    }

    public function boot(): void
    {
        //
    }
}
