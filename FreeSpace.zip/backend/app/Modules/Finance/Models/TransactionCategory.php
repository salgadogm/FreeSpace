<?php

namespace App\Modules\Finance\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class TransactionCategory extends Model
{
    use HasFactory;

    protected $table = 'transaction_categories';

    protected $fillable = [
        'user_id', 'name', 'type', 'icon', 'color', 'is_active', 'sort_order',
    ];

    protected function casts(): array
    {
        return ['is_active' => 'boolean'];
    }

    public function user()    { return $this->belongsTo(User::class); }
    public function transactions() { return $this->hasMany(FinancialTransaction::class, 'category_id'); }
    public function budgetItems()  { return $this->hasMany(BudgetItem::class, 'category_id'); }
}
