<?php

namespace App\Modules\Finance\Models;

use App\Models\User;
use App\Shared\Enums\TransactionType;
use Brick\Money\Money;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Laravel\Scout\Searchable;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class FinancialTransaction extends Model
{
    use HasFactory, SoftDeletes, Searchable, LogsActivity;

    protected $table = 'financial_transactions';

    protected $fillable = [
        'user_id', 'category_id', 'account_id', 'transfer_to_account_id',
        'parent_id', 'type', 'amount_minor', 'transfer_amount_minor',
        'currency', 'description', 'notes', 'transaction_date',
        'is_recurring', 'recurring_frequency', 'recurring_end_date',
        'tags', 'ai_generated', 'ai_request_id',
    ];

    protected function casts(): array
    {
        return [
            'transaction_date'  => 'date',
            'recurring_end_date' => 'date',
            'type'              => TransactionType::class,
            'is_recurring'      => 'boolean',
            'ai_generated'      => 'boolean',
            'tags'              => 'array',
            'amount_minor'      => 'integer',
            'transfer_amount_minor' => 'integer',
        ];
    }

    // ── Money helpers using brick/money ───────────────────────────────────────
    public function amount(): Money
    {
        return Money::ofMinor($this->amount_minor, $this->currency);
    }

    public function formattedAmount(): string
    {
        return 'Rp' . number_format($this->amount_minor / 100, 0, ',', '.');
    }

    // ── Scout searchable ──────────────────────────────────────────────────────
    public function toSearchableArray(): array
    {
        return [
            'id'          => $this->id,
            'description' => $this->description,
            'notes'       => $this->notes ?? '',
            'type'        => $this->type->value,
        ];
    }

    // ── Relationships ─────────────────────────────────────────────────────────
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function category()
    {
        return $this->belongsTo(TransactionCategory::class);
    }

    public function account()
    {
        return $this->belongsTo(FinancialAccount::class);
    }

    public function transferToAccount()
    {
        return $this->belongsTo(FinancialAccount::class, 'transfer_to_account_id');
    }

    // ── Scopes ────────────────────────────────────────────────────────────────
    public function scopeForUser($query, int $userId)
    {
        return $query->where('user_id', $userId);
    }

    public function scopeInMonth($query, int $year, int $month)
    {
        return $query->whereYear('transaction_date', $year)
                     ->whereMonth('transaction_date', $month);
    }

    // ── Activity Log ──────────────────────────────────────────────────────────
    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['description', 'amount_minor', 'type', 'transaction_date', 'category_id'])
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs();
    }
}
