<?php

namespace App\Modules\Finance\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class FinancialAccount extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'financial_accounts';

    protected $fillable = [
        'user_id', 'name', 'type', 'initial_balance_minor',
        'currency', 'is_active', 'is_default', 'color', 'icon',
    ];

    protected function casts(): array
    {
        return [
            'is_active'  => 'boolean',
            'is_default' => 'boolean',
            'initial_balance_minor' => 'integer',
        ];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function transactions()
    {
        return $this->hasMany(FinancialTransaction::class, 'account_id');
    }

    public function getTypeLabel(): string
    {
        return match($this->type) {
            'kas'            => 'Kas',
            'bank'           => 'Bank',
            'dompet_digital' => 'Dompet Digital',
            'tabungan'       => 'Tabungan',
            'investasi'      => 'Investasi',
            default          => 'Lainnya',
        };
    }
}
