<?php

namespace App\Modules\Finance\Livewire;

use App\Modules\Finance\Models\FinancialTransaction;
use App\Modules\Finance\Models\FinancialAccount;
use App\Modules\Finance\Models\TransactionCategory;
use App\Shared\Enums\TransactionType;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Url;
use Livewire\Attributes\Validate;
use Livewire\Component;
use Livewire\WithPagination;
use Illuminate\Support\Facades\DB;

#[Layout('components.layouts.app')]
#[Title('Transaksi')]
class TransactionsPage extends Component
{
    use WithPagination;

    public array $breadcrumbs = ['Keuangan', 'Transaksi'];

    // ── Filters (synced to URL) ───────────────────────────────────────────────
    #[Url(as: 'q')]
    public string $search = '';

    #[Url(as: 'type')]
    public string $filterType = '';

    #[Url(as: 'cat')]
    public string $filterCategory = '';

    #[Url(as: 'month')]
    public string $filterMonth = '';

    #[Url(as: 'sort')]
    public string $sortBy = 'transaction_date';

    #[Url(as: 'dir')]
    public string $sortDir = 'desc';

    // ── Modal state ───────────────────────────────────────────────────────────
    public bool $showCreateModal  = false;
    public bool $showDeleteModal  = false;
    public ?int $editingId        = null;
    public ?int $deletingId       = null;

    // ── Form fields ───────────────────────────────────────────────────────────
    #[Validate('required|string|max:255')]
    public string $description = '';

    #[Validate('required|numeric|min:0.01')]
    public string $amount = '';

    #[Validate('required|in:income,expense,transfer')]
    public string $type = 'expense';

    #[Validate('required|date')]
    public string $date = '';

    #[Validate('nullable|integer')]
    public ?int $categoryId = null;

    #[Validate('nullable|integer')]
    public ?int $accountId = null;

    public string $notes = '';
    public bool   $isRecurring = false;
    public string $recurringFrequency = '';

    // ── Watchers for pagination reset ─────────────────────────────────────────
    public function updatingSearch(): void { $this->resetPage(); }
    public function updatingFilterType(): void { $this->resetPage(); }
    public function updatingFilterCategory(): void { $this->resetPage(); }
    public function updatingFilterMonth(): void { $this->resetPage(); }

    // ── Computed data ─────────────────────────────────────────────────────────
    #[Computed]
    public function transactions()
    {
        return FinancialTransaction::query()
            ->where('user_id', auth()->id())
            ->when($this->search, fn($q) => $q->where('description', 'like', "%{$this->search}%"))
            ->when($this->filterType, fn($q) => $q->where('type', $this->filterType))
            ->when($this->filterCategory, fn($q) => $q->where('category_id', $this->filterCategory))
            ->when($this->filterMonth, fn($q) => $q->whereRaw("DATE_FORMAT(transaction_date,'%Y-%m') = ?", [$this->filterMonth]))
            ->orderBy($this->sortBy, $this->sortDir)
            ->with(['category', 'account'])
            ->paginate(15);
    }

    #[Computed(persist: true, seconds: 60)]
    public function monthlySummary(): array
    {
        $month = $this->filterMonth ?: now()->format('Y-m');
        return FinancialTransaction::query()
            ->where('user_id', auth()->id())
            ->whereRaw("DATE_FORMAT(transaction_date,'%Y-%m') = ?", [$month])
            ->selectRaw("
                SUM(CASE WHEN type='income'  THEN amount_minor ELSE 0 END) as total_income,
                SUM(CASE WHEN type='expense' THEN amount_minor ELSE 0 END) as total_expense,
                COUNT(*) as total_count
            ")
            ->first()?->toArray() ?? ['total_income' => 0, 'total_expense' => 0, 'total_count' => 0];
    }

    #[Computed]
    public function categories()
    {
        return TransactionCategory::where('user_id', auth()->id())->orderBy('name')->get();
    }

    #[Computed]
    public function accounts()
    {
        return FinancialAccount::where('user_id', auth()->id())->where('is_active', true)->get();
    }

    // ── Actions ───────────────────────────────────────────────────────────────
    public function openCreate(): void
    {
        $this->reset(['description', 'amount', 'type', 'date', 'categoryId', 'accountId', 'notes', 'isRecurring', 'recurringFrequency', 'editingId']);
        $this->date          = now()->format('Y-m-d');
        $this->type          = 'expense';
        $this->showCreateModal = true;
    }

    public function openEdit(int $id): void
    {
        $tx = FinancialTransaction::where('user_id', auth()->id())->findOrFail($id);
        $this->editingId           = $tx->id;
        $this->description         = $tx->description;
        $this->amount              = (string) ($tx->amount_minor / 100);
        $this->type                = $tx->type->value;
        $this->date                = $tx->transaction_date->format('Y-m-d');
        $this->categoryId          = $tx->category_id;
        $this->accountId           = $tx->account_id;
        $this->notes               = $tx->notes ?? '';
        $this->isRecurring         = $tx->is_recurring;
        $this->recurringFrequency  = $tx->recurring_frequency ?? '';
        $this->showCreateModal     = true;
    }

    public function save(): void
    {
        $this->validate();

        DB::transaction(function () {
            $data = [
                'user_id'             => auth()->id(),
                'description'         => $this->description,
                'amount_minor'        => (int) round((float) $this->amount * 100),
                'type'                => $this->type,
                'transaction_date'    => $this->date,
                'category_id'         => $this->categoryId,
                'account_id'          => $this->accountId,
                'notes'               => $this->notes ?: null,
                'is_recurring'        => $this->isRecurring,
                'recurring_frequency' => $this->isRecurring ? $this->recurringFrequency : null,
            ];

            if ($this->editingId) {
                FinancialTransaction::where('user_id', auth()->id())->findOrFail($this->editingId)->update($data);
                $this->dispatch('toast', type: 'success', message: 'Transaksi berhasil diperbarui.');
            } else {
                FinancialTransaction::create($data);
                $this->dispatch('toast', type: 'success', message: 'Transaksi berhasil ditambahkan.');
            }
        });

        $this->showCreateModal = false;
        unset($this->transactions, $this->monthlySummary);
    }

    public function confirmDelete(int $id): void
    {
        $this->deletingId    = $id;
        $this->showDeleteModal = true;
    }

    public function delete(): void
    {
        if ($this->deletingId) {
            FinancialTransaction::where('user_id', auth()->id())->findOrFail($this->deletingId)->delete();
            $this->dispatch('toast', type: 'success', message: 'Transaksi berhasil dihapus.');
        }
        $this->showDeleteModal = false;
        $this->deletingId      = null;
        unset($this->transactions, $this->monthlySummary);
    }

    public function sortOn(string $column): void
    {
        if ($this->sortBy === $column) {
            $this->sortDir = $this->sortDir === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortBy  = $column;
            $this->sortDir = 'desc';
        }
    }

    public function render()
    {
        return view('livewire.finance.transactions-page');
    }
}
