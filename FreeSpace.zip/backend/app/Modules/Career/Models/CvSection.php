<?php
namespace App\Modules\Career\Models;
use Illuminate\Database\Eloquent\Model;
class CvSection extends Model {
    protected $table = 'cv_sections';
    protected $fillable = ['cv_id','section_key','label','content_json','is_visible','sort_order'];
    protected function casts(): array { return ['is_visible' => 'boolean', 'content_json' => 'array']; }
    public function cv() { return $this->belongsTo(CvDocument::class, 'cv_id'); }
}
