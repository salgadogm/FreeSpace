<?php
namespace App\Modules\Career\Models;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
class InterviewQuestion extends Model {
    protected $table = 'interview_question_bank';
    protected $fillable = ['user_id','question','type','field','difficulty','language','is_saved'];
    protected function casts(): array { return ['is_saved' => 'boolean']; }
    public function user() { return $this->belongsTo(User::class); }
}
