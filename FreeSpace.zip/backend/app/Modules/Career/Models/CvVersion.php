<?php
namespace App\Modules\Career\Models;
use Illuminate\Database\Eloquent\Model;
class CvVersion extends Model {
    protected $table = 'cv_versions';
    protected $fillable = ['cv_id','user_id','version_label','change_description','snapshot_json','source'];
    protected function casts(): array { return ['snapshot_json' => 'array']; }
    public function cv() { return $this->belongsTo(CvDocument::class, 'cv_id'); }
}
