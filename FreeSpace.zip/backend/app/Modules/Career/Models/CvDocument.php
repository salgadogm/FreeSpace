<?php
namespace App\Modules\Career\Models;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CvDocument extends Model {
    use HasFactory, SoftDeletes;
    protected $table = 'cv_documents';
    protected $fillable = ['user_id','name','target_position','language','template','completeness','last_ats_score','status','is_active','sort_order'];
    protected function casts(): array { return ['is_active' => 'boolean', 'completeness' => 'integer', 'last_ats_score' => 'integer']; }
    public function user() { return $this->belongsTo(User::class); }
    public function sections() { return $this->hasMany(CvSection::class, 'cv_id'); }
    public function versions() { return $this->hasMany(CvVersion::class, 'cv_id'); }
}
