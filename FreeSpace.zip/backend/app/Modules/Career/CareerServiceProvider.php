<?php

namespace App\Modules\Career;

use Illuminate\Support\ServiceProvider;

class CareerServiceProvider extends ServiceProvider
{
    public function register(): void {}
    public function boot(): void {}
}
