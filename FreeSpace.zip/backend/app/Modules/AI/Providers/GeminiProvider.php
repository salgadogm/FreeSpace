<?php

namespace App\Modules\AI\Providers;

use App\Modules\AI\Contracts\AIProviderInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class GeminiProvider implements AIProviderInterface
{
    private string $apiKey;
    private string $model;
    private int    $timeout;
    private int    $maxRetries;
    private string $baseUrl;

    public function __construct()
    {
        $this->apiKey     = config('ai.providers.gemini.api_key', '');
        $this->model      = config('ai.providers.gemini.model', 'gemini-2.0-flash');
        $this->timeout    = config('ai.providers.gemini.timeout', 30);
        $this->maxRetries = config('ai.providers.gemini.max_retries', 2);
        $this->baseUrl    = config('ai.providers.gemini.base_url', 'https://generativelanguage.googleapis.com/v1beta');
    }

    public function generateText(string $prompt, array $options = []): string
    {
        $response = $this->call('generateContent', [
            'contents' => [
                ['role' => 'user', 'parts' => [['text' => $prompt]]],
            ],
            'systemInstruction' => isset($options['system'])
                ? ['parts' => [['text' => $options['system']]]]
                : null,
        ]);

        return $response['candidates'][0]['content']['parts'][0]['text'] ?? '';
    }

    public function generateStructured(string $prompt, array $jsonSchema, array $options = []): array
    {
        $response = $this->call('generateContent', [
            'contents' => [
                ['role' => 'user', 'parts' => [['text' => $prompt]]],
            ],
            'generationConfig' => [
                'response_mime_type' => 'application/json',
                'response_schema'    => $jsonSchema,
            ],
        ]);

        $text = $response['candidates'][0]['content']['parts'][0]['text'] ?? '{}';

        $decoded = json_decode($text, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \RuntimeException('Gemini returned invalid JSON: ' . $text);
        }

        return $decoded;
    }

    public function analyzeImage(string $base64Image, string $prompt, string $mimeType = 'image/jpeg'): string
    {
        $apiKey = config('ai.providers.gemini_vision.api_key', $this->apiKey);

        $response = Http::withQueryParameters(['key' => $apiKey])
            ->timeout($this->timeout)
            ->retry($this->maxRetries, 500)
            ->post("{$this->baseUrl}/models/{$this->model}:generateContent", [
                'contents' => [[
                    'parts' => [
                        ['inline_data' => ['mime_type' => $mimeType, 'data' => $base64Image]],
                        ['text' => $prompt],
                    ],
                ]],
            ]);

        $response->throw();

        return $response->json('candidates.0.content.parts.0.text', '');
    }

    public function summarize(string $text, int $maxWords = 100): string
    {
        return $this->generateText(
            "Ringkas teks berikut dalam maksimal {$maxWords} kata dalam Bahasa Indonesia:\n\n{$text}"
        );
    }

    public function healthCheck(): bool
    {
        try {
            $this->call('generateContent', [
                'contents' => [['role' => 'user', 'parts' => [['text' => 'ping']]]],
                'generationConfig' => ['maxOutputTokens' => 5],
            ]);
            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    public function getName(): string { return 'gemini'; }

    private function call(string $endpoint, array $payload): array
    {
        $response = Http::withQueryParameters(['key' => $this->apiKey])
            ->timeout($this->timeout)
            ->retry($this->maxRetries, 500, fn ($e) => $e instanceof \Illuminate\Http\Client\ConnectionException)
            ->post("{$this->baseUrl}/models/{$this->model}:{$endpoint}", array_filter($payload));

        $response->throw();

        return $response->json();
    }
}
