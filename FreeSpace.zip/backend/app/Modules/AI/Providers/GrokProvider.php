<?php

namespace App\Modules\AI\Providers;

use App\Modules\AI\Contracts\AIProviderInterface;
use Illuminate\Support\Facades\Http;

class GrokProvider implements AIProviderInterface
{
    private string $apiKey;
    private string $model;
    private int    $timeout;
    private int    $maxRetries;
    private string $baseUrl;

    public function __construct()
    {
        $this->apiKey     = config('ai.providers.grok.api_key', '');
        $this->model      = config('ai.providers.grok.model', 'grok-3-mini');
        $this->timeout    = config('ai.providers.grok.timeout', 30);
        $this->maxRetries = config('ai.providers.grok.max_retries', 2);
        $this->baseUrl    = config('ai.providers.grok.base_url', 'https://api.x.ai/v1');
    }

    public function generateText(string $prompt, array $options = []): string
    {
        $response = Http::withToken($this->apiKey)
            ->timeout($this->timeout)
            ->retry($this->maxRetries, 500)
            ->post("{$this->baseUrl}/chat/completions", [
                'model'    => $this->model,
                'messages' => [
                    ['role' => 'system', 'content' => $options['system'] ?? 'You are a helpful assistant. Respond in Indonesian unless asked otherwise.'],
                    ['role' => 'user',   'content' => $prompt],
                ],
                'max_tokens' => $options['max_tokens'] ?? 2048,
            ]);

        $response->throw();

        return $response->json('choices.0.message.content', '');
    }

    public function generateStructured(string $prompt, array $jsonSchema, array $options = []): array
    {
        $schemaPrompt = $prompt . "\n\nRespond with valid JSON only, matching this schema: " . json_encode($jsonSchema);
        $text = $this->generateText($schemaPrompt, $options);

        // Extract JSON from response
        if (preg_match('/```json\s*(.*?)\s*```/s', $text, $matches)) {
            $text = $matches[1];
        } elseif (preg_match('/\{.*\}/s', $text, $matches)) {
            $text = $matches[0];
        }

        $decoded = json_decode($text, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \RuntimeException('Grok returned invalid JSON: ' . $text);
        }

        return $decoded;
    }

    public function analyzeImage(string $base64Image, string $prompt, string $mimeType = 'image/jpeg'): string
    {
        // Grok vision (when available)
        $response = Http::withToken($this->apiKey)
            ->timeout($this->timeout)
            ->post("{$this->baseUrl}/chat/completions", [
                'model'    => 'grok-2-vision',
                'messages' => [[
                    'role'    => 'user',
                    'content' => [
                        ['type' => 'image_url', 'image_url' => ['url' => "data:{$mimeType};base64,{$base64Image}"]],
                        ['type' => 'text', 'text' => $prompt],
                    ],
                ]],
                'max_tokens' => 1024,
            ]);

        $response->throw();

        return $response->json('choices.0.message.content', '');
    }

    public function summarize(string $text, int $maxWords = 100): string
    {
        return $this->generateText(
            "Ringkas teks berikut dalam maksimal {$maxWords} kata dalam Bahasa Indonesia:\n\n{$text}"
        );
    }

    public function healthCheck(): bool
    {
        try {
            $this->generateText('ping', ['max_tokens' => 5]);
            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    public function getName(): string { return 'grok'; }
}
