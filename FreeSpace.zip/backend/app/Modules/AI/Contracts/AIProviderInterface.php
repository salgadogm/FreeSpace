<?php

namespace App\Modules\AI\Contracts;

interface AIProviderInterface
{
    /**
     * Generate a text response.
     */
    public function generateText(string $prompt, array $options = []): string;

    /**
     * Generate a structured JSON response validated against a schema.
     *
     * @param  array  $jsonSchema  JSON Schema object
     */
    public function generateStructured(string $prompt, array $jsonSchema, array $options = []): array;

    /**
     * Analyze an image (base64 encoded).
     */
    public function analyzeImage(string $base64Image, string $prompt, string $mimeType = 'image/jpeg'): string;

    /**
     * Summarize given text.
     */
    public function summarize(string $text, int $maxWords = 100): string;

    /**
     * Check if the provider API is reachable.
     */
    public function healthCheck(): bool;

    /**
     * Get the provider name/identifier.
     */
    public function getName(): string;
}
