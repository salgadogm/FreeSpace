<?php

namespace App\Modules\AI\Services;

use App\Modules\AI\Contracts\AIProviderInterface;
use App\Modules\AI\Providers\GeminiProvider;
use App\Modules\AI\Providers\GrokProvider;
use Illuminate\Support\Facades\Log;

class AIProviderManager
{
    private array $providers = [];

    public function __construct()
    {
        $this->providers['gemini'] = new GeminiProvider();
        $this->providers['grok']   = new GrokProvider();
    }

    /**
     * Get a provider by name. Falls back to default if not found.
     */
    public function provider(string $name = null): AIProviderInterface
    {
        $name ??= config('ai.default_provider', 'gemini');

        if (! isset($this->providers[$name])) {
            throw new \InvalidArgumentException("Unknown AI provider: {$name}");
        }

        return $this->providers[$name];
    }

    /**
     * Get the default provider.
     */
    public function default(): AIProviderInterface
    {
        return $this->provider();
    }

    /**
     * Try a request with fallback to other provider on failure.
     *
     * @throws \Throwable if all providers fail
     */
    public function withFallback(callable $callback): mixed
    {
        $primary  = config('ai.default_provider', 'gemini');
        $fallback = $primary === 'gemini' ? 'grok' : 'gemini';

        try {
            return $callback($this->provider($primary));
        } catch (\Throwable $e) {
            if (! config('ai.fallback', false)) {
                throw $e;
            }

            Log::warning("AI provider {$primary} failed, falling back to {$fallback}", [
                'error' => $e->getMessage(),
            ]);

            return $callback($this->provider($fallback));
        }
    }
}
