<?php

namespace App\Modules\Productivity;

use Illuminate\Support\ServiceProvider;

class ProductivityServiceProvider extends ServiceProvider
{
    public function register(): void {}
    public function boot(): void {}
}
