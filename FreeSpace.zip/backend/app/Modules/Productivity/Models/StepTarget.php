<?php
namespace App\Modules\Productivity\Models;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
class StepTarget extends Model {
    protected $table = 'step_targets';
    protected $fillable = ['user_id','daily_target','weekend_target','active_days','reminder_time','reminder_enabled','effective_from'];
    protected function casts(): array { return ['active_days' => 'array', 'reminder_enabled' => 'boolean', 'effective_from' => 'date']; }
    public function user() { return $this->belongsTo(User::class); }
}
