<?php
namespace App\Modules\Productivity\Models;
use Illuminate\Database\Eloquent\Model;
class ActivityReminder extends Model {
    protected $table = 'activity_reminders';
    protected $fillable = ['activity_id','remind_before','sent','scheduled_at'];
    protected function casts(): array { return ['sent' => 'boolean', 'scheduled_at' => 'datetime']; }
    public function activity() { return $this->belongsTo(Activity::class); }
}
