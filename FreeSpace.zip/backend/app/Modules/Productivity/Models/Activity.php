<?php

namespace App\Modules\Productivity\Models;

use App\Models\User;
use App\Shared\Enums\ActivityStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Activity extends Model
{
    use HasFactory, SoftDeletes, LogsActivity;

    protected $table = 'activities';

    protected $fillable = [
        'user_id', 'category_id', 'title', 'description', 'date',
        'start_time', 'end_time', 'all_day', 'priority', 'status',
        'completed_at', 'notes',
    ];

    protected function casts(): array
    {
        return [
            'date'         => 'date',
            'start_time'   => 'datetime:H:i',
            'end_time'     => 'datetime:H:i',
            'all_day'      => 'boolean',
            'completed_at' => 'datetime',
            'status'       => ActivityStatus::class,
        ];
    }

    public function user()     { return $this->belongsTo(User::class); }
    public function category() { return $this->belongsTo(ActivityCategory::class); }
    public function recurrence() { return $this->hasOne(ActivityRecurrence::class); }
    public function reminders()  { return $this->hasMany(ActivityReminder::class); }

    public function scopeForUser($q, int $uid) { return $q->where('user_id', $uid); }
    public function scopeToday($q)             { return $q->whereDate('date', today()); }
    public function scopePending($q)           { return $q->whereNotIn('status', ['selesai', 'dibatalkan']); }

    public function isCompleted(): bool { return $this->status === ActivityStatus::Selesai; }

    public function complete(): void
    {
        $this->update(['status' => ActivityStatus::Selesai, 'completed_at' => now()]);
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()->logOnly(['title','status','date'])->logOnlyDirty()->dontSubmitEmptyLogs();
    }
}
