<?php

namespace App\Modules\Productivity\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StepRecord extends Model
{
    use HasFactory;

    protected $table = 'step_records';

    protected $fillable = [
        'user_id', 'record_date', 'steps', 'target', 'source', 'notes',
    ];

    protected function casts(): array
    {
        return ['record_date' => 'date'];
    }

    public function user() { return $this->belongsTo(User::class); }

    public function percentage(): int
    {
        return $this->target > 0 ? min(100, (int) round($this->steps / $this->target * 100)) : 0;
    }

    public function isAchieved(): bool
    {
        return $this->steps >= $this->target;
    }
}
