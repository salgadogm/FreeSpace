<?php
namespace App\Modules\Productivity\Models;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
class ActivityCategory extends Model {
    protected $table = 'activity_categories';
    protected $fillable = ['user_id','name','color','icon','is_active','sort_order'];
    protected function casts(): array { return ['is_active' => 'boolean']; }
    public function user() { return $this->belongsTo(User::class); }
    public function activities() { return $this->hasMany(Activity::class, 'category_id'); }
}
