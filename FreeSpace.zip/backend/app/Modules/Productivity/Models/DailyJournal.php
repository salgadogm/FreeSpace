<?php
namespace App\Modules\Productivity\Models;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
class DailyJournal extends Model {
    protected $table = 'daily_journals';
    protected $fillable = ['user_id','journal_date','title','mood','story','gratitude','lesson','reflection','tomorrow_plan','tags','status'];
    protected function casts(): array { return ['journal_date' => 'date', 'gratitude' => 'array', 'tomorrow_plan' => 'array', 'tags' => 'array']; }
    public function user() { return $this->belongsTo(User::class); }
}
