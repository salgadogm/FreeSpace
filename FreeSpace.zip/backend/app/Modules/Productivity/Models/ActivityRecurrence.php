<?php
namespace App\Modules\Productivity\Models;
use Illuminate\Database\Eloquent\Model;
class ActivityRecurrence extends Model {
    protected $table = 'activity_recurrences';
    protected $fillable = ['activity_id','frequency','days_of_week','interval','end_date','never_ends'];
    protected function casts(): array { return ['days_of_week' => 'array', 'end_date' => 'date', 'never_ends' => 'boolean']; }
    public function activity() { return $this->belongsTo(Activity::class); }
}
