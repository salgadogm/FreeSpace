<?php

namespace App\Modules\Library\Models;

use App\Models\User;
use App\Shared\Enums\BookStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Laravel\Scout\Searchable;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Book extends Model implements HasMedia
{
    use HasFactory, SoftDeletes, Searchable, InteractsWithMedia;

    protected $fillable = [
        'user_id', 'category_id', 'title', 'author', 'description', 'language',
        'total_pages', 'isbn', 'published_year', 'tags', 'status', 'is_favorite',
        'current_page', 'read_percentage', 'last_read_at', 'file_status',
        'file_size_bytes', 'subject',
    ];

    protected function casts(): array
    {
        return [
            'is_favorite'  => 'boolean',
            'tags'         => 'array',
            'status'       => BookStatus::class,
            'last_read_at' => 'datetime',
        ];
    }

    // ── Media collections ─────────────────────────────────────────────────────
    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('pdf')
            ->useDisk('media')
            ->singleFile();

        $this->addMediaCollection('cover')
            ->useDisk('media')
            ->singleFile();
    }

    // ── Scout ─────────────────────────────────────────────────────────────────
    public function toSearchableArray(): array
    {
        return ['id' => $this->id, 'title' => $this->title, 'author' => $this->author ?? ''];
    }

    // ── Relationships ─────────────────────────────────────────────────────────
    public function user()          { return $this->belongsTo(User::class); }
    public function category()      { return $this->belongsTo(BookCategory::class); }
    public function readingSessions() { return $this->hasMany(ReadingSession::class); }
    public function bookmarks()      { return $this->hasMany(BookBookmark::class); }
    public function highlights()     { return $this->hasMany(BookHighlight::class); }
    public function notes()          { return $this->hasMany(BookNote::class); }

    // ── Helpers ───────────────────────────────────────────────────────────────
    public function isReady(): bool { return $this->file_status === 'ready'; }

    public function updateProgress(int $currentPage): void
    {
        $pct = $this->total_pages > 0
            ? min(100, (int) round($currentPage / $this->total_pages * 100))
            : 0;

        $this->update([
            'current_page'    => $currentPage,
            'read_percentage' => $pct,
            'last_read_at'    => now(),
            'status'          => $pct >= 100 ? BookStatus::Selesai : BookStatus::SedangDibaca,
        ]);
    }
}
