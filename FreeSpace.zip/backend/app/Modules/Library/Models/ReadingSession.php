<?php

namespace App\Modules\Library\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReadingSession extends Model
{
    use HasFactory;

    protected $table = 'reading_sessions';

    protected $fillable = [
        'user_id', 'book_id', 'start_page', 'end_page', 'pages_read',
        'started_at', 'ended_at', 'duration_minutes',
    ];

    protected function casts(): array
    {
        return [
            'started_at' => 'datetime',
            'ended_at'   => 'datetime',
        ];
    }

    public function user() { return $this->belongsTo(User::class); }
    public function book() { return $this->belongsTo(Book::class); }

    public function end(int $endPage): void
    {
        $duration = (int) now()->diffInMinutes($this->started_at);
        $this->update([
            'end_page'         => $endPage,
            'pages_read'       => max(0, $endPage - $this->start_page),
            'ended_at'         => now(),
            'duration_minutes' => $duration,
        ]);
    }
}
