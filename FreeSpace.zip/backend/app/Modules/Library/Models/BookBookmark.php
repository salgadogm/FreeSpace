<?php
namespace App\Modules\Library\Models;
use Illuminate\Database\Eloquent\Model;
class BookBookmark extends Model {
    protected $table = 'book_bookmarks';
    protected $fillable = ['user_id','book_id','page_number','label'];
    public function book() { return $this->belongsTo(Book::class); }
}
