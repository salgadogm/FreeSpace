<?php
namespace App\Modules\Library\Models;
use Illuminate\Database\Eloquent\Model;
class BookHighlight extends Model {
    protected $table = 'book_highlights';
    protected $fillable = ['user_id','book_id','page_number','text_excerpt','color','note'];
    public function book() { return $this->belongsTo(Book::class); }
}
