<?php
namespace App\Modules\Library\Models;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
class BookCategory extends Model {
    protected $table = 'book_categories';
    protected $fillable = ['user_id','name','sort_order'];
    public function user() { return $this->belongsTo(User::class); }
    public function books() { return $this->hasMany(Book::class, 'category_id'); }
}
