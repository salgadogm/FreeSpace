<?php
namespace App\Modules\Library\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class BookNote extends Model {
    use SoftDeletes;
    protected $table = 'book_notes';
    protected $fillable = ['user_id','book_id','title','subject','topic','page_reference','page_range','content','tags','is_favorite','status'];
    protected function casts(): array { return ['tags' => 'array', 'is_favorite' => 'boolean']; }
    public function book() { return $this->belongsTo(Book::class); }
}
