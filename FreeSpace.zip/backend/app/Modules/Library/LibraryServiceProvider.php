<?php

namespace App\Modules\Library;

use Illuminate\Support\ServiceProvider;

class LibraryServiceProvider extends ServiceProvider
{
    public function register(): void {}
    public function boot(): void {}
}
