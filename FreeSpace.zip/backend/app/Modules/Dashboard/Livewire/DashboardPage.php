<?php

namespace App\Modules\Dashboard\Livewire;

use App\Modules\Dashboard\Services\DashboardSummaryService;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Attributes\Computed;
use Livewire\Component;

#[Layout('components.layouts.app')]
#[Title('Dashboard')]
class DashboardPage extends Component
{
    public array $breadcrumbs = ['Dashboard'];

    #[Computed(persist: true, seconds: 300)]
    public function summary(): array
    {
        return app(DashboardSummaryService::class)->getSummary(auth()->user());
    }

    #[Computed]
    public function recentTransactions()
    {
        return app(DashboardSummaryService::class)->getRecentTransactions(auth()->user());
    }

    #[Computed]
    public function todayActivities()
    {
        return app(DashboardSummaryService::class)->getTodayActivities(auth()->user());
    }

    // ── Finance chart data ────────────────────────────────────────────────────
    #[Computed(persist: true, seconds: 300)]
    public function monthlyExpenseByCategory(): array
    {
        return \App\Modules\Finance\Models\FinancialTransaction::query()
            ->where('user_id', auth()->id())
            ->where('type', 'expense')
            ->whereYear('transaction_date', now()->year)
            ->whereMonth('transaction_date', now()->month)
            ->join('transaction_categories', 'transaction_categories.id', '=', 'financial_transactions.category_id')
            ->selectRaw('transaction_categories.name, SUM(amount_minor) as total')
            ->groupBy('transaction_categories.id', 'transaction_categories.name')
            ->orderByDesc('total')
            ->limit(6)
            ->get()
            ->map(fn ($row) => [
                'name'  => $row->name,
                'value' => $row->total,
                'formatted' => 'Rp' . number_format($row->total / 100, 0, ',', '.'),
            ])
            ->toArray();
    }

    public function render()
    {
        return view('livewire.dashboard.dashboard-page', [
            'breadcrumbs' => $this->breadcrumbs,
        ]);
    }
}
