<?php

namespace App\Modules\Dashboard\Services;

use App\Models\User;
use Illuminate\Support\Facades\Cache;

class DashboardSummaryService
{
    public function getSummary(User $user): array
    {
        return Cache::remember(
            "dashboard_summary_{$user->id}",
            now()->addMinutes(5),
            fn () => $this->computeSummary($user)
        );
    }

    private function computeSummary(User $user): array
    {
        $month = now()->month;
        $year  = now()->year;

        // ── Finance ───────────────────────────────────────────────────────────
        $transactions = \App\Modules\Finance\Models\FinancialTransaction::query()
            ->where('user_id', $user->id)
            ->whereYear('transaction_date', $year)
            ->whereMonth('transaction_date', $month)
            ->get();

        $income  = $transactions->where('type->value', 'income')->sum('amount_minor');
        $expense = $transactions->where('type->value', 'expense')->sum('amount_minor');
        $balance = $income - $expense;

        // Budget remaining
        $budget = \App\Modules\Finance\Models\Budget::query()
            ->where('user_id', $user->id)
            ->where('is_active', true)
            ->first();

        $budgetRemaining = $budget
            ? ($budget->amount_minor - $transactions->where('type->value', 'expense')->sum('amount_minor'))
            : 0;

        // ── Productivity ──────────────────────────────────────────────────────
        $todayActivities = \App\Modules\Productivity\Models\Activity::query()
            ->where('user_id', $user->id)
            ->whereDate('date', today())
            ->get();

        $deadlines = \App\Modules\Productivity\Models\Activity::query()
            ->where('user_id', $user->id)
            ->whereDate('date', '>', today())
            ->whereDate('date', '<=', today()->addDays(7))
            ->where('status', '!=', 'selesai')
            ->count();

        // ── Library ───────────────────────────────────────────────────────────
        $activeBook = \App\Modules\Library\Models\Book::query()
            ->where('user_id', $user->id)
            ->where('status', 'sedang_dibaca')
            ->latest('last_read_at')
            ->first();

        $pagesThisMonth = \App\Modules\Library\Models\ReadingSession::query()
            ->where('user_id', $user->id)
            ->whereYear('started_at', $year)
            ->whereMonth('started_at', $month)
            ->sum('pages_read');

        // ── Steps ─────────────────────────────────────────────────────────────
        $todaySteps = \App\Modules\Productivity\Models\StepRecord::query()
            ->where('user_id', $user->id)
            ->whereDate('record_date', today())
            ->value('steps') ?? 0;

        $stepsTarget = \App\Modules\Productivity\Models\StepTarget::query()
            ->where('user_id', $user->id)
            ->value('daily_target') ?? 10000;

        return [
            // Finance
            'balance'          => $balance,
            'income'           => $income,
            'expense'          => $expense,
            'budget_remaining' => $budgetRemaining,

            // Productivity
            'today_activities'   => $todayActivities->count(),
            'completed_today'    => $todayActivities->where('status', 'selesai')->count(),
            'upcoming_deadlines' => $deadlines,

            // Library
            'active_book'      => $activeBook,
            'pages_this_month' => $pagesThisMonth,
            'reading_target'   => 600,

            // Steps
            'today_steps'      => $todaySteps,
            'steps_target'     => $stepsTarget,
            'steps_percentage' => $stepsTarget > 0 ? min(100, round($todaySteps / $stepsTarget * 100)) : 0,

            // Notifications
            'unread_notifications' => $user->unreadNotifications()->count(),
        ];
    }

    public function getRecentTransactions(User $user, int $limit = 5): \Illuminate\Database\Eloquent\Collection
    {
        return \App\Modules\Finance\Models\FinancialTransaction::query()
            ->where('user_id', $user->id)
            ->with(['category', 'account'])
            ->latest('transaction_date')
            ->limit($limit)
            ->get();
    }

    public function getTodayActivities(User $user): \Illuminate\Database\Eloquent\Collection
    {
        return \App\Modules\Productivity\Models\Activity::query()
            ->where('user_id', $user->id)
            ->whereDate('date', today())
            ->with('category')
            ->orderBy('start_time')
            ->get();
    }

    public function invalidate(User $user): void
    {
        Cache::forget("dashboard_summary_{$user->id}");
    }
}
