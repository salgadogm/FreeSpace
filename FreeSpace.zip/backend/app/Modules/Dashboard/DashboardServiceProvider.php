<?php

namespace App\Modules\Dashboard;

use Illuminate\Support\ServiceProvider;

class DashboardServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(
            Services\DashboardSummaryService::class,
            Services\DashboardSummaryService::class
        );
    }

    public function boot(): void
    {
        //
    }
}
