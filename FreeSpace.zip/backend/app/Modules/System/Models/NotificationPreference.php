<?php

namespace App\Modules\System\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NotificationPreference extends Model
{
    use HasFactory;

    protected $table = 'notification_preferences';

    protected $fillable = [
        'user_id',
        'in_app_enabled', 'email_enabled', 'browser_enabled',
        'quiet_hours_enabled', 'quiet_start', 'quiet_end',
        'budget_approaching', 'budget_threshold', 'budget_exceeded',
        'recurring_transaction', 'due_date_reminder', 'ai_draft_ready',
        'activity_reminder', 'activity_deadline',
        'journal_reminder', 'journal_reminder_time',
        'bible_reminder', 'bible_reminder_time',
        'steps_reminder', 'steps_reminder_time',
        'reading_plan_reminder', 'book_unread_reminder',
        'toefl_reminder', 'interview_reminder', 'ats_result_ready',
        'new_device_login', 'failed_login', 'backup_success', 'backup_failed', 'app_update',
    ];

    protected function casts(): array
    {
        return [
            'in_app_enabled'        => 'boolean',
            'email_enabled'         => 'boolean',
            'browser_enabled'       => 'boolean',
            'quiet_hours_enabled'   => 'boolean',
            'budget_approaching'    => 'boolean',
            'budget_exceeded'       => 'boolean',
            'recurring_transaction' => 'boolean',
            'due_date_reminder'     => 'boolean',
            'ai_draft_ready'        => 'boolean',
            'activity_reminder'     => 'boolean',
            'activity_deadline'     => 'boolean',
            'journal_reminder'      => 'boolean',
            'bible_reminder'        => 'boolean',
            'steps_reminder'        => 'boolean',
            'reading_plan_reminder' => 'boolean',
            'book_unread_reminder'  => 'boolean',
            'toefl_reminder'        => 'boolean',
            'interview_reminder'    => 'boolean',
            'ats_result_ready'      => 'boolean',
            'new_device_login'      => 'boolean',
            'failed_login'          => 'boolean',
            'backup_success'        => 'boolean',
            'backup_failed'         => 'boolean',
            'app_update'            => 'boolean',
        ];
    }

    public function user() { return $this->belongsTo(User::class); }
}
