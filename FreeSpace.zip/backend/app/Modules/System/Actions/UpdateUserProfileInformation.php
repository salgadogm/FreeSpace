<?php
namespace App\Modules\System\Actions;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Fortify\Contracts\UpdatesUserProfileInformation;
class UpdateUserProfileInformation implements UpdatesUserProfileInformation {
    public function update($user, array $input): void {
        Validator::make($input, ['name' => ['required','string','max:255'], 'email' => ['required','string','email','max:255',Rule::unique('users')->ignore($user->id)]])->validate();
        $user->forceFill(['name' => $input['name'], 'email' => $input['email']])->save();
    }
}
