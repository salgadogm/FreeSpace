<?php

namespace App\Modules\System;

use Illuminate\Support\ServiceProvider;

class SystemServiceProvider extends ServiceProvider
{
    public function register(): void {}
    public function boot(): void {}
}
