<?php

namespace App\Modules\Accounting\Models;

use App\Models\User;
use App\Shared\Enums\JournalEntryStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Custom Double-Entry Accounting Engine.
 *
 * Invariants enforced at app level:
 * 1. Posted entries are IMMUTABLE.
 * 2. Corrections → new reversing entry via ReverseJournalEntryAction.
 * 3. Balance check before posting.
 * 4. Closed period blocks new entries.
 */
class JournalEntry extends Model
{
    use HasFactory, LogsActivity;

    protected $table = 'journal_entries';

    protected $fillable = [
        'user_id', 'period_id', 'entry_number', 'entry_date', 'description',
        'reference', 'status', 'reversed_by', 'source', 'transaction_id',
        'ai_request_id', 'posted_at', 'posted_by',
    ];

    protected function casts(): array
    {
        return [
            'entry_date' => 'date',
            'posted_at'  => 'datetime',
            'status'     => JournalEntryStatus::class,
        ];
    }

    // ── Relationships ─────────────────────────────────────────────────────────
    public function user()   { return $this->belongsTo(User::class); }
    public function period() { return $this->belongsTo(AccountingPeriod::class); }
    public function lines()  { return $this->hasMany(JournalLine::class); }

    public function reversedByEntry()
    {
        return $this->belongsTo(JournalEntry::class, 'reversed_by');
    }

    // ── Balance check ─────────────────────────────────────────────────────────
    public function isBalanced(): bool
    {
        $debit  = $this->lines->sum('debit_amount_minor');
        $credit = $this->lines->sum('credit_amount_minor');
        return $debit === $credit && $debit > 0;
    }

    public function totalDebit(): int
    {
        return $this->lines->sum('debit_amount_minor');
    }

    public function totalCredit(): int
    {
        return $this->lines->sum('credit_amount_minor');
    }

    // ── Activity log ──────────────────────────────────────────────────────────
    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['status', 'posted_at', 'posted_by'])
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs();
    }
}
