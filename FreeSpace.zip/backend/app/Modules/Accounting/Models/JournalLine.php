<?php
namespace App\Modules\Accounting\Models;
use Illuminate\Database\Eloquent\Model;
class JournalLine extends Model {
    protected $table = 'journal_lines';
    protected $fillable = ['journal_entry_id','account_id','debit_amount_minor','credit_amount_minor','description'];
    protected function casts(): array { return ['debit_amount_minor' => 'integer', 'credit_amount_minor' => 'integer']; }
    public function entry() { return $this->belongsTo(JournalEntry::class, 'journal_entry_id'); }
    public function account() { return $this->belongsTo(ChartOfAccounts::class, 'account_id'); }
}
