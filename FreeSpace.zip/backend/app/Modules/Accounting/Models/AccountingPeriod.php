<?php
namespace App\Modules\Accounting\Models;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
class AccountingPeriod extends Model {
    protected $table = 'accounting_periods';
    protected $fillable = ['user_id','name','start_date','end_date','status','locked_at','closed_at'];
    protected function casts(): array { return ['start_date' => 'date', 'end_date' => 'date', 'locked_at' => 'datetime', 'closed_at' => 'datetime']; }
    public function user() { return $this->belongsTo(User::class); }
    public function entries() { return $this->hasMany(JournalEntry::class, 'period_id'); }
    public function isClosed(): bool { return $this->status === 'closed'; }
    public function isOpen(): bool { return $this->status === 'open'; }
}
