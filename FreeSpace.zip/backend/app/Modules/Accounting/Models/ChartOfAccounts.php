<?php
namespace App\Modules\Accounting\Models;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
class ChartOfAccounts extends Model {
    protected $table = 'chart_of_accounts';
    protected $fillable = ['user_id','code','name','type','normal_balance','is_active','is_system','sort_order'];
    protected function casts(): array { return ['is_active' => 'boolean', 'is_system' => 'boolean']; }
    public function user() { return $this->belongsTo(User::class); }
    public function journalLines() { return $this->hasMany(JournalLine::class, 'account_id'); }
}
