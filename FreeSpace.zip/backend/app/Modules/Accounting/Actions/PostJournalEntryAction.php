<?php

namespace App\Modules\Accounting\Actions;

use App\Modules\Accounting\Models\JournalEntry;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Spatie\Activitylog\Facades\Activity;

/**
 * Posts a draft journal entry.
 * A posted entry is IMMUTABLE — corrections must use ReverseJournalEntryAction.
 */
class PostJournalEntryAction
{
    public function execute(JournalEntry $entry, User $user): JournalEntry
    {
        if ($entry->status !== 'draft') {
            throw new \DomainException("Only draft entries can be posted. Entry #{$entry->entry_number} is '{$entry->status}'.");
        }

        if (! $entry->isBalanced()) {
            $debit  = $entry->lines->sum('debit_amount_minor');
            $credit = $entry->lines->sum('credit_amount_minor');
            throw new \DomainException(
                "Journal entry #{$entry->entry_number} is not balanced. Debit: {$debit}, Credit: {$credit}."
            );
        }

        if ($entry->period?->status === 'closed') {
            throw new \DomainException("Accounting period '{$entry->period->name}' is closed. Cannot post journal entries.");
        }

        DB::transaction(function () use ($entry, $user) {
            $entry->update([
                'status'    => 'posted',
                'posted_at' => now(),
                'posted_by' => $user->id,
            ]);

            activity()
                ->causedBy($user)
                ->performedOn($entry)
                ->withProperties([
                    'entry_number' => $entry->entry_number,
                    'debit_total'  => $entry->lines->sum('debit_amount_minor'),
                ])
                ->log('journal_posted');
        });

        return $entry->fresh();
    }
}
