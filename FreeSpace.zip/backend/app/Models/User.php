<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Fortify\TwoFactorAuthenticatable;
use Spatie\Activitylog\Traits\CausesActivity;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasFactory, Notifiable, TwoFactorAuthenticatable, CausesActivity;

    protected $fillable = [
        'name',
        'email',
        'password',
        'language',
        'timezone',
        'theme',
        'density',
        'text_size',
        'date_format',
        'time_format',
        'currency',
        'number_format',
        'sidebar_behavior',
        'animations_enabled',
        'high_contrast',
        'reduce_motion',
        'large_click_area',
        'keyboard_focus',
        'avatar_path',
        'last_login_at',
        'last_login_ip',
        'last_login_device',
        'last_login_browser',
    ];

    protected $hidden = [
        'password',
        'remember_token',
        'two_factor_secret',
        'two_factor_recovery_codes',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at'             => 'datetime',
            'last_login_at'                 => 'datetime',
            'password'                      => 'hashed',
            'animations_enabled'            => 'boolean',
            'high_contrast'                 => 'boolean',
            'reduce_motion'                 => 'boolean',
            'large_click_area'              => 'boolean',
            'keyboard_focus'                => 'boolean',
        ];
    }

    // ── Relationships ─────────────────────────────────────────────────────────
    public function financialAccounts()
    {
        return $this->hasMany(\App\Modules\Finance\Models\FinancialAccount::class);
    }

    public function transactions()
    {
        return $this->hasMany(\App\Modules\Finance\Models\FinancialTransaction::class);
    }

    public function budgets()
    {
        return $this->hasMany(\App\Modules\Finance\Models\Budget::class);
    }

    public function activities()
    {
        return $this->hasMany(\App\Modules\Productivity\Models\Activity::class);
    }

    public function journals()
    {
        return $this->hasMany(\App\Modules\Productivity\Models\DailyJournal::class);
    }

    public function books()
    {
        return $this->hasMany(\App\Modules\Library\Models\Book::class);
    }

    public function cvDocuments()
    {
        return $this->hasMany(\App\Modules\Career\Models\CvDocument::class);
    }

    public function notificationPreferences()
    {
        return $this->hasOne(\App\Modules\System\Models\NotificationPreference::class);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    public function isIndonesian(): bool
    {
        return $this->language === 'id';
    }

    public function preferredLocale(): string
    {
        return $this->language ?? 'id';
    }

    public function getFormattedCurrencyAttribute(): string
    {
        return $this->currency ?? 'IDR';
    }
}
