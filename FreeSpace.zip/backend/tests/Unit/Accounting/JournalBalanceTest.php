<?php

use App\Modules\Accounting\Actions\PostJournalEntryAction;
use App\Modules\Accounting\Models\JournalEntry;
use App\Models\User;

test('journal entry with equal debit and credit is balanced', function () {
    $entry = JournalEntry::make(['user_id' => 1, 'entry_number' => 'JE-001', 'status' => 'draft']);
    $entry->setRelation('lines', collect([
        (object) ['debit_amount_minor' => 120000, 'credit_amount_minor' => 0],
        (object) ['debit_amount_minor' => 0, 'credit_amount_minor' => 120000],
    ]));

    expect($entry->isBalanced())->toBeTrue();
});

test('journal entry with unequal debit and credit is not balanced', function () {
    $entry = JournalEntry::make(['status' => 'draft']);
    $entry->setRelation('lines', collect([
        (object) ['debit_amount_minor' => 120000, 'credit_amount_minor' => 0],
        (object) ['debit_amount_minor' => 0, 'credit_amount_minor' => 100000],
    ]));

    expect($entry->isBalanced())->toBeFalse();
});

test('posting an unbalanced entry throws an exception', function () {
    $user  = User::factory()->make(['id' => 1]);
    $entry = JournalEntry::make(['status' => 'draft', 'user_id' => 1, 'entry_number' => 'JE-001']);
    $entry->setRelation('lines', collect([
        (object) ['debit_amount_minor' => 100000, 'credit_amount_minor' => 0],
        (object) ['debit_amount_minor' => 0, 'credit_amount_minor' => 50000],
    ]));

    expect(fn () => (new PostJournalEntryAction())->execute($entry, $user))
        ->toThrow(\DomainException::class, 'not balanced');
});

test('posting a draft entry with balanced lines succeeds', function () {
    $user  = User::factory()->create();
    $entry = JournalEntry::factory()->create([
        'user_id' => $user->id,
        'status'  => 'draft',
    ]);

    // Add balanced lines
    $entry->lines()->createMany([
        ['account_id' => 1, 'debit_amount_minor' => 120000, 'credit_amount_minor' => 0],
        ['account_id' => 2, 'debit_amount_minor' => 0,      'credit_amount_minor' => 120000],
    ]);

    (new PostJournalEntryAction())->execute($entry->fresh(['lines']), $user);

    expect($entry->fresh()->status)->toBe('posted');
});

test('a posted entry cannot be posted again', function () {
    $user  = User::factory()->make(['id' => 1]);
    $entry = JournalEntry::make(['status' => 'posted', 'entry_number' => 'JE-001']);
    $entry->setRelation('lines', collect([]));

    expect(fn () => (new PostJournalEntryAction())->execute($entry, $user))
        ->toThrow(\DomainException::class, "Only draft entries");
});

test('money is never stored as float', function () {
    $amount = 1200000; // Rp12,000.00 stored as minor unit
    expect($amount)->toBeInt();
    expect($amount / 100)->toBe(12000.0); // conversion only for display
});
