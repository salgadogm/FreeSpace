<?php

/*
|--------------------------------------------------------------------------
| Test Case
|--------------------------------------------------------------------------
*/

uses(Tests\TestCase::class)->in('Feature', 'Livewire');
uses(Tests\TestCase::class)->in('Unit');

/*
|--------------------------------------------------------------------------
| Expectations
|--------------------------------------------------------------------------
*/

expect()->extend('toBeIndonesianRupiah', function () {
    return $this->toMatch('/^Rp[\d.,]+$/');
});

expect()->extend('toBePositiveInteger', function () {
    return $this->toBeInt()->toBeGreaterThan(0);
});

/*
|--------------------------------------------------------------------------
| Functions
|--------------------------------------------------------------------------
*/

function demoUser(): \App\Models\User
{
    return \App\Models\User::factory()->create([
        'name'     => 'Test User',
        'email'    => 'test@freespace.app',
        'language' => 'id',
    ]);
}

function authenticateAs(\App\Models\User $user = null): \App\Models\User
{
    $user ??= demoUser();
    test()->actingAs($user);
    return $user;
}
