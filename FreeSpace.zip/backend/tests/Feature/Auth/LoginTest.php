<?php

use App\Models\User;

test('login page renders', function () {
    $response = $this->get('/login');
    $response->assertOk();
    $response->assertSeeText('Masuk ke Akun');
});

test('authenticated user is redirected from login', function () {
    $user = User::factory()->create();
    $this->actingAs($user)->get('/login')->assertRedirect('/');
});

test('user can login with valid credentials', function () {
    $user = User::factory()->create([
        'password' => bcrypt('password123!'),
    ]);

    $response = $this->post('/login', [
        'email'    => $user->email,
        'password' => 'password123!',
    ]);

    $this->assertAuthenticated();
    $response->assertRedirect('/');
});

test('user cannot login with invalid credentials', function () {
    $user = User::factory()->create();

    $this->post('/login', [
        'email'    => $user->email,
        'password' => 'wrong-password',
    ]);

    $this->assertGuest();
});

test('login is rate limited after 5 attempts', function () {
    $user = User::factory()->create();

    foreach (range(1, 5) as $_) {
        $this->post('/login', [
            'email'    => $user->email,
            'password' => 'wrong',
        ]);
    }

    $response = $this->post('/login', [
        'email'    => $user->email,
        'password' => 'wrong',
    ]);

    $response->assertStatus(429);
});

test('authenticated user can access dashboard', function () {
    $user = User::factory()->create();
    $this->actingAs($user)->get('/dashboard')->assertOk();
});

test('unauthenticated user cannot access dashboard', function () {
    $this->get('/dashboard')->assertRedirect('/login');
});

test('user can logout', function () {
    $user = User::factory()->create();

    $this->actingAs($user)
        ->post('/logout')
        ->assertRedirect('/login');

    $this->assertGuest();
});
