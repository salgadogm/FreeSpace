# MIGRATION MATRIX — FreeSpace React → Laravel 13

Generated: July 2026  
Purpose: Maps every legacy React component/page to its Laravel equivalent.

## Status Legend
- ✅ Complete
- 🔄 In Progress
- ⏳ Pending

---

## Global Layout & Navigation

| Legacy React File | Legacy Component | Target Laravel | Status |
|---|---|---|---|
| `src/app/App.tsx` | `Sidebar` | `resources/views/components/layouts/app.blade.php` | ✅ |
| `src/app/App.tsx` | `MenuAccordion` | `resources/views/components/navigation/sidebar-group.blade.php` | ✅ |
| `src/app/App.tsx` | `NavItem` | `resources/views/components/navigation/sidebar-item.blade.php` | ✅ |
| `src/app/App.tsx` | `SubItem` | `resources/views/components/navigation/sidebar-child.blade.php` | ✅ |
| `src/app/App.tsx` | `TopBar` | Inline in `layouts/app.blade.php` | ✅ |
| `src/app/App.tsx` | `AIPanel` | `app/Modules/System/Livewire/AiPanel.php` | ⏳ |
| `src/app/App.tsx` | `ShareModal` | Inline Alpine in `layouts/app.blade.php` | ✅ |
| `src/app/App.tsx` | `UserProfileMenu` | Inline in `layouts/app.blade.php` | ✅ |
| `src/app/App.tsx` | Language toggle (`t()` fn) | Blade `auth()->user()->language` + session | ✅ |

---

## Pages → Livewire Components

| React Page ID | React File | Livewire Class | Blade View | Status |
|---|---|---|---|---|
| `dashboard` | `DashboardFreeSpace.tsx` | `Dashboard\Livewire\DashboardPage` | `livewire/dashboard/dashboard-page.blade.php` | ✅ |
| `transaksi` | `TransaksiPage.tsx` | `Finance\Livewire\TransactionsPage` | `livewire/finance/transactions-page.blade.php` | ✅ |
| `budget` | `BudgetPage.tsx` | `Finance\Livewire\BudgetPage` | `livewire/finance/budget-page.blade.php` | ⏳ |
| `analisis` | `AnalisisPage.tsx` | `Finance\Livewire\AnalysisProjectionPage` | `livewire/finance/analysis-projection-page.blade.php` | ⏳ |
| `kondisi-keuangan` | `KondisiKeuanganPage.tsx` | `Finance\Livewire\FinancialConditionPage` | `livewire/finance/financial-condition-page.blade.php` | ⏳ |
| `investasi` | `InvestasiPage.tsx` | `Finance\Livewire\InvestmentsPage` | `livewire/finance/investments-page.blade.php` | ⏳ |
| `akuntansi` | `AkuntansiPage.tsx` | `Accounting\Livewire\AccountingPage` | `livewire/accounting/accounting-page.blade.php` | ⏳ |
| `spt` | `SPTPage.tsx` | `Finance\Livewire\PersonalTaxPage` | `livewire/finance/personal-tax-page.blade.php` | ⏳ |
| `produktivitas-aktivitas` | `ProduktivitasAktivitasPage.tsx` | `Productivity\Livewire\ActivitiesPage` | `livewire/productivity/activities-page.blade.php` | ⏳ |
| `jurnal` | `JurnalHarianPage.tsx` | `Productivity\Livewire\DailyJournalPage` | `livewire/productivity/daily-journal-page.blade.php` | ⏳ |
| `bible` | `BibleHarianPage.tsx` | `Productivity\Livewire\BibleDailyPage` | `livewire/productivity/bible-daily-page.blade.php` | ⏳ |
| `steps` | `StepsTrackerPage.tsx` | `Productivity\Livewire\StepsTrackerPage` | `livewire/productivity/steps-tracker-page.blade.php` | ⏳ |
| `koleksi` | `KoleksiBukuPage.tsx` | `Library\Livewire\BooksCollectionPage` | `livewire/library/books-collection-page.blade.php` | ⏳ |
| `baca-buku` | `BacaBukuPage.tsx` | `Library\Livewire\BookReaderPage` | `livewire/library/book-reader-page.blade.php` | ⏳ |
| `accounting-space` | `AccountingSpacePage.tsx` | `Library\Livewire\AccountingSpacePage` | `livewire/library/accounting-space-page.blade.php` | ⏳ |
| `cv-builder` | `CVBuilderPage.tsx` | `Career\Livewire\CvBuilderPage` | `livewire/career/cv-builder-page.blade.php` | ⏳ |
| `ats` | `ATSAnalyzerPage.tsx` | `Career\Livewire\AtsAnalyzerPage` | `livewire/career/ats-analyzer-page.blade.php` | ⏳ |
| `toefl` | `TOEFLTrainingPage.tsx` | `Career\Livewire\ToeflTrainingPage` | `livewire/career/toefl-training-page.blade.php` | ⏳ |
| `interview` | `InterviewSimulatorPage.tsx` | `Career\Livewire\InterviewSimulatorPage` | `livewire/career/interview-simulator-page.blade.php` | ⏳ |
| `history` | `HistoryPage.tsx` | `System\Livewire\HistoryPage` | `livewire/system/history-page.blade.php` | ⏳ |
| `preferensi` | `PreferensiPage.tsx` | `System\Livewire\PreferencesPage` | `livewire/system/preferences-page.blade.php` | ⏳ |
| `pengaturan-data` | `PengaturanDataPage.tsx` | `System\Livewire\DataSettingsPage` | `livewire/system/data-settings-page.blade.php` | ⏳ |
| `notifikasi-setting` | `NotifikasiSettingPage.tsx` | `System\Livewire\NotificationSettingsPage` | `livewire/system/notification-settings-page.blade.php` | ⏳ |
| `keamanan` | `KeamananDataPage.tsx` | `System\Livewire\SecurityDataPage` | `livewire/system/security-data-page.blade.php` | ⏳ |

---

## State Migration

| React Pattern | Laravel Equivalent |
|---|---|
| `useState()` local UI | Alpine `x-data` |
| `useState()` server-connected | Livewire public property |
| `useApp()` context | `auth()->user()` + session |
| `language` context | `auth()->user()->language` |
| `showToast()` | Livewire `$this->dispatch('toast')` → Alpine `$store.toast` |
| `page` routing state | Laravel named routes + `wire:navigate` |
| Mock data arrays | Eloquent + Seeders |

---

## Legacy Files to Remove (Phase 7)

After parity is verified:

```
src/app/App.tsx
src/app/components/*.tsx
src/app/services/
src/imports/pasted_text/ (keep migration docs)
node_modules/ (frontend)
package.json (root — React)
pnpm-workspace.yaml
Dockerfile.frontend
docker-compose.yml
nginx/
```

---

## Design Tokens Migration

| React Source | Laravel Target |
|---|---|
| `src/styles/theme.css` CSS variables | `resources/css/theme.css` |
| `App.tsx` palette constants (`P`, `GREEN`, etc.) | `resources/css/theme.css` CSS variables |
| Tailwind classes (all preserved) | Same Tailwind classes in Blade |
| `lucide-react` icons | Heroicons (Blade components) |
| `recharts` | ApexCharts via `resources/js/charts/apex-chart.ts` |
| React modal state | Alpine `x-data` + Livewire |
| React drawer | `resources/views/components/overlays/drawer.blade.php` |
