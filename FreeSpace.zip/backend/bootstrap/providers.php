<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\FortifyServiceProvider::class,

    // Module Service Providers
    App\Modules\Dashboard\DashboardServiceProvider::class,
    App\Modules\Finance\FinanceServiceProvider::class,
    App\Modules\Accounting\AccountingServiceProvider::class,
    App\Modules\Productivity\ProductivityServiceProvider::class,
    App\Modules\Library\LibraryServiceProvider::class,
    App\Modules\Career\CareerServiceProvider::class,
    App\Modules\AI\AIServiceProvider::class,
    App\Modules\System\SystemServiceProvider::class,
];
