<?php

use Illuminate\Support\Facades\Schedule;
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// ── Scheduled Tasks (cron: php artisan schedule:run every minute) ─────────────
Schedule::command('queue:work --stop-when-empty --max-jobs=50 --max-time=55')
    ->everyMinute()
    ->withoutOverlapping()
    ->name('process-queue');

Schedule::command('freespace:process-recurring-transactions')
    ->dailyAt('00:05')
    ->withoutOverlapping()
    ->name('recurring-transactions');

Schedule::command('freespace:send-activity-reminders')
    ->everyMinute()
    ->withoutOverlapping()
    ->name('activity-reminders');

Schedule::command('freespace:send-budget-alerts')
    ->twiceDaily(8, 20)
    ->name('budget-alerts');

Schedule::command('freespace:send-daily-digest')
    ->dailyAt('07:00')
    ->name('daily-digest');

Schedule::command('freespace:send-weekly-summary')
    ->weeklyOn(1, '08:00')
    ->name('weekly-summary');

Schedule::command('freespace:backup-user-data')
    ->dailyAt('02:00')
    ->withoutOverlapping()
    ->name('auto-backup');

Schedule::command('freespace:cleanup-temp-exports')
    ->dailyAt('03:00')
    ->name('cleanup-exports');

Schedule::command('freespace:cleanup-temp-ai-results')
    ->twiceDaily(6, 18)
    ->name('cleanup-ai-results');

Schedule::command('model:prune')
    ->daily()
    ->name('model-prune');
