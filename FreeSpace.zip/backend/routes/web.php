<?php

use Illuminate\Support\Facades\Route;

// ── Auth (Fortify handles POST routes automatically) ─────────────────────────
Route::middleware('guest')->group(function () {
    Route::get('/login',          fn () => view('auth.login'))->name('login');
    Route::get('/register',       fn () => view('auth.register'))->name('register');
    Route::get('/forgot-password', fn () => view('auth.forgot-password'))->name('password.request');
    Route::get('/reset-password/{token}', fn ($token) => view('auth.reset-password', ['token' => $token]))->name('password.reset');
});

// ── Protected application routes ─────────────────────────────────────────────
Route::middleware(['auth', 'verified'])->group(function () {

    // Root → Dashboard
    Route::get('/', fn () => redirect()->route('dashboard'));

    // ── Dashboard ─────────────────────────────────────────────────────────────
    Route::get('/dashboard', \App\Modules\Dashboard\Livewire\DashboardPage::class)
        ->name('dashboard');

    // ── Finance ───────────────────────────────────────────────────────────────
    Route::prefix('keuangan')->name('finance.')->group(function () {
        Route::get('/transaksi',    \App\Modules\Finance\Livewire\TransactionsPage::class)->name('transactions.index');
        Route::get('/budget',       \App\Modules\Finance\Livewire\BudgetPage::class)->name('budgets.index');
        Route::get('/analisis',     \App\Modules\Finance\Livewire\AnalysisProjectionPage::class)->name('analysis.index');
        Route::get('/kondisi',      \App\Modules\Finance\Livewire\FinancialConditionPage::class)->name('condition.index');
        Route::get('/investasi',    \App\Modules\Finance\Livewire\InvestmentsPage::class)->name('investments.index');
        Route::get('/akuntansi',    \App\Modules\Accounting\Livewire\AccountingPage::class)->name('accounting.index');
        Route::get('/spt',          \App\Modules\Finance\Livewire\PersonalTaxPage::class)->name('tax.index');
    });

    // ── Productivity ──────────────────────────────────────────────────────────
    Route::prefix('produktivitas')->name('productivity.')->group(function () {
        Route::get('/aktivitas', \App\Modules\Productivity\Livewire\ActivitiesPage::class)->name('activities.index');
        Route::get('/jurnal',    \App\Modules\Productivity\Livewire\DailyJournalPage::class)->name('journal.index');
        Route::get('/bible',     \App\Modules\Productivity\Livewire\BibleDailyPage::class)->name('bible.index');
        Route::get('/steps',     \App\Modules\Productivity\Livewire\StepsTrackerPage::class)->name('steps.index');
    });

    // ── Library ───────────────────────────────────────────────────────────────
    Route::prefix('perpustakaan')->name('library.')->group(function () {
        Route::get('/koleksi',          \App\Modules\Library\Livewire\BooksCollectionPage::class)->name('books.index');
        Route::get('/baca',             \App\Modules\Library\Livewire\BookReaderPage::class)->name('reader.index');
        Route::get('/baca/{book}',      \App\Modules\Library\Livewire\BookReaderPage::class)->name('reader.show');
        Route::get('/ruang-akuntansi',  \App\Modules\Library\Livewire\AccountingSpacePage::class)->name('accounting-space.index');
    });

    // ── Career ────────────────────────────────────────────────────────────────
    Route::prefix('karier')->name('career.')->group(function () {
        Route::get('/pembuat-cv',       \App\Modules\Career\Livewire\CvBuilderPage::class)->name('cv.index');
        Route::get('/pembuat-cv/{cv}',  \App\Modules\Career\Livewire\CvEditorPage::class)->name('cv.edit');
        Route::get('/analisis-ats',     \App\Modules\Career\Livewire\AtsAnalyzerPage::class)->name('ats.index');
        Route::get('/latihan-toefl',    \App\Modules\Career\Livewire\ToeflTrainingPage::class)->name('toefl.index');
        Route::get('/simulator-wawancara', \App\Modules\Career\Livewire\InterviewSimulatorPage::class)->name('interview.index');
    });

    // ── System ────────────────────────────────────────────────────────────────
    Route::get('/riwayat', \App\Modules\System\Livewire\HistoryPage::class)->name('system.history.index');

    // ── Settings ──────────────────────────────────────────────────────────────
    Route::prefix('pengaturan')->name('settings.')->group(function () {
        Route::get('/preferensi',   \App\Modules\System\Livewire\PreferencesPage::class)->name('preferences');
        Route::get('/data',         \App\Modules\System\Livewire\DataSettingsPage::class)->name('data');
        Route::get('/notifikasi',   \App\Modules\System\Livewire\NotificationSettingsPage::class)->name('notifications');
        Route::get('/keamanan',     \App\Modules\System\Livewire\SecurityDataPage::class)->name('security-data');
    });

    // ── Profile ───────────────────────────────────────────────────────────────
    Route::get('/profil', \App\Modules\System\Livewire\ProfilePage::class)->name('profile.show');

    // ── Private file access (signed URLs) ─────────────────────────────────────
    Route::get('/media/{path}', \App\Http\Controllers\MediaController::class)
        ->where('path', '.*')
        ->name('media.serve')
        ->middleware('signed');

    // ── Export download ───────────────────────────────────────────────────────
    Route::get('/exports/{filename}', \App\Http\Controllers\ExportDownloadController::class)
        ->name('exports.download')
        ->middleware('signed');
});
